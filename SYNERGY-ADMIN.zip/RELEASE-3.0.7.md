# SYnerGY 3.0.7 — OpenAI Sol and Luna

Free active accounts default to `gpt-6-luna`. Active paid accounts and administrators default to `gpt-6.1-sol` and may also select Luna. Chat trials alone do not grant Sol. The server rechecks account, mode and model access immediately before inference. Existing sign-ins, subscriptions, payment records and tool permissions are preserved.

SYnerGY, OpenAI and Hybrid remain available. Hybrid records one account-aware plan, attempts its eligible OpenAI model and retains the local SYnerGY fallback. Legacy Gemini/OpenRouter credentials are not used by this Hybrid plan. Direct OpenAI selection does not silently change models. Conversations retain the selected provider and model when reopened. Existing privacy consent is retained; this release does not opt users into sharing private context.

The new OpenAI project key is kept only in ignored `secrets/openai.env`, outside images, archives and source-vault exports. Replacing the runtime credential does not revoke old keys at their providers. Global provider-key revocation is not performed by this release.

The existing cumulative administrator-controlled shared OpenAI allowance is preserved. Additional UTC-day account ceilings default to $0.10 for free accounts and $1.00 for paid/admin accounts. Operators can set `SYNERGY_OPENAI_FREE_DAILY_USD` and `SYNERGY_OPENAI_PAID_DAILY_USD`. Reservations are transactional and retained on ambiguous failures; definite provider rejection releases them. Every new ledger row records the actual model and account. Usage is conservatively calculated at standard short-context uncached rates: Sol $2 input / $10 output and Luna $0.10 input / $0.50 output per million tokens. This application allowance is not the OpenAI account balance. Funding and provider limits remain on OpenAI Platform.

No training occurred. The shared tools, scoped history and existing knowledge remain in use. This release does not introduce a new foundation-model training pipeline or claim all future blueprint features are implemented.

Validation includes real model discovery and one successful short Responses API request per model; 13 account-boundary, fallback, migration and accounting tests; the existing regression suite; Python and JavaScript syntax checks; staged Docker verification; and post-release health/account preservation checks. Two stale existing test expectations were corrected to the source's unchanged subscription price and extension version.

Deployment uses the existing pinned AWS host, private backup, image staging, guarded source hashes, additive usage migration and per-service image rollback. It does not provision new infrastructure or change the domain.
