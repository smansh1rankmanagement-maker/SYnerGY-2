"""Fail closed before release if this is not the approved AWS account/host/domain."""
import os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/backend'))
from deployment_policy import validate
from aws_status_bridge import identity

if __name__=='__main__':
    target=validate(identity(),os.environ.get('SYNERGY_PUBLIC_ORIGIN',''))
    print('Verified AWS deployment target: '+target['public_origin']+'; domain provider: Hostinger.')
