"""Operator-only 3.0.0 / SYNERGY 2.0 product release on the owner-pinned existing AWS host.
Keeps source, data, login guards and rollback; never called by generated code.
"""
import datetime,hashlib,json,os,shutil,sqlite3,subprocess,tarfile,time,urllib.request,zipfile
from pathlib import Path
os.umask(0o077)
live=Path('/srv/synergy');stage=Path('/srv/synergy-upgrade-3.0.0');data=Path('/var/lib/docker/volumes/synergy_app_data/_data')
evidence=Path('/srv/synergy-upgrade-3.0.0-upload');stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');backup=live/'backups'/('product-300-'+stamp)
oldcompose=['docker','compose','-f','compose.yaml','-f','compose.voice.yaml','-f','compose.connections.yaml']
compose=oldcompose
def run(args,**kw):return subprocess.run(args,check=True,**kw)
def names(root):return [line.split('  ',1)[1] for line in (root/'SHA256SUMS').read_text().splitlines()]+['SHA256SUMS']
def digest_tables():
 out={}
 with sqlite3.connect(data/'accounts.sqlite3') as c:
  for table in ['subscriptions','payment_orders','payment_refs','project_transfers','external_connections','external_clients']:
   rows=c.execute('SELECT * FROM '+table).fetchall();rows=sorted([json.dumps(r,default=lambda v:v.hex() if isinstance(v,bytes) else str(v),sort_keys=True) for r in rows]);out[table]={'count':len(rows),'sha256':hashlib.sha256('\n'.join(rows).encode()).hexdigest()}
 budget=data/'openai-usage.sqlite3'
 if budget.exists():
  with sqlite3.connect('file:'+str(budget)+'?mode=ro',uri=True) as c:
   for (table,) in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"):
    rows=sorted(json.dumps(r,default=str) for r in c.execute('SELECT * FROM "'+table.replace('"','""')+'"'))
    out['openai:'+table]={'count':len(rows),'sha256':hashlib.sha256('\n'.join(rows).encode()).hexdigest()}
 return out
run(['python3',str(stage/'deploy/verify_deployment_target.py')],env={**os.environ,'SYNERGY_PUBLIC_ORIGIN':'https://synergyai.1rank.in'})
assert json.loads((live/'RELEASE.json').read_text())['version']=='2.9.0', 'Refinement requires deployed 2.9.0'
newnames=names(stage)
for line in (stage/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1)
 if hashlib.sha256((stage/name).read_bytes()).hexdigest()!=expected:raise SystemExit('Candidate checksum mismatch: '+name)
release=json.loads((stage/'RELEASE.json').read_text());assert release['version']=='3.0.0'
# Release only the tested image, source and actual acceptance evidence.
for report in ['/srv/synergy-product300-tests/evidence.json','/srv/synergy-product300-ui/ui-evidence/evidence.json']:
 result=json.loads(Path(report).read_text());assert result['checks'],report
 assert all(x['passed'] for x in result['checks']),report
log=(evidence/'regression-final.log').read_text()
assert 'Ran 376 tests' in log and 'OK' in log and 'FAILED' not in log and 'skipped=' not in log
vault_hash=json.loads((stage/'source-vault/manifest.json').read_text())['archive_sha256']
assert hashlib.sha256((stage/'source-vault/synergy.zip').read_bytes()).hexdigest()==vault_hash
with sqlite3.connect(data/'accounts.sqlite3') as c:
 for table in ['beast_jobs','research_tasks','studio_jobs','lab_runs','website_jobs','media_jobs']:
  if not c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():continue
  active=c.execute('SELECT COUNT(*) FROM '+table+" WHERE state IN ('queued','running','cancelling')").fetchone()[0]
  if active:raise SystemExit('Active jobs detected in '+table+'; switch deferred')
# Legacy image/video jobs are file-backed, so check them as well.
for kind in ['image','video']:
 for job in (data/kind).glob('**/job.json'):
  if json.loads(job.read_text()).get('state') in {'queued','running'}:raise SystemExit('Active legacy '+kind+' job; switch deferred')
backup.mkdir(mode=0o700)
(evidence/'backup-path.txt').write_text(str(backup)+'\n')
oldnames=names(live)
with tarfile.open(backup/'source.tar.gz','w:gz') as t:
 for name in oldnames:
  p=live/name
  if p.is_file():t.add(p,arcname=name,recursive=False)
 t.add(live/'source-vault',arcname='source-vault')
shutil.copy2(live/'.env',backup/'production.env')
shutil.copytree(live/'secrets',backup/'secrets')
oldtables=digest_tables();(backup/'business-digests.json').write_text(json.dumps(oldtables))
run(['python3',str(stage/'deploy/auth_guard.py'),'snapshot',str(data/'accounts.sqlite3'),str(backup/'auth.json')])
run(['docker','stop','synergy-candidate300'],stdout=subprocess.DEVNULL)
stopped=False;changed=False
try:
 stopped=True
 run(oldcompose+['stop','app','media','beast','operations','lab','voice'],cwd=live)
 with (backup/'data.tar.gz').open('wb') as f:run(['python3',str(stage/'deploy/data_archive.py'),'backup'],stdout=f,env={**os.environ,'SYNERGY_DATA_DIR':str(data)})
 print('Consistent data backup complete',flush=True)
 for name in newnames:
  dst=live/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(stage/name,dst)
 shutil.copytree(stage/'source-vault',live/'source-vault',dirs_exist_ok=True)
 changed=True
 run(['python3',str(live/'deploy/install_aws_status_bridge.py')])
 updates={'SYNERGY_APP_IMAGE':'synergy-ai:3.0.0-final'}
 lines=[];seen=set()
 for line in (live/'.env').read_text().splitlines():
  k=line.split('=',1)[0]
  if k in updates:lines.append(k+'='+updates[k]);seen.add(k)
  else:lines.append(line)
 lines.extend(k+'='+v for k,v in updates.items() if k not in seen)
 (live/'.env').write_text('\n'.join(lines)+'\n');(live/'.env').chmod(0o600)
 run(['docker','run','--rm','--user','10001:10001','--entrypoint','/opt/web/bin/python','-v',str(data)+':/var/lib/synergy','synergy-ai:3.0.0-final','/opt/synergy/deploy/refresh_admin_source.py','--data','/var/lib/synergy','--vault','/opt/synergy/source-vault'])
 transferzip=evidence/'synergy-300-transfer.zip'
 with zipfile.ZipFile(transferzip,'w',zipfile.ZIP_DEFLATED) as z:
  for name in newnames:z.write(stage/name,name)
 # The operator-only refresh explicitly checks escrow ownership and pending state.
 run(['docker','run','--rm','--user','0:0','--entrypoint','/opt/web/bin/python','-v',str(data)+':/var/lib/synergy','-v',str(transferzip)+':/tmp/transfer.zip:ro','-v',str(backup)+':/backup','synergy-ai:3.0.0-final','/opt/synergy/deploy/update_pending_source.py','--data','/var/lib/synergy','--archive','/tmp/transfer.zip','--project-id','5d922f9946d84562ad43d28e39e53572','--expected-revision','16','--backup','/backup/pending-source'])
 # Preserve the existing provider policy and cumulative ledger exactly.
 for pattern in ['accounts.sqlite3*','openai-usage.sqlite3*']:
  for p in data.glob(pattern):os.chown(p,10001,10001)
 for p in (data/'source-bundles/5d922f9946d84562ad43d28e39e53572').rglob('*'):os.chown(p,10001,10001)
 run(['docker','run','--rm','--user','10001:10001','--entrypoint','/opt/web/bin/python','-v',str(data)+':/var/lib/synergy','synergy-ai:3.0.0-final','/opt/synergy/deploy/authorize_hostinger_domain.py','--data','/var/lib/synergy','--user-id','6','--domain','1rank.in'])
 run(compose+['up','-d','--no-deps','app','media','beast','operations','lab','voice'],cwd=live)
 for i in range(24):
  try:
   with urllib.request.urlopen('https://synergyai.1rank.in/healthz',timeout=5) as r:health=json.load(r)
   if health.get('version')=='3.0.0':break
  except Exception:pass
  time.sleep(5)
 else:raise RuntimeError('Public health check failed')
 for i in range(12):
  voicecheck=subprocess.run(['docker','exec','synergy-voice-1','python','-c',"import json,urllib.request;d=json.load(urllib.request.urlopen('http://127.0.0.1:8091/health',timeout=5));assert d.get('version')=='2.8.0' and d.get('ready')"],capture_output=True)
  if voicecheck.returncode==0:break
  time.sleep(3)
 else:raise RuntimeError('Voice service readiness check failed')
 run(['docker','exec','synergy-media-1','/opt/web/bin/python','/opt/synergy/deploy/healthcheck.py','media'])
 run(['python3',str(live/'deploy/auth_guard.py'),'verify',str(data/'accounts.sqlite3'),str(backup/'auth.json')])
 after=digest_tables()
 if after!=oldtables:raise RuntimeError('Business record guard failed')
 receipt={'version':'3.0.0','product_version':'SYNERGY 2.0','refinement':'pricing, Graphify, Observation and navigation','commit':os.environ['SYNERGY_RELEASE_COMMIT'],'deployed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'backup':str(backup),'health':health,'business_records_unchanged':True,'business_counts':{k:v['count'] for k,v in after.items()},'source_vault_sha256':vault_hash,'hosting_provider':'aws','domain_provider':'hostinger','openai_ledger_unchanged':True,'media_health_verified':True}
 (evidence/'production-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
except BaseException:
 if stopped:
  subprocess.run(['docker','stop','synergy-app-1','synergy-media-1','synergy-beast-1','synergy-operations-1','synergy-lab-1'],check=False,stdout=subprocess.DEVNULL)
  if changed:
   with tarfile.open(backup/'source.tar.gz') as t:t.extractall(live,filter='data')
   shutil.copy2(backup/'production.env',live/'.env')
  subprocess.run(oldcompose+['up','-d','--no-deps','app','media','beast','operations','lab','voice'],cwd=live,check=False)
 print('Deployment failed; previous source/configuration restart requested. Database backup retained.',flush=True)
 raise
