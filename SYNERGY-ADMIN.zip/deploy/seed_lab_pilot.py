"""Create and verify a private administrator pilot; no curriculum/training claim.
Run only during a guarded release with the Lab worker stopped.
"""
import argparse,copy,json,sqlite3,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/backend'))
from membership import Membership
from workspace import Workspace
from beast.store import Beast
from eternal_lab.store import Lab
from eternal_lab.templates import agent,tool,example,ref
from eternal_lab.proposals import propose,apply
from eternal_lab.runner import run_one

def seed(data,uid):
 data=Path(data);db=data/'accounts.sqlite3';m=Membership(db);m.admin(uid);lab=Lab(db,data,m.admin,Workspace(db),Beast(db,data/'beast'));checks=[]
 with lab.connect() as c:
  if c.execute("SELECT 1 FROM lab_audit WHERE action='verified_pilot_installed' AND actor=?",(uid,)).fetchone():return {'already_installed':True,'operator':uid}
  if c.execute("SELECT 1 FROM lab_runs WHERE state IN ('queued','running')").fetchone():raise ValueError('Finish or cancel existing Lab work before installing the pilot.')
 def execute(kind,obj,inputs=None):
  r=lab.submit(uid,kind,obj['id'],obj['version'],inputs)
  with lab.connect() as c:c.execute("UPDATE lab_runs SET state='running',started=? WHERE id=?",(time.time(),r['id']))
  run_one(data,r['id']);result=lab.run(uid,r['id'])
  if result['state']!='succeeded':raise RuntimeError(result['error'] or json.dumps(result['result']))
  checks.append({'kind':kind,'run_id':r['id'],'state':result['state'],'object_id':obj['id'],'version':obj['version']});return result
 def release(obj):return lab.action(uid,{'id':obj['id'],'version':obj['version'],'action':'activate','expected_version':obj['latest'],'reviewed_hash':obj['hash'],'note':'Release of the requested deterministic mathematics pilot after actual executable checks. This is engineering fixture validation, not subject-expert curriculum approval.'})
 for name in ['server-vedics','server-foundr']:
  server=lab.get(uid,name);execute('test',server);release(server)
 t=tool('VEDICS exact arithmetic · Lab pilot');t=lab.save(uid,'mcp_tool',t);execute('test',t);release(t)
 suite=example('evaluation');suite.update(name='Arithmetic pilot · four held-out checks',purpose='Check exact fraction and whole-number operations with the real VEDICS tool. Does not certify Class 10 curriculum or general model quality.');suite['tasks']=[{'prompt':'Explain '+expression,'check':'tool_answer','expected':expected} for expression,expected in [('1/2 + 1/4','3/4'),('3/4 - 1/2','1/4'),('100 + 200','300'),('-1/2 + 1/4','-1/4')]];suite['tasks'].append({'prompt':'Explain what a denominator means.','check':'blocked','expected':'No evaluated tool'});ev=lab.save(uid,'evaluation',suite);release(ev)
 spec=agent('VEDICS arithmetic pilot · manual');spec['tools']=[ref(t['id'])];spec['evaluation']=ref(ev['id']);spec['limits']['steps']=16;spec['allow_model_fallback']=False
 manual=lab.save(uid,'agent',spec);execute('evaluation',manual);release(manual)
 request=propose(lab,uid,'Create the same verified VEDICS arithmetic configuration through Beast.',configuration=spec,kind='agent');conversational=apply(lab,uid,request['id'],request['hash'])[0]
 assert manual['spec']==conversational['spec']
 renamed=copy.deepcopy(conversational['spec']);renamed['name']='VEDICS arithmetic pilot · Beast';conversational=lab.save(uid,'agent',renamed,conversational['id'],1,route='beast')
 execute('evaluation',conversational);release(conversational)
 childspec=copy.deepcopy(spec);childspec['name']='VEDICS arithmetic pilot · bounded child';childspec['parent']=ref(manual['id']);childspec['delegation']['depth']=0;child=lab.save(uid,'subagent',childspec);execute('evaluation',child);release(child)
 result=execute('agent',manual,{'prompt':'Explain 1/2 + 1/4','delegate_id':child['id']});assert json.loads(result['result']['text'])['answer']=='3/4'
 workflow=example('workflow');workflow.update(name='Daily capability review · draft',purpose='Review stale sources and candidate data, then evaluate the limited arithmetic pilot. No automatic training, external requests or publishing.',trigger='daily',enabled_schedule=True,schedule='09:00',agents=[ref(manual['id'])],steps=[{'action':'refresh_review'},{'action':'dataset_review'},{'action':'evaluate'}]);flow=lab.save(uid,'workflow',workflow)
 # The schedule remains draft for administrator review; structural testing is recorded.
 execute('test',flow)
 evidence={'operator':uid,'manual_agent':manual['id'],'conversational_agent':conversational['id'],'subagent':child['id'],'tool':t['id'],'evaluation':ev['id'],'draft_daily_review':flow['id'],'checks':checks,'weights_trained':False,'domain_expert_review':False,'scope':'Four exact arithmetic fixtures and a scope-boundary check only. No official board or full Class 10 coverage. Conceptual model answers remain unverified.'}
 with lab.connect() as c:lab.audit(c,uid,'verified_pilot_installed',detail=evidence)
 return evidence
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--operator',required=True,type=int);p.add_argument('--evidence',required=True);a=p.parse_args();result=seed(a.data,a.operator);Path(a.evidence).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
