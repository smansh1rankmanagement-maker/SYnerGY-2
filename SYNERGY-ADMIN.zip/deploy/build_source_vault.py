"""Build a curated read-only admin source archive; never sweep runtime folders."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import zipfile

FORBIDDEN = {'.git', '.aws', '.ssh', '__pycache__', 'node_modules', 'backups', 'secrets', 'local-data', 'source-vault'}


def allowed(name):
    path = PurePosixPath(name)
    return (not path.is_absolute() and bool(path.parts) and '..' not in path.parts and '\\' not in name
            and not any(p in FORBIDDEN or p.startswith('.env') and p not in {'.env.example', '.env.sample'} for p in path.parts)
            and path.suffix.lower() not in {'.pyc', '.sqlite', '.sqlite3', '.db', '.pem', '.key', '.p12', '.bundle'}
            and path.name not in {'mapping.json', 'credentials', 'config.json'} and not path.name.endswith('.mapping.json'))


def build(root, hashes, destination, version):
    root = Path(root).resolve()
    destination = Path(destination)
    if not isinstance(hashes, dict) or not 1 <= len(hashes) <= 1500:
        raise ValueError('Provide a reviewed filename-to-SHA256 manifest (1..1500 files).')
    files = []
    total = 0
    for name, digest in sorted(hashes.items()):
        if not allowed(name):
            raise ValueError('Non-distributable path: ' + name)
        path = root
        for part in PurePosixPath(name).parts:
            path = path/part
            if path.is_symlink():
                raise ValueError('Symlinks are not distributable: ' + name)
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != digest:
            raise ValueError('Source changed after review: ' + name)
        total += len(raw)
        if total > 128*1024*1024:
            raise ValueError('Source archive exceeds 128 MiB.')
        files.append((name, raw, digest))
    destination.mkdir(parents=True, exist_ok=True)
    archive = destination/'synergy.zip'
    partial = destination/'synergy.zip.partial'
    metadata = []
    with zipfile.ZipFile(partial, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw, digest in files:
            info = zipfile.ZipInfo('synergy/'+name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, raw)
            metadata.append({'id': hashlib.sha256(name.encode()).hexdigest(), 'path': name, 'size': len(raw), 'sha256': digest})
    partial.replace(archive)
    manifest = {'folder': 'synergy', 'version': version, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': metadata, 'excluded': ['production configuration and secrets', 'accounts, sessions and payment databases', 'user files', 'model weights', 'generated private mappings', 'git history and dependencies']}
    (destination/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps({'folder': 'synergy', 'files': len(files), 'source_bytes': total, 'zip_bytes': archive.stat().st_size, 'archive_sha256': manifest['archive_sha256']}))
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument('--manifest', type=Path)
    inputs.add_argument('--checksums', type=Path, help='reviewed SHA256SUMS file from the release')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--version', required=True)
    args = parser.parse_args()
    try:
        if args.manifest:
            hashes = json.loads(args.manifest.read_text())
        else:
            hashes = {}
            for line in args.checksums.read_text().splitlines():
                digest, name = line.split('  ', 1)
                if len(digest) != 64 or any(x not in '0123456789abcdef' for x in digest) or name in hashes:
                    raise ValueError('Invalid checksum manifest.')
                hashes[name] = digest
            name = str(args.checksums.resolve().relative_to(args.source.resolve()))
            hashes[name] = hashlib.sha256(args.checksums.read_bytes()).hexdigest()
        build(args.source, hashes, args.output, args.version)
    except (OSError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
