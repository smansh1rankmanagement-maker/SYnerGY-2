"""Operator-only domain approval. Run only for a user/domain explicitly authorised by its owner."""
import argparse,os,sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',type=Path,required=True);p.add_argument('--user-id',type=int,required=True);p.add_argument('--domain',required=True);a=p.parse_args()
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/backend'))
from connections.store import Connections
c=Connections(a.data/'accounts.sqlite3',a.data/'connections','https://synergyai.1rank.in');c.authorise_hostinger_domain(a.user_id,a.domain)
print('Authorised exact domain: '+a.domain+' for account '+str(a.user_id)+'. No subdomains or other Hostinger operations were granted.')
