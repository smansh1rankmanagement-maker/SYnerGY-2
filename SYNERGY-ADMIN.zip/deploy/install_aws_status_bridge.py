"""Install only on the existing /srv/synergy EC2 host as its administrator.
No IAM modification, credentials export, infrastructure creation or spending.
"""
import os,shutil,subprocess
from pathlib import Path
if os.geteuid()!=0:raise SystemExit('Run as root on the existing EC2 host.')
root=Path('/srv/synergy')
if Path(__file__).resolve().parent!=root/'deploy':raise SystemExit('Install the reviewed source under /srv/synergy first.')
status=root/'runtime-status';status.mkdir(mode=0o755,exist_ok=True);status.chmod(0o755)
for name in ['synergy-aws-status.service','synergy-aws-status.timer']:
 shutil.copy2(root/'deploy'/name,Path('/etc/systemd/system')/name)
subprocess.run(['systemctl','daemon-reload'],check=True)
subprocess.run(['systemctl','enable','--now','synergy-aws-status.timer'],check=True)
subprocess.run(['systemctl','start','synergy-aws-status.service'],check=True)
print('Status timer installed. Include compose.connections.yaml when starting the application.')
