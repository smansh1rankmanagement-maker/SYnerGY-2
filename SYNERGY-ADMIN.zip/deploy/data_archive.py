"""Stream an offline application-data backup. The caller stops all writers first."""
import argparse, os, tarfile, sys
from pathlib import Path, PurePosixPath

def backup(root, output):
    with tarfile.open(fileobj=output,mode='w|gz') as tar:
        for path in sorted(root.rglob('*')):
            if path.is_symlink() or not path.is_file():continue
            if path.name in {'worker.lock'} or 'worker-tmp' in path.parts or 'node_modules' in path.parts or 'npm-cache' in path.parts:continue
            tar.add(path,arcname=str(path.relative_to(root)),recursive=False)

def restore(root, source):
    if any(root.iterdir()):raise ValueError('Restore requires an empty data volume. Keep the original volume for rollback.')
    with tarfile.open(fileobj=source,mode='r|gz') as tar:
        for item in tar:
            p=PurePosixPath(item.name)
            if p.is_absolute() or '..' in p.parts or item.issym() or item.islnk() or not item.isfile():raise ValueError('Unsafe archive entry.')
            target=root/str(p);target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
            source_file=tar.extractfile(item)
            if source_file is None:raise ValueError('Unreadable archive entry.')
            with target.open('xb') as out:
                for chunk in iter(lambda:source_file.read(1024*1024),b''):out.write(chunk)
            target.chmod(0o600)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['backup','restore']);a=p.parse_args()
    root=Path(os.environ.get('SYNERGY_DATA_DIR','/var/lib/synergy'));root.mkdir(parents=True,exist_ok=True);os.umask(0o077)
    if a.action=='backup':backup(root,sys.stdout.buffer)
    else:restore(root,sys.stdin.buffer)
