"""Refresh pristine admin copies only; retain every previous revision and archive."""
import argparse,base64,hashlib,json,os,shutil,sys,time,zipfile
from pathlib import Path,PurePosixPath
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/backend'))
from beast.store import Beast
from beast.safety import record,bytes_of,BINARY
from admin_source import SourceVault
from admin_workspace import AdminWorkspace
p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--vault',type=Path,required=True);a=p.parse_args()
b=Beast(a.data/'accounts.sqlite3',a.data/'beast');v=SourceVault(a.vault);w=AdminWorkspace(b,v);cat=v.catalog();out=[]
with b.connect() as c:users=[r[0] for r in c.execute('SELECT user_id FROM admin_source_workspaces')]
for uid in users:
 meta,project=w.project(uid)
 if meta['manifest']['archive_sha256']==cat['archive_sha256']:continue
 base=b.root/'admin-sources'/str(uid)/'base.zip'
 if hashlib.sha256(base.read_bytes()).hexdigest()!=meta['manifest']['archive_sha256']:raise SystemExit('Base archive integrity failure')
 with zipfile.ZipFile(base) as old:
  pristine=set(project['files'])==set(meta['manifest']['editable_paths']) and all(bytes_of(value)==old.read('synergy/'+name) for name,value in project['files'].items())
 if not pristine or any(j['state'] in {'queued','running','awaiting_review'} for j in project['jobs']):out.append({'account_id':uid,'state':'preserved_modified_or_busy'});continue
 files={};excluded=[]
 with zipfile.ZipFile(v.root/'synergy.zip') as z:
  for f in cat['files']:
   raw=z.read('synergy/'+f['path']);name=f['path']
   try:files[name]=record(name,{'encoding':'base64','content':base64.b64encode(raw).decode()} if PurePosixPath(name).suffix.lower() in BINARY else raw.decode('utf-8-sig'))
   except (ValueError,UnicodeError) as exc:excluded.append({'path':name,'reason':str(exc)})
 backup=base.with_name('base-'+str(project['revision'])+'-'+str(int(time.time()))+'.zip');shutil.copyfile(base,backup)
 manifest={'version':cat['version'],'archive_sha256':cat['archive_sha256'],'editable_paths':list(files),'excluded':excluded}
 try:
  with b.connect() as c:
   c.execute('BEGIN IMMEDIATE');rev=b.revision(c,project['id'],project['revision'],files,'Refresh pristine copy to '+cat['version'])
   c.execute('UPDATE admin_source_workspaces SET manifest=? WHERE user_id=?',(json.dumps(manifest),uid))
   temp=base.with_suffix('.partial');shutil.copyfile(v.root/'synergy.zip',temp);temp.chmod(0o600);temp.replace(base)
 except BaseException:shutil.copyfile(backup,base);raise
 out.append({'account_id':uid,'revision':rev,'state':'pristine_copy_refreshed','old_revision_preserved':project['revision']})
print(json.dumps(out))
