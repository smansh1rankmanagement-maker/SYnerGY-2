import json, os, sqlite3, sys, time, urllib.request
from pathlib import Path
from urllib.parse import urlsplit
mode=sys.argv[1]
if mode=='app':
    origin=os.environ.get('SYNERGY_PUBLIC_ORIGIN','http://127.0.0.1:8090')
    req=urllib.request.Request('http://127.0.0.1:8090/healthz',headers={'Host':urlsplit(origin).netloc})
    with urllib.request.urlopen(req,timeout=3) as r:
        assert json.load(r)['status']=='ok'
else:
    db=Path(os.environ.get('SYNERGY_DATA_DIR','/var/lib/synergy'))/'accounts.sqlite3'
    table={'beast':'beast_worker','operations':'ops_worker','lab':'lab_heartbeat','media':'media_worker'}[mode]
    with sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True,timeout=2) as c:
        row=c.execute('SELECT * FROM '+table).fetchone()
        assert row and time.time()-float(row[1])<120, 'Worker heartbeat is stale'
