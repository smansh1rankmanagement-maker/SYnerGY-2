"""Guarded in-place OpenAI model upgrade; preserves credentials and account data."""
import datetime,hashlib,json,os,pathlib,shutil,sqlite3,subprocess,time,urllib.request
LIVE=pathlib.Path('/srv/synergy')
STAGE=pathlib.Path('/srv/synergy-openai-3.0.7')
UPLOAD=pathlib.Path('/srv/synergy-openai-3.0.7-upload')
DATA=pathlib.Path('/var/lib/docker/volumes/synergy_app_data/_data')
IMAGE='synergy-ai:openai-3.0.7'
COMPOSE=['docker','compose','-f','compose.yaml','-f','compose.voice.yaml','-f','compose.connections.yaml']
SERVICES=['app','operations','beast','lab']
def run(args,**kw):return subprocess.run(args,check=True,**kw)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def records():
 with sqlite3.connect('file:'+str(DATA/'accounts.sqlite3')+'?mode=ro',uri=True) as c:
  out={}
  for table in ['users','subscriptions','payment_orders','payment_refs','project_transfers','external_connections','external_clients']:
   if c.execute("SELECT 1 FROM sqlite_master WHERE name=?",(table,)).fetchone():
    rows=sorted(json.dumps(r,default=lambda v:v.hex() if isinstance(v,bytes) else str(v)) for r in c.execute('SELECT * FROM '+table))
    out[table]={'count':len(rows),'sha256':hashlib.sha256('\n'.join(rows).encode()).hexdigest()}
  return out
manifest=json.loads((UPLOAD/'overlay-manifest.json').read_text())
assert json.loads((LIVE/'RELEASE.json').read_text())['version']=='3.0.6','Baseline version changed'
for name,item in manifest.items():
 p=LIVE/name
 if item['before'] is not None:assert p.is_file() and sha(p)==item['before'],'Live file changed: '+name
 assert sha(STAGE/name)==item['after'],'Candidate file changed: '+name
checks=json.loads((UPLOAD/'test-summary.json').read_text())
assert checks['focused_ok'] and checks['regression_ok'],'Candidate checks have not passed'
with sqlite3.connect(DATA/'accounts.sqlite3') as c:
 for table in ['research_tasks','beast_jobs','studio_jobs','lab_runs','website_jobs','media_jobs']:
  if c.execute("SELECT 1 FROM sqlite_master WHERE name=?",(table,)).fetchone():
   assert not c.execute('SELECT count(*) FROM '+table+" WHERE state IN ('queued','running','cancelling')").fetchone()[0],'Active jobs: '+table
backup=LIVE/'backups'/('openai307-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));backup.mkdir(mode=0o700)
old_env=(LIVE/'.env').read_bytes();(backup/'production.env').write_bytes(old_env);(backup/'production.env').chmod(0o600)
keyfile=LIVE/'secrets/openai.env'
if keyfile.exists():shutil.copy2(keyfile,backup/'openai.env');(backup/'openai.env').chmod(0o600)
for name in manifest:
 p=LIVE/name
 if p.exists():dst=backup/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
shutil.copytree(LIVE/'source-vault',backup/'source-vault')
# Reuse each service's exact image during rollback; the previous app and workers differ.
prior={}
for name in SERVICES:
 value=json.loads(subprocess.check_output(['docker','inspect','synergy-'+name+'-1']))[0]
 prior[name]={'image':value['Config']['Image'],'id':value['Image']}
(backup/'prior-images.json').write_text(json.dumps(prior))
run(COMPOSE+['stop',*SERVICES],cwd=LIVE)
before=records()
with sqlite3.connect(DATA/'accounts.sqlite3') as c,sqlite3.connect(backup/'accounts.sqlite3') as dest:c.backup(dest)
(backup/'accounts.sqlite3').chmod(0o600)
try:
 for name in manifest:
  p=LIVE/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(STAGE/name,p)
 shutil.copytree(STAGE/'source-vault',LIVE/'source-vault',dirs_exist_ok=True)
 replacement=(UPLOAD/'new-openai.env').read_bytes()
 assert replacement.startswith(b'OPENAI_API_KEY=sk-') and replacement.count(b'\n')==1
 keyfile.write_bytes(replacement);keyfile.chmod(0o600)
 settings={'SYNERGY_APP_IMAGE':IMAGE,'SYNERGY_ALLOW_OPENAI':'1','SYNERGY_OPENAI_MODEL':'gpt-6.1-sol'}
 lines=old_env.decode().splitlines()
 output=[]
 for line in lines:
  key=line.split('=',1)[0]
  if key in settings:output.append(key+'='+settings.pop(key))
  elif key=='OPENAI_API_KEY':continue
  else:output.append(line)
 output.extend(k+'='+v for k,v in settings.items())
 (LIVE/'.env').write_text('\n'.join(output)+'\n');(LIVE/'.env').chmod(0o600)
 # Additive ledger schema migration. Historical rows keep their original Sol cost.
 run(['docker','run','--rm','--entrypoint','/opt/web/bin/python','-e','SYNERGY_DATA_DIR=/var/lib/synergy','-v',str(DATA)+':/var/lib/synergy',IMAGE,'-c',"import sys;sys.path.insert(0,'/opt/synergy/app/backend');import openai_budget;print('Ledger migration completed') if openai_budget.status() else None"])
 run(COMPOSE+['up','-d','--no-deps',*SERVICES],cwd=LIVE)
 health=None
 for _ in range(45):
  try:
   with urllib.request.urlopen('https://synergyai.1rank.in/healthz',timeout=5) as r:health=json.load(r)
   if health.get('version')=='3.0.7':break
  except Exception:pass
  time.sleep(2)
 else:raise RuntimeError('Live health verification failed')
 assert records()==before,'Account or business records changed; inspect private backup'
 receipt={'version':'3.0.7','health':health,'backup':str(backup),'accounts_and_business_preserved':True,'account_counts':{k:v['count'] for k,v in before.items()},'image':IMAGE,'openai_models':['gpt-6.1-sol','gpt-6-luna'],'previous_openai_credential_replaced':True,'provider_key_revocation_performed':False,'shared_budget_preserved':True}
 (UPLOAD/'deployment-receipt.json').write_text(json.dumps(receipt,indent=2))
 (UPLOAD/'new-openai.env').unlink(missing_ok=True);(UPLOAD/'transfer-private.pem').unlink(missing_ok=True)
 print(json.dumps(receipt))
except BaseException:
 for name,item in manifest.items():
  saved=backup/name;dst=LIVE/name
  if saved.exists():shutil.copy2(saved,dst)
  elif item['before'] is None:dst.unlink(missing_ok=True)
 shutil.copytree(backup/'source-vault',LIVE/'source-vault',dirs_exist_ok=True)
 (LIVE/'.env').write_bytes(old_env)
 if (backup/'openai.env').exists():shutil.copy2(backup/'openai.env',keyfile)
 override=backup/'rollback-images.yaml';override.write_text('services:\n'+''.join('  '+name+':\n    image: '+info['image']+'\n' for name,info in prior.items()))
 run(COMPOSE+['-f',str(override),'up','-d','--no-deps',*SERVICES],cwd=LIVE)
 raise
