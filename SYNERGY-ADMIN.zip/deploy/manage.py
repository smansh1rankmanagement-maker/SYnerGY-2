"""Explicit Linux deployment operations. Docker access required; never buys services."""
import argparse, datetime, json, os, shutil, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser();p.add_argument('--gpu',action='store_true');sub=p.add_subparsers(dest='action',required=True)
    install=sub.add_parser('install');install.add_argument('--models',action='store_true');install.add_argument('--accept-model-licenses',action='store_true')
    models=sub.add_parser('models');models.add_argument('--accept-model-licenses',action='store_true');models.add_argument('--only',choices=['all','chat','media'],default='all')
    sub.add_parser('status');sub.add_parser('backup');sub.add_parser('stop');sub.add_parser('start')
    a=p.parse_args();os.chdir(ROOT);os.umask(0o077)
    cmd=['docker','compose','-f','compose.yaml']+(['-f','compose.voice.yaml'] if (ROOT/'compose.voice.yaml').exists() else [])+(['-f','compose.gpu.yaml'] if a.gpu else [])
    def run(args,**kwargs):return subprocess.run(cmd+args,check=True,**kwargs)
    if a.action in {'models','install'} and (a.action=='models' or a.models) and not a.accept_model_licenses:p.error('Read docs/MODELS.md and pass --accept-model-licenses.')
    if a.action=='install':
        subprocess.run([sys.executable,'deploy/preflight.py'],check=True)
        run(['build','app','voice']);run(['run','--rm','--no-deps','voice-setup']);run(['up','-d','ollama'])
        if a.models:run(['run','--rm','--no-deps','model-setup','models','--accept-model-licenses'])
        run(['up','-d','--no-build','--wait','--wait-timeout','180','app','operations','beast','caddy','voice'])
        receipt=run(['images','--format','json'],capture_output=True,text=True)
        (ROOT/'deployment-images.json').write_text(receipt.stdout)
        print('Services started. Open your configured HTTPS domain. Complete docs/ACCEPTANCE.md before wider use.')
    elif a.action=='models':
        run(['up','-d','ollama']);run(['run','--rm','--no-deps','model-setup','models','--accept-model-licenses','--only',a.only])
    elif a.action=='status':run(['ps'])
    elif a.action=='start':run(['up','-d','--no-build','--wait','--wait-timeout','180','app','operations','beast','caddy','voice'])
    elif a.action=='stop':run(['stop','caddy','app','operations','beast','ollama','voice'])
    elif a.action=='backup':
        folder=ROOT/'backups'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');folder.mkdir(parents=True,mode=0o700)
        # Preserve exactly which services were running before the backup.
        active=run(['ps','--services','--status','running'],capture_output=True,text=True).stdout.split()
        writers=[s for s in ['app','operations','beast'] if s in active]
        if writers:run(['stop','-t','30',*writers])
        target=folder/'application-data.tar.gz';partial=folder/'application-data.partial'
        try:
            with partial.open('wb') as out:run(['run','--rm','--no-deps','-T','--entrypoint','/opt/web/bin/python','app','/opt/synergy/deploy/data_archive.py','backup'],stdout=out)
            partial.rename(target);shutil.copy2(ROOT/'.env',folder/'deployment.env');(folder/'deployment.env').chmod(0o600)
            print('Private backup created at '+str(folder)+'. It contains account data and deployment secrets. Keep it private.')
        finally:
            if writers:run(['start',*writers])

if __name__=='__main__':main()
