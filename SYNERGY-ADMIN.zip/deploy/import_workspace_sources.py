"""Operator-only import. Never exposed as a public remote-command endpoint."""
import argparse,base64,hashlib,json,sys,zipfile,re
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/backend'))
from workspace import Workspace
from beast.store import Beast
from beast.safety import record,BINARY
from source_bundles import SourceBundles
p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--username',required=True);p.add_argument('--archive',type=Path,required=True);p.add_argument('--name',required=True);p.add_argument('--kind',default='app');p.add_argument('--website',default='');a=p.parse_args();w=Workspace(a.data/'accounts.sqlite3');b=Beast(w.db,a.data/'beast');bundles=SourceBundles(w,b,a.data/'source-bundles')
with w.connect() as c:
 row=c.execute('SELECT id FROM users WHERE username=?',(a.username,)).fetchone()
 if not row:raise SystemExit('Owner account not found; no import was performed.')
 owner=row[0]
 prior=c.execute('SELECT id FROM work_projects WHERE user_id=? AND name=? AND archived=0',(owner,a.name)).fetchone()
 if prior:raise SystemExit('Project already exists; explicitly review a version update instead of overwriting it.')
# Distributed bundles must not contain production credentials.
with zipfile.ZipFile(a.archive) as z:
 for name in z.namelist():
  if name.endswith('/config.php') or name.startswith('.env') and name not in {'.env.example','.env.sample'}:
   if name=='cms-data/config.php':raise SystemExit('Sanitise the CMS credential file before import; preserve live credentials separately.')
files={};preserved=[];size=0
with zipfile.ZipFile(a.archive) as z:
 for i in z.infolist():
  if i.is_dir():continue
  name=i.filename;raw=z.read(i)
  try:
   if Path(name).suffix.lower() in BINARY:
    if len(raw)>200000 or size+len(raw)>8*1024*1024:raise ValueError('Large media retained in full source bundle.')
    v=record(name,{'encoding':'base64','content':base64.b64encode(raw).decode()})
   else:v=record(name,raw.decode('utf-8-sig'))
   files[name]=v;size+=len(raw)
  except (ValueError,UnicodeError):preserved.append(name)
meta={'archive':a.archive.name,'sha256':hashlib.sha256(a.archive.read_bytes()).hexdigest(),'editable_paths':list(files),'bundle_only_paths':preserved,'website':a.website,'origin':'Saved project source package supplied in this ChatGPT project. Conversation history and production secrets are not included.'}
readme='''# Project in SYnerGY\n\nUse the project header to keep chats and files together. Open code to inspect source, select the relevant files, then ask Beast for a focused change. Source revisions and checkpoints stay in this private account.\n\nThe full source download combines the original assets and bundle-only files with the latest edited source. It preserves deleted editable files as deletions.\n\nThis import does not copy a production database, change domain settings, reset passwords, or install a production deployment credential. The built-in preview is a static HTML/CSS design preview; PHP/MySQL and application builds use the package's documented toolchain. Changes to a source copy do not automatically update a live domain.\n'''
files['SYNERGY-PROJECT.md']=record('SYNERGY-PROJECT.md',readme)
source=b.create(owner,{'name':a.name,'brief':'Imported private source for maintenance. Preserve behaviour and existing authentication. Keep changes small, inspect diffs and verify actual tests before deployment. '+a.website,'files':files})
project=w.save_project(owner,{'name':a.name,'kind':a.kind,'beast_project_id':source['id'],'instructions':'This project contains the saved source for '+a.name+'. Use the linked Beast workspace for code changes. Current website: '+(a.website or 'not supplied')+'. Keep existing authentication and data. Never claim a source edit is deployed or a test executed without evidence.'})
bundles.attach(owner,project['id'],a.archive,meta)
chat=w.create_chat(owner,'Project source and next steps',project['id'],'beast');w.add(owner,chat['id'],'assistant','Your project source is saved here. '+str(len(files))+' files are editable in the code workspace. '+str(len(preserved))+' additional assets or restricted files remain in the full source ZIP. Existing live services and logins are unchanged.\n\nOpen code to inspect a file, or use Troubleshoot to report a focused issue. Follow the included setup instructions for executable previews and deployment.',{'beast_project_id':source['id']})
print(json.dumps({'project':project['name'],'project_id':project['id'],'beast_project_id':source['id'],'editable_files':len(files),'bundle_only_files':len(preserved),'sha256':meta['sha256']}))
