import os, sys
from pathlib import Path
os.umask(0o077)
data=Path(os.environ.get('SYNERGY_DATA_DIR','/var/lib/synergy'))
data.mkdir(parents=True,exist_ok=True,mode=0o700)
if not os.access(data,os.W_OK):raise SystemExit('The persistent data directory must be writable by UID 10001.')
mode=sys.argv[1] if len(sys.argv)>1 else 'app'
commands={
 'app':['/opt/web/bin/python','/opt/synergy/app/backend/server.py'],
 'operations':['/opt/web/bin/python','/opt/synergy/app/backend/operations/worker.py','--data',str(data)],
 'beast':['/opt/web/bin/python','/opt/synergy/app/backend/beast/worker.py','--data',str(data)],
 'lab':['/opt/web/bin/python','/opt/synergy/app/backend/eternal_lab/worker.py','--data',str(data)],
 'media':['/opt/web/bin/python','/opt/synergy/app/backend/media/worker.py','--data',str(data)],
 'models':['/opt/web/bin/python','/opt/synergy/deploy/setup_models.py'],
}
if mode not in commands:raise SystemExit('Unknown service mode.')
args=commands[mode]+sys.argv[2:]
os.execv(args[0],args)
