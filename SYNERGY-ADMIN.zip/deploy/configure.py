"""Create local deployment configuration; never overwrite secrets or provision services."""
import argparse, os, re
from pathlib import Path

def configure(root, domain, email, admin):
    domain=domain.strip().lower()
    if len(domain)>253 or not re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}',domain):
        raise ValueError('Use a DNS name only, for example ai.yourdomain.com.')
    if not re.fullmatch(r'[^\s@${}]+@[^\s@${}]+\.[^\s@${}]+',email):raise ValueError('Use a valid certificate contact email.')
    if not re.fullmatch(r'(?:[A-Za-z0-9_.-]{3,32}|[^\s@${}]+@[^\s@${}]+\.[^\s@${}]+)',admin):raise ValueError('Use the existing owner username or registration email.')
    target=root/'.env'
    if target.exists():raise FileExistsError('.env already exists. Edit it deliberately; it was not overwritten.')
    text=(root/'.env.example').read_text().replace('ai.yourdomain.com',domain).replace('owner@yourdomain.com',email).replace('SYNERGY_PLUGIN_ADMIN=owner','SYNERGY_PLUGIN_ADMIN='+admin)
    # Exclude example comments containing unneeded instructions.
    fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:f.write(text)
    secrets=root/'secrets';secrets.mkdir(exist_ok=True,mode=0o700)
    for name in ['openrouter-api-key','gemini-api-key']:
        p=secrets/name
        if not p.exists():p.touch(mode=0o400)
    return target

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--domain',required=True);p.add_argument('--email',required=True);p.add_argument('--admin',default='owner');a=p.parse_args()
    configure(Path(__file__).resolve().parents[1],a.domain,a.email,a.admin)
    print('Configuration created. Registration uses email and password. Provision the administrator separately with deploy/provision_admin.py; existing settings were not overwritten.')
