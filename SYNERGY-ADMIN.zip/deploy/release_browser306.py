"""Owner-authorised in-place browser upgrade. Run only after staged tests pass."""
import pathlib,json,hashlib,subprocess,sqlite3,shutil,datetime,time,urllib.request,os
live=pathlib.Path('/srv/synergy');stage=pathlib.Path('/srv/synergy-browser-3.0.6');data=pathlib.Path('/var/lib/docker/volumes/synergy_app_data/_data')
compose=['docker','compose','-f','compose.yaml','-f','compose.voice.yaml','-f','compose.connections.yaml']
def run(args,**kw):return subprocess.run(args,check=True,**kw)
def guard():
 with sqlite3.connect('file:'+str(data/'accounts.sqlite3')+'?mode=ro',uri=True) as c:
  out={}
  for table in ['users','subscriptions','payment_orders','payment_refs','project_transfers','external_connections','external_clients']:
   rows=sorted(json.dumps(r,default=str) for r in c.execute('SELECT * FROM '+table));out[table]=hashlib.sha256('\n'.join(rows).encode()).hexdigest()
  return out
assert json.loads((live/'RELEASE.json').read_text())['version']=='3.0.5','Baseline changed'
payload=json.loads((stage/'overlay-manifest.json').read_text())
for name,e in payload.items():
 p=live/name
 if e['before'] is not None:assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==e['before'],'Live file changed: '+name
 assert hashlib.sha256((stage/'overlay'/name).read_bytes()).hexdigest()==e['after']
logs=(stage/'tests.log').read_text();assert 'FAILED' not in logs and logs.count('\nOK')>=2,'Staged tests required'
with sqlite3.connect(data/'accounts.sqlite3') as c:
 for table in ['research_tasks','beast_jobs','studio_jobs','lab_runs','website_jobs','media_jobs']:
  if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():
   assert not c.execute('SELECT COUNT(*) FROM '+table+" WHERE state IN ('queued','running','cancelling')").fetchone()[0], 'Active jobs: '+table
backup=live/'backups'/('browser306-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));backup.mkdir(mode=0o700)
old=guard();old_env=(live/'.env').read_bytes();(backup/'production.env').write_bytes(old_env);(backup/'production.env').chmod(0o600)
for name in payload:
 p=live/name
 if p.exists():dst=backup/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
shutil.copytree(live/'source-vault',backup/'source-vault')
with sqlite3.connect(data/'accounts.sqlite3') as c,sqlite3.connect(backup/'accounts.sqlite3') as dst:c.backup(dst)
(backup/'accounts.sqlite3').chmod(0o600)
changed=False
try:
 for name in payload:
  dst=live/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(stage/'overlay'/name,dst)
 shutil.copytree(stage/'source-vault',live/'source-vault',dirs_exist_ok=True)
 lines=old_env.decode().splitlines();lines=[('SYNERGY_APP_IMAGE=synergy-ai:browser-3.0.6' if line.startswith('SYNERGY_APP_IMAGE=') else line) for line in lines]
 if not any(line.startswith('SYNERGY_APP_IMAGE=') for line in lines):lines.append('SYNERGY_APP_IMAGE=synergy-ai:browser-3.0.6')
 (live/'.env').write_text('\n'.join(lines)+'\n');changed=True
 run(compose+['up','-d','--no-deps','app'],cwd=live)
 for _ in range(30):
  try:
   with urllib.request.urlopen('https://synergyai.1rank.in/healthz',timeout=5) as r:h=json.load(r)
   if h.get('version')=='3.0.6':break
  except Exception:pass
  time.sleep(2)
 else:raise RuntimeError('Health check failed')
 assert old==guard(),'Account or business records changed during release; inspect backup'
 receipt={'version':'3.0.6','extension':'1.8.0','health':h,'backup':str(backup),'account_and_business_records_preserved':True,'browser_e2e':'pending Chrome reload and selected-tab test'}
 (stage/'deployment-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
except Exception:
 for name in payload:
  saved=backup/name
  if saved.exists():shutil.copy2(saved,live/name)
 shutil.copytree(backup/'source-vault',live/'source-vault',dirs_exist_ok=True)
 (live/'.env').write_bytes(old_env)
 if changed:run(compose+['up','-d','--no-deps','app'],cwd=live)
 raise
