"""Private pre-upgrade digests; output contains counts, never credentials."""
import argparse,hashlib,json,sqlite3,time,os
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('action',choices=['snapshot','verify']);p.add_argument('database');p.add_argument('private_snapshot');a=p.parse_args();os.umask(0o077)
with sqlite3.connect(a.database) as c:
 users={str(r[0]):hashlib.sha256(json.dumps([x.hex() if isinstance(x,bytes) else x for x in r]).encode()).hexdigest() for r in c.execute('SELECT id,username,salt,password FROM users')}
 sessions={r[0]:list(r[1:]) for r in c.execute('SELECT token_hash,user_id,expires FROM sessions')}
state={'users':users,'sessions':sessions};path=Path(a.private_snapshot)
if a.action=='snapshot':
 if path.exists():raise SystemExit('Refusing to replace an existing snapshot.')
 path.write_text(json.dumps(state));path.chmod(0o600);print(json.dumps({'users_recorded':len(users),'sessions_recorded':len(sessions)}))
else:
 old=json.loads(path.read_text());u=all(users.get(k)==v for k,v in old['users'].items());live={k:v for k,v in old['sessions'].items() if v[1]>time.time()};s=all(sessions.get(k)==v for k,v in live.items());print(json.dumps({'preexisting_users':len(old['users']),'password_records_unchanged':u,'unexpired_sessions_checked':len(live),'sessions_unchanged':s}));raise SystemExit(0 if u and s else 1)
