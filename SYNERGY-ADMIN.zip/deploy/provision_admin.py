#!/usr/bin/env python3
"""Explicit, idempotent administrator provisioning. Secret arrives on stdin only.
Run inside the app container, pointing at its existing persistent database.
"""
import argparse,json,os,sqlite3,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'/'backend'))
from membership import Membership,password_value,derive

def provision(db,username,password,owner=None):
    password_value(password);salt=os.urandom(16)
    return provision_hash(db,username,salt,derive(password,salt),owner)

def provision_hash(db,username,salt,password_hash,owner=None):
    if not username or len(username)>254:raise ValueError('Choose an administrator username.')
    if not isinstance(salt,bytes) or len(salt)!=16 or not isinstance(password_hash,bytes) or len(password_hash)!=32:raise ValueError('Invalid scrypt hash input.')
    m=Membership(db)
    with m.connect() as c:
        c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT id,role FROM users WHERE username=? COLLATE NOCASE',(username,)).fetchone()
        if r:
            if r['role']!='admin':raise ValueError('An existing non-admin account has this username; no account was changed.')
            uid=r['id'];created=False
        else:
            uid=c.execute("INSERT INTO users(username,salt,password,role,account_state,created) VALUES(?,?,?,'admin','active',?)",(username,salt,password_hash,time.time())).lastrowid;created=True
            m.audit(c,uid,'administrator_provisioned',uid,{'existing_passwords_unchanged':True})
        if owner:
            row=c.execute('SELECT id FROM users WHERE username=?',(owner,)).fetchone()
            if not row:raise ValueError('The specified existing owner account was not found.')
            c.execute("UPDATE users SET role='admin' WHERE id=?",(row['id'],));m.audit(c,uid,'owner_administrator_granted',row['id'],{'password_unchanged':True})
    return {'created':created,'admin_id':uid,'owner_access_preserved':bool(owner)}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--db',type=Path,default=Path(os.environ.get('SYNERGY_DATA_DIR','/var/lib/synergy'))/'accounts.sqlite3');p.add_argument('--username',required=True);p.add_argument('--owner');p.add_argument('--scrypt-stdin',action='store_true',help='Read precomputed scrypt salt/hash JSON from stdin, never a command argument.');a=p.parse_args()
    if a.scrypt_stdin:
        value=json.load(sys.stdin);result=provision_hash(a.db,a.username,bytes.fromhex(value['salt']),bytes.fromhex(value['password_hash']),a.owner)
    else:result=provision(a.db,a.username,sys.stdin.readline().rstrip('\r\n'),a.owner)
    print(json.dumps(result))
