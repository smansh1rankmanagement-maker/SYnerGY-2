"""Operator-only source refresh for a quarantined, unapproved transfer.

Run with application writers stopped. Backups contain private data and must
remain outside any distributed source archive. This never approves access.
"""
import argparse,base64,hashlib,json,shutil,sqlite3,sys,time,zipfile
from pathlib import Path,PurePosixPath
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/backend'))
from workspace import Workspace
from beast.store import Beast
from beast.safety import record,validate_files,BINARY
from source_bundles import SourceBundles
from hosting import VERSION

def main():
 p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--archive',type=Path,required=True);p.add_argument('--project-id',required=True);p.add_argument('--expected-revision',type=int,required=True);p.add_argument('--backup',type=Path,required=True);a=p.parse_args()
 w=Workspace(a.data/'accounts.sqlite3');b=Beast(w.db,a.data/'beast');bundles=SourceBundles(w,b,a.data/'source-bundles')
 with w.connect() as c:
  transfer=c.execute('SELECT * FROM project_transfers WHERE project_id=?',(a.project_id,)).fetchone()
  if not transfer or transfer['state'] not in {'pending','revoked'}:raise SystemExit('Only an unapproved transfer can be refreshed with this command.')
  owner=transfer['escrow_owner'];project=w.project(owner,a.project_id);source=b.project(owner,project['beast_project_id'])
  if owner>=0 or source['revision']!=a.expected_revision:raise SystemExit('Owner or revision changed; review before retrying.')
 if a.archive.stat().st_size>300*1024*1024:raise SystemExit('Source archive exceeds 300 MB.')
 files={};preserved=[]
 with zipfile.ZipFile(a.archive) as z:
  if len(z.infolist())>1500 or sum(i.file_size for i in z.infolist())>500*1024*1024:raise SystemExit('Oversized source archive.')
  for i in z.infolist():
   if i.is_dir():continue
   n=PurePosixPath(i.filename)
   if n.is_absolute() or '..' in n.parts or '\\' in i.filename or (i.external_attr>>16)&0o170000==0o120000:raise SystemExit('Unsafe archive path.')
   if any(x in {'.git','.aws','.ssh','node_modules','__pycache__','accounts.sqlite3'} or x.startswith('.env') and x not in {'.env.example','.env.sample'} for x in n.parts):raise SystemExit('Private or dependency content is not distributable.')
   raw=z.read(i)
   try:
    value={'encoding':'base64','content':base64.b64encode(raw).decode()} if n.suffix.lower() in BINARY else raw.decode('utf-8-sig')
    files[i.filename]=record(i.filename,value)
   except (ValueError,UnicodeError):preserved.append(i.filename)
 validate_files(files)
 meta={'archive':a.archive.name,'sha256':hashlib.sha256(a.archive.read_bytes()).hexdigest(),'editable_paths':list(files),'bundle_only_paths':preserved,'website':'https://synergyai.1rank.in','origin':'Reviewed SYnerGY '+VERSION+' source release; no production database, secrets or model weights. Transfer remains subject to administrator email approval.'}
 a.backup.mkdir(parents=True,mode=0o700,exist_ok=False)
 with sqlite3.connect(w.db) as src,sqlite3.connect(a.backup/'accounts.sqlite3') as dst:src.backup(dst)
 folder=bundles.root/a.project_id;shutil.copy2(folder/'base.zip',a.backup/'base.zip')
 with w.connect() as c:
  old=c.execute('SELECT manifest FROM project_source_bundles WHERE project_id=?',(a.project_id,)).fetchone()[0]
 (a.backup/'manifest.json').write_text(old)
 temp=folder/'refresh.partial';shutil.copyfile(a.archive,temp);temp.chmod(0o600)
 try:
  with b.connect() as c:
   c.execute('BEGIN IMMEDIATE')
   t=c.execute('SELECT state,escrow_owner FROM project_transfers WHERE project_id=?',(a.project_id,)).fetchone()
   if t['state'] not in {'pending','revoked'} or t['escrow_owner']!=owner:raise RuntimeError('Transfer changed; no source updated.')
   revision=b.revision(c,source['id'],a.expected_revision,files,'SYnerGY '+VERSION+' deployed release')
   c.execute('UPDATE project_source_bundles SET manifest=?,created=? WHERE project_id=?',(json.dumps(meta),time.time(),a.project_id))
   temp.replace(folder/'base.zip')
 except BaseException:
  shutil.copy2(a.backup/'base.zip',folder/'base.zip')
  raise
 finally:temp.unlink(missing_ok=True)
 print(json.dumps({'project_id':a.project_id,'revision':revision,'previous_revision_preserved':a.expected_revision,'editable_files':len(files),'bundle_only_files':len(preserved),'sha256':meta['sha256'],'transfer_state':transfer['state']}))

if __name__=='__main__':main()
