"""Explicit, resumable setup of pinned local media weights and Ollama profiles."""
import argparse, hashlib, json, os, time, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA=Path(os.environ.get('SYNERGY_DATA_DIR','/var/lib/synergy'))
MODELS=Path(os.environ.get('SYNERGY_MODELS_DIR','/models'))
OLLAMA=os.environ.get('SYNERGY_OLLAMA_URL','http://ollama:11434').rstrip('/')

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def atomic(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2));temp.chmod(0o600);temp.replace(path)

def download(url,path,size=None,digest=None):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.is_file() and (size is None or path.stat().st_size==size) and (not digest or sha(path)==digest):return
    part=path.with_suffix(path.suffix+'.part')
    for attempt in range(3):
        try:
            print('Downloading '+path.name,flush=True)
            request=urllib.request.Request(url,headers={'User-Agent':'SYnerGY-model-setup/1.8.1'})
            with urllib.request.urlopen(request,timeout=90) as response,part.open('wb') as out:
                total=0
                for chunk in iter(lambda:response.read(1024*1024),b''):
                    total+=len(chunk)
                    if size and total>size:raise ValueError('Download is larger than the locked size: '+path.name)
                    out.write(chunk)
            if size and part.stat().st_size!=size:raise ValueError('Incomplete model download: '+path.name)
            if digest and sha(part)!=digest:raise ValueError('Model SHA256 mismatch: '+path.name)
            part.chmod(0o600);part.replace(path);return
        except Exception:
            part.unlink(missing_ok=True)
            if attempt==2:raise
            time.sleep(2**attempt)

def hf(group,folder):
    for f in group['files']:
        url='https://huggingface.co/'+group['model_id']+'/resolve/'+group['revision']+'/'+f['file']
        download(url,folder/f['file'],f.get('size'),f.get('sha256'))
    atomic(folder/'verified.json',{'model_id':group['model_id'],'revision':group['revision'],'files':[{'file':f['file'],'sha256':sha(folder/f['file'])} for f in group['files']],'verified_at':time.time()})

def api(path,body=None,timeout=600):
    req=urllib.request.Request(OLLAMA+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as resp:return json.load(resp)

def chat_setup():
    for attempt in range(30):
        try:api('/api/tags',timeout=2);break
        except OSError:
            if attempt==29:raise RuntimeError('Ollama did not start. Inspect the ollama service logs.')
            time.sleep(2)
    models=['qwen3:4b-instruct-2507-q4_K_M','qwen3:0.6b','qwen3-vl:2b-instruct']
    for model in models:
        print('Installing local chat model '+model,flush=True)
        req=urllib.request.Request(OLLAMA+'/api/pull',data=json.dumps({'model':model,'stream':True}).encode(),headers={'Content-Type':'application/json'})
        last=''
        with urllib.request.urlopen(req,timeout=600) as resp:
            for line in resp:
                event=json.loads(line)
                if event.get('error'):raise RuntimeError(event['error'])
                status=event.get('status','')
                if status!=last:print(status,flush=True);last=status
    for alias,base in [('aerny:v2.0',models[0]),('aerny-fast:v2.0',models[1]),('eternal:v1.0',models[0]),('eternal-fast:v1.0',models[1])]:
        api('/api/create',{'model':alias,'from':base,'system':('You are '+('ETERNAL' if alias.startswith('eternal') else 'Aerny 2.0')+' in SYnerGY AI. Answer clearly. Never claim actions or tests without tool evidence. You are a configured Qwen profile, not a newly trained foundation model.'),'parameters':{'temperature':0.4,'num_ctx':4096,'num_predict':768},'stream':False})
    tags=api('/api/tags')
    atomic(DATA/'model-installation.json',{'installed_at':time.time(),'models':tags.get('models',[]),'training_performed':False})
    answer=api('/api/chat',{'model':'aerny-fast:v2.0','stream':False,'think':False,'messages':[{'role':'user','content':'What is 2 + 2? Answer with the number only.'}],'options':{'num_predict':16}})
    text=answer.get('message',{}).get('content','').strip()
    if not text:raise RuntimeError('The local chat smoke test returned no text.')
    atomic(DATA/'model-smoke-test.json',{'time':time.time(),'model':'aerny-fast:v2.0','prompt':'What is 2 + 2? Answer with the number only.','reply':text,'transport_passed':True,'arithmetic_passed':text.rstrip('.')=='4'})
    if text.rstrip('.')!='4':print('Chat returned text, but the arithmetic check needs review.',flush=True)

def media_setup():
    lock=json.loads((ROOT/'app/backend/video_studio/models.lock.json').read_text())
    hf(lock['base'],MODELS/'epicrealism');hf(lock['motion'],MODELS/'motion')
    lcm=json.loads((ROOT/'app/backend/studio/models.lock.json').read_text())['fast_adapter']
    hf({'model_id':lcm['id'],'revision':lcm['revision'],'files':[{'file':lcm['filename'],'size':lcm['size'],'sha256':lcm['sha256']}]},MODELS/'lcm')
    atomic(DATA/'image/model.json',{'model_id':lock['base']['model_id'],'revision':lock['base']['revision'],'path':str(MODELS/'epicrealism'),'license':'creativeml-openrail-m'})
    print('Media model files verified. Run the image/video acceptance checks before inviting users.',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--accept-model-licenses',action='store_true');p.add_argument('--only',choices=['all','chat','media'],default='all');a=p.parse_args()
    if not a.accept_model_licenses:p.error('Read docs/MODELS.md, then pass --accept-model-licenses to download models onto your own machine.')
    os.umask(0o077);DATA.mkdir(parents=True,exist_ok=True)
    if a.only in {'all','chat'}:chat_setup()
    if a.only in {'all','media'}:media_setup()
