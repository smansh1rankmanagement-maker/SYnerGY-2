"""Owner-only AWS hosting status bridge. Runs on EC2; never exposes credentials.
Uses the existing instance profile for STS GetCallerIdentity only. No IAM changes.
"""
import datetime,hashlib,hmac,json,os,subprocess,urllib.request,xml.etree.ElementTree as ET
from pathlib import Path

def fetch(url,headers=None,method='GET',data=None):
    req=urllib.request.Request(url,data=data,headers=headers or {},method=method)
    with urllib.request.urlopen(req,timeout=6) as r:return r.read(1000000)
def identity():
    base='http://169.254.169.254/latest/'
    token=fetch(base+'api/token',{'X-aws-ec2-metadata-token-ttl-seconds':'60'},'PUT').decode()
    h={'X-aws-ec2-metadata-token':token};doc=json.loads(fetch(base+'dynamic/instance-identity/document',h))
    role=fetch(base+'meta-data/iam/security-credentials/',h).decode().strip()
    if not role or '/' in role or '\n' in role:raise ValueError('Unexpected instance profile metadata')
    credentials=json.loads(fetch(base+'meta-data/iam/security-credentials/'+role,h))
    region=doc['region'];host='sts.'+region+'.amazonaws.com';payload=b'Action=GetCallerIdentity&Version=2011-06-15'
    now=datetime.datetime.now(datetime.timezone.utc);amz=now.strftime('%Y%m%dT%H%M%SZ');date=amz[:8];scope=date+'/'+region+'/sts/aws4_request'
    headers={'content-type':'application/x-www-form-urlencoded; charset=utf-8','host':host,'x-amz-date':amz,'x-amz-security-token':credentials['Token']}
    names=';'.join(sorted(headers));canonical_headers=''.join(k+':'+headers[k]+'\n' for k in sorted(headers))
    canonical='POST\n/\n\n'+canonical_headers+'\n'+names+'\n'+hashlib.sha256(payload).hexdigest()
    signing='AWS4-HMAC-SHA256\n'+amz+'\n'+scope+'\n'+hashlib.sha256(canonical.encode()).hexdigest()
    key=('AWS4'+credentials['SecretAccessKey']).encode()
    for value in [date,region,'sts','aws4_request']:key=hmac.new(key,value.encode(),hashlib.sha256).digest()
    signature=hmac.new(key,signing.encode(),hashlib.sha256).hexdigest()
    headers['Authorization']='AWS4-HMAC-SHA256 Credential='+credentials['AccessKeyId']+'/'+scope+', SignedHeaders='+names+', Signature='+signature
    root=ET.fromstring(fetch('https://'+host+'/',headers,'POST',payload));ns={'s':'https://sts.amazonaws.com/doc/2011-06-15/'}
    account=root.findtext('.//s:Account',namespaces=ns);arn=root.findtext('.//s:Arn',namespaces=ns)
    if account!=doc['accountId']:raise ValueError('AWS identity mismatch')
    return {'account_id':account,'region':region,'instance_id':doc['instanceId'],'role_arn':arn,'verified':True,'method':'IMDSv2 + signed STS GetCallerIdentity'}
def main():
    import time
    target=Path('/srv/synergy/runtime-status/aws-status.json');target.parent.mkdir(mode=0o755,parents=True,exist_ok=True)
    result={'checked_at':time.time(),'scope':'Existing SYnerGY hosting identity and service health. No infrastructure mutations or billing permissions.'}
    try:result.update(identity())
    except Exception as e:result.update(verified=False,error='AWS identity check failed: '+type(e).__name__)
    health={}
    for name in ['synergy-app-1','synergy-beast-1','synergy-operations-1','synergy-lab-1','synergy-media-1']:
        r=subprocess.run(['docker','inspect','--format','{{json .State}}',name],capture_output=True,timeout=5)
        if r.returncode:health[name]='unavailable';continue
        state=json.loads(r.stdout);health[name]={'status':state['Status'],'health':state.get('Health',{}).get('Status','unknown')}
    result['services']=health
    tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps(result,indent=2)+'\n');tmp.chmod(0o644);os.replace(tmp,target)
if __name__=='__main__':main()
