"""Host preflight. No package installation, cloud provisioning or paid API calls."""
import json, platform, shutil, subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
errors=[]
if platform.system()!='Linux':errors.append('This deployment target is Linux, not macOS shared hosting.')
if platform.machine() not in {'x86_64','amd64'}:errors.append('The packaged media runtime targets Linux x86_64.')
if not (root/'.env').is_file():errors.append('Run deploy/configure.py first.')
if not shutil.which('docker'):errors.append('Install Docker Engine and the Compose plugin from docs.docker.com/engine/install/.')
else:
    for args in [['docker','info'],['docker','compose','config','--quiet']]:
        p=subprocess.run(args,cwd=root,capture_output=True,text=True)
        if p.returncode:errors.append('Check failed: '+' '.join(args)+'. Check Docker access and .env configuration.')
free=shutil.disk_usage(root).free//(1024**3)
print(json.dumps({'system':platform.system(),'architecture':platform.machine(),'free_disk_GiB':free,'errors':errors},indent=2))
if free<30:print('Space is low for container images, all models and outputs. Reserve at least 80 GB total for a small installation.')
sys.exit(bool(errors))
