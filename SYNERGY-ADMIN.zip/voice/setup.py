"""Populate the persistent voice cache once; inference uses offline files."""
import json, pathlib
from huggingface_hub import snapshot_download, model_info
root=pathlib.Path('/voice-models')
records=[]
for repo, dest, patterns in [
 ('Systran/faster-whisper-small',root/'whisper-small',None),
 ('hexgrad/Kokoro-82M',None,['config.json','kokoro-v1_0.pth','voices/am_michael.pt','voices/hm_omega.pt'])]:
 revision=model_info(repo).sha
 snapshot_download(repo,revision=revision,local_dir=dest,allow_patterns=patterns)
 # OpenJarvis/Kokoro requests the default branch; cache its resolved reference offline.
 if dest is None:
  ref=root/'hf'/'hub'/('models--'+repo.replace('/','--'))/'refs'/'main'
  ref.parent.mkdir(parents=True,exist_ok=True);ref.write_text(revision)
 records.append({'repository':repo,'revision':revision})
(root/'manifest.json').write_text(json.dumps({'openjarvis_commit':'324c9c3ac61bff07a0d99b715a7511dcd78600c4','models':records},indent=2))
print(json.dumps({'models_downloaded':records}))
