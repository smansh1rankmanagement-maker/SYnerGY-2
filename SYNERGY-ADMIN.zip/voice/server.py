"""Private OpenJarvis speech worker. SYnerGY owns authentication and chat."""
import io,json,os,re,threading,time,wave
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TRANSFORMERS_OFFLINE']='1'
import torch
torch.set_num_threads(2)
from recognition import Recognizer
from openjarvis.speech.kokoro_tts import KokoroTTSBackend
stt=Recognizer()
tts=KokoroTTSBackend(device='cpu',max_cached_pipelines=2)
gate=threading.Lock()
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def result(self,code,data,mime='application/json'):
  if isinstance(data,dict):data=json.dumps(data).encode()
  self.send_response(code);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def do_GET(self):
  if self.path!='/health':return self.result(404,{'detail':'Not found.'})
  ready=Path('/voice-models/manifest.json').is_file()
  self.result(200 if ready else 503,{'ready':ready,'engine':'OpenJarvis','commit':'324c9c3ac61bff07a0d99b715a7511dcd78600c4','stt':'Faster-Whisper small / CPU int8 / Silero VAD','version':'2.8.0','tts':'Kokoro-82M / CPU','languages':['en','hi'],'busy':gate.locked()})
 def do_POST(self):
  if self.path not in {'/transcribe','/speak'}:return self.result(404,{'detail':'Not found.'})
  if not gate.acquire(False):return self.result(429,{'detail':'Voice is busy. Try again shortly.'})
  try:
   size=int(self.headers.get('Content-Length','0'))
   if not 0<size<=8*1024*1024:raise ValueError('Use a recording under 8 MB.')
   data=self.rfile.read(size);started=time.monotonic()
   if self.path=='/transcribe':
    import av
    container=av.open(io.BytesIO(data));audio=container.streams.audio
    if not audio:raise ValueError('No audio found.')
    # Decode and check duration before passing bytes to the inference engine.
    samples=0
    for frame in container.decode(audio[0]):
     samples+=frame.samples/frame.sample_rate
     if samples>65:raise ValueError('Record up to 60 seconds at a time.')
    container.close()
    language=self.headers.get('X-Language','auto')
    if language not in {'auto','en','hi'}:raise ValueError('Choose English, Hindi or Auto.')
    out=stt.transcribe(data,language=language)
    self.result(200,{**out,'elapsed':round(time.monotonic()-started,2),'engine':'SYnerGY Jarvis / Faster-Whisper small + Silero VAD'})
   else:
    d=json.loads(data);text=d.get('text','')
    if not isinstance(text,str) or not 1<=len(text)<=1800:raise ValueError('Use 1–1,800 characters.')
    voice='hm_omega' if re.search(r'[\u0900-\u097f]',text) else 'am_michael'
    out=tts.synthesize(text,voice_id=voice,output_format='wav')
    if not out.audio:raise ValueError('No speech was produced.')
    self.result(200,out.audio,'audio/wav')
  except (ValueError,TypeError,json.JSONDecodeError):self.result(400,{'detail':'Could not read the audio or text. Record up to 60 seconds and try again.'})
  except Exception as exc:
   print('Voice failure:',type(exc).__name__,str(exc)[:300],flush=True)
   self.result(503,{'detail':'The local voice engine could not finish. You can continue typing and retry voice.'})
  finally:gate.release()
ThreadingHTTPServer(('0.0.0.0',8091),Handler).serve_forever()
