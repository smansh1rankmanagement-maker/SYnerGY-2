"""Local speech recognition, with silence filtering and review metadata.

Uses the existing licensed Faster-Whisper small weights. Confidence is an
uncalibrated model signal, not a guarantee of transcript accuracy.
"""
import io
import numpy as np
from faster_whisper import WhisperModel
from faster_whisper.audio import decode_audio

class Recognizer:
    def __init__(self, path='/voice-models/whisper-small'):
        self.path, self.model = path, None

    def transcribe(self, data, language='auto'):
        if language not in {'auto', 'en', 'hi'}:
            raise ValueError('Choose English, Hindi or Auto.')
        audio = decode_audio(io.BytesIO(data), sampling_rate=16000)
        duration = len(audio) / 16000
        if duration > 65:
            raise ValueError('Record up to 60 seconds at a time.')
        rms = float(np.sqrt(np.mean(audio * audio))) if len(audio) else 0
        empty = {'text': '', 'language': language, 'duration': round(duration, 2),
                 'needs_review': True, 'warning': 'No clear speech was detected. Check your microphone and try again.'}
        if duration < .25 or rms < .0005:
            return empty
        if self.model is None:
            self.model = WhisperModel(self.path, device='cpu', compute_type='int8', cpu_threads=2, local_files_only=True)
        segments, info = self.model.transcribe(
            audio, language=None if language == 'auto' else language,
            beam_size=5, temperature=0, condition_on_previous_text=False,
            vad_filter=True, vad_parameters={'min_silence_duration_ms': 500, 'speech_pad_ms': 250},
            word_timestamps=True, hallucination_silence_threshold=1.5,
        )
        segments = list(segments)
        segments = [s for s in segments if not (s.no_speech_prob > .6 and s.avg_logprob < -1)]
        text = ''.join(s.text for s in segments).strip()
        if not text:
            return {**empty, 'language': info.language}
        scores = [w.probability for s in segments for w in (s.words or [])]
        score = float(sum(scores) / len(scores)) if scores else 0.0
        review = bool(score < .8 or (language == 'auto' and info.language_probability < .65))
        return {'text': text, 'language': info.language, 'duration': round(duration, 2),
                'speech_seconds': round(info.duration_after_vad, 2),
                'word_confidence': round(score, 3), 'language_probability': round(float(info.language_probability), 3),
                'needs_review': review,
                'warning': 'Some words may be unclear. Review the transcript before sending.' if review else '',
                'confidence_note': 'Model estimate only; not verified transcription accuracy.'}
