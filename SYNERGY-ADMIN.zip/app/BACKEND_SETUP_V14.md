# SYnerGY v1.4 runtime

## Web and accounts

Run `python3 backend/server.py` with Python 3.10+ and `hashlib.scrypt` available. The Apple Command Line Tools Python on the tested Mac lacks scrypt; use its installed managed Python 3.12 runtime for the web server. No web framework packages are required.

Configuration:
- `SYNERGY_DATA_DIR`: private application data directory (accounts, knowledge, jobs).
- `SYNERGY_PORT`: default 8090, bound to loopback only.
- `SYNERGY_OLLAMA_MODEL`: default `aerny:v1.4`.
- `SYNERGY_INVITE_CODE`: optional; when set, registration requires the code. When unset, anyone with access to the local site can create an account.

Passwords use scrypt and per-user salts. Sessions use hashed tokens and HttpOnly/SameSite cookies. Job results, notes, conversations, plugins and skills are checked against the signed-in account. This standard-library development server must not be exposed directly to the internet.

## Ollama

With the named base model already installed, run `ollama create aerny:v1.4 -f backend/AeRny.Modelfile`. The tested Mac has a launch agent at `~/Library/LaunchAgents/in.1rank.synergy-v14.plist`, which starts the web server at login. Its runtime configuration is outside the source package. A desktop `SYnerGY AI.command` opens the local website. The app calls `http://127.0.0.1:11434/api/chat`. Chat, Work and Beast apply different instructions to the same profile. Knowledge notes provide bounded per-account retrieval, not weight training or autonomous browsing.

## Image

Reuse the verified environment in the previous AeRny installation. The deployed build copies it into Application Support/SYnerGY/runtime/v14-media so the background service does not depend on Downloads access. Set `SYNERGY_IMAGE_PYTHON` to its absolute Python path. Its environment root must contain `verified.json`. The tested environment has torch 2.2.2, diffusers 0.30.3, transformers 4.44.2, Pillow, Accelerate and Safetensors.

Copy the existing model manifest into `$SYNERGY_DATA_DIR/image/model.json`: it contains an absolute `path` to the complete epiCRealism local safetensors directory and `model_id` of `emilianJR/epiCRealism`. The pinned revision is listed below. The safety checker is required. No weights are downloaded during inference. Image rendering uses CPU and enlarges output for 1080p/4K export; the deployed enhancement uses the verified Real-ESRGAN general-x4v3 weights in `$SYNERGY_DATA_DIR/image/super_resolution`. Enhanced uses a 768×432 landscape render with 28 steps; Detail uses approximately 896×504 with 30 steps. The exported image combines super-resolution texture with the original render.

## CPU video

Set:
- `SYNERGY_VIDEO_ENGINE=animatediff`
- `SYNERGY_VIDEO_PYTHON`: existing image-environment Python.
- `SYNERGY_VIDEO_MODEL`: complete local epiCRealism SD1.5 directory.
- `SYNERGY_VIDEO_ADAPTER`: absolute path to `animatediff_lightning_4step_diffusers.safetensors`.
- `SYNERGY_VIDEO_STEPS=4`. Native size is selected by the request quality/aspect preset.
- `SYNERGY_VIDEO_BASE_NAME=epiCRealism (SD1.5)`.
- `PYTHONPATH`: isolated dependency directory containing imageio 2.36.0 and imageio-ffmpeg 0.5.1 (plus any existing necessary paths).

Download the motion adapter from the official ByteDance/AnimateDiff-Lightning repository at revision `027c893eec01df7330f5d4b733bc9485ee02e8b2`. Verify SHA-256 `8f3330914edd8fc2ee5659e6944323858feb0ec21cc913789202d043f69b5e17` and then create `verified.json` alongside it containing that hash and revision. The adapter is about 908 MB. No inference-provider account or API credits are required. The model is distributed under CreativeML Open RAIL-M; retain upstream terms and notices.

The base model is `emilianJR/epiCRealism`, pinned to revision `6522cf856b8c8e14638a0aaa7bd89b1b098aed17`. The exact file sizes and safetensors SHA-256 values are included in `backend/video_studio/models.lock.json`. The deployed downloads were verified against those hashes.

The worker uses CPU float32, attention slicing, VAE slicing and forward chunking. Fast produces eight model frames; Enhanced and Detail produce sixteen. Landscape native sizes are 512×288 / 640×360 / 768×432 respectively; portrait swaps dimensions and square uses 384 / 512 / 640. The worker uses four diffusion steps, runs the existing SD1.5 safety checker over frames, then interpolates at native size to 24 fps and enlarges to the selected export resolution. H.264 CRF 17 and fast-start encode the two-second MP4. The optional reference path uses AnimateDiff video-to-video with repeated reference frames as its initialization; output motion is denoised by the model. Exact identity retention is not guaranteed.

The older Wan GPU adapter remains in the package for compatibility, but the deployed Mac configuration selects AnimateDiff. Wan has not been verified on this Mac.

## Verification

Run `python3 -m unittest discover -s tests -v` from this directory. Tests cover authentication, session invalidation, origin restrictions, account isolation, references and job state handling. Inference verification must additionally run on the configured Mac with its real model files.

During media generation, only one image/video job is admitted at once to limit memory pressure. Keep the Mac awake while a job runs. Closing the browser does not stop a submitted generation; recent creations can be reopened after signing back in.

## Workflows and files

`backend/workspace.py` adds conversations, messages, skills, plugins and preferences to the existing SQLite database. Existing account records are preserved. `backend/extensions.py` imports public GitHub SKILL.md files as instructions, pins their source commit and embeds up to six small explicitly linked Markdown references within a 16,000-character budget. It does not execute downloaded code. GitHub must be reachable during imports; ordinary local inference needs no network.

Chat accepts PNG/JPEG up to 6 MB and UTF-8 text/code files up to 100 KB. Only the first 12,000 text characters enter the model context. Photo chat requires `qwen3-vl:2b-instruct` installed in Ollama. Attachment bytes are not retained as conversation history.

Response levels use these Ollama context/output-token budgets: Instant 4096/512, Medium 4096/1024, High 8192/1536, Max 8192/2048, Ultra 8192/3072. They apply to Chat, Work and Beast. Image/video generation instead uses the separate quality preset.
