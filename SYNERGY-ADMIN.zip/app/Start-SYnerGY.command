#!/bin/zsh
cd "$(dirname "$0")"
if [ -f "$HOME/Library/LaunchAgents/in.1rank.synergy-v14.plist" ]; then
  launchctl kickstart "gui/$(id -u)/in.1rank.synergy-v14"
  open 'http://127.0.0.1:8090'
else
  echo 'This source package needs the existing local runtimes. See BACKEND_SETUP.md.'
fi
