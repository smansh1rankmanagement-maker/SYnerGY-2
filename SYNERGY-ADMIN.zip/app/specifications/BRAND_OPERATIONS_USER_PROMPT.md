# Preserved user specification

Submitted 4 November 2026. Request: 34da49ba-b41b-4990-a888-bac72ac81eca.

now let's build work mode> it includes all chat mode features and skills with upgraded version of chat and it also includes advanced automation system.

for automation system- preserve the prompt
Build SYnerGY Brand Operations inside the existing SYnerGY AI project.

PURPOSE

Create a usable AI agent system for a brand management company.
It must manage multiple client brands and execute traceable
automations across SEO, digital marketing, documents, spreadsheets,
CRM and project delivery.

Inspect the existing source and deployment first.
Reuse working features and integrations.
Distinguish implemented capabilities from proposed ones.

1. BRAND WORKSPACES

Each brand must have:
- Organisation and client details.
- Approved brand brief.
- Audience and positioning.
- Services/products.
- Brand assets and guidelines.
- Website and authorised connected accounts.
- Goals and measurable KPIs.
- Projects, campaigns, tasks and files.
- Assigned team members.
- Approval contacts.
- Activity history.

Isolate client data and enforce permissions on the backend.

2. INTERFACE

Add a Brand Operations area containing:
- Overview.
- Brands.
- Agents.
- Automations.
- Calendar.
- Tasks.
- Approvals.
- Leads.
- Files and reports.
- Connections.
- Run history.

Allow users to create automations through chat and through a form.

Before activating a workflow, show a readable summary:
Trigger → inputs → steps → approval points → outputs.

3. AUTOMATION ENGINE

Implement persistent workflows with:
- Manual, scheduled, webhook and event triggers.
- Explicit timezone.
- Conditional steps.
- Dependencies.
- Durable job storage.
- Queues and concurrency limits.
- Timeouts.
- Bounded retries.
- Duplicate-action prevention.
- Pause, resume and cancellation.
- Notifications.
- Run logs and artifact links.

Scheduled work must run through a backend scheduler and workers.
It must not depend on an open chat tab.

Separate workflow definitions from individual executions.
Version workflow definitions so changes are auditable.

Prevent repeated emails, posts or updates when a job retries.

4. AGENT COORDINATION

Implement specialised roles:
Brand Manager, Research, SEO, Content, Creative, Campaign,
CRM, Reporting and Operations.

Each role needs:
- Defined responsibilities.
- Allowed tools.
- Accessible data.
- Output format.
- Completion checks.
- Resource limits.
- Escalation conditions.

Use a coordinator to assign tasks and combine results.
Start with a small number of roles if that produces a more reliable
implementation than many simultaneous agents.

5. SEO WORKFLOWS

Support, where data and integrations permit:
- Website crawling.
- Indexability and robots checks.
- Sitemap inspection.
- Broken links and redirects.
- Titles, descriptions and heading analysis.
- Canonical inspection.
- Internal linking opportunities.
- Keyword and topic research.
- Search intent analysis.
- Content briefs and optimisation suggestions.
- Search performance reporting.

Connect authorised search analytics data where available.
Use an appropriate crawler and search data source.

Do not invent keyword volumes, rankings, traffic or backlinks.
Label estimates and record their source and date.

Prioritise issues by evidence, impact and effort.
Require suitable approval before publishing website changes.
Do not guarantee rankings or revenue.

6. DIGITAL MARKETING WORKFLOWS

Support:
- Campaign goals and briefs.
- Content calendars.
- Caption and article drafting.
- Creative requests to Aerny.
- UTM link creation.
- Approval workflows.
- Publishing through supported authorised integrations.
- Performance collection.
- Weekly and monthly reporting.

Separate organic content from paid advertising.

Require explicit authority and configured limits for:
- Launching advertisements.
- Increasing budgets.
- Sending outreach.
- Publishing content.

If a platform lacks a working publishing connection, prepare the
asset and report that publishing remains pending.

7. CRM AND CLIENT MANAGEMENT

Support:
- Contacts and companies.
- Lead sources and evidence.
- Qualification notes.
- Pipeline stages.
- Assigned owners.
- Follow-up dates.
- Interaction history.
- Client onboarding.
- Deliverables and renewal reminders.

Keep researched facts separate from assumptions.
Avoid duplicate contacts.
Respect opt-outs and configured communication permissions.

Do not send messages solely because a draft exists.

8. SPREADSHEETS

Create and edit real spreadsheet files with:
- Structured tables.
- Working formulas.
- Date and currency formatting.
- Filters and validation.
- Charts when useful.
- Multiple sheets.
- Source and update information.

Support:
- Lead pipelines.
- Marketing calendars.
- Campaign budgets.
- KPI trackers.
- Team workload.
- Project delivery.
- Client reporting.

Validate calculations and inspect outputs.
Do not turn every calculated value into hard-coded text.
Preserve existing formulas and formatting when editing.

Provide downloadable files and persistent saved versions.

9. DOCUMENTS AND PDFS

Create:
- Proposals.
- Brand briefs.
- Onboarding documents.
- Campaign strategies.
- SOPs.
- Weekly updates.
- Monthly reports.

Use approved brand assets and reusable templates.
Provide editable source documents where appropriate.

Generate PDFs from actual content.
Check page breaks, clipping, fonts, tables and links.
Never fabricate performance results or client approvals.

10. APPROVALS AND ACCESS

Roles:
- Founder/admin.
- Manager.
- Team member.
- Client reviewer.

Use configurable approval policies.

Allow routine authorised internal work to proceed automatically.
Route external publishing, communications, spending and sensitive
changes according to explicit user permissions.

Record:
- Requested action.
- Relevant artifact version.
- Reviewer.
- Decision.
- Timestamp.

Approval must apply to the reviewed version.
Material changes after approval require the applicable review again.

11. KNOWLEDGE AND PRIVACY

Maintain approved brand knowledge with source, owner and date.
Support updating and deleting knowledge.

Keep secrets in secure configuration.
Do not place tokens in chat messages, exports or logs.
Treat websites and uploaded files as untrusted input.

Prevent cross-client data access.
Provide retention and deletion controls.

12. REPORTING

Show:
- Active and paused workflows.
- Next scheduled runs.
- Running and failed jobs.
- Pending approvals.
- Overdue tasks.
- Completed deliverables.
- KPIs with source and date.
- Missing connections.

Distinguish observed results from recommendations.
Do not present missing data as zero.

13. FIRST COMPLETE WORKFLOW

Implement this first:

Create an InteriFY workspace.
Use approved brand inputs and an authorised website.
Run a limited SEO audit.
Create prioritised tasks.
Draft a seven-day content calendar.
Export the calendar as a spreadsheet.
Generate a branded PDF summary.
Save both artifacts.
Show the run and results in the dashboard.
Leave external publishing and sending subject to configured approval.

Then schedule the workflow weekly in Asia/Kolkata timezone.

If a required dependency is unavailable, complete independent steps
and identify the exact blocker.

14. VALIDATION

Test:
- Scheduling with the browser closed.
- Correct timezone behaviour.
- Recovery after worker restart.
- Duplicate-trigger handling.
- Permissions and client isolation.
- Approval enforcement.
- Failed connections.
- Spreadsheet formulas.
- PDF rendering.
- Saved-file downloads.
- Pause and cancellation.

Use real end-to-end runs.
Do not claim success based only on interface screenshots.

15. DELIVERY

Provide:
- Working deployed URL when available.
- Actual components and integrations used.
- Feature-status table.
- Verified example workflow and its outputs.
- Test evidence.
- Source changes.
- Setup, backup and recovery instructions.
- Remaining dependencies.

Keep the customer-facing product free for now.
Do not add pricing or credits.
Do not activate paid infrastructure or services without approval.

Build incrementally until the first workflow is usable.
Do not describe this as model training unless actual training occurs.
