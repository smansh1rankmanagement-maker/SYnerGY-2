'use strict';
// Only this trusted build config runs on the server. Project scripts are never run.
const esbuild=require('esbuild'),path=require('node:path').posix;
let input='';process.stdin.setEncoding('utf8');process.stdin.on('data',x=>{input+=x;if(input.length>32000000)process.exit(2);});
process.stdin.on('end',async()=>{try{const {files,entry}=JSON.parse(input),allowed=new Set(['react','react-dom','react-dom/client','react/jsx-runtime','react/jsx-dev-runtime','framer-motion']);
function locate(p){return [p,p+'.tsx',p+'.jsx',p+'.ts',p+'.js',p+'/index.tsx',p+'/index.jsx',p+'/index.js'].find(n=>Object.hasOwn(files,n));}
const plugin={name:'synergy-project',setup(build){build.onResolve({filter:/.*/},a=>{
 if(a.namespace==='project'||a.kind==='entry-point'){
  if(allowed.has(a.path))return {path:require.resolve(a.path)};
  if(/^(?:[a-z]+:|\/|\\)/i.test(a.path)||(!a.path.startsWith('.')&&a.kind!=='entry-point'))return {errors:[{text:'Unsupported dependency: '+a.path+'. Use the installed React and Framer Motion packages.'}]};
  const p=path.normalize(path.join(a.kind==='entry-point'?'':path.dirname(a.importer),a.path));if(p.startsWith('..'))return {errors:[{text:'Import outside project.'}]};const n=locate(p);return n?{path:n,namespace:'project'}:{errors:[{text:'Missing project file: '+p}]};
 }});build.onLoad({filter:/.*/,namespace:'project'},a=>{const f=files[a.path],ext=path.extname(a.path).slice(1);if(f.encoding==='base64')return {contents:Buffer.from(f.content,'base64'),loader:'dataurl'};if(!['tsx','jsx','ts','js','css','json'].includes(ext))return {errors:[{text:'Unsupported preview import: '+a.path}]};return {contents:f.content,loader:ext,resolveDir:'/'};});}};
const result=await esbuild.build({entryPoints:[entry],bundle:true,write:false,outdir:'/virtual-output',plugins:[plugin],format:'iife',platform:'browser',jsx:'automatic',target:'es2020',minify:true,define:{'process.env.NODE_ENV':'"production"'},logLevel:'silent'});
console.log(JSON.stringify({js:result.outputFiles.filter(x=>x.path.endsWith('.js')).map(x=>x.text).join('\n'),css:result.outputFiles.filter(x=>x.path.endsWith('.css')).map(x=>x.text).join('\n'),warnings:result.warnings.map(x=>x.text)}));
}catch(e){console.log(JSON.stringify({error:(e.errors||[{text:e.message}]).map(x=>x.text).join('\n').slice(0,1500)}));process.exitCode=1;}});
