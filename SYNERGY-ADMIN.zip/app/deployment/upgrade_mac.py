"""Switch the inspected local deployment to v1.5; preserve rollback material."""
from pathlib import Path
import json,os,plistlib,shutil,sqlite3,subprocess,time,urllib.request
b=Path.home()/'Library/Application Support/SYnerGY';plist=Path.home()/'Library/LaunchAgents/in.1rank.synergy-v14.plist'
config=plistlib.loads(plist.read_bytes());data=Path(config['EnvironmentVariables']['SYNERGY_DATA_DIR'])
active=[]
for kind in ['image','video']:
 for f in (data/kind).glob('**/job.json'):
  try:
   if json.loads(f.read_text()).get('state') in {'queued','running','cancelling'}:active.append(str(f))
  except (OSError,ValueError):pass
if active:raise RuntimeError('Existing media jobs are active. Let them finish before switching.')
backup=b/'backups'/time.strftime('aerny-v15-%Y%m%d-%H%M%S');backup.mkdir(parents=True,mode=0o700)
shutil.copy2(plist,backup/plist.name)
with sqlite3.connect(data/'accounts.sqlite3') as src,sqlite3.connect(backup/'accounts.sqlite3') as dst:src.backup(dst)
(backup/'rollback.json').write_text(json.dumps({'source':str(b/'v1.4'),'data':str(data),'label':config['Label']},indent=2));os.chmod(backup/'accounts.sqlite3',0o600)
env=config['EnvironmentVariables'];old_media_path=env.get('PYTHONPATH','')
env.update(SYNERGY_OLLAMA_MODEL='aerny:v1.5',PYTHONPATH=str(b/'runtime/v15-web-deps'),SYNERGY_STUDIO_WORKER_PATH=':'.join(x for x in [str(b/'runtime/v15-deps'),old_media_path] if x),SYNERGY_LCM_ADAPTER=str(b/'models/lcm-lora-sdv1-5'))
config['ProgramArguments']=[str(b/'runtime/managed-python/cpython-3.12.15-macos-x86_64-none/bin/python3.12'),str(b/'v1.5/backend/server.py')]
config['WorkingDirectory']=str(b/'v1.5');domain='gui/'+str(os.getuid())
subprocess.run(['launchctl','bootout',domain,str(plist)],capture_output=True)
tmp=plist.with_suffix('.new');tmp.write_bytes(plistlib.dumps(config));tmp.replace(plist)
subprocess.run(['launchctl','bootstrap',domain,str(plist)],check=True,capture_output=True)
subprocess.run(['launchctl','kickstart',domain+'/'+config['Label']],capture_output=True)
ready=False
for _ in range(30):
 try:
  with urllib.request.urlopen('http://127.0.0.1:8090/api/auth/config',timeout=2) as r:ready=json.load(r).get('version')=='1.5'
 except (OSError,ValueError):pass
 if ready:break
 time.sleep(.5)
if not ready:
 subprocess.run(['launchctl','bootout',domain,str(plist)],capture_output=True);shutil.copy2(backup/plist.name,plist);subprocess.run(['launchctl','bootstrap',domain,str(plist)],check=True)
 raise RuntimeError('v1.5 did not start; the previous startup configuration was restored.')
report={'version':'1.5','backup':str(backup),'url':'http://127.0.0.1:8090/','source':str(b/'v1.5'),'data':str(data),'openai_enabled':env.get('SYNERGY_ALLOW_OPENAI')=='1'}
(b/'v15-evidence/deployment.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
