"""Import this run's generated photo and supplied logo into the specified owner's workspace."""
from pathlib import Path
import json,os,sqlite3,sys,time,uuid,shutil
b=Path.home()/'Library/Application Support/SYnerGY';sys.path.insert(0,str(b/'v1.5/backend'))
from studio.service import Studio
from workspace import Workspace
with sqlite3.connect(b/'v1.4-data/accounts.sqlite3') as c:
 row=c.execute('SELECT id FROM users WHERE username=? COLLATE NOCASE',(sys.argv[1],)).fetchone()
 if not row:raise RuntimeError('Owner account was not found.')
 uid=row[0]
studio=Studio(b/'v1.4-data/accounts.sqlite3',b/'v1.4-data/studio',b/'v1.4-data/image/model.json',b/'runtime/v14-media/bin/python',b/'models/lcm-lora-sdv1-5',start=False,recover=False)
photo=studio.add_asset(uid,(b/'v15-evidence/fast-generation/base.png').read_bytes(),'Local office lounge · epiCRealism + LCM · 134 seconds')
logo=studio.add_asset(uid,(b/'v15-evidence/input-assets/Transparent InteriFY logo cutout(1).png').read_bytes(),'InteriFY supplied transparent logo')
studio.save_brand(uid,{'name':'InteriFY','logo_id':logo['id'],'colour':'#d6a575','font':'bold','approved':False})
original=json.loads((b/'v15-evidence/fast-generation/input.json').read_text())['spec'];p=studio.save(uid,{'title':'InteriFY · office launch draft','spec':original})
jid=uuid.uuid4().hex;folder=studio.folder(jid);folder.mkdir(parents=True)
for name in ['base.png','output.png','output.svg','result.json','input.json']:shutil.copy2(b/'v15-evidence/fast-generation'/name,folder/name)
result=json.loads((folder/'result.json').read_text());result['base_asset_id']=photo['id'];result['provenance']='Actual local inference from the v1.5 verification run.';(folder/'result.json').write_text(json.dumps(result))
now=time.time()
with studio.connection() as c:c.execute('INSERT INTO studio_jobs(id,user_id,project_id,state,spec,created,started,finished,result) VALUES(?,?,?,?,?,?,?,?,?)',(jid,uid,p['id'],'succeeded',json.dumps(original),now-result['seconds'],now-result['seconds'],now,json.dumps(result)))
layout={**original,'workflow':'layout','reference_id':photo['id'],'background':'#211e1a','image_frame':{'x':0,'y':28,'width':100,'height':72,'fit':'cover'},'layers':[{'type':'text','text':'OFFICE\nLAUNCH','x':6,'y':5,'width':57,'height':20,'size':8.5,'colour':'#f5eee5','font':'bold','panel':False},{'type':'logo','asset_id':logo['id'],'x':70,'y':4,'width':25,'height':21}]}
p=studio.save(uid,{**p,'spec':layout});j=studio.submit(uid,p['id'])
w=Workspace(studio.db);chat=w.create_chat(uid);w.edit_chat(uid,chat['id'],title='Aerny v1.5 · InteriFY studio preview')
w.add(uid,chat['id'],'user','Create an InteriFY office launch poster with the supplied logo, 1080 × 1350.',{'mode':'chat','effort':'instant','tool':'studio','project_id':p['id']})
w.add(uid,chat['id'],'assistant','The local office image is composed with your original logo and exact headline. Open the saved design to adjust the layout or make a selected-area edit.',{'studio_job_id':j['id'],'project_id':p['id']})
record={'project_id':p['id'],'generation_job':jid,'layout_job':j['id'],'conversation_id':chat['id'],'logo_asset':logo['id'],'photo_asset':photo['id']};(b/'v15-evidence/owner-preview.json').write_text(json.dumps(record));print(json.dumps(record))
