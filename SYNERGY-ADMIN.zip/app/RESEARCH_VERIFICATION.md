# SYnerGY AI · research verification

Application 1.5.1; Aerny v1.5 profiles; 4 November 2026.

The upgrade is deployed at **http://127.0.0.1:8090/** on the configured Mac. This is a local application, not a publicly hosted service. Existing accounts, four conversations, the saved image project and its two studio jobs were retained during the switch. The deployment record identifies the rollback backup and verified source hashes.

## Automated regression

**52 tests passed** in the final automated suite. Coverage includes authentication/ownership, original image/video/layout workflows, research task persistence, SSE streaming, privacy settings, denied external requests, document parsers, explicit page-reference linking, bounded arithmetic, citation-ID checks, search caching/expiry/domain/date parameters, source-read failures, duplicate submissions, conversation branching, cancellation, DNS/private-address rejection and untrusted-document placement.

The parser tests use synthetic PDF, DOCX, XLSX, CSV, code and image fixtures. PDF originals were downloaded and matched by SHA-256. Tests exercise credential redaction while preserving ordinary text such as “Session recognised.” The arithmetic component evaluates numeric AST nodes using Decimal; it never calls eval or executes supplied code.

These are software checks. They do not prove that the language model understands every document, that every citation entails its claim, or that subjective answer quality is perfect.

## Live acceptance on the Mac

| Test | Observed result | Measured time | Assessment |
|---|---|---:|---|
| A: web research | Public search returned official pages; three pages read, including a relevant followed link; streamed answer cited the isolation page | 67.08 s; model first token 28.18 s | Working for this brief; three cited findings manually checked against the retrieved context |
| B: three-tool comparison | Four official documentation pages read; comparison table and four valid citation IDs | 74.40 s | Workflow works; some model-written limitations were inferred too broadly. Prompt tightened; semantic quality remains partial |
| C: uploaded PDF | Correct 12-desk and 2-quiet-room counts; original pages retained | 32.03 s | Correct facts/pages; first answer used prose page references rather than clickable citation syntax |
| C follow-up UI edit | Edited a new branch while retaining the original PDF; answer returned `12 [D2]` and `2 [D1]` | About 20 s | Passed: saved upload, page links, branch preservation and reopened conversation |
| D: broken button | Captured the null-element JavaScript error, HTTP 404/500, redirect, screenshot and DOM | 6.26 s | Passed after replacing model-guessed browser summaries with evidence-based reports |
| E: fixed button | Developer corrected the owned fixture; app repeated click/type/scroll. “Button works” appeared, no uncaught click error; unrelated HTTP failures remained | 3.98 s | Passed; app did not itself edit the website source |
| F: cancel model request | Task reached cancelled; no model/browser child worker remained for that task | 0.02 s after Stop in this run | Passed; not a guaranteed cancellation latency |
| G: image text recognition | Local Vision returned JUNIPER OFFICE, 12 DESKS, 2 QUIET ROOMS | 63.30 s | Correct synthetic transcription; general OCR quality remains partial |
| H: Hindi/Hinglish | Balanced produced Hindi/Hinglish replies after Auto routing changes | 20–24 s in final extra run | Language switching works; Hinglish grammar/precision remains uneven |
| I: session/CORS/download | Session cookie recognized; CORS failure captured; download bytes matched; cookie value absent from output | 8.82 s | All five explicit checks passed |
| J: cancel browser | Cancelled a slow fixture navigation; no browser-worker process remained | 2.62 s including cleanup wait | Passed |
| K: arithmetic | `2 plus 2` returned `4` through the local calculator | 0.14 s | Passed; avoids relying on the small language model for arithmetic |
| Public HTTPS browser | Inspected Playwright's real public page through the isolated proxy; HTTP 200, screenshot and diagnostics returned | About 6 s | Passed through the UI |

Observed failure history is retained to avoid presenting a success-only picture:

- The first worker test found a module-name conflict with Python's `http` package. Renaming the route module fixed startup; an actual subprocess startup test was added.
- DDGS with a newer primp transport failed; pinning primp 0.15.0 fixed compatibility. Bing returned results; DuckDuckGo and Brave returned no results in initial checks.
- A final production check found that the previous DDGS region setting returned unrelated results. Domain filtering rejected them and the app reported an unavailable search. Switching to the standard English region restored relevant results; the final production rerun is recorded below.
- Long natural-language search queries included answer-format instructions and returned poor results. The planner now extracts shorter search terms and follows relevant page links.
- Fast incorrectly read a PDF count and misstated browser errors. Auto uses Balanced for substantive questions; diagnostic summaries use captured facts.
- Fast also failed a basic arithmetic prompt and echoed one Hinglish request. Explicit arithmetic now uses the calculator, and Auto limits Fast to greetings. Fast remains a manual option with lower reliability.
- A credential-redaction pattern incorrectly removed ordinary “session” text. It now requires an assignment/header pattern; the real cookie/session test was rerun and passed.

## Interface evidence

Verified in the connected browser: login with the staging account, history search, restored task progress, streamed text, source cards, PDF excerpts, citation navigation, Edit with saved-upload retention, Retry in a preserved branch, Stop, Settings and the public-website inspection flow. The live upgrade also reopened the existing InteriFY project and displayed saved media outputs.

Automated fresh file selection was blocked by the ChatGPT Chrome extension's file-URL permission. Upload parsing/original downloads passed through the app API. Existing-upload reuse was tested through the actual interface. This remaining automation limitation is not represented as a completed file-picker test. See RESEARCH_SETUP.md for the exact optional browser setting.

## Feature status

| Feature | Status | Boundary |
|---|---|---|
| Multi-turn chat, history/search, streaming, stop/retry/edit | Working | Context and output budgets are finite; editing/retry preserves originals in branches |
| Web search, domains/date hints, reads, find, topical links | Working with availability limits | Provider outages/blocks reported; not Google Search; Auto classification is heuristic |
| Source provenance and clickable citations | Working structurally; semantic quality partial | IDs and page mapping are checked; claim truth still needs review |
| PDF/TXT/MD/CSV/code/DOCX/XLSX extraction | Working within documented limits | Partial formats/sections are disclosed; no spreadsheet macro execution |
| Image understanding/OCR | Partial | Vision model, no dedicated OCR confidence/boxes; scanned PDF OCR missing |
| Isolated browser and diagnostics | Working for tested public/read-only flows | Per-task context; explicit actions only; no existing Chrome login access |
| Authenticated production actions/source editing | Missing by design in this release | Credential entry, mutations and arbitrary source/server access not enabled |
| OpenAI | Blocked/unconfigured | No key, model or paid inference enabled; adapter not live-tested |
| Hybrid | Working locally | External routing needs independent server and account opt-ins |
| Hindi/Hinglish | Partial | Responds in the language; grammar and reasoning quality are inconsistent |
| Preferences, notes, uploads and findings separation | Working | Deleting an upload does not erase earlier quoted answers/reports; no full account purge UI |
| Deep research/Beast | Partial | Real broader budgets and reports; heuristic decomposition, finite evidence, no exhaustive verification claim |
| Exact simple arithmetic | Working | Bounded expression grammar; 28-digit Decimal precision, no symbolic algebra |
| Image/video features | Preserved | Existing regression tests pass; unchanged inference was not rerun just for this chat upgrade |

## Source and deployment

Changed: `backend/server.py`, `backend/workspace.py`, `backend/model_router.py`, the new `backend/research/` package, chat UI files and research tests/fixtures. New isolated dependency/setup files and license notices are included. Existing image/video inference and the approved logo were preserved.

Machine: Intel MacBook Pro, 16 GB RAM, CPU inference, existing Chrome and Ollama. There is no persistent ChatGPT GPU behind this application. Larger context and image understanding can take tens of seconds or minutes. The timings above are observations, not service-level promises.

No model was trained or fine-tuned. No paid provider was connected. Public web requests leave the Mac for search/page retrieval; model inference remains local by default.

## Final production verification

The final UI retry completed on the deployed app in **77.81 seconds**. It searched the public web, read three official Playwright pages and followed the relevant isolation link. It automatically selected `aerny:v1.5` (Balanced), streamed the reply, and saved six valid citation references with no invalid IDs or source failures. The three substantive bullets were checked against the retrieved excerpts. The answer was more verbose than the requested three brief bullets, so concise instruction-following remains a quality limitation.

The failed search before the region fix is retained as `LIVE_search_region_failure.json`; the successful rerun is `LIVE_final_research.json`. The separate public HTTPS UI inspection completed in 6.36 seconds. The final regression run passed all 52 tests in 7.743 seconds, and the connected app tab reported no browser console errors.

The final UI patch also hides an old image when opening research evidence. The production health endpoint reports application 1.5.1 and the local-address test exception is absent from the live configuration. The app is open on the completed research conversation, with sources in the right-side preview.
