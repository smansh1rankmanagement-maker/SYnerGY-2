"""Authenticated speech proxy; the OpenJarvis worker is not public."""
import json,os,re,urllib.request,urllib.error
from hosting import RateLimiter
LIMIT=RateLimiter(limit=20,window=60)
URL=os.environ.get('SYNERGY_VOICE_URL','').rstrip('/')
class VoiceHTTP:
 def voice_get(self,user):
  if not self.workspace.tool_enabled(user['id'],'voice'):return self.response(200,{'ready':False,'detail':'Enable OpenJarvis voice in Plugins first.'})
  if not URL:return self.response(200,{'ready':False,'detail':'Local voice is not configured.'})
  try:
   with urllib.request.urlopen(URL+'/health',timeout=4) as r:data=json.load(r)
   return self.response(200,{**data,'profile':{'id':'synergy-jarvis','name':'SYnerGY Jarvis','default':True,'modes':['chat','work','beast'],'voice_type':'licensed_stock_voice','personal_clone_trained':False,'english_voice':'am_michael','hindi_voice':'hm_omega','detail':'Personal assistant profile using local speech models. A personal voice clone has not been trained.'}})
  except (OSError,ValueError):return self.response(200,{'ready':False,'detail':'Voice is starting. You can keep typing.'})
 def voice_post(self,path,d,user):
  if path not in {'/api/voice/transcribe','/api/voice/speak'}:return self.fail(404,'Not found.')
  if not self.workspace.tool_enabled(user['id'],'voice'):return self.fail(409,'Enable OpenJarvis voice in Plugins first.')
  if not URL:return self.fail(503,'Voice is not configured on this server.')
  if not LIMIT.allow(user['id']):return self.fail(429,'Voice is receiving requests too quickly. Retry in a minute; this is a temporary traffic safeguard, not a usage credit limit.')
  try:
   if path.endswith('/transcribe'):
    data=d.get('file');language=d.get('language','auto')
    if not isinstance(data,bytes) or not 0<len(data)<=8*1024*1024 or language not in {'auto','en','hi'}:raise ValueError('Choose a recording up to 60 seconds and under 8 MB.')
    req=urllib.request.Request(URL+'/transcribe',data=data,headers={'Content-Type':'application/octet-stream','X-Language':language})
   else:
    chat=self.workspace.chat(user['id'],d.get('conversation_id'))
    msg=next((m for m in reversed(chat['messages']) if m['role']=='assistant' and (not d.get('message_id') or m['id']==d['message_id'])),None)
    if not msg:raise KeyError('Reply not found.')
    # Read an owned saved reply, never arbitrary client-supplied content.
    text=re.sub(r'```[\s\S]*?```',' Code is shown in the chat. ',msg['content'])
    text=re.sub(r'\[([^\]]+)\]\([^)]+\)',r'\1',text);text=re.sub(r'https?://\S+','',text)
    text=re.sub(r'[*#`|]',' ',text).strip()[:1750]
    if not text:raise ValueError('This reply has no speakable text.')
    req=urllib.request.Request(URL+'/speak',data=json.dumps({'text':text}).encode(),headers={'Content-Type':'application/json'})
   with urllib.request.urlopen(req,timeout=180) as r:
    body=r.read(16*1024*1024)
    return self.response(200,body,'audio/wav' if path.endswith('/speak') else 'application/json')
  except KeyError:return self.fail(404,'Reply not found in this account.')
  except ValueError as exc:return self.fail(400,str(exc))
  except urllib.error.HTTPError as exc:
   return self.fail(429 if exc.code==429 else 503,'Voice is busy. Try again shortly.' if exc.code==429 else 'Voice could not finish. Try a shorter recording or continue typing.')
  except (OSError,TimeoutError):return self.fail(503,'Voice is taking too long. You can continue typing and retry.')
