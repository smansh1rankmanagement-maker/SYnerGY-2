"""Resumable private uploads: 200 MiB per file or folder batch, four-MiB chunks."""
import base64,hashlib,json,os,re,shutil,sqlite3,threading,time,uuid
from pathlib import Path,PurePosixPath
MAX_UPLOAD=200*1024*1024
CHUNK=4*1024*1024
class Uploads:
 def __init__(self,ws,research,root):
  self.ws=ws;self.research=research;self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True,mode=0o700);self.lock=threading.RLock()
  with ws.connect() as c:c.executescript('CREATE TABLE IF NOT EXISTS large_uploads(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,conversation_id TEXT NOT NULL,batch_id TEXT NOT NULL,name TEXT NOT NULL,size INTEGER NOT NULL,state TEXT NOT NULL,sha256 TEXT,created REAL NOT NULL,updated REAL NOT NULL,research_id TEXT);CREATE TABLE IF NOT EXISTS upload_chunks(upload_id TEXT NOT NULL,idx INTEGER NOT NULL,size INTEGER NOT NULL,sha256 TEXT NOT NULL,PRIMARY KEY(upload_id,idx));CREATE INDEX IF NOT EXISTS upload_account ON large_uploads(user_id,conversation_id,created);')
 def get(self,uid,rid):
  with self.ws.connect() as c:r=c.execute('SELECT * FROM large_uploads WHERE id=? AND user_id=?',(rid,uid)).fetchone()
  if not r:raise KeyError('Upload not found.')
  self.ws.chat(uid,r['conversation_id']);return dict(r)
 def create(self,uid,d):
  cid=d.get('conversation_id');self.ws.chat(uid,cid);name=d.get('name','');size=d.get('size');batch=d.get('batch_id')
  if not isinstance(name,str) or len(name)>300 or any(x in {'','..','.'} for x in name.split('/')) or name.startswith('/') or '\\' in name or any(ord(ch)<32 for ch in name):raise ValueError('Use a relative filename without traversal or control characters.')
  if type(size) is not int or not 0<=size<=MAX_UPLOAD or not isinstance(batch,str) or not re.fullmatch(r'[a-f0-9-]{32,36}',batch):raise ValueError('Maximum upload size is 200 MB per file or folder selection.')
  with self.lock,self.ws.connect() as c:
   c.execute('BEGIN IMMEDIATE');old=c.execute('SELECT * FROM large_uploads WHERE user_id=? AND conversation_id=? AND batch_id=? AND name=?',(uid,cid,batch,name)).fetchone()
   if old:
    if old['size']!=size:raise ValueError('The resumed file size changed. Start a new upload.')
    return dict(old)
   count,total=c.execute('SELECT count(*),coalesce(sum(size),0) FROM large_uploads WHERE user_id=? AND batch_id=?',(uid,batch)).fetchone()
   if count>=200 or total+size>MAX_UPLOAD:raise ValueError('A folder selection supports up to 200 files and 200 MB total.')
   quota=max(MAX_UPLOAD,int(os.environ.get('SYNERGY_UPLOAD_QUOTA_BYTES',str(1024*1024*1024))))
   if c.execute('SELECT coalesce(sum(size),0) FROM large_uploads WHERE user_id=?',(uid,)).fetchone()[0]+size>quota:raise ValueError('Your upload storage is full. Delete saved uploads before adding more.')
   if shutil.disk_usage(self.root).free<size+1024*1024*1024:raise ValueError('Upload storage is temporarily busy. Try again later.')
   rid=uuid.uuid4().hex;now=time.time();(self.root/rid).mkdir(mode=0o700);c.execute('INSERT INTO large_uploads VALUES(?,?,?,?,?,?,?,?,?,?,?)',(rid,uid,cid,batch,name,size,'uploading',None,now,now,None));return {'id':rid,'size':size,'state':'uploading','name':name,'chunk_bytes':CHUNK}
 def chunk(self,uid,d):
  with self.lock:
   row=self.get(uid,d.get('id'));idx=d.get('index')
   if type(idx) is not int or idx<0 or idx*CHUNK>=row['size']:raise ValueError('Invalid upload chunk.')
   try:raw=base64.b64decode(d.get('data',''),validate=True)
   except (ValueError,TypeError):raise ValueError('Invalid upload bytes.') from None
   expected=min(CHUNK,row['size']-idx*CHUNK)
   if len(raw)!=expected:raise ValueError('Chunk length does not match the declared file size.')
   digest=hashlib.sha256(raw).hexdigest()
   with self.ws.connect() as c:
    old=c.execute('SELECT sha256 FROM upload_chunks WHERE upload_id=? AND idx=?',(row['id'],idx)).fetchone()
    if old:
     if old[0]!=digest:raise ValueError('This chunk differs from the saved upload. Start a new upload.')
     return {'ok':True,'duplicate':True}
    if row['state']!='uploading':raise ValueError('This upload is already complete.')
    path=self.root/row['id']/str(idx);temp=path.with_suffix('.part');temp.write_bytes(raw);temp.chmod(0o600);temp.replace(path)
    c.execute('INSERT INTO upload_chunks VALUES(?,?,?,?)',(row['id'],idx,len(raw),digest));c.execute('UPDATE large_uploads SET updated=? WHERE id=?',(time.time(),row['id']))
   return {'ok':True,'received_bytes':len(raw)}
 def finish(self,uid,rid):
  with self.lock:
   row=self.get(uid,rid)
   if row['state']=='ready':return row
   with self.ws.connect() as c:chunks=c.execute('SELECT * FROM upload_chunks WHERE upload_id=? ORDER BY idx',(rid,)).fetchall()
   if [r['idx'] for r in chunks]!=list(range((row['size']+CHUNK-1)//CHUNK)) or sum(r['size'] for r in chunks)!=row['size']:raise ValueError('Some upload chunks are missing. Resume the upload.')
   folder=self.root/rid;tmp=folder/'assembling';digest=hashlib.sha256()
   with tmp.open('wb') as out:
    for c in chunks:
     data=(folder/str(c['idx'])).read_bytes()
     if hashlib.sha256(data).hexdigest()!=c['sha256']:raise ValueError('Saved chunk verification failed. Upload again.')
     digest.update(data);out.write(data)
    out.flush();os.fsync(out.fileno())
   tmp.chmod(0o600);tmp.replace(folder/'original')
   with self.ws.connect() as c:c.execute("UPDATE large_uploads SET state='ready',sha256=?,updated=? WHERE id=?",(digest.hexdigest(),time.time(),rid))
   for c in chunks:(folder/str(c['idx'])).unlink(missing_ok=True)
   return self.get(uid,rid)
 def path(self,uid,rid):
  r=self.get(uid,rid)
  if r['state']!='ready':raise ValueError('Finish this upload first.')
  return self.root/rid/'original'
 def list(self,uid,cid):
  self.ws.chat(uid,cid)
  with self.ws.connect() as c:return [dict(r) for r in c.execute('SELECT * FROM large_uploads WHERE user_id=? AND conversation_id=? ORDER BY created',(uid,cid))]
 def prepare(self,uid,ids):
  if not isinstance(ids,list) or not 1<=len(ids)<=200:raise ValueError('Choose uploaded files to read.')
  rows=[self.get(uid,rid) for rid in ids]
  if len({r['conversation_id'] for r in rows})!=1:raise ValueError('Files must belong to the same conversation.')
  if len(rows)==1:
   r=rows[0]
   if r['research_id']:
    try:return {'file':self.research.file(uid,r['research_id']),'assets':rows}
    except KeyError:pass
   f=self.research.upload_path(uid,self.path(uid,r['id']),Path(r['name']).name)
   with self.ws.connect() as c:c.execute('UPDATE large_uploads SET research_id=? WHERE id=?',(f['id'],r['id']))
   return {'file':f,'assets':rows}
  lines=['Folder upload. Originals are preserved in Saved uploads.','Inventory:']+['- '+r['name']+' ('+str(r['size'])+' bytes)' for r in rows]
  remaining=100000
  for r in rows[:20]:
   if remaining<=0:break
   try:
    f=self.prepare(uid,[r['id']])['file'];text='\n'.join(s['label']+': '+s['text'] for s in f['parsed'].get('sections',[]));warnings=f['parsed'].get('warnings',[])
    excerpt=text[:min(10000,remaining)];remaining-=len(excerpt);lines+=['\nFILE: '+r['name'],excerpt,'Limits: '+('; '.join(warnings) or 'Extraction is bounded to this excerpt.')]
   except ValueError as e:lines+=['\nFILE: '+r['name'],'Stored; extraction unavailable: '+str(e)]
  lines+=['\nOnly the first 20 files and up to 100,000 extracted characters were analysed. Images in a folder need individual selection for vision. Never claim the full folder was read.']
  return {'file':self.research.upload(uid,'\n'.join(lines).encode(),'folder-extract.txt'),'assets':rows}
 def message_assets(self,uid,cid,ids):
  if not isinstance(ids,list) or not 1<=len(ids)<=200 or any(not isinstance(x,str) for x in ids) or len(set(ids))!=len(ids):raise ValueError('Choose up to 200 distinct attachments.')
  rows=[self.get(uid,rid) for rid in ids]
  if any(r['conversation_id']!=cid or r['state']!='ready' for r in rows):raise ValueError('Attachments must be ready and belong to this conversation.')
  if sum(r['size'] for r in rows)>MAX_UPLOAD:raise ValueError('Attachments exceed 200 MB.')
  return [{'id':r['id'],'name':r['name'],'size':r['size']} for r in rows]
 def thumbnail(self,uid,rid):
  from PIL import Image,ImageOps,UnidentifiedImageError
  import io
  source=self.path(uid,rid);thumb=source.parent/'preview.jpg'
  if thumb.exists():return thumb.read_bytes()
  try:
   with Image.open(source) as im:
    if im.width*im.height>25000000:raise ValueError('Image is too large for a chat thumbnail. Download the original.')
    im.thumbnail((512,512));im=ImageOps.exif_transpose(im).convert('RGBA')
    background=Image.new('RGB',im.size,'white');background.paste(im,mask=im.getchannel('A'))
    out=io.BytesIO();background.save(out,format='JPEG',quality=85);data=out.getvalue()
  except (UnidentifiedImageError,OSError,Image.DecompressionBombError) as exc:raise ValueError('No image preview is available for this file.') from None
  tmp=thumb.with_suffix('.'+uuid.uuid4().hex+'.tmp');tmp.write_bytes(data);tmp.chmod(0o600);tmp.replace(thumb)
  return data
 def delete(self,uid,rid):
  with self.lock:
   r=self.get(uid,rid)
   if r['research_id']:self.research.delete_file(uid,r['research_id'])
   with self.ws.connect() as c:c.execute('DELETE FROM upload_chunks WHERE upload_id=?',(rid,));c.execute('DELETE FROM large_uploads WHERE id=? AND user_id=?',(rid,uid))
   shutil.rmtree(self.root/rid,ignore_errors=True)
  return {'ok':True}

class UploadsHTTP:
 def uploads_get(self,path,user):
  from urllib.parse import urlsplit,parse_qs
  uid=user['id'];u=self.uploads
  try:
   if path=='/api/uploads':return self.response(200,{'uploads':u.list(uid,parse_qs(urlsplit(self.path).query).get('conversation_id',[''])[0]),'maximum_bytes':MAX_UPLOAD,'chunk_bytes':CHUNK})
   m=re.fullmatch(r'/api/uploads/([0-9a-f]{32})(/original|/preview)?',path)
   if not m:raise KeyError()
   r=u.get(uid,m[1])
   if m[2]=='/preview':return self.response(200,u.thumbnail(uid,m[1]),'image/jpeg')
   if m[2]:return self.research_download_path(u.path(uid,m[1]),Path(r['name']).name)
   with u.ws.connect() as c:r['chunks']=[x[0] for x in c.execute('SELECT idx FROM upload_chunks WHERE upload_id=? ORDER BY idx',(r['id'],))]
   return self.response(200,r)
  except (KeyError,FileNotFoundError):return self.fail(404,'Upload not found in this account.')
  except (ValueError,TypeError) as e:return self.fail(400,str(e))
 def uploads_post(self,path,d,user):
  u=self.uploads;uid=user['id']
  try:
   if path=='/api/uploads/create':r=u.create(uid,d)
   elif path=='/api/uploads/chunk':r=u.chunk(uid,d)
   elif path=='/api/uploads/finish':r=u.finish(uid,d.get('id'))
   elif path=='/api/uploads/prepare':r=u.prepare(uid,d.get('ids'))
   elif path=='/api/uploads/delete':r=u.delete(uid,d.get('id'))
   else:raise KeyError()
   return self.response(200,r)
  except (KeyError,FileNotFoundError):return self.fail(404,'Upload not found in this account.')
  except (ValueError,TypeError) as e:return self.fail(400,str(e))
