"""One durable proposal worker. It executes trusted model/check clients only."""
import argparse, fcntl, json, os, shutil, signal, subprocess, sys, tempfile, time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from beast.store import Beast,encode,stamp,validate_proposal
from beast.checks import run_checks, capabilities
import model_router

class Worker:
    def __init__(self,store):
        self.store=store
        from support import Support
        self.support=Support(store.db,store)
        from beast.managed import Managed
        from beast.managed_worker import ManagedWorker
        with store.connect() as c:accounts_ready=c.execute("SELECT 1 FROM sqlite_master WHERE name='users'").fetchone()
        self.managed=ManagedWorker(Managed(store),heartbeat=self.heartbeat) if accounts_ready else None
    def heartbeat(self):
        self.support.tick()
        with self.store.connect() as c:c.execute("INSERT OR REPLACE INTO beast_worker VALUES('local',?,?)",(stamp(),os.getpid()))
    def recover(self):
        with self.store.connect() as c:
            for row in c.execute("SELECT id,project_id,attempt FROM beast_jobs WHERE state='running'").fetchall():
                state='queued' if row['attempt']<2 else 'failed'
                c.execute('UPDATE beast_jobs SET state=?,error=?,updated=? WHERE id=?',(state,'Worker restarted; no source was applied.' if state=='failed' else None,stamp(),row['id']))
                self.store.log(c,row['project_id'],'recovered','Worker restarted. '+('Task returned to queue.' if state=='queued' else 'Retry limit reached.'),row['id'])
        scratch=self.store.root/'worker-tmp'
        if scratch.exists():shutil.rmtree(scratch)
        scratch.mkdir(mode=0o700)
    def claim(self):
        with self.store.connect() as c:
            c.execute('BEGIN IMMEDIATE');row=c.execute("SELECT * FROM beast_jobs WHERE state='queued' ORDER BY created LIMIT 1").fetchone()
            if not row:return None
            c.execute("UPDATE beast_jobs SET state='running',attempt=attempt+1,updated=? WHERE id=?",(stamp(),row['id']));self.store.log(c,row['project_id'],'started','Reading selected files and preparing the model request.',row['id']);return dict(row)
    def cancelled(self,jid):
        with self.store.connect() as c:r=c.execute('SELECT state FROM beast_jobs WHERE id=?',(jid,)).fetchone()
        return not r or r[0]!='running'
    def log(self,j,kind,message):
        with self.store.connect() as c:self.store.log(c,j['project_id'],kind,message,j['id'])
    def fail(self,j,message):
        with self.store.connect() as c:
            changed=c.execute("UPDATE beast_jobs SET state='failed',error=?,updated=? WHERE id=? AND state='running'",(message[:600],stamp(),j['id'])).rowcount
            if changed:self.store.log(c,j['project_id'],'failed',message,j['id'])
            if changed:self.store.conversation_update(c,j['id'])
    def process(self,j):
        start=time.monotonic();p=None;folder=None
        try:
            if getattr(self.store,'access',None):self.store.access(j['user_id'],'beast')
            request=json.loads(j['request'])
            if getattr(self.store,'provider_access',None):self.store.provider_access(j['user_id'],request.get('provider','synergy'),'beast')
            with self.store.connect() as c:
                project=self.store.require(c,j['user_id'],j['project_id']);files=self.store.files(c,j['project_id'],j['base_revision'])
            if project['revision']!=j['base_revision']:raise ValueError('Project changed before this task started. Submit a task against the current revision.')
            provider='synergy' if request['provider']=='hybrid' and not request['allow_external'] else request['provider']
            selection=model_router.route(provider,request['local_model'],request['effort'],request['prompt'],bool(request.get('reference_path') or request.get('video_reference_id')),True,mode='beast',family=request.get('model_family','eternal'),user_id=j['user_id'],openai_model=request.get('openai_model','auto'))
            if selection['provider']=='openai' and not request['allow_external']:raise ValueError('Enable external-model use in your settings before sending project source to OpenAI.')
            payload={'user_id':j['user_id'],'runtime_capabilities':capabilities(),'selection':selection,'request':request,'project_name':project['name'],'brief':project['brief'],'files':{n:(request['region']['text'] if request.get('region') and n==request['region']['path'] else files[n]['content']) for n in request['paths']}}
            from adaptive_preferences import Preferences
            with self.store.connect() as c:
                pref=c.execute('SELECT settings FROM research_settings WHERE user_id=?',(j['user_id'],)).fetchone() if c.execute("SELECT 1 FROM sqlite_master WHERE name='research_settings'").fetchone() else None
            if (not pref or json.loads(pref[0]).get('adaptive_memory',True)) and request.get('model_family','eternal')=='eternal':
                memory=Preferences(self.store.db);saved=memory.capture(j['user_id'],request['prompt']);payload['preference_context']=memory.instruction(j['user_id'])
                if saved:self.log(j,'preferences','Saved your explicitly requested response preferences for this account.')
            if request.get('reference_path'):payload['image']=files[request['reference_path']]['content']
            if request.get('video_reference_id'):
                from beast.references import References
                refs=References(self.store);payload['images']=refs.images(j['user_id'],j['project_id'],request['video_reference_id']);payload['video_reference']=refs.get(j['user_id'],j['project_id'],request['video_reference_id'])['metadata']
                self.log(j,'reference','Reading four sampled video frames. Original video preserved; audio is not analysed.')
            from beast.design import guidance
            payload['design_guidance']=guidance(request['prompt'],files)
            if payload['design_guidance']:self.log(j,'design',payload['design_guidance']['source']+' guidance added. User brief and reference take priority.')
            self.log(j,'model','Generating a reviewable proposal with '+selection['label']+'. No source has changed.')
            tmp=self.store.root/'worker-tmp';tmp.mkdir(exist_ok=True,mode=0o700);folder=Path(tempfile.mkdtemp(prefix=j['id']+'-',dir=tmp));os.chmod(folder,0o700)
            outfile=folder/'response.jsonl'
            # This child runs our fixed client, not a command supplied by the model/project.
            with outfile.open('wb') as out:
                p=subprocess.Popen([sys.executable,str(Path(__file__).with_name('model_worker.py'))],stdin=subprocess.PIPE,stdout=out,stderr=subprocess.DEVNULL,start_new_session=True)
                p.stdin.write(encode(payload).encode());p.stdin.close()
                last_progress=0;seen_stages=set();seen_notices=set()
                while p.poll() is None:
                    self.heartbeat()
                    if self.cancelled(j['id']):return
                    if getattr(self.store,'access',None):self.store.access(j['user_id'],'beast')
                    if time.monotonic()-start>min(1800,max(60,int(os.environ.get('SYNERGY_BEAST_TIMEOUT','900')))):raise ValueError('The task reached its configured time limit. Try a smaller change or fewer context files.')
                    if outfile.stat().st_size>900000:raise ValueError('The model output exceeded its limit.')
                    lines=outfile.read_text(errors='replace').splitlines()
                    for line in reversed(lines):
                        try:event=json.loads(line)
                        except ValueError:continue
                        if event.get('notice') and event['notice']['id'] not in seen_notices:
                            seen_notices.add(event['notice']['id']);self.log(j,'quota_notice',json.dumps(event['notice']))
                        if event.get('stage') and event['stage'] not in seen_stages:
                            seen_stages.add(event['stage']);self.log(j,'review',event['stage'])
                        if event.get('progress',0)>last_progress:
                            last_progress=event['progress'];self.log(j,'progress',str(last_progress)+' response chunks received.');break
                    time.sleep(.3)
            if self.cancelled(j['id']):return
            result=None;usage={}
            for line in outfile.read_text().splitlines():
                event=json.loads(line)
                if event.get('notice') and event['notice']['id'] not in seen_notices:
                    seen_notices.add(event['notice']['id']);self.log(j,'quota_notice',json.dumps(event['notice']))
                if event.get('error'):raise ValueError(event['error'])
                if 'result' in event:result=event['result'];usage=event.get('usage',{})
            if p.returncode or result is None:raise ValueError('The model stopped before producing a complete proposal.')
            review=usage.get('review')
            if review:
                selection['review_status']=review['status'];selection['actual_provider']='hybrid' if review['status']=='reviewed' else 'synergy';selection['label']='ETERNAL + OpenAI · reviewed' if review['status']=='reviewed' else 'ETERNAL · local draft'
            self.log(j,'validate','Validating the response schema, allowed paths and selected edit scope.')
            result,updated=validate_proposal(result,files,request)
            self.log(j,'checks','Running available parse-only checks against the proposed files.')
            if usage.get('review',{}).get('warning'):result['notes'].append(usage['review']['warning'])
            result['notes'].insert(0,'Model explanation (not execution evidence): '+result['summary'])
            result['model_summary']=result['summary']
            result['summary']='Source proposal prepared for review.' if result['changes'] else 'Explanation prepared; no source files were changed.'
            result['summary']+=' No project code or tests were executed.'
            result['checks']=run_checks(updated);result['selection']=selection;result['usage']=usage;result['elapsed']=round(time.monotonic()-start,2);result['sources']=request.get('sources',[])
            state='awaiting_review' if result['changes'] else 'completed'
            with self.store.connect() as c:
                c.execute('BEGIN IMMEDIATE')
                if c.execute("UPDATE beast_jobs SET state=?,result=?,updated=? WHERE id=? AND state='running'",(state,encode(result),stamp(),j['id'])).rowcount:
                    self.store.log(c,j['project_id'],state,'Proposal ready for review. No source changed.' if state=='awaiting_review' else 'Explanation saved. No source changed.',j['id']);self.store.conversation_update(c,j['id'])
            if state=='awaiting_review' and request.get('admin_auto_apply') and not result['checks']['failed']:
                # Ownership and current revision are rechecked in this transaction.
                self.store.job_action(j['user_id'],{'id':j['id'],'action':'apply','revision':j['base_revision'],'reviewed_hash':result['hash']})
                self.log(j,'auto_applied','Administrator-authorised changes saved to the private source copy. Live deployment remains separate.')
        except Exception as e:self.fail(j,str(e) if isinstance(e,(ValueError,KeyError,PermissionError)) else 'The development worker could not complete this task. Retry after checking the local service.')
        finally:
            if p and p.poll() is None:
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                p.wait(timeout=5)
            if folder:shutil.rmtree(folder,ignore_errors=True)
            self.heartbeat()
    def loop(self):
        lock=(self.store.root/'worker.lock').open('w')
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('A Beast worker is already active.')
        self.recover()
        pending=[]
        if self.managed:
            with self.managed.store.connect() as c:pending=[dict(r) for r in c.execute("SELECT * FROM codex_tasks WHERE state='queued' AND ready=0")]
        for task in pending:
            try:self.managed.store.activate(task)
            except Exception:pass
        while True:
            self.heartbeat()
            if self.managed and self.managed.tick():continue
            job=self.claim()
            if job:self.process(job)
            else:time.sleep(1)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path,required=True);args=parser.parse_args()
    from membership import Membership
    store=Beast(args.data/'accounts.sqlite3',args.data/'beast');membership=Membership(store.db);store.access=membership.require;store.provider_access=membership.require_provider;Worker(store).loop()
if __name__=='__main__':main()
