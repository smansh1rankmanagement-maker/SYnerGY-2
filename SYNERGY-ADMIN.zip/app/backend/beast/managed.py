"""Durable managed-coding tasks on the existing Beast database and worker."""
import difflib,hashlib,io,json,os,re,sqlite3,time,uuid,zipfile,zlib
from pathlib import Path
from .safety import validate_files,bytes_of,no_secrets,import_zip,path
from .store import Conflict
from .managed_provider import safe_text,SDK_VERSION
from membership import Membership
import model_router,openai_budget

ACTIVE={'queued','starting','running','waiting_for_user','stopping'}
FINAL={'completed','failed','cancelled'}
def encode(value):return json.dumps(value,ensure_ascii=False,separators=(',',':'))
def now():return time.time()

class Managed:
    def __init__(self,beast):
        self.beast=beast;self.db=beast.db;self.root=beast.root/'managed';self.root.mkdir(mode=0o700,exist_ok=True)
        self.membership=Membership(self.db)
        with self.connect() as c:c.executescript('''
        CREATE TABLE IF NOT EXISTS codex_tasks(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,project_id TEXT NOT NULL,base_revision INTEGER NOT NULL,conversation_id TEXT,model TEXT NOT NULL,state TEXT NOT NULL,prompt TEXT NOT NULL,request TEXT NOT NULL,snapshot BLOB NOT NULL,source_hash TEXT NOT NULL,budget INTEGER NOT NULL,ready INTEGER NOT NULL DEFAULT 0,created REAL NOT NULL,updated REAL NOT NULL,deadline REAL NOT NULL,session_id TEXT,creation_intent REAL,provider_state TEXT,turn_id TEXT,result TEXT,error TEXT,usage TEXT,stop_requested INTEGER NOT NULL DEFAULT 0,lease TEXT,lease_until REAL,cleanup_state TEXT NOT NULL DEFAULT 'pending',idempotency_key TEXT NOT NULL,UNIQUE(user_id,idempotency_key));
        CREATE INDEX IF NOT EXISTS codex_task_queue ON codex_tasks(state,ready,created);
        CREATE TABLE IF NOT EXISTS codex_events(task_id TEXT NOT NULL,seq INTEGER NOT NULL,provider_ref TEXT NOT NULL,kind TEXT NOT NULL,payload TEXT NOT NULL,created REAL NOT NULL,PRIMARY KEY(task_id,seq),UNIQUE(task_id,provider_ref));
        CREATE TABLE IF NOT EXISTS codex_artifacts(id TEXT PRIMARY KEY,task_id TEXT NOT NULL,user_id INTEGER NOT NULL,provider_id TEXT NOT NULL,name TEXT NOT NULL,media_type TEXT NOT NULL,storage_path TEXT NOT NULL,size INTEGER NOT NULL,sha256 TEXT NOT NULL,UNIQUE(task_id,provider_id));
        CREATE TABLE IF NOT EXISTS codex_messages(id TEXT NOT NULL,task_id TEXT NOT NULL,user_id INTEGER NOT NULL,text TEXT NOT NULL,state TEXT NOT NULL,created REAL NOT NULL,PRIMARY KEY(task_id,id));
        CREATE TABLE IF NOT EXISTS codex_approvals(id TEXT PRIMARY KEY,task_id TEXT NOT NULL,action TEXT NOT NULL,scope TEXT NOT NULL,state TEXT NOT NULL,expires REAL NOT NULL,decision_actor INTEGER,decision_at REAL);
        ''')
    def connect(self):
        c=sqlite3.connect(self.db,timeout=20);c.row_factory=sqlite3.Row;return c
    def require(self,uid,tid):
        self.membership.require(uid,'beast')
        with self.connect() as c:r=c.execute('SELECT * FROM codex_tasks WHERE id=? AND user_id=?',(tid,uid)).fetchone()
        if not r:raise KeyError('Coding task not found in this account.')
        with self.beast.connect() as c:self.beast.require(c,uid,r['project_id'])
        return dict(r)
    def event(self,c,tid,kind,payload,ref=None):
        ref=ref or uuid.uuid4().hex
        if c.execute('SELECT 1 FROM codex_events WHERE task_id=? AND provider_ref=?',(tid,ref)).fetchone():return
        seq=c.execute('SELECT coalesce(max(seq),0)+1 FROM codex_events WHERE task_id=?',(tid,)).fetchone()[0]
        c.execute('INSERT INTO codex_events VALUES(?,?,?,?,?,?)',(tid,seq,ref,kind,encode(payload),now()))
    def public(self,r):
        t={k:r[k] for k in ['id','project_id','base_revision','conversation_id','model','state','created','updated','deadline','provider_state','session_id','turn_id','error','stop_requested','cleanup_state']}
        t.update(result=json.loads(r['result']) if r['result'] else None,usage=json.loads(r['usage']) if r['usage'] else None,budget_usd=r['budget']/1e6,billing_status='Estimated allowance; reservation retained pending provider-bill reconciliation.')
        return t
    def task(self,uid,tid):
        r=self.require(uid,tid)
        with self.connect() as c:
            events=[{**dict(e),'payload':json.loads(e['payload'])} for e in c.execute('SELECT seq,kind,payload,created FROM codex_events WHERE task_id=? ORDER BY seq DESC LIMIT 100',(tid,))]
            artifacts=[self.public_artifact(a) for a in c.execute('SELECT * FROM codex_artifacts WHERE task_id=? ORDER BY name',(tid,))]
        return {**self.public(r),'events':list(reversed(events)),'artifacts':artifacts}
    def list(self,uid,project_id=None,conversation_id=None):
        self.membership.require(uid,'beast')
        with self.connect() as c:rows=c.execute('SELECT * FROM codex_tasks WHERE user_id=? ORDER BY created DESC LIMIT 40',(uid,)).fetchall()
        out=[]
        for r in rows:
            if (project_id and r['project_id']!=project_id) or (conversation_id and r['conversation_id']!=conversation_id):continue
            try:
                with self.beast.connect() as c:self.beast.require(c,uid,r['project_id'])
            except (KeyError,PermissionError):continue
            out.append(self.public(r))
        return out
    def events(self,uid,tid,after=0):
        self.require(uid,tid)
        if type(after) is not int or after<0:raise ValueError('Use a non-negative event sequence.')
        with self.connect() as c:rows=c.execute('SELECT seq,kind,payload,created FROM codex_events WHERE task_id=? AND seq>? ORDER BY seq LIMIT 100',(tid,after)).fetchall()
        return [{**dict(e),'payload':json.loads(e['payload'])} for e in rows]
    def catalog(self,uid):
        e=self.membership.entitlement(uid);enabled=os.environ.get('SYNERGY_CODEX_ENABLED')=='1' and model_router.external_config()[2]
        verified=set(os.environ.get('SYNERGY_CODEX_MODELS','').split(','))
        if os.environ.get('SYNERGY_CODEX_ADMIN_ONLY','1')=='1' and e['profile']['role']!='admin':enabled=False
        allowed=['gpt-6-luna','gpt-6.1-sol'] if e['usage_policy']['subscribed'] else ['gpt-6-luna']
        return {'enabled':enabled,'sdk_version':SDK_VERSION,'models':[{'id':m,'available':enabled and m in verified and m in allowed and e['access']['beast'],'locked':m not in allowed} for m in model_router.OPENAI_MODELS],'mode_available':e['access']['beast'],'default_model':allowed[-1],'execution':'OpenAI-hosted sandbox','network_default':'disabled','provider_spend_control':False,'billing':'Token and sandbox costs apply. Application reserves are estimates, not a guaranteed provider billing cap.','default_budget_usd':float(os.environ.get('SYNERGY_CODEX_TASK_USD','0.25')),'pause_available':False}
    def submit(self,uid,d,instructions='',allow_external=False):
        self.membership.require_provider(uid,'openai','beast')
        key=d.get('idempotency_key')
        if not isinstance(key,str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,100}',key):raise ValueError('A valid idempotency key is required.')
        with self.connect() as c:existing=c.execute('SELECT * FROM codex_tasks WHERE user_id=? AND idempotency_key=?',(uid,key)).fetchone()
        if existing:
            if existing['project_id']!=d.get('project_id') or existing['prompt']!=str(d.get('prompt','')).strip() or existing['conversation_id']!=d.get('conversation_id'):raise Conflict('The retry key belongs to a different task.')
            if not existing['ready'] and existing['state']=='queued':self.activate(dict(existing))
            return self.task(uid,existing['id'])
        if not allow_external:raise PermissionError('Enable external AI before sending this project to the hosted coding environment.')
        if not self.catalog(uid)['enabled']:raise ValueError('Managed Codex execution is not enabled. Source proposal mode remains available.')
        provider=d.get('provider','hybrid')
        if provider not in {'openai','hybrid'}:raise ValueError('Select OpenAI or Hybrid for a managed coding task. SYnerGY source assistance stays local.')
        model=model_router.select_openai(uid,'beast',d.get('openai_model') or 'auto')
        if model not in set(os.environ.get('SYNERGY_CODEX_MODELS','').split(',')):raise ValueError('The selected model has not passed managed-execution verification. Ordinary chat is unchanged.')
        prompt=d.get('prompt')
        if not isinstance(prompt,str) or not 1<=len(prompt.strip())<=6000:raise ValueError('Enter a coding task up to 6,000 characters.')
        no_secrets(prompt);no_secrets(instructions)
        with self.beast.connect() as c:
            project=self.beast.require(c,uid,d.get('project_id'))
            if type(d.get('revision')) is not int or d['revision']!=project['revision']:raise ValueError('Project revision changed. Reload before running the task.')
            files=self.beast.files(c,project['id'],project['revision'])
        paths=d.get('paths')
        if paths is None:paths=list(files)
        if not isinstance(paths,list) or not paths or len(paths)>40 or any(n not in files for n in paths) or len(set(paths))!=len(paths):raise ValueError('Select 1–40 project files.')
        files=validate_files({n:files[n] for n in paths})
        if sum(len(bytes_of(v)) for v in files.values())>5*1024*1024:raise ValueError('Select no more than 5 MB of project source.')
        request={'instructions':instructions[:18000],'dependency_network':d.get('dependency_network') is True,'requested_provider':provider,'paths':paths}
        budget=int(round(float(os.environ.get('SYNERGY_CODEX_TASK_USD','0.25'))*1000000))
        if not 10000<=budget<=1000000:raise ValueError('Configure a coding-task allowance from $0.01 to $1.00.')
        seconds=max(30,min(600,int(os.environ.get('SYNERGY_CODEX_TIMEOUT','180'))))
        tid=uuid.uuid4().hex;created=now();raw=encode(files).encode();source_hash=hashlib.sha256(raw).hexdigest()
        cid=d.get('conversation_id')
        if cid:
            with self.connect() as c:
                if not c.execute('SELECT 1 FROM conversations WHERE id=? AND user_id=?',(cid,uid)).fetchone():raise KeyError('Conversation not found.')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            old=c.execute('SELECT id FROM codex_tasks WHERE user_id=? AND idempotency_key=?',(uid,key)).fetchone()
            if old:tid=old['id']
            else:
                if c.execute("SELECT count(*) FROM codex_tasks WHERE user_id=? AND state IN ('queued','starting','running','waiting_for_user','stopping')",(uid,)).fetchone()[0]>=1:raise ValueError('One coding task is already active for this account.')
                c.execute('INSERT INTO codex_tasks(id,user_id,project_id,base_revision,conversation_id,model,state,prompt,request,snapshot,source_hash,budget,created,updated,deadline,idempotency_key) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(tid,uid,project['id'],project['revision'],cid,model,'queued',prompt.strip(),encode(request),zlib.compress(raw),source_hash,budget,created,created,created+seconds,key))
                self.event(c,tid,'queued',{'message':'Coding task saved. Waiting for the managed execution worker.','model':model})
        with self.connect() as c:r=dict(c.execute('SELECT * FROM codex_tasks WHERE id=?',(tid,)).fetchone())
        self.activate(r)
        return self.task(uid,tid)
    def activate(self,t):
        try:openai_budget.reserve_execution(t['id'],t['user_id'],t['model'],t['budget'])
        except Exception:
            with self.connect() as c:c.execute("UPDATE codex_tasks SET state='failed',error='The configured OpenAI allowance cannot cover this task.',updated=? WHERE id=? AND ready=0",(now(),t['id']))
            raise
        with self.connect() as c:c.execute('UPDATE codex_tasks SET ready=1 WHERE id=?',(t['id'],))
    def stop(self,uid,tid):
        self.require(uid,tid)
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT * FROM codex_tasks WHERE id=?',(tid,)).fetchone()
            if r['state'] not in FINAL:
                c.execute("UPDATE codex_tasks SET stop_requested=1,state='stopping',updated=? WHERE id=?",(now(),tid));self.event(c,tid,'stopping',{'message':'Stop requested; waiting for provider confirmation.'},'user-stop')
        return self.task(uid,tid)
    def steer(self,uid,tid,d):
        r=self.require(uid,tid);text=d.get('message');key=d.get('idempotency_key')
        if r['state'] not in ACTIVE or r['stop_requested']:raise ValueError('This task is no longer accepting steering messages. Start a new task for a follow-up change.')
        if not isinstance(text,str) or not 1<=len(text.strip())<=4000:raise ValueError('Use a steering message up to 4,000 characters.')
        if not isinstance(key,str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,100}',key):raise ValueError('A message idempotency key is required.')
        no_secrets(text)
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            old=c.execute('SELECT text FROM codex_messages WHERE task_id=? AND id=?',(tid,key)).fetchone()
            if old and old['text']!=text.strip():raise Conflict('The message retry key belongs to a different message.')
            c.execute('INSERT OR IGNORE INTO codex_messages VALUES(?,?,?,?,?,?)',(key,tid,uid,text.strip(),'queued',now()))
        return {'accepted':True,'message_id':key,'state':'queued'}
    def public_artifact(self,a):return {'id':a['id'],'name':a['name'],'media_type':a['media_type'],'size':a['size'],'sha256':a['sha256'],'url':'/api/beast/tasks/'+a['task_id']+'/artifacts/'+a['id']}
    def artifact(self,uid,tid,aid):
        self.require(uid,tid)
        with self.connect() as c:r=c.execute('SELECT * FROM codex_artifacts WHERE id=? AND task_id=? AND user_id=?',(aid,tid,uid)).fetchone()
        if not r:raise KeyError('Artifact not found.')
        p=Path(r['storage_path']);base=(self.root/tid).resolve()
        if p.is_symlink() or not p.resolve().is_relative_to(base) or not p.is_file():raise KeyError('Artifact unavailable.')
        return p,r['name']
    def reconcile(self,uid,tid):
        r=self.require(uid,tid)
        if r['state']!='waiting_for_user' and r['cleanup_state']!='outputs_pending':raise ValueError('This task does not need reconciliation.')
        with self.connect() as c:
            c.execute("UPDATE codex_tasks SET state='starting',lease=NULL,lease_until=NULL,error=NULL,updated=? WHERE id=?",(now(),tid))
            self.event(c,tid,'reconcile',{'message':'Checking the existing provider session. A duplicate will not be created.'})
        return self.task(uid,tid)
    def proposal(self,uid,tid):
        t=self.require(uid,tid)
        if t['state']!='completed':raise ValueError('Wait for the coding task to finish before reviewing its changes.')
        result=json.loads(t['result'] or '{}')
        if result.get('applied_revision'):return {'applied_revision':result['applied_revision'],'changes':[]}
        with self.connect() as c:artifacts=c.execute('SELECT * FROM codex_artifacts WHERE task_id=?',(tid,)).fetchall()
        named={}
        for a in artifacts:
            if a['name'] in named:raise ValueError('Ambiguous output artifact names. Inspect the downloaded outputs.')
            named[a['name']]=a
        if 'changes.zip' not in named or 'deleted.json' not in named:raise ValueError('The coding task did not return a complete changes archive and deletion manifest.')
        archive=self.artifact(uid,tid,named['changes.zip']['id'])[0].read_bytes()
        with zipfile.ZipFile(io.BytesIO(archive)) as z:empty=not z.infolist()
        changed={} if empty else import_zip(archive)
        deleted=json.loads(self.artifact(uid,tid,named['deleted.json']['id'])[0].read_bytes())
        snapshot=json.loads(zlib.decompress(t['snapshot']))
        if not isinstance(deleted,list) or len(deleted)>40 or any(not isinstance(n,str) for n in deleted) or len(deleted)!=len(set(deleted)):raise ValueError('Invalid deletion manifest.')
        if any(path(n) not in snapshot or n in changed for n in deleted):raise ValueError('Deletion is outside the selected snapshot or conflicts with a change.')
        with self.beast.connect() as c:
            self.beast.require(c,uid,t['project_id']);base=self.beast.files(c,t['project_id'],t['base_revision'])
        if any(n in base and n not in snapshot for n in changed):raise ValueError('A returned change would overwrite an existing file outside the selected snapshot.')
        merged={**base,**changed}
        for n in deleted:merged.pop(n)
        validate_files(merged)
        changes=[];diff=[]
        for n in sorted(set(base)|set(merged)):
            a=base.get(n);b=merged.get(n)
            if a==b:continue
            changes.append({'path':n,'action':'create' if a is None else 'delete' if b is None else 'modify'})
            if (a is None or a['encoding']=='utf-8') and (b is None or b['encoding']=='utf-8'):
                diff.extend(difflib.unified_diff((a or {}).get('content','').splitlines(True),(b or {}).get('content','').splitlines(True),fromfile='a/'+n,tofile='b/'+n))
            else:diff.append('Binary asset changed: '+n+'\n')
        digest=hashlib.sha256(encode(merged).encode()).hexdigest()
        return {'task_id':tid,'project_id':t['project_id'],'base_revision':t['base_revision'],'reviewed_hash':digest,'changes':changes,'diff':''.join(diff)[:150000],'diff_truncated':sum(len(x) for x in diff)>150000,'_files':merged}
    def apply(self,uid,tid,d):
        p=self.proposal(uid,tid)
        if p.get('applied_revision'):return self.task(uid,tid)
        if d.get('revision')!=p['base_revision'] or d.get('reviewed_hash')!=p['reviewed_hash']:raise Conflict('Review the current task diff before applying.')
        if not p['changes']:raise ValueError('The task returned no source changes.')
        with self.beast.connect() as c:
            c.execute('BEGIN IMMEDIATE');self.beast.require(c,uid,p['project_id'])
            r=c.execute('SELECT result FROM codex_tasks WHERE id=?',(tid,)).fetchone();result=json.loads(r['result'] or '{}')
            if result.get('applied_revision'):return self.task(uid,tid)
            rev=self.beast.revision(c,p['project_id'],p['base_revision'],p['_files'],'Applied managed Codex task '+tid[:8])
            result.update(source_applied=True,applied_revision=rev)
            c.execute('UPDATE codex_tasks SET result=?,updated=? WHERE id=?',(encode(result),now(),tid));self.event(c,tid,'applied',{'message':'Reviewed source saved as revision '+str(rev)+'.','revision':rev})
        return self.task(uid,tid)
    def claim(self,worker):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            r=c.execute("SELECT * FROM codex_tasks WHERE ready=1 AND state IN ('queued','starting','running','stopping') AND (lease_until IS NULL OR lease_until<?) ORDER BY created LIMIT 1",(now(),)).fetchone()
            if not r:return None
            c.execute("UPDATE codex_tasks SET lease=?,lease_until=?,state=CASE WHEN state='queued' THEN 'starting' ELSE state END,updated=? WHERE id=?",(worker,now()+300,now(),r['id']))
            return dict(c.execute('SELECT * FROM codex_tasks WHERE id=?',(r['id'],)).fetchone())
    def touch(self,tid,worker,**fields):
        allowed={'state','session_id','creation_intent','provider_state','turn_id','result','error','usage','stop_requested','cleanup_state'}
        if set(fields)-allowed:raise ValueError('Invalid task update.')
        with self.connect() as c:
            args=list(fields.values())+[now(),now()+300,tid,worker]
            return c.execute('UPDATE codex_tasks SET '+''.join(k+'=?,' for k in fields)+'updated=?,lease_until=? WHERE id=? AND lease=?',args).rowcount==1
    def finish(self,t,worker,state,result=None,error=None,usage=None):
        if state not in FINAL:raise ValueError('Invalid terminal outcome.')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            changed=c.execute('UPDATE codex_tasks SET state=?,result=?,error=?,usage=?,updated=?,lease_until=NULL WHERE id=? AND lease=?',(state,encode(result) if result else None,error,encode(usage) if usage else None,now(),t['id'],worker)).rowcount
            if changed:self.event(c,t['id'],state,{'message':error or (result or {}).get('summary') or state})
        openai_budget.execution_outcome(t['id'],state,usage)
    def approval(self,uid,tid,approval_id,d):
        self.require(uid,tid)
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');a=c.execute("SELECT * FROM codex_approvals WHERE id=? AND task_id=? AND state='pending' AND expires>?",(approval_id,tid,now())).fetchone()
            if not a:raise KeyError('Approval not found or expired.')
            # This first execution backend exposes no external tool actions.
            # Never turn a generic approval into credentials or browser access.
            if d.get('decision')!='deny':raise ValueError('This action is not supported by the configured tool gateway. Stop the task or use the separately authorised tool.')
            c.execute("UPDATE codex_approvals SET state='denied',decision_actor=?,decision_at=? WHERE id=?",(uid,now(),approval_id))
        return self.stop(uid,tid)
