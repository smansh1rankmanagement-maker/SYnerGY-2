"""One execution owner; restart recovery reconciles sessions instead of replaying work."""
import hashlib,json,mimetypes,os,time,uuid,zlib
from pathlib import PurePosixPath
from .managed import Managed,encode,now,FINAL
from .managed_provider import Provider,INSTRUCTIONS,safe_text
import model_router,openai_budget

def data(obj):return obj.to_dict() if hasattr(obj,'to_dict') else obj

class ManagedWorker:
    def __init__(self,store,provider_factory=Provider,heartbeat=lambda:None):
        self.store=store;self.provider_factory=provider_factory;self.heartbeat=heartbeat;self.owner=uuid.uuid4().hex
    def tick(self):
        task=self.store.claim(self.owner)
        if not task:
            return self.cleanup_pending()
        self.run(task);return True
    def cleanup_pending(self):
        with self.store.connect() as c:
            t=c.execute("SELECT id,session_id FROM codex_tasks WHERE cleanup_state='retry_pending' AND state IN ('completed','failed','cancelled') ORDER BY updated LIMIT 1").fetchone()
        if not t:return False
        try:self.provider_factory().cleanup(t['session_id'])
        except Exception as exc:
            if getattr(exc,'status_code',None)!=404:return False
        with self.store.connect() as c:c.execute("UPDATE codex_tasks SET cleanup_state='released',updated=? WHERE id=?",(now(),t['id']))
        return True
    def log(self,t,kind,payload,ref=None):
        with self.store.connect() as c:
            c.execute('BEGIN IMMEDIATE');self.store.event(c,t['id'],kind,payload,ref)
    def current(self,t):
        with self.store.connect() as c:return dict(c.execute('SELECT * FROM codex_tasks WHERE id=?',(t['id'],)).fetchone())
    def uncertain(self,t,message):
        self.store.touch(t['id'],self.owner,state='waiting_for_user',provider_state='unknown',error=message)
        self.log(t,'reconciliation_required',{'message':message},'reconciliation-required')
    def run(self,t):
        p=None;session_id=t['session_id'];usage=None;confirmed_terminal=False;outputs_saved=False
        try:
            t['request']=json.loads(t['request'])
            if not session_id and not t['creation_intent']:
                self.store.membership.require(t['user_id'],'beast')
                model_router.select_openai(t['user_id'],'beast',t['model'])
            if (t['stop_requested'] or now()>t['deadline']) and not session_id and not t['creation_intent']:
                openai_budget.execution_outcome(t['id'],'cancelled',definite_rejection=True)
                self.store.finish(t,self.owner,'cancelled',error='Cancelled before provider execution.');return
            if os.environ.get('SYNERGY_CODEX_ENABLED')!='1' and not session_id and not t['creation_intent']:
                openai_budget.execution_outcome(t['id'],'cancelled',definite_rejection=True)
                self.store.finish(t,self.owner,'cancelled',error='Managed execution is disabled.');return
            p=self.provider_factory()
            if not session_id and t['creation_intent']:
                found=[data(s) for s in p.find(t['id'])]
                if len(found)!=1:
                    self.uncertain(t,'Provider creation outcome is uncertain. No duplicate session will be created; the allowance remains reserved.');return
                session_id=found[0]['id'];self.store.touch(t['id'],self.owner,session_id=session_id,provider_state=found[0].get('status'))
                self.log(t,'recovered',{'message':'Reconnected to the existing provider session.','session_id':session_id},'recovered:'+session_id)
            if not session_id:
                t['creation_intent']=now()
                self.store.touch(t['id'],self.owner,creation_intent=t['creation_intent'],state='starting')
                self.log(t,'starting',{'message':'Starting an isolated OpenAI-hosted workspace.','model':t['model']})
                files=json.loads(zlib.decompress(t['snapshot']))
                # Only server-resolved skills and snapshot files are supplied.
                session=data(p.create(t,files,INSTRUCTIONS+'\nApproved task-scoped project guidance:\n'+t['request'].get('instructions','')))
                session_id=session['id']
                self.store.touch(t['id'],self.owner,session_id=session_id,provider_state=session.get('status'),state='running')
                self.log(t,'session_created',{'message':'Managed Codex session created.','session_id':session_id,'model':t['model']},'session:'+session_id)
            stop_sent=False;read_failures=0
            while True:
                self.heartbeat();current=self.current(t)
                if current['lease']!=self.owner:return
                stop=current['stop_requested'] or now()>t['deadline'] or os.environ.get('SYNERGY_CODEX_ENABLED')!='1'
                try:
                    self.store.membership.require(t['user_id'],'beast');model_router.select_openai(t['user_id'],'beast',t['model'])
                except (ValueError,PermissionError,KeyError):stop=True
                if stop and not stop_sent:
                    p.cancel(session_id,'synergy-stop-'+t['id']);stop_sent=True
                    self.store.touch(t['id'],self.owner,state='stopping',stop_requested=1)
                    self.log(t,'stopping',{'message':'Provider cancellation submitted; confirming the actual outcome.'},'cancel-submitted')
                try:
                    session=data(p.retrieve(session_id));turns=p.turns(session_id);items=p.items(session_id);read_failures=0
                except Exception:
                    read_failures+=1
                    if read_failures>=3:
                        try:p.cancel(session_id,'synergy-stop-'+t['id'])
                        except Exception:pass
                        self.uncertain(t,'The provider could not be reached after three checks. Stop was attempted; cancellation is not yet confirmed. No new session was created.');return
                    time.sleep(1);continue
                if not stop and session.get('status')=='in_progress':
                    with self.store.connect() as c:messages=c.execute("SELECT * FROM codex_messages WHERE task_id=? AND state='queued' ORDER BY created",(t['id'],)).fetchall()
                    for message in messages:
                        p.message(session_id,message['text'],'synergy-message-'+message['id'])
                        with self.store.connect() as c:
                            c.execute("UPDATE codex_messages SET state='sent' WHERE id=? AND task_id=?",(message['id'],t['id']));self.store.event(c,t['id'],'steering',{'message':'Steering message delivered.'},'message:'+message['id'])
                    if messages:
                        self.store.touch(t['id'],self.owner,state='running')
                        continue
                usage=session.get('usage')
                self.store.touch(t['id'],self.owner,provider_state=session.get('status'),usage=encode(usage) if usage else None)
                for item in items:
                    kind=item.get('type');ref=item.get('id')
                    if kind not in {'command_execution','message'} or not ref:continue
                    payload={'item_id':ref,'message':'Running a sandbox command' if kind=='command_execution' else 'Agent output updated'}
                    if kind=='command_execution':payload.update(command=safe_text(item.get('command',''),1500),exit_code=item.get('exit_code'),output=safe_text(item.get('output') or '',5000),status=item.get('status'))
                    else:
                        if item.get('role')!='assistant':continue
                        payload['message']=safe_text('\n'.join(c.get('text','') for c in item.get('content',[]) if c.get('type')=='output_text'),6000)
                    version=hashlib.sha256(encode(payload).encode()).hexdigest()
                    self.log(t,kind,payload,ref+':'+version)
                # Reserve in-flight/compute headroom; usage reports can lag.
                if isinstance(usage,dict) and all(type(usage.get(k)) is int for k in ['input_tokens','output_tokens']):
                    if openai_budget.cost(t['model'],usage['input_tokens'],usage['output_tokens'])>=t['budget']//2:
                        self.store.touch(t['id'],self.owner,stop_requested=1)
                        self.log(t,'budget',{'message':'Reported token usage reached the task stop threshold. Compute and delayed usage remain reserved.'},'budget-stop')
                root_turns=[x for x in turns if x.get('subagent_id') is None]
                terminal=max(root_turns,key=lambda x:(x.get('created_at',0),x.get('started_at') or 0)) if root_turns and session.get('status') in {'idle','failed'} and all(x.get('status') in FINAL for x in root_turns) else None
                if terminal:
                    confirmed_terminal=True;self.store.touch(t['id'],self.owner,turn_id=terminal['id'])
                    if terminal.get('usage'):usage=terminal['usage']
                    state=terminal['status']
                    if state=='completed':
                        result=self.collect(p,t,session_id,terminal['id'],items)
                        outputs_saved=True
                        # A completed turn is not itself verification evidence.
                        self.store.finish(t,self.owner,'completed',result=result,usage=usage)
                    else:
                        result=self.collect(p,t,session_id,terminal['id'],items);outputs_saved=True
                        self.store.finish(t,self.owner,state,result=result,error='Provider confirmed '+state+'. '+safe_text((terminal.get('error') or {}).get('message',''),400),usage=usage)
                    return
                if session.get('status')=='failed':
                    confirmed_terminal=True;self.store.touch(t['id'],self.owner,cleanup_state='outputs_pending');self.store.finish(t,self.owner,'failed',error='The provider session failed. Hosted outputs are retained for recovery.',usage=usage);return
                if session.get('required_actions'):
                    self.store.touch(t['id'],self.owner,state='waiting_for_user',error='The provider requested an action outside this sandbox-only execution service. Use Stop; external tools remain controlled by their existing gateway.')
                    self.log(t,'waiting_for_user',{'message':'An additional action requires a separately supported tool gateway.'},'action-required')
                    # Do not grant generic or credential approvals from model output.
                    p.cancel(session_id,'synergy-stop-'+t['id']);stop_sent=True
                    self.store.touch(t['id'],self.owner,state='stopping',stop_requested=1)
                if stop_sent and now()>t['deadline']+90:
                    self.uncertain(t,'Cancellation was requested but a terminal provider outcome is not yet confirmed. The allowance remains reserved.');return
                time.sleep(2)
        except Exception as exc:
            status=getattr(exc,'status_code',None)
            if not session_id and status in {400,401,403,404,422,429}:
                definite_rejection=True;openai_budget.execution_outcome(t['id'],'rejected',definite_rejection=True)
                code=safe_text(getattr(exc,'code',None) or 'request_rejected',100)
                self.store.finish(t,self.owner,'failed',error='Managed execution rejected: HTTP '+str(status)+' ('+code+'). Ordinary model chat remains available.');return
            if not session_id and t.get('creation_intent'):
                self.uncertain(t,'Session creation has an uncertain outcome. Reconciliation is required before any retry.');return
            if session_id:
                if not confirmed_terminal:
                    try:p.cancel(session_id,'synergy-stop-'+t['id'])
                    except Exception:pass
                if not confirmed_terminal:
                    self.uncertain(t,'Execution was interrupted. Stop was attempted, but the provider outcome still needs reconciliation.');return
                self.store.touch(t['id'],self.owner,cleanup_state='outputs_pending')
            elif not t.get('creation_intent'):
                openai_budget.execution_outcome(t['id'],'rejected',definite_rejection=True)
            self.store.finish(t,self.owner,'failed',error=safe_text(str(exc),500) if isinstance(exc,(ValueError,PermissionError,KeyError)) else 'The managed coding worker could not complete this task.')
        finally:
            if p and session_id and confirmed_terminal and outputs_saved:
                try:
                    p.cleanup(session_id);self.store.touch(t['id'],self.owner,cleanup_state='released')
                    self.log(t,'cleanup',{'message':'Outputs retained in SYnerGY; hosted session released.'},'cleanup')
                except Exception:
                    self.store.touch(t['id'],self.owner,cleanup_state='retry_pending')
                    self.log(t,'cleanup_pending',{'message':'Outputs are saved; hosted environment cleanup will be retried.'},'cleanup-pending')

    def collect(self,p,t,session_id,turn_id,items):
        artifacts=[a for a in p.artifacts(session_id) if a.get('turn_id')==turn_id]
        if len(artifacts)>16:raise ValueError('The task produced more than 16 output artifacts.')
        folder=self.store.root/t['id'];folder.mkdir(mode=0o700,exist_ok=True);saved=[];total=0;report=None
        for a in artifacts:
            provider_id=a.get('id');name=PurePosixPath(a.get('path','')).name
            if not provider_id or not name or len(name)>180:continue
            with self.store.connect() as c:old=c.execute('SELECT * FROM codex_artifacts WHERE task_id=? AND provider_id=?',(t['id'],provider_id)).fetchone()
            if old:
                total+=old['size'];saved.append(dict(old))
                if name=='result.json':report=json.loads(self.store.artifact(t['user_id'],t['id'],old['id'])[0].read_bytes())
                continue
            aid=uuid.uuid4().hex;dest=folder/aid
            try:p.download(session_id,provider_id,dest)
            except BaseException:dest.unlink(missing_ok=True);raise
            total+=dest.stat().st_size
            if total>32*1024*1024:dest.unlink();raise ValueError('Task outputs exceeded 32 MB.')
            dest.chmod(0o600);raw=dest.read_bytes()
            with self.store.connect() as c:
                c.execute('INSERT INTO codex_artifacts VALUES(?,?,?,?,?,?,?,?,?)',(aid,t['id'],t['user_id'],provider_id,name,mimetypes.guess_type(name)[0] or 'application/octet-stream',str(dest.resolve()),len(raw),hashlib.sha256(raw).hexdigest()))
            saved.append({'id':aid,'name':name})
            if name=='result.json':
                try:report=json.loads(raw)
                except (ValueError,UnicodeError):raise ValueError('The coding result report is invalid.')
        commands=[{'command':safe_text(i.get('command',''),1500),'exit_code':i.get('exit_code'),'output':safe_text(i.get('output') or '',5000),'status':i.get('status')} for i in items if i.get('type')=='command_execution' and i.get('turn_id')==turn_id]
        verified=bool(commands) and all(c['status']=='completed' and c['exit_code']==0 for c in commands)
        summary=safe_text(report.get('summary','Coding task completed.') if isinstance(report,dict) else 'Coding task completed; inspect the captured commands and artifacts.',1500)
        clean_report={'checks':report.get('checks',[])[:30] if isinstance(report.get('checks'),list) else [],'limitations':report.get('limitations',[])[:20] if isinstance(report.get('limitations'),list) else []} if isinstance(report,dict) else None
        return {'summary':summary,'execution_verified':verified,'commands':commands,'report':clean_report,'artifact_count':len(saved),'source_applied':False,'model':t['model'],'session_id':session_id,'turn_id':turn_id,'billing_final':False,'billing_note':'Allowance reservation remains pending final provider-bill reconciliation. The API did not accept native session spend_control.'}
