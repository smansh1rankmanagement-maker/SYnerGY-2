"""Parse-only checks. No project code, dependency scripts or shell commands run."""
import ast, functools, io, json, os, re, shutil, subprocess, sys, tempfile, time, tokenize
from html.parser import HTMLParser
from pathlib import PurePosixPath

LANGUAGES=[('HTML','html'),('CSS','css'),('JavaScript','js'),('TypeScript','ts'),('Python','py'),('PHP','php'),('SQL','sql'),('Java','java'),('C','c'),('C++','cpp'),('C#','cs'),('Go','go'),('Rust','rs'),('Ruby','rb'),('Swift','swift'),('Kotlin','kt'),('Dart','dart'),('Bash','sh'),('PowerShell','ps1'),('R','r'),('JSON','json'),('Vue','vue'),('Svelte','svelte')]
LANGUAGES += [('Lua','lua'),('Scala','scala'),('Elixir','ex'),('Erlang','erl'),('Haskell','hs'),('Clojure','clj'),('Perl','pl'),('Julia','jl'),('F#','fs'),('Objective-C','m'),('Solidity','sol'),('Zig','zig'),('Fortran','f90'),('COBOL','cob'),('Assembly','asm'),('OCaml','ml'),('Lisp','lisp'),('Groovy','groovy'),('Terraform','tf'),('D','d'),('Pascal','pas'),('Visual Basic','vb'),('Verilog','v'),('VHDL','vhd')]

def clean_env():return {'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'en_US.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
def executable(name):return shutil.which(name,path=os.environ.get('PATH','')+os.pathsep+clean_env()['PATH'])
def limits():
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CPU,(4,4));resource.setrlimit(resource.RLIMIT_FSIZE,(1024*1024,1024*1024));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    except (ImportError,ValueError,OSError):pass

@functools.lru_cache(maxsize=1)
def runtimes():
    result={'Python':{'available':True,'version':sys.version.split()[0],'path':sys.executable}}
    for name,exe,flag in [('Node.js','node','--version'),('PHP','php','--version'),('Ruby','ruby','--version'),('Go','go','version'),('Rust','rustc','--version'),('Java','java','-version'),('C/C++','clang','--version'),('Swift','swift','--version'),('Dart','dart','--version'),('PowerShell','pwsh','--version'),('R','R','--version')]:
        p=executable(exe);ok=False;version='Not found'
        if p:
            try:
                r=subprocess.run([p,flag],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=5,env=clean_env(),cwd=tempfile.gettempdir());ok=r.returncode==0;version=r.stdout.decode(errors='replace').splitlines()[0][:150] if r.stdout else 'No version returned'
            except (OSError,subprocess.TimeoutExpired):version='Version probe failed'
        result[name]={'available':ok,'version':version,'path':p}
    return result

def capabilities():
    rt=runtimes();rows=[]
    for name,ext in LANGUAGES:
        syntax='Python AST parser' if ext=='py' else 'Node.js --check' if ext=='js' and rt['Node.js']['available'] else 'JSON parser' if ext=='json' else 'HTML structure and local references' if ext=='html' else 'Not configured'
        rows.append({'language':name,'extension':ext,'assistance':'Model-assisted generation, explanation and editing; review required','syntax':syntax,'build':'Unavailable','test':'Unavailable','preview':'HTML/CSS design only' if ext in {'html','css','js'} else 'Unavailable','deployment':'Export and setup instructions only'})
    return {'languages':rows,'runtimes':rt,'execution_available':False,'reason':'No isolated build/test service is configured. Detected host runtimes are not permission to execute project code.','frameworks':['React','Next.js','Vue','Nuxt','Svelte','Angular','Node.js / Express','FastAPI / Flask / Django','Laravel','Flutter / React Native','PostgreSQL / MySQL / SQLite'],'framework_status':'Source assistance only; dependencies are not installed or executed automatically.','checked_at':time.time()}

class Structure(HTMLParser):
    def __init__(self):super().__init__();self.images=[];self.refs=[];self.title=False;self.lang=False;self.viewport=False;self.buttons=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='img' and 'alt' not in a:self.images.append(self.getpos()[0])
        if tag=='title':self.title=True
        if tag=='html':self.lang=bool(a.get('lang'))
        if tag=='meta' and a.get('name')=='viewport':self.viewport=True
        if tag in {'link','script','img'}:
            ref=a.get('href') if tag=='link' else a.get('src')
            if ref:self.refs.append(ref)

def run_checks(files):
    from .preview import resolve
    items=[];start=time.monotonic()
    for name,v in files.items():
        ext=PurePosixPath(name).suffix.lower();text=v['content'];detail=[];status='passed';check='Not configured';exit_code=None
        if v['encoding']!='utf-8':continue
        if time.monotonic()-start>30:
            items.append({'path':name,'check':'Check budget','status':'skipped','exit_code':None,'diagnostics':['The 30-second project check budget was reached. Check a smaller project or run your toolchain in an isolated environment.']});continue
        try:
            if ext=='.py':
                check='Python ast.parse (no execution)'
                # Parse in a bounded child, not in the HTTP server. Input is data over stdin.
                code="import ast,sys; ast.parse(sys.stdin.read(),filename='project.py'); print('Python syntax is valid; no code executed.')"
                r=subprocess.run([sys.executable,'-I','-c',code],input=text.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=clean_env(),cwd=tempfile.gettempdir(),timeout=5,preexec_fn=limits)
                exit_code=r.returncode;status='passed' if r.returncode==0 else 'failed';detail=[(r.stdout or r.stderr).decode(errors='replace')[-3500:]]
            elif ext in {'.js','.mjs','.cjs'}:
                node=executable('node');check='Node.js --check (no execution)'
                if not node:status='skipped';detail=['Node.js was not found.']
                else:
                    # stdin avoids module resolution, config files and package install hooks.
                    kind='commonjs' if ext=='.cjs' else 'module'
                    r=subprocess.run([node,'--max-old-space-size=64','--check','--input-type='+kind],input=text.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=clean_env(),cwd=tempfile.gettempdir(),timeout=5,preexec_fn=limits)
                    exit_code=r.returncode;status='passed' if r.returncode==0 else 'failed';detail=[r.stderr.decode(errors='replace')[-3500:] if r.returncode else 'JavaScript syntax is valid; no code executed.']
            elif ext=='.json':check='JSON parser';json.loads(text);exit_code=0;detail=['Valid JSON.']
            elif ext in {'.html','.htm'}:
                check='HTML metadata, image alternatives and local references';p=Structure();p.feed(text)
                if not p.title:detail.append('Missing page title.')
                if not p.lang:detail.append('Missing document language.')
                if not p.viewport:detail.append('Missing responsive viewport metadata.')
                if p.images:detail.append('Images without alt text on lines: '+', '.join(map(str,p.images)))
                for ref in p.refs:
                    local=resolve(name,ref)
                    if local and local not in files:detail.append('Missing local file: '+local)
                    if local is None:detail.append('External resource will not load in the offline design preview.')
                status='warning' if detail else 'passed';exit_code=0;detail=detail or ['Checked metadata, local asset links and image alt attributes. This is not a full HTML or accessibility validator.']
            elif ext=='.css':check='CSS source review';status='skipped';detail=['No full CSS parser is configured. Inspect the rendered layout at mobile and desktop widths.']
            else:status='skipped';detail=['No syntax checker is configured for this file type.']
        except (SyntaxError,ValueError) as e:status='failed';exit_code=1;detail=[str(e)[:1000]]
        except subprocess.TimeoutExpired:status='failed';exit_code=124;detail=['The parse-only check exceeded its 5-second limit.']
        except OSError:status='failed';exit_code=1;detail=['The configured checker could not start.']
        items.append({'path':name,'check':check,'status':status,'exit_code':exit_code,'diagnostics':detail})
    return {'items':items,'passed':sum(i['status']=='passed' for i in items),'failed':sum(i['status']=='failed' for i in items),'skipped':sum(i['status']=='skipped' for i in items),'warnings':sum(i['status']=='warning' for i in items),'seconds':round(time.monotonic()-start,2),'execution':'No project code was executed. Builds, tests, dependency installation and deployment were not run.','checked_at':time.time()}
