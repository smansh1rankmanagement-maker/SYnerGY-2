"""Account-isolated, revisioned source and durable development jobs."""
import ast, base64, difflib, hashlib, io, json, re, sqlite3, time, uuid, zipfile, zlib
from pathlib import Path
from .safety import validate_files, path, record, bytes_of, import_zip, no_secrets
from .templates import starter

def ident():return uuid.uuid4().hex
def stamp():return time.time()
def encode(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def pack(v):return zlib.compress(encode(v).encode())
def unpack(v):return json.loads(zlib.decompress(v))
def digest(v):return hashlib.sha256(encode(v).encode()).hexdigest()

class Conflict(ValueError):pass

class Beast:
    def __init__(self,db,root):
        self.db=Path(db);self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        with self.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS beast_projects(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,name TEXT NOT NULL,brief TEXT NOT NULL,revision INTEGER NOT NULL,created REAL NOT NULL,updated REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS beast_project_owner ON beast_projects(user_id,updated);
            CREATE TABLE IF NOT EXISTS beast_revisions(project_id TEXT NOT NULL,revision INTEGER NOT NULL,files BLOB NOT NULL,label TEXT NOT NULL,created REAL NOT NULL,PRIMARY KEY(project_id,revision));
            CREATE TABLE IF NOT EXISTS beast_checkpoints(id TEXT PRIMARY KEY,project_id TEXT NOT NULL,revision INTEGER NOT NULL,name TEXT NOT NULL,created REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS beast_jobs(id TEXT PRIMARY KEY,project_id TEXT NOT NULL,user_id INTEGER NOT NULL,base_revision INTEGER NOT NULL,state TEXT NOT NULL,request TEXT NOT NULL,result TEXT,error TEXT,attempt INTEGER NOT NULL DEFAULT 0,created REAL NOT NULL,updated REAL NOT NULL,idempotency_key TEXT NOT NULL,UNIQUE(project_id,idempotency_key));
            CREATE INDEX IF NOT EXISTS beast_job_queue ON beast_jobs(state,created);
            CREATE TABLE IF NOT EXISTS beast_activity(id INTEGER PRIMARY KEY AUTOINCREMENT,project_id TEXT NOT NULL,job_id TEXT,kind TEXT NOT NULL,message TEXT NOT NULL,created REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS beast_checks(id TEXT PRIMARY KEY,project_id TEXT NOT NULL,revision INTEGER NOT NULL,result TEXT NOT NULL,created REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS beast_worker(id TEXT PRIMARY KEY,heartbeat REAL NOT NULL,pid INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS admin_source_workspaces(user_id INTEGER PRIMARY KEY,project_id TEXT NOT NULL UNIQUE,manifest TEXT NOT NULL,created REAL NOT NULL);
            ''')
    def connect(self):
        c=sqlite3.connect(self.db,timeout=15);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c
    def require(self,c,uid,pid):
        r=c.execute('SELECT * FROM beast_projects WHERE id=? AND user_id=?',(pid,uid)).fetchone()
        if not r:raise KeyError('Project not found.')
        if c.execute('SELECT 1 FROM admin_source_workspaces WHERE project_id=?',(pid,)).fetchone():
            role=c.execute('SELECT role,account_state FROM users WHERE id=?',(uid,)).fetchone()
            if not role or role['role']!='admin' or role['account_state']!='active':raise PermissionError('Administrator access is required for this source workspace.')
        return dict(r)
    def files(self,c,pid,revision):
        row=c.execute('SELECT files FROM beast_revisions WHERE project_id=? AND revision=?',(pid,revision)).fetchone()
        if not row:raise KeyError('Revision not found.')
        return unpack(row[0])
    def log(self,c,pid,kind,message,jid=None):
        c.execute('INSERT INTO beast_activity(project_id,job_id,kind,message,created) VALUES(?,?,?,?,?)',(pid,jid,kind,str(message)[:1200],stamp()))
    def conversation_update(self,c,jid):
        row=c.execute('SELECT * FROM beast_jobs WHERE id=?',(jid,)).fetchone()
        if not row:return
        j=self.public_job(row);cid=j['request'].get('conversation_id')
        if not cid:return
        if not c.execute('SELECT 1 FROM conversations WHERE id=? AND user_id=?',(cid,j['user_id'])).fetchone():return
        r=j.get('result') or {};state=j['state'];summary=r.get('summary','')
        content=('Proposal ready for review. '+summary+'\n\n'+str(len(r.get('changes',[])))+' file(s) proposed; no source has been changed. Review the diff and diagnostics before applying.' if state=='awaiting_review' else 'Reviewed changes saved as revision '+str(r['applied_revision'])+'. '+summary if state=='completed' and r.get('applied_revision') else summary if state=='completed' else 'Development task failed: '+str(j.get('error') or 'Try a smaller change.') if state=='failed' else 'Development task cancelled. No proposal was applied.' if state=='cancelled' else '')
        if not content:return
        for message in c.execute("SELECT id,metadata FROM messages WHERE conversation_id=? AND role='assistant' ORDER BY created DESC LIMIT 100",(cid,)).fetchall():
            meta=json.loads(message['metadata'])
            if meta.get('beast_job_id')==jid:
                meta.update(beast_state=state)
                if r.get('elapsed') is not None:meta.update(elapsed=r['elapsed'],selection=r.get('selection'))
                c.execute('UPDATE messages SET content=?,metadata=? WHERE id=?',(content,encode(meta),message['id']));break
    def list(self,uid):
        with self.connect() as c:
            rows=[]
            for r in c.execute('SELECT * FROM beast_projects WHERE user_id=? ORDER BY updated DESC',(uid,)).fetchall():
                try:self.require(c,uid,r['id'])
                except PermissionError:continue
                rows.append(dict(r))
            return rows
    def capacity(self,c,uid,blob):
        used=c.execute('SELECT coalesce(sum(length(r.files)),0) FROM beast_revisions r JOIN beast_projects p ON p.id=r.project_id WHERE p.user_id=?',(uid,)).fetchone()[0]
        if used+len(blob)>512*1024*1024:raise ValueError('This account reached 512 MB of compressed source history. Export and delete an unneeded project before saving more.')
    def project(self,uid,pid):
        with self.connect() as c:
            p=self.require(c,uid,pid);p['files']=self.files(c,pid,p['revision'])
            p['history']=[dict(r) for r in c.execute('SELECT revision,label,created FROM beast_revisions WHERE project_id=? ORDER BY revision DESC LIMIT 100',(pid,))]
            p['checkpoints']=[dict(r) for r in c.execute('SELECT id,revision,name,created FROM beast_checkpoints WHERE project_id=? ORDER BY created DESC LIMIT 100',(pid,))]
            p['jobs']=[self.public_job(r) for r in c.execute('SELECT * FROM beast_jobs WHERE project_id=? ORDER BY created DESC LIMIT 30',(pid,))]
            p['activity']=[dict(r) for r in c.execute('SELECT * FROM beast_activity WHERE project_id=? ORDER BY id DESC LIMIT 100',(pid,))]
            checks=c.execute('SELECT * FROM beast_checks WHERE project_id=? ORDER BY created DESC LIMIT 1',(pid,)).fetchone();p['checks']=dict(checks) if checks else None
            if p['checks']:p['checks']['result']=json.loads(p['checks']['result'])
            return p
    def create(self,uid,d):
        name=d.get('name','Untitled project');brief=d.get('brief','')
        if not isinstance(name,str) or not 1<=len(name.strip())<=80 or not isinstance(brief,str) or len(brief)>6000:raise ValueError('Use a project name up to 80 characters and a brief up to 6,000.')
        no_secrets(name);no_secrets(brief)
        files=validate_files(d.get('files') if d.get('files') is not None else starter(name.strip(),d.get('template','website')))
        pid=ident();now=stamp()
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute('SELECT count(*) FROM beast_projects WHERE user_id=?',(uid,)).fetchone()[0]>=50:raise ValueError('This account has reached the 50-project limit.')
            blob=pack(files);self.capacity(c,uid,blob)
            c.execute('INSERT INTO beast_projects VALUES(?,?,?,?,?,?,?)',(pid,uid,name.strip(),brief,1,now,now))
            c.execute('INSERT INTO beast_revisions VALUES(?,?,?,?,?)',(pid,1,blob,'Initial source',now));self.log(c,pid,'project','Created project. '+str(len(files))+' files saved.')
        return self.project(uid,pid)
    def revision(self,c,pid,expected,files,label):
        p=c.execute('SELECT revision FROM beast_projects WHERE id=?',(pid,)).fetchone()
        if not isinstance(expected,int) or isinstance(expected,bool) or p[0]!=expected:raise Conflict('The project changed in another tab. Reload it and review your edit again.')
        files=validate_files(files)
        if expected>=250:raise ValueError('This project has reached 250 saved revisions. Export it and start a new project.')
        blob=pack(files);owner=c.execute('SELECT user_id FROM beast_projects WHERE id=?',(pid,)).fetchone()[0];self.capacity(c,owner,blob)
        rev=expected+1;now=stamp();c.execute('INSERT INTO beast_revisions VALUES(?,?,?,?,?)',(pid,rev,blob,label[:120],now));c.execute('UPDATE beast_projects SET revision=?,updated=? WHERE id=?',(rev,now,pid));self.log(c,pid,'revision',label+' · revision '+str(rev));return rev
    def edit(self,uid,d):
        pid=d.get('project_id');action=d.get('action');name=d.get('path')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');p=self.require(c,uid,pid);files=self.files(c,pid,p['revision'])
            if action=='write':files[path(name)]=record(name,d.get('file',d.get('content')));label='Saved '+name
            elif action=='delete':
                if name not in files:raise KeyError()
                files.pop(name);label='Deleted '+name
            elif action=='rename':
                if name not in files:raise KeyError()
                target=path(d.get('to'))
                if target in files:raise Conflict('The destination already exists.')
                files[target]=files.pop(name);label='Renamed '+name+' to '+target
            elif action=='import':
                incoming=validate_files(d.get('files'))
                if any(k in files for k in incoming):raise Conflict('Import contains an existing path. Rename it or edit the existing file explicitly.')
                files.update(incoming);label='Imported '+str(len(incoming))+' files'
            elif action=='restore':
                files=self.files(c,pid,int(d.get('restore_revision',0)));label='Restored revision '+str(d['restore_revision'])
            else:raise ValueError('Unsupported file action.')
            self.revision(c,pid,d.get('revision'),files,label)
        return self.project(uid,pid)
    def checkpoint(self,uid,d):
        name=d.get('name','')
        if not isinstance(name,str) or not 1<=len(name.strip())<=80:raise ValueError('Name this checkpoint (up to 80 characters).')
        no_secrets(name)
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');p=self.require(c,uid,d.get('project_id'))
            if d.get('revision')!=p['revision']:raise Conflict('Reload the current revision before saving a checkpoint.')
            if c.execute('SELECT count(*) FROM beast_checkpoints WHERE project_id=?',(p['id'],)).fetchone()[0]>=100:raise ValueError('Checkpoint limit reached.')
            c.execute('INSERT INTO beast_checkpoints VALUES(?,?,?,?,?)',(ident(),p['id'],p['revision'],name.strip(),stamp()));self.log(c,p['id'],'checkpoint','Checkpoint: '+name)
        return self.project(uid,p['id'])
    def delete(self,uid,d):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');p=self.require(c,uid,d.get('project_id'))
            if d.get('confirmation')!=p['name']:raise ValueError('Type the exact project name to delete it.')
            if c.execute('SELECT 1 FROM admin_source_workspaces WHERE project_id=?',(p['id'],)).fetchone():raise ValueError('The administrator source workspace is retained for maintenance history.')
            if c.execute("SELECT 1 FROM beast_jobs WHERE project_id=? AND state IN ('queued','running')",(p['id'],)).fetchone():raise Conflict('Cancel the active job before deleting this project.')
            for t in ['beast_activity','beast_checks','beast_checkpoints','beast_jobs','beast_revisions']:c.execute('DELETE FROM '+t+' WHERE project_id=?',(p['id'],))
            c.execute('DELETE FROM beast_projects WHERE id=?',(p['id'],))
        return {'deleted':True}
    def diff(self,uid,pid,before=None,after=None):
        with self.connect() as c:
            p=self.require(c,uid,pid);after=int(after or p['revision']);before=int(before if before is not None else max(1,after-1));a=self.files(c,pid,before);b=self.files(c,pid,after)
        return {'before':before,'after':after,'diff':diff_files(a,b)}
    def export(self,uid,pid):
        p=self.project(uid,pid);out=io.BytesIO();files=validate_files(p['files']);checks=p['checks']
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
            for name,v in files.items():z.writestr(name,bytes_of(v))
            status={'project':p['name'],'revision':p['revision'],'exported_at':stamp(),'checks':checks if checks and checks['revision']==p['revision'] else None,'execution':'Unavailable: no isolated application build/test service is configured.','preview':'HTML/CSS and local image assets only; scripts, forms and external requests disabled.'}
            name='SYNERGY_VALIDATION.json'
            while name in files:name='_'+name
            z.writestr(name,json.dumps(status,indent=2))
        return out.getvalue(),re.sub(r'[^a-zA-Z0-9_-]+','-',p['name']).strip('-')+'-r'+str(p['revision'])+'.zip'
    def save_checks(self,uid,pid,rev,result):
        with self.connect() as c:
            self.require(c,uid,pid);self.files(c,pid,rev)
            c.execute('INSERT INTO beast_checks VALUES(?,?,?,?,?)',(ident(),pid,rev,encode(result),stamp()));self.log(c,pid,'checks','Checked revision '+str(rev)+': '+str(result['passed'])+' passed, '+str(result['failed'])+' failed, '+str(result['skipped'])+' unsupported.')
        return {'revision':rev,'result':result}
    def submit(self,uid,d,skill='',sources=None):
        if getattr(self,'access',None):self.access(uid,'beast')
        if getattr(self,'provider_access',None):self.provider_access(uid,d.get('provider','synergy'),'beast')
        family=d.get('model_family','eternal')
        if family not in {'eternal','aerny'}:raise ValueError('Choose ETERNAL or Aerny.')
        pid=d.get('project_id');prompt=d.get('prompt','');mode=d.get('task_mode','change');key=d.get('idempotency_key')
        if not isinstance(prompt,str) or not 1<=len(prompt.strip())<=6000:raise ValueError('Describe the task in up to 6,000 characters.')
        no_secrets(prompt)
        if mode not in {'change','explain'}:raise ValueError('Choose Change or Explain.')
        if not isinstance(key,str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,100}',key):raise ValueError('A request identifier is required.')
        if d.get('provider','synergy') not in {'synergy','hybrid','openai'} or d.get('local_model','auto') not in {'auto','balanced','fast','vision'} or d.get('effort','high') not in {'instant','medium','high','max','ultra'}:raise ValueError('Choose a configured model and response level.')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');p=self.require(c,uid,pid)
            prior=c.execute('SELECT * FROM beast_jobs WHERE project_id=? AND idempotency_key=?',(pid,key)).fetchone()
            if prior:return self.public_job(prior)
            if d.get('revision')!=p['revision']:raise Conflict('Reload the project before starting a new task.')
            if c.execute("SELECT 1 FROM beast_jobs WHERE project_id=? AND state IN ('queued','running','awaiting_review')",(pid,)).fetchone():raise Conflict('Finish, discard or cancel the existing task first.')
            if c.execute("SELECT count(*) FROM beast_jobs WHERE state IN ('queued','running')").fetchone()[0]>=8:raise ValueError('The development queue is full. Try again after another task finishes.')
            files=self.files(c,pid,p['revision']);selected=d.get('paths')
            if selected is None:selected=[n for n,v in files.items() if v['encoding']=='utf-8']
            if not isinstance(selected,list) or len(selected)>12 or any(not isinstance(n,str) or n not in files or files[n]['encoding']!='utf-8' for n in selected):raise ValueError('Select up to 12 source files from this project.')
            selected=list(dict.fromkeys(selected))
            # Never truncate a code file. The user narrows the explicit file selection when necessary.
            context={n:files[n]['content'] for n in selected};sources=sources or []
            no_secrets(skill);no_secrets(encode(sources))
            region=d.get('region')
            if region:
                if not isinstance(region,dict):raise ValueError('Invalid source selection.')
                n=region.get('path');start=region.get('start');end=region.get('end')
                if n not in context or not isinstance(start,int) or not isinstance(end,int) or not 0<=start<end<=len(context[n]):raise ValueError('Select a valid text region in a selected file.')
                region={'path':n,'start':start,'end':end,'text':context[n][start:end]}
            budget_context={n:(region['text'] if region and n==region['path'] else v) for n,v in context.items()}
            if len(encode(budget_context))+len(prompt)+len(skill)+len(encode(sources))+len(encode(region))>22000:raise ValueError('The selected source exceeds the local context budget. Select fewer files or a smaller region; no source was truncated.')
            reference=d.get('reference_path');video=d.get('video_reference_id')
            if video:
                from .references import References
                References(self).get(uid,pid,video)
            if reference and (reference not in files or files[reference]['encoding']!='base64'):raise ValueError('Choose an image asset from this project.')
            auto_apply=False
            if d.get('_admin_auto_apply') is True:
                admin=c.execute("SELECT 1 FROM admin_source_workspaces a JOIN users u ON u.id=a.user_id WHERE a.user_id=? AND a.project_id=? AND u.role='admin' AND u.account_state='active'",(uid,pid)).fetchone()
                if not admin:raise PermissionError('Automatic source editing requires an administrator workspace.')
                auto_apply=mode=='change'
            request={'admin_auto_apply':auto_apply,'model_family':family,'prompt':prompt.strip(),'task_mode':mode,'paths':selected,'provider':d.get('provider','synergy'),'local_model':d.get('local_model','auto'),'openai_model':d.get('openai_model','auto'),'effort':d.get('effort','high'),'skill':skill,'sources':sources,'region':region,'reference_path':reference,'video_reference_id':video,'allow_external':bool(d.get('_allow_external',False)),'allow_free_data_use':bool(d.get('_allow_free_data_use',False)),'conversation_id':d.get('conversation_id')}
            jid=ident();now=stamp();c.execute('INSERT INTO beast_jobs(id,project_id,user_id,base_revision,state,request,created,updated,idempotency_key) VALUES(?,?,?,?,?,?,?,?,?)',(jid,pid,uid,p['revision'],'queued',encode(request),now,now,key));self.log(c,pid,'queued','Task queued. Base revision '+str(p['revision'])+'.',jid)
        return self.job(uid,jid)
    def public_job(self,row):
        j=dict(row);j['request']=json.loads(j['request']);j['result']=json.loads(j['result']) if j.get('result') else None
        j['request'].pop('skill',None);j['request'].pop('allow_external',None)
        return j
    def job(self,uid,jid):
        with self.connect() as c:
            r=c.execute('SELECT * FROM beast_jobs WHERE id=? AND user_id=?',(jid,uid)).fetchone()
            if not r:raise KeyError()
            self.require(c,uid,r['project_id']);j=self.public_job(r);j['activity']=[dict(a) for a in c.execute('SELECT kind,message,created FROM beast_activity WHERE job_id=? ORDER BY id',(jid,))];return j
    def job_action(self,uid,d):
        jid=d.get('id');action=d.get('action')
        if action!='cancel' and getattr(self,'access',None):self.access(uid,'beast')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');row=c.execute('SELECT * FROM beast_jobs WHERE id=? AND user_id=?',(jid,uid)).fetchone()
            if not row:raise KeyError()
            j=dict(row);p=self.require(c,uid,j['project_id'])
            if action=='cancel':
                if j['state'] not in {'queued','running','awaiting_review'}:raise Conflict('This task has already finished.')
                c.execute("UPDATE beast_jobs SET state='cancelled',updated=? WHERE id=?",(stamp(),jid));self.log(c,p['id'],'cancelled','Task cancelled; no proposal was applied.',jid)
            elif action=='apply':
                if j['state']!='awaiting_review':raise Conflict('This task is not awaiting review.')
                result=json.loads(j['result'])
                if d.get('reviewed_hash')!=result['hash']:raise Conflict('Review the current proposal before applying it.')
                if d.get('revision')!=j['base_revision']:raise Conflict('The reviewed project revision does not match.')
                current=self.files(c,p['id'],j['base_revision']);files=apply_changes(current,result['changes'])
                rev=self.revision(c,p['id'],j['base_revision'],files,'Applied Aerny proposal '+jid[:8]);result['applied_revision']=rev
                c.execute("UPDATE beast_jobs SET state='completed',result=?,updated=? WHERE id=?",(encode(result),stamp(),jid));self.log(c,p['id'],'applied','Reviewed changes applied to revision '+str(rev)+'.',jid)
            else:raise ValueError('Choose apply or cancel.')
            self.conversation_update(c,jid)
        return self.job(uid,jid)
    def worker_status(self):
        with self.connect() as c:r=c.execute("SELECT heartbeat,pid FROM beast_worker WHERE id='local'").fetchone()
        return {'running':bool(r and stamp()-r['heartbeat']<12),'heartbeat':r['heartbeat'] if r else None,'concurrency':1,'execution_available':False}

def diff_files(a,b):
    chunks=[]
    for name in sorted(set(a)|set(b)):
        before=a.get(name);after=b.get(name)
        if before==after:continue
        if (before and before['encoding']=='base64') or (after and after['encoding']=='base64'):
            chunks.append('Binary asset changed: '+name+'\n');continue
        for line in difflib.unified_diff((before or {'content':''})['content'].splitlines(True),(after or {'content':''})['content'].splitlines(True),fromfile='a/'+name if before else '/dev/null',tofile='b/'+name if after else '/dev/null'):
            chunks.append(line if line.endswith('\n') else line+'\n\\ No newline at end of file\n')
    return ''.join(chunks)

def apply_changes(files,changes):
    result=dict(files)
    for change in changes:
        name=path(change['path'])
        if change['operation']=='delete':
            if name not in result:raise ValueError('Cannot delete a missing file.')
            result.pop(name)
        else:result[name]=record(name,change['content'])
    return validate_files(result)

def validate_proposal(value,files,request):
    if not isinstance(value,dict) or set(value)-{'summary','plan','changes','notes'}:raise ValueError('The model returned an unsupported response schema.')
    summary=value.get('summary');plan=value.get('plan',[]);notes=value.get('notes',[]);changes=value.get('changes',[])
    if not isinstance(summary,str) or not 1<=len(summary)<=3000 or not isinstance(plan,list) or not isinstance(notes,list) or len(plan)>8 or len(notes)>10 or any(not isinstance(x,str) or len(x)>1500 for x in plan+notes):raise ValueError('The model returned an invalid summary or plan.')
    if not isinstance(changes,list) or len(changes)>8 or request['task_mode']=='explain' and changes:raise ValueError('Explain tasks cannot change source files.')
    seen=set();region=request.get('region')
    for change in changes:
        if not isinstance(change,dict) or set(change) not in ({'path','operation','content'},{'path','operation','before','content'}):raise ValueError('The model returned an invalid file change.')
        n=path(change['path'])
        if n in seen or change['operation'] not in {'write','delete','replace','append'}:raise ValueError('Duplicate or unsupported file change.')
        seen.add(n)
        if not isinstance(change['content'],str) or len(change['content'].encode())>128*1024:raise ValueError('The model response contains an oversized file.')
        if n in files and n not in request['paths']:raise ValueError('The model tried to edit a file outside the selected context.')
        if change['operation'] in {'append','replace'}:
            if region or n not in files or files[n]['encoding']!='utf-8':raise ValueError('Structured edits require a selected existing text file, without a region selection.')
            original=files[n]['content']
            if change['operation']=='append':change['content']=original+change['content']
            else:
                before=change.get('before')
                if not isinstance(before,str) or not before or len(before)>128*1024 or original.count(before)!=1:raise ValueError('The proposed edit does not match one exact source block. No source was changed; narrow the edit and retry.')
                change['content']=original.replace(before,change['content'],1)
            change['operation']='write'
        change.pop('before',None)
        if region:
            if len(changes)!=1 or n!=region['path'] or change['operation']!='write':raise ValueError('The model tried to edit outside the selected region.')
            original=files[n]['content'];change['content']=original[:region['start']]+change['content']+original[region['end']:]
    no_secrets(encode(value));updated=apply_changes(files,changes)
    preserve_python(files,updated,request['prompt'])
    result={'summary':summary,'plan':plan,'changes':changes,'notes':notes,'diff':diff_files(files,updated)}
    result['hash']=digest(result);return result,updated

def preserve_python(before,after,prompt):
    """Conservative regression gate; this is not a general semantic verifier."""
    explicit_removal=any(not re.search(r'\b(?:not|never|without|don.t)\b',prompt[max(0,m.start()-30):m.start()],re.I) for m in re.finditer(r'\b(?:remove|delete|rename|replace|rewrite)\b',prompt,re.I))
    for name,old in before.items():
        if not name.endswith('.py') or name not in after or old==after[name]:continue
        try:a=ast.parse(old['content']);b=ast.parse(after[name]['content'])
        except (SyntaxError,ValueError):continue  # Actual syntax diagnostics report this separately.
        defs=lambda tree:{n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
        old_defs=defs(a);new_defs=defs(b);missing=set(old_defs)-set(new_defs)
        if missing and not explicit_removal:raise ValueError('The proposal removed existing Python definitions ('+', '.join(sorted(missing))+'). No source was changed. Ask for a smaller edit or select the exact region.')
        # Honour explicit preservation of a named existing definition or the entry point.
        for n,old_node in old_defs.items():
            if re.search(r'(?:preserve|without changing|keep|do not (?:change|remove|delete))[^.\n]{0,150}\b'+re.escape(n)+r'\b',prompt,re.I) and (n not in new_defs or ast.dump(old_node)!=ast.dump(new_defs[n])):raise ValueError('The proposal changed '+n+' despite the preservation request. No source was changed.')
        if re.search(r'(?:preserve|without changing|keep|do not change)[^.\n]{0,180}(?:command.line|entry.point|__main__)',prompt,re.I):
            entry=lambda tree:[ast.dump(n) for n in tree.body if isinstance(n,ast.If) and '__name__' in ast.dump(n.test) and '__main__' in ast.dump(n.test)]
            if entry(a)!=entry(b):raise ValueError('The proposal changed the Python entry point despite the preservation request. No source was changed.')
