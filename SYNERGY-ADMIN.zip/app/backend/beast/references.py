"""Preserved, private video references with bounded local frame extraction."""
import base64,hashlib,json,math,os,re,shutil,subprocess,tempfile,time,uuid
from pathlib import Path
MAX_VIDEO=200*1024*1024
class References:
 def __init__(self,store):
  self.store=store;self.root=store.root/'references';self.root.mkdir(exist_ok=True,mode=0o700)
  with store.connect() as c:c.execute('CREATE TABLE IF NOT EXISTS beast_references(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,project_id TEXT NOT NULL,name TEXT NOT NULL,metadata TEXT NOT NULL,created REAL NOT NULL)')
 def get(self,uid,pid,rid):
  with self.store.connect() as c:
   self.store.require(c,uid,pid);r=c.execute('SELECT * FROM beast_references WHERE id=? AND user_id=? AND project_id=?',(rid,uid,pid)).fetchone()
   if not r:raise KeyError('Reference not found.')
  return {**dict(r),'metadata':json.loads(r['metadata'])}
 def list(self,uid,pid):
  with self.store.connect() as c:
   self.store.require(c,uid,pid);rows=c.execute('SELECT * FROM beast_references WHERE user_id=? AND project_id=? ORDER BY created',(uid,pid)).fetchall()
  return [{**dict(r),'metadata':json.loads(r['metadata'])} for r in rows]
 def upload(self,uid,pid,raw,name):
  size=raw.stat().st_size if isinstance(raw,Path) else len(raw) if isinstance(raw,bytes) else 0
  if not 0<size<=MAX_VIDEO:raise ValueError('Use a video under 200 MB and up to 30 minutes.')
  ext=Path(str(name)).suffix.lower()
  if ext not in {'.mp4','.mov','.webm'}:raise ValueError('Use an MP4, MOV or WebM reference.')
  if len(self.list(uid,pid))>=3:raise ValueError('This project already has three video references. Remove one before uploading another.')
  ffmpeg=shutil.which('ffmpeg');ffprobe=shutil.which('ffprobe')
  if not ffmpeg or not ffprobe:raise ValueError('Video reference processing needs FFmpeg and FFprobe on this server.')
  rid=uuid.uuid4().hex;folder=self.root/rid;folder.mkdir(mode=0o700);original=folder/('original'+ext);shutil.copyfile(raw,original) if isinstance(raw,Path) else original.write_bytes(raw);original.chmod(0o600)
  try:
   probe=subprocess.run([ffprobe,'-v','error','-protocol_whitelist','file,pipe','-max_alloc','67108864','-show_format','-show_streams','-of','json',str(original)],capture_output=True,timeout=20,check=True)
   if len(probe.stdout)>128000:raise ValueError('The video metadata exceeds the supported limit.')
   data=json.loads(probe.stdout);fmt=data.get('format',{});duration=float(fmt.get('duration',0));streams=[s for s in data.get('streams',[]) if s.get('codec_type')=='video'];stream=streams[0] if streams else {}
   if not math.isfinite(duration) or not 0<duration<=1800 or not any(x in fmt.get('format_name','').split(',') for x in ['mov','mp4','matroska','webm']) or not 0<int(stream.get('width',0))<=3840 or not 0<int(stream.get('height',0))<=2160:raise ValueError('Use a playable MP4/MOV/WebM, up to 30 minutes and 3840 × 2160.')
   frames=[]
   for i,fraction in enumerate([.02,.33,.66,.95]):
    second=round(min(duration*fraction,max(0,duration-.5)),3);frame=folder/f'frame-{i}.jpg'
    subprocess.run([ffmpeg,'-v','error','-nostdin','-protocol_whitelist','file,pipe','-max_alloc','67108864','-threads','1','-ss',str(second),'-i',str(original),'-map','0:v:0','-frames:v','1','-vf','scale=960:960:force_original_aspect_ratio=decrease','-threads','1','-q:v','4',str(frame)],capture_output=True,timeout=20,check=True)
    if not frame.is_file() or not 0<frame.stat().st_size<1024*1024:raise ValueError('A preview frame could not be extracted.')
    frame.chmod(0o600);frames.append({'index':i,'second':second})
   digest=hashlib.sha256()
   with original.open('rb') as f:
    for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
   meta={'sha256':digest.hexdigest(),'bytes':size,'duration':duration,'width':stream['width'],'height':stream['height'],'format':ext,'frames':frames,'analysis':'Four sampled frames; audio and hidden interaction logic are not analysed.'}
   clean=re.sub(r'[^\w .()-]','_',Path(str(name)).name)[:120]
   with self.store.connect() as c:
    c.execute('BEGIN IMMEDIATE');self.store.require(c,uid,pid)
    if c.execute('SELECT count(*) FROM beast_references WHERE user_id=? AND project_id=?',(uid,pid)).fetchone()[0]>=3:raise ValueError('This project has reached its video reference limit.')
    c.execute('INSERT INTO beast_references VALUES(?,?,?,?,?,?)',(rid,uid,pid,clean,json.dumps(meta),time.time()))
   return self.get(uid,pid,rid)
  except (subprocess.SubprocessError,ValueError,KeyError,TypeError,OverflowError):
   shutil.rmtree(folder,ignore_errors=True);raise ValueError('Could not read this reference. Use a playable MP4/MOV/WebM under 200 MB, up to 30 minutes, with a maximum size of 3840 × 2160.') from None
 def bytes(self,uid,pid,rid,index=None):
  r=self.get(uid,pid,rid)
  if index is not None and index not in range(4):raise ValueError('Frame not found.')
  file=self.root/rid/(f'frame-{index}.jpg' if index is not None else 'original'+r['metadata']['format'])
  return file.read_bytes(),('frame-'+str(index)+'.jpg' if index is not None else r['name'])
 def images(self,uid,pid,rid):return [base64.b64encode(self.bytes(uid,pid,rid,i)[0]).decode() for i in range(4)]
 def delete(self,uid,pid,rid):
  self.get(uid,pid,rid)
  with self.store.connect() as c:
   if c.execute("SELECT 1 FROM beast_jobs WHERE project_id=? AND state IN ('queued','running')",(pid,)).fetchone():raise ValueError('Wait for the active task before removing a reference.')
   c.execute('DELETE FROM beast_references WHERE id=? AND user_id=?',(rid,uid))
  shutil.rmtree(self.root/rid,ignore_errors=True);return {'ok':True}
