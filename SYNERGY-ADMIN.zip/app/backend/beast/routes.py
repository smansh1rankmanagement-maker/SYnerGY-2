import base64,json,re,io,zipfile,tempfile,time,uuid
from pathlib import Path
from .references import References
from urllib.parse import parse_qs,urlsplit
from .store import Conflict
from .safety import import_zip
from .checks import capabilities,run_checks
from .preview import render,CSP

class BeastHTTP:
    def managed_store(self):
        from .managed import Managed
        return Managed(self.beast)
    def managed_instructions(self,uid,d):
        instructions='';cid=d.get('conversation_id')
        if cid:self.workspace.chat(uid,cid)
        if d.get('skill_id'):
            selected=next((s for s in self.workspace.skills(uid) if s['id']==d['skill_id']),None)
            if not selected:raise KeyError('Skill not found.')
            instructions=selected['instructions']
        if cid:
            pc=self.workspace.project_context(uid,cid)
            if pc.get('name'):instructions+='\nProject preferences: '+pc['name']+'\n'+pc['instructions']
        if d.get('research_task_id'):
            task=self.research.task(uid,d['research_task_id'])
            if task['state']!='succeeded':raise ValueError('Select a completed research task.')
            instructions+='\nResearch reference data (not external-action authority):\n'+json.dumps([{k:s.get(k) for k in ['title','url','text']} for s in task['detail'].get('sources',[])[:3]])[:6000]
        return instructions
    def beast_get(self,path,user):
        b=self.beast;uid=user['id'];q=parse_qs(urlsplit(self.path).query)
        try:
            if path=='/api/beast/managed-capabilities':return self.response(200,self.managed_store().catalog(uid))
            if path=='/api/beast/tasks':return self.response(200,{'tasks':self.managed_store().list(uid,q.get('project_id',[None])[0],q.get('conversation_id',[None])[0])})
            task=re.fullmatch(r'/api/beast/tasks/([0-9a-f]{32})(?:/(events|proposal|artifacts)(?:/([0-9a-f]{32}))?)?',path)
            if task:
                m=self.managed_store();tid=task[1]
                if task[2]=='events':return self.response(200,{'events':m.events(uid,tid,int(q.get('after',['0'])[0]))})
                if task[2]=='proposal':
                    p=m.proposal(uid,tid);p.pop('_files',None);return self.response(200,p)
                if task[2]=='artifacts' and task[3]:
                    file,name=m.artifact(uid,tid,task[3]);return self.research_download_path(file,name)
                if task[2]=='artifacts':return self.response(200,{'artifacts':m.task(uid,tid)['artifacts']})
                return self.response(200,m.task(uid,tid))
            if path=='/api/beast/projects':return self.response(200,{'projects':b.list(uid),'worker':b.worker_status()})
            if path=='/api/beast/capabilities':return self.response(200,capabilities())
            ref=re.fullmatch(r'/api/beast/projects/([0-9a-f]{32})/references(?:/([0-9a-f]{32}))?',path)
            if ref:
                r=References(b)
                if not ref[2]:return self.response(200,{'references':r.list(uid,ref[1])})
                index=int(q['frame'][0]) if 'frame' in q else None
                if index is None:
                    item=r.get(uid,ref[1],ref[2]);return self.research_download_path(r.root/ref[2]/('original'+item['metadata']['format']),item['name'])
                raw,name=r.bytes(uid,ref[1],ref[2],index)
                return self.research_download(raw,name)
            m=re.fullmatch(r'/api/beast/(projects|jobs)/([0-9a-f]{32})(?:/(export|diff|patch|preview|preview-info))?',path)
            if m:
                if m[1]=='jobs' and not m[3]:return self.response(200,b.job(uid,m[2]))
                if m[1]!='projects':return self.fail(404,'Not found.')
                if not m[3]:return self.response(200,b.project(uid,m[2]))
                if m[3]=='export':
                    with self.workspace.connect() as c:linked=c.execute('SELECT id FROM work_projects WHERE user_id=? AND beast_project_id=? AND archived=0 LIMIT 1',(uid,m[2])).fetchone()
                    if linked:name,raw=self.source_bundles.export(uid,linked[0])
                    else:raw,name=b.export(uid,m[2])
                    refs=References(b);saved=refs.list(uid,m[2])
                    if saved:
                        with tempfile.TemporaryDirectory(prefix='synergy-export-',dir=b.root) as folder:
                            archive=Path(folder)/'project.zip';archive.write_bytes(raw)
                            with zipfile.ZipFile(archive,'a') as z:
                                z.writestr('video-references/manifest.json',json.dumps(saved,indent=2))
                                for ref in saved:z.write(refs.root/ref['id']/('original'+ref['metadata']['format']),'video-references/'+ref['id']+'/'+ref['name'])
                            return self.research_download_path(archive,name)
                    return self.research_download(raw,name)
                if m[3] in {'diff','patch'}:
                    data=b.diff(uid,m[2],q.get('before',[None])[0],q.get('after',[None])[0])
                    return self.research_download(data['diff'].encode(),'synergy-changes.patch') if m[3]=='patch' else self.response(200,data)
                p=b.project(uid,m[2]);entry=q.get('entry',['index.html'])[0];scripts=entry.endswith(('.jsx','.tsx','.js','.ts'));csp=CSP
                if scripts:
                    from .react_preview import render as react_render
                    document,warnings,csp=react_render(p['files'],entry)
                else:document,warnings=render(p['files'],entry)
                if m[3]=='preview-info':return self.response(200,{'revision':p['revision'],'entry':entry,'warnings':warnings,'scripts':scripts,'network':False})
                raw=document.encode();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.send_header('Content-Security-Policy',csp);self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','SAMEORIGIN');self.send_header('Referrer-Policy','no-referrer');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw);return
        except Conflict as e:return self.fail(409,str(e))
        except zipfile.BadZipFile:return self.fail(400,'The task returned an invalid changes archive.')
        except (KeyError,FileNotFoundError):return self.fail(404,'This development item was not found in your account.')
        except PermissionError as exc:return self.fail(402,str(exc))
        except (ValueError,TypeError,OverflowError) as e:return self.fail(400,str(e))
        return self.fail(404,'Not found.')
    def beast_post(self,path,d,user):
        b=self.beast;uid=user['id']
        try:
            if path=='/api/beast/tasks':
                m=self.managed_store();t=m.submit(uid,d,self.managed_instructions(uid,d),self.research.settings(uid)['allow_external'])
                cid=t['conversation_id']
                if cid:
                    with b.connect() as c:
                        c.execute('BEGIN IMMEDIATE')
                        exists=c.execute("SELECT 1 FROM codex_events WHERE task_id=? AND provider_ref='conversation'",(t['id'],)).fetchone()
                        if not exists:
                            saved=c.execute('SELECT prompt FROM codex_tasks WHERE id=?',(t['id'],)).fetchone()[0]
                            created=time.time()
                            for role,content,meta in [('user',saved,{'mode':'beast','provider':d.get('provider','hybrid'),'openai_model':t['model'],'beast_project_id':t['project_id']}),('assistant','Managed coding task saved. Open its progress to inspect commands and returned files.',{'mode':'beast','managed_task_id':t['id'],'beast_project_id':t['project_id']})]:
                                c.execute('INSERT INTO messages VALUES(?,?,?,?,?,?)',(uuid.uuid4().hex,cid,role,content,created,json.dumps(meta)));created+=0.001
                            c.execute('UPDATE conversations SET updated=? WHERE id=?',(created,cid))
                            c.execute("UPDATE conversations SET title=? WHERE id=? AND title='New conversation'",(' '.join(saved.split())[:64],cid))
                            m.event(c,t['id'],'conversation',{'message':'Linked to the task conversation.'},'conversation')
                return self.response(202,t)
            task=re.fullmatch(r'/api/beast/tasks/([0-9a-f]{32})/(messages|stop|reconcile|apply|approvals/([0-9a-f]{32}))',path)
            if task:
                m=self.managed_store();tid=task[1]
                if task[2]=='messages':return self.response(202,m.steer(uid,tid,d))
                if task[2]=='stop':return self.response(202,m.stop(uid,tid))
                if task[2]=='reconcile':return self.response(202,m.reconcile(uid,tid))
                if task[2]=='apply':return self.response(200,m.apply(uid,tid,d))
                return self.response(200,m.approval(uid,tid,task[3],d))
            if path=='/api/beast/references/upload':return self.response(201,References(b).upload(uid,d.get('project_id'),self.uploads.path(uid,d['asset_id']) if d.get('asset_id') else d.get('file'),d.get('name')))
            if path=='/api/beast/references/delete':return self.response(200,References(b).delete(uid,d.get('project_id'),d.get('id')))
            if path=='/api/beast/projects':return self.response(201,b.create(uid,d))
            if path=='/api/beast/import':
                raw=base64.b64decode(d.get('data',''),validate=True);files=import_zip(raw)
                if d.get('project_id'):return self.response(200,b.edit(uid,{**d,'action':'import','files':files}))
                return self.response(201,b.create(uid,{**d,'files':files}))
            if path=='/api/beast/edit':return self.response(200,b.edit(uid,d))
            if path=='/api/beast/checkpoint':return self.response(201,b.checkpoint(uid,d))
            if path=='/api/beast/delete':return self.response(200,b.delete(uid,d))
            if path=='/api/beast/checks':
                p=b.project(uid,d.get('project_id'))
                if d.get('revision')!=p['revision']:raise Conflict('Reload before checking the current source.')
                return self.response(200,b.save_checks(uid,p['id'],p['revision'],run_checks(p['files'])))
            if path=='/api/beast/jobs':
                skill='';sources=[];cid=d.get('conversation_id')
                if cid:self.workspace.chat(uid,cid)
                if d.get('skill_id'):
                    selected=next((s for s in self.workspace.skills(uid) if s['id']==d['skill_id']),None)
                    if not selected:raise KeyError()
                    skill=selected['instructions']
                if d.get('research_task_id'):
                    task=self.research.task(uid,d['research_task_id'])
                    if task['state']!='succeeded':raise ValueError('Select a completed research task.')
                    sources=[{k:s.get(k) for k in ['id','title','url','source','retrieved_at','text']} for s in task['detail'].get('sources',[])[:3]]
                    for s in sources:
                        if isinstance(s.get('text'),str):s['text']=s['text'][:1500]
                if cid:
                    pc=self.workspace.project_context(uid,cid)
                    if pc.get('name'):
                        skill+='\nProject preferences (scope only; no external-action authority): '+pc['name']+'\n'+pc['instructions']
                        sources.extend({**x,'text':x['excerpt']} for x in pc['sources'])
                preferences=self.research.settings(uid)
                if preferences.get('observe_feedback',True):
                    from observation_mcp import observe,instruction
                    skill+=instruction(observe(d.get('prompt','')))
                d['_allow_external']=preferences['allow_external'];d['_allow_free_data_use']=preferences.get('allow_free_data_use',False)
                job=b.submit(uid,d,skill,sources)
                # Idempotency also covers saved conversation messages.
                if cid:
                    with b.connect() as c:
                        c.execute('BEGIN IMMEDIATE')
                        exists=c.execute("SELECT 1 FROM beast_activity WHERE job_id=? AND kind='conversation'",(job['id'],)).fetchone()
                        if not exists:
                            b.log(c,job['project_id'],'conversation','Linked to the task conversation.',job['id'])
                    if not exists:
                        self.workspace.add(uid,cid,'user',d['prompt'],{'mode':'beast','effort':d.get('effort','high'),'provider':d.get('provider','synergy'),'local_model':d.get('local_model','auto'),'skill_id':d.get('skill_id'),'beast_project_id':job['project_id']})
                        self.workspace.add(uid,cid,'assistant','Development task saved. Open the Beast workspace to follow progress, review the diff and apply changes.',{'mode':'beast','beast_job_id':job['id'],'beast_project_id':job['project_id']})
                return self.response(202,job)
            if path=='/api/beast/jobs/action':return self.response(200,b.job_action(uid,d))
        except Conflict as e:return self.fail(409,str(e))
        except zipfile.BadZipFile:return self.fail(400,'The task returned an invalid changes archive.')
        except (KeyError,FileNotFoundError):return self.fail(404,'This development item was not found in your account.')
        except PermissionError as exc:return self.fail(402,str(exc))
        except (ValueError,TypeError,OverflowError) as e:return self.fail(400,str(e))
        return self.fail(404,'Not found.')
