"""Compile source with a fixed React/Motion toolchain; run only inside an opaque iframe."""
import base64,hashlib,json,shutil,subprocess,threading
_BUILD_SLOTS=threading.BoundedSemaphore(2)
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]/'builder-runtime'
def available():return bool(shutil.which('node') and (ROOT/'node_modules/esbuild').is_dir())
def render(files,entry):
 if not _BUILD_SLOTS.acquire(blocking=False):raise ValueError("Preview builds are busy. Try again shortly.")
 try:return _render(files,entry)
 finally:_BUILD_SLOTS.release()
def _render(files,entry):
 if entry not in files or not entry.endswith(('.jsx','.tsx','.js','.ts')):raise ValueError('Choose a saved React entry file.')
 if not available():raise ValueError('The React preview runtime is not installed. Download the source and follow its setup instructions.')
 try:p=subprocess.run([shutil.which('node'),'--max-old-space-size=384',str(ROOT/'compile.cjs')],input=json.dumps({'files':files,'entry':entry}).encode(),stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=25)
 except subprocess.TimeoutExpired:raise ValueError('Preview build reached its 25-second limit. Reduce the entry bundle.') from None
 if len(p.stdout)>8*1024*1024:raise ValueError('The compiled preview exceeds 8 MB.')
 try:r=json.loads(p.stdout)
 except ValueError:raise ValueError('Preview compiler stopped before returning a bundle.') from None
 if p.returncode or r.get('error'):raise ValueError(r.get('error','Preview compilation failed.'))
 js=r['js'].replace('</','<\\/');css=r['css'].replace('</','<\\/')
 digest=base64.b64encode(hashlib.sha256(js.encode()).digest()).decode()
 csp="default-src 'none'; script-src 'sha256-"+digest+"'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'self'; sandbox allow-scripts"
 doc='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SYnerGY React preview</title><style>'+css+'</style></head><body><div id="root"></div><script>'+js+'</script></body></html>'
 return doc,r.get('warnings',[])+['Isolated React preview. Network requests, forms and access to the SYnerGY account are blocked. No backend is connected.'],csp
