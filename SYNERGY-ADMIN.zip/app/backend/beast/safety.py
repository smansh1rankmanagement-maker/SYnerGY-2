"""Bounded source ingestion. Project content is never a host path or command."""
import base64, io, json, re, stat, zipfile
from pathlib import PurePosixPath

MAX_FILES = 600
MAX_TEXT = 2 * 1024 * 1024
MAX_BYTES = 24 * 1024 * 1024
MAX_ASSET = 1024 * 1024
TEXT_EXTENSIONS = set('html htm css scss sass less js mjs cjs jsx ts tsx json jsonc py pyi php sql java c h cpp hpp cs go rs rb swift kt kts dart sh bash ps1 r R md txt csv yaml yml toml xml svg ini cfg conf dockerfile gitignore env example lock graphql proto vue svelte'.lower().split())
TEXT_EXTENSIONS.update('command modelfile sha256 ex exs erl hrl hs lhs lua pl pm clj cljs cljc edn scala sc ml mli f90 f95 f03 f cob cbl jl v sv vhd vhdl asm s m mm coffee groovy rkt lisp lsp scm elm sml nix tf fs fsx sol vy zig d pas lpr ipynb tex cmake gradle properties bat cmd csproj fsproj sln vb vbs razor'.split())
BINARY = {'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp'}
SECRET = re.compile(r'-----BEGIN (?:[A-Z ]*PRIVATE KEY)-----|\b(?:sk-(?:proj-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[A-Z0-9]{16})\b', re.I)
ASSIGNMENT = re.compile(r'''(?im)["']?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|secret[_-]?key)["']?\s*[:=]\s*["']([^"'\n]{6,})["']''')

def no_secrets(text):
    if SECRET.search(text):
        raise ValueError('Remove credentials and private keys before adding project content.')
    for m in ASSIGNMENT.finditer(text):
        if m[1] in {'Password','new-password','current-password','Let’s get you back in.','A fresh start.','Enter your password.','Use 10–128 characters, including a letter and a number.','Show password','Show new Branch password'}:continue
        if not re.search(r'(?i)example|placeholder|your[-_ ]|replace|changeme|\$\{|process\.env|os\.environ|test[-_ ]|<|\*{3}',m[1]):
            raise ValueError('A possible credential was found. Use an environment variable or explicit placeholder.')
    return text

def path(value):
    if not isinstance(value,str) or not 1 <= len(value) <= 180 or not re.fullmatch(r'[A-Za-z0-9_@. /+()\-]+',value):
        raise ValueError('Use a relative project path with letters, numbers, spaces, dots, dashes or underscores.')
    parts=value.split('/')
    if any(p in {'','.', '..'} or p.endswith((' ','.')) for p in parts) or len(parts)>10:
        raise ValueError('The file path must stay inside the project.')
    denied={'.git','.ssh','.aws','.npmrc','.pypirc','node_modules','__pycache__','.ds_store','credentials','credentials.json','secrets.json','id_rsa','id_ed25519'}
    if any(p.lower() in denied or p.lower().startswith('.env') and p.lower() not in {'.env.example','.env.sample'} for p in parts):
        raise ValueError('Secrets, dependency folders and system metadata cannot be imported.')
    suffix=PurePosixPath(value).suffix.lower()
    if suffix.lstrip('.') not in TEXT_EXTENSIONS and suffix not in BINARY and parts[-1].lower() not in {'dockerfile','makefile','license','caddyfile','.gitignore','.env.example','.env.sample','.htaccess','.dockerignore'}:
        raise ValueError('Unsupported file type. Import source text or PNG, JPEG, GIF and WebP assets.')
    return value

def record(name,value):
    name=path(name)
    if isinstance(value,str):value={'content':value,'encoding':'utf-8'}
    if not isinstance(value,dict) or set(value)-{'content','encoding'}:raise ValueError('Invalid file record.')
    content=value.get('content');encoding=value.get('encoding','utf-8');suffix=PurePosixPath(name).suffix.lower()
    if not isinstance(content,str):raise ValueError('File content must be text.')
    if suffix in BINARY:
        if encoding!='base64':raise ValueError('Image assets must be base64 encoded.')
        try:raw=base64.b64decode(content,validate=True)
        except Exception:raise ValueError('Invalid image encoding.')
        if len(raw)>MAX_ASSET:raise ValueError('Each image asset must be at most 1 MB.')
        from PIL import Image
        try:
            with Image.open(io.BytesIO(raw)) as image:
                if image.width*image.height>16_000_000 or image.format not in {'PNG','JPEG','GIF','WEBP'}:raise ValueError()
                image.verify()
        except Exception:raise ValueError('Invalid or oversized image asset.')
    else:
        if encoding!='utf-8' or '\x00' in content:raise ValueError('Source files must contain UTF-8 text.')
        raw=no_secrets(content).encode()
        if len(raw)>MAX_TEXT:raise ValueError('Each source file must be at most 2 MB.')
    return {'content':content,'encoding':encoding}

def validate_files(files):
    if not isinstance(files,dict) or not 1<=len(files)<=MAX_FILES:raise ValueError('A project must contain 1–600 files.')
    checked={path(k):record(k,v) for k,v in files.items()}
    # Case-insensitive collisions are unsafe on the deployment Mac and in ZIP exports.
    folded=[p.casefold() for p in checked]
    if len(folded)!=len(set(folded)):raise ValueError('Two paths differ only by letter case.')
    if any(any('/'.join(p.split('/')[:i]).casefold() in folded for i in range(1,len(p.split('/')))) for p in checked):raise ValueError('A file cannot also be a folder.')
    if sum(len(bytes_of(v)) for v in checked.values())>MAX_BYTES:raise ValueError('Project contents exceed 24 MB.')
    return checked

def bytes_of(v):return base64.b64decode(v['content']) if v['encoding']=='base64' else v['content'].encode()

def import_zip(raw):
    if not isinstance(raw,bytes) or len(raw)>8*1024*1024:raise ValueError('Choose a ZIP smaller than 8 MB.')
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            entries=z.infolist()
            if len(entries)>1000:raise ValueError('The archive has too many entries.')
            out={};total=0
            for i in entries:
                name=i.filename
                if i.is_dir():
                    path(name.rstrip('/')+'/placeholder.txt');continue
                mode=i.external_attr>>16
                if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) and not stat.S_ISREG(mode)) or i.flag_bits & 1:raise ValueError('Links, devices and encrypted files are not supported.')
                path(name)
                if name in out:raise ValueError('The archive contains duplicate names.')
                total+=i.file_size
                if i.file_size>MAX_ASSET or total>MAX_BYTES or i.file_size>max(100000,i.compress_size*200):raise ValueError('Archive extraction limit exceeded.')
                content=z.read(i)
                if PurePosixPath(name).suffix.lower() in BINARY:out[name]={'content':base64.b64encode(content).decode(),'encoding':'base64'}
                else:out[name]={'content':content.decode('utf-8-sig'),'encoding':'utf-8'}
            return validate_files(out)
    except (zipfile.BadZipFile,UnicodeError,RuntimeError,NotImplementedError):raise ValueError('This is not a supported UTF-8 source ZIP.')
