"""Static design renderer: no script execution, network, frames or submissions."""
import base64, html, posixpath, re
from html.parser import HTMLParser
from urllib.parse import unquote,urlsplit
from .safety import BINARY,bytes_of

CSP="default-src 'none'; script-src 'none'; style-src 'unsafe-inline'; img-src data:; font-src 'none'; connect-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'self'; sandbox"
TAGS=set('a abbr address article aside b bdi bdo blockquote br button caption cite code col colgroup dd del details dfn div dl dt em fieldset figcaption figure footer h1 h2 h3 h4 h5 h6 header hgroup hr i img input ins kbd label legend li main mark menu nav ol optgroup option p pre q rp rt ruby s samp section select small source span strong sub summary sup table tbody td textarea tfoot th thead time tr u ul var wbr'.split())
VOID={'br','hr','img','input','source','wbr','col'}
DROP={'script','iframe','object','embed','svg','math','template','noscript','audio','video','title'}
ATTRS={'id','class','title','role','lang','dir','alt','width','height','colspan','rowspan','scope','datetime','open','for','type','value','placeholder','name','tabindex','hidden','loading','decoding'}

def resolve(base,value):
    parsed=urlsplit(value)
    if parsed.scheme or parsed.netloc or value.startswith('//'):return None
    p=unquote(parsed.path)
    n=posixpath.normpath(posixpath.join(posixpath.dirname(base),p)) if not p.startswith('/') else posixpath.normpath(p[1:])
    if n.startswith('../') or n=='..':return None
    return n

class Renderer(HTMLParser):
    def __init__(self,files,entry):
        super().__init__(convert_charrefs=True);self.files=files;self.entry=entry;self.out=[];self.skip=[];self.in_style=False;self.css=[];self.warnings=set()
    def asset(self,value,base):
        name=resolve(base,value);suffix=posixpath.splitext(name or '')[1].lower();v=self.files.get(name)
        if v and suffix in BINARY and v['encoding']=='base64':return 'data:'+BINARY[suffix]+';base64,'+v['content']
        self.warnings.add('External or unsupported image resources were omitted.');return ''
    def styles(self,value,base):
        if re.search(r'@import',value,re.I):self.warnings.add('CSS imports were omitted; use local stylesheet links.')
        value=re.sub(r'@import\s+(?:url\([^)]*\)|["\'][^"\']*["\'])[^;]*;?','',value,flags=re.I)
        value=re.sub(r'url\(\s*(["\']?)(.*?)\1\s*\)',lambda m:'url("'+self.asset(m[2],base)+'")',value,flags=re.I|re.S)
        return value.replace('</','<\\/').replace('\x00','')
    def handle_starttag(self,tag,attrs):
        if self.skip:
            if tag in DROP:self.skip.append(tag)
            return
        if tag in DROP:
            if tag!='title':self.warnings.add('Scripts and embedded applications are disabled in the design preview.')
            if tag not in {'embed'}:self.skip.append(tag)
            return
        a=dict(attrs)
        if tag=='style':self.in_style=True;self.css=[];return
        if tag=='link':
            if a.get('rel','').lower()=='stylesheet':
                name=resolve(self.entry,a.get('href',''));v=self.files.get(name)
                if v and v['encoding']=='utf-8' and name.endswith('.css'):self.out.append('<style>'+self.styles(v['content'],name)+'</style>')
                else:self.warnings.add('A missing or external stylesheet was omitted.')
            return
        if tag not in TAGS:return
        keep=[]
        for k,v in attrs:
            v=v or ''
            if k in ATTRS or k.startswith('aria-'):keep.append((k,v))
            elif k=='style':keep.append((k,self.styles(v,self.entry)))
            elif k=='href' and tag=='a' and v.startswith('#'):keep.append((k,v))
            elif k=='src' and tag=='img':keep.append((k,self.asset(v,self.entry)))
        if tag in {'button','input','select','textarea','option'}:keep.append(('disabled',''))
        if tag=='input':keep=[(k,v) for k,v in keep if k!='type']+[('type','text')]
        self.out.append('<'+tag+''.join(' '+k+'="'+html.escape(v,quote=True)+'"' for k,v in keep)+'>')
    def handle_startendtag(self,tag,attrs):
        self.handle_starttag(tag,attrs)
        if tag not in VOID:self.handle_endtag(tag)
    def handle_endtag(self,tag):
        if self.skip:
            if tag==self.skip[-1]:self.skip.pop()
            return
        if tag=='style' and self.in_style:
            self.out.append('<style>'+self.styles(''.join(self.css),self.entry)+'</style>');self.in_style=False;return
        if tag in TAGS and tag not in VOID:self.out.append('</'+tag+'>')
    def handle_data(self,data):
        if self.skip:return
        if self.in_style:self.css.append(data)
        else:self.out.append(html.escape(data))

def render(files,entry='index.html'):
    if entry not in files or not entry.lower().endswith(('.html','.htm')):raise ValueError('Choose a saved HTML file for the design preview.')
    parser=Renderer(files,entry);parser.feed(files[entry]['content']);parser.close()
    document='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SYnerGY project design preview</title></head><body>'+''.join(parser.out)+'</body></html>'
    return document,sorted(parser.warnings)
