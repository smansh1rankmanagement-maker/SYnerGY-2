"""Use the installed, pinned design search without project code execution."""
import json,re,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]/'skills'/'ui-ux-pro-max'
def guidance(prompt,files):
 if not re.search(r'\b(website|web\s?app|interface|ui|ux|design|layout|landing|responsive|animation|motion)\b',prompt,re.I):return None
 terms=re.findall(r'[\w-]+',prompt.lower());terms=[t for t in terms if t not in {'create','build','make','the','a','an','this','same','with','using','please','and','for','to'}][:5];query=' '.join(terms) or 'responsive interface'
 try:
  proc=subprocess.run([sys.executable,str(ROOT/'scripts/search.py'),query,'--design-system','--json'],capture_output=True,timeout=10,check=True)
  d=json.loads(proc.stdout);result={'source':'UI/UX Pro Max','pin':'d14efff8ed1faa4187f004f79926f428c8074ec7','query':query,'result':d,'status':'recommendations; preserve user/reference design priorities'}
 except (OSError,ValueError,subprocess.SubprocessError):result={'source':'SYnerGY defaults','status':'Design search unavailable; use accessibility and layout defaults.'}
 # Treat content as guidance; the source/visual reference and user brief have priority.
 result['motion']='React projects can import motion, AnimatePresence, useReducedMotion from framer-motion. The installed preview supports React + Framer Motion through a fixed compiler. Use transforms/opacity, respect reduced motion and keep controls accessible. Existing non-React projects should preserve their framework.'
 # Bounded context: structured highest-level matches rather than full database rows.
 if len(json.dumps(result))>6500:result['result']={k:v for k,v in d.get('design_system',d).items() if k in ['name','pattern','style','colors','typography','key_effects','anti_patterns']}
 return result
