"""Durable, account-scoped suggestions for work already running.

Suggestions are applied at the next safe step, never by mutating an in-flight
image render, shell action or reviewed source version. A dispatcher survives UI
closure and uses the underlying engines' idempotency keys across restarts.
"""
import json,sqlite3,threading,time,uuid
from urllib.parse import parse_qs,urlsplit
class LiveUpdates:
 def __init__(self,ws,research,beast,access):
  self.ws=ws;self.db=ws.db;self.research=research;self.beast=beast;self.access=access;self.guard=threading.Lock();self.stopping=threading.Event()
  with self.connect() as c:c.executescript('CREATE TABLE IF NOT EXISTS live_updates(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,conversation_id TEXT NOT NULL,kind TEXT NOT NULL,target_id TEXT NOT NULL,text TEXT NOT NULL,request_key TEXT NOT NULL,state TEXT NOT NULL,child_id TEXT,error TEXT NOT NULL DEFAULT "",created REAL NOT NULL,updated REAL NOT NULL,batch_id TEXT,UNIQUE(user_id,request_key));CREATE INDEX IF NOT EXISTS live_updates_pending ON live_updates(state,created);')
 def connect(self):
  c=sqlite3.connect(self.db,timeout=20);c.row_factory=sqlite3.Row;return c
 def target(self,uid,kind,tid):
  if kind=='research':
   t=self.research.task(uid,tid);return t,t['conversation_id'],t['request']['mode']
  if kind=='beast':
   t=self.beast.job(uid,tid);cid=t['request'].get('conversation_id')
   if not cid:raise ValueError('This code task is not attached to a conversation.')
   self.ws.chat(uid,cid);return t,cid,'beast'
  raise ValueError('Choose the current chat or code task.')
 def submit(self,uid,d):
  text=d.get('text','');key=d.get('request_key','')
  if not isinstance(text,str) or not 1<=len(text.strip())<=2000 or not isinstance(key,str) or not 8<=len(key)<=100:raise ValueError('Send a suggestion of up to 2,000 characters.')
  with self.guard:
   t,cid,mode=self.target(uid,d.get('kind'),d.get('target_id'));self.access(uid,mode)
   with self.connect() as c:
    c.execute('BEGIN IMMEDIATE');old=c.execute('SELECT * FROM live_updates WHERE user_id=? AND request_key=?',(uid,key)).fetchone()
    if old:return dict(old)
    if t['state'] not in {'queued','running'}:raise ValueError('That step has finished. Send your message as a normal follow-up.')
    pending=c.execute("SELECT count(*),coalesce(sum(length(text)),0) FROM live_updates WHERE user_id=? AND target_id=? AND state IN ('queued','dispatching')",(uid,d['target_id'])).fetchone()
    budget=5800-(len(t['request']['prompt'])+70 if d['kind']=='beast' else 0)
    if pending[0]>=10 or pending[1]+len(text)>budget:raise ValueError('The pending suggestions reached the context limit. Wait for the current step, or discard one suggestion.')
    now=time.time();rid=uuid.uuid4().hex;c.execute('INSERT INTO live_updates VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(rid,uid,cid,d['kind'],d['target_id'],text.strip(),key,'queued',None,'',now,now,None))
    return dict(c.execute('SELECT * FROM live_updates WHERE id=?',(rid,)).fetchone())
 def list(self,uid,cid):
  self.ws.chat(uid,cid)
  with self.connect() as c:rows=[dict(r) for r in c.execute('SELECT * FROM live_updates WHERE user_id=? AND conversation_id=? ORDER BY created DESC LIMIT 30',(uid,cid))]
  for r in rows:
   if r['child_id']:
    try:r['child_state']=self.target(uid,r['kind'],r['child_id'])[0]['state']
    except KeyError:r['child_state']='unavailable'
  return rows
 def cancel(self,uid,rid):
  with self.guard,self.connect() as c:
   r=c.execute('SELECT * FROM live_updates WHERE id=? AND user_id=?',(rid,uid)).fetchone()
   if not r:raise KeyError('Suggestion not found.')
   if r['state']!='queued':raise ValueError('This suggestion has already reached the next step. Stop that task instead.')
   c.execute("UPDATE live_updates SET state='cancelled',updated=? WHERE id=?",(time.time(),rid))
  return {'ok':True}
 def tick(self):
  if not self.guard.acquire(blocking=False):return
  try:
   with self.connect() as c:heads=c.execute("SELECT * FROM live_updates WHERE state IN ('queued','dispatching') GROUP BY user_id,kind,target_id ORDER BY created LIMIT 20").fetchall()
   for head in heads:
    try:
     t,cid,mode=self.target(head['user_id'],head['kind'],head['target_id'])
     if t['state'] in {'queued','running'}:continue
     with self.connect() as c:
      rows=c.execute("SELECT * FROM live_updates WHERE user_id=? AND kind=? AND target_id=? AND state IN ('queued','dispatching') ORDER BY created",(head['user_id'],head['kind'],head['target_id'])).fetchall()
      if not rows:continue
      batch=next((r['batch_id'] for r in rows if r['batch_id']),rows[0]['id'])
      # A recovery must replay the exact frozen batch, never absorb later messages.
      frozen=[r for r in rows if r['batch_id']==batch]
      if frozen:rows=frozen
     if t['state']=='cancelled' and not any(r['state']=='dispatching' for r in rows):raise ValueError('The original task was stopped. The suggestion was saved but not run; send it again when ready.')
     self.access(head['user_id'],mode)
     # Another conversation may own this user's research slot. Keep the queue durable.
     if head['kind']=='research':
      with self.connect() as c:
       active=c.execute("SELECT id,request_id FROM research_tasks WHERE user_id=? AND state IN ('queued','running')",(head['user_id'],)).fetchone()
       if active and active['request_id']!='followup-'+batch:continue
     with self.connect() as c:
      c.executemany("UPDATE live_updates SET state='dispatching',batch_id=?,updated=? WHERE id=?",[(batch,time.time(),r['id']) for r in rows])
     prompt='\n\n'.join(r['text'] for r in rows);request=dict(t['request'])
     if head['kind']=='beast':
      # Internal replay retains the original selected skill and opt-in; public jobs redact them.
      with self.connect() as c:request=json.loads(c.execute('SELECT request FROM beast_jobs WHERE id=?',(t['id'],)).fetchone()[0])
     if head['kind']=='research':
      child=self.research.submit(head['user_id'],{**request,'prompt':prompt,'conversation_id':cid,'browser':None,'request_id':'followup-'+batch})
     else:
      with self.connect() as c:prior=c.execute('SELECT id FROM beast_jobs WHERE project_id=? AND idempotency_key=?',(t['project_id'],'followup-'+batch)).fetchone()
      if prior:child=self.beast.job(head['user_id'],prior['id'])
      else:
       if t['state']=='awaiting_review':self.beast.job_action(head['user_id'],{'id':t['id'],'action':'cancel'})
       child=self.beast.submit(head['user_id'],{**request,'project_id':t['project_id'],'revision':t['base_revision'],'prompt':request['prompt']+'\n\nAdditional user instructions:\n'+prompt,'_allow_external':request.get('allow_external',False),'idempotency_key':'followup-'+batch},request.get('skill',''),request.get('sources',[]))
       self.ws.add(head['user_id'],cid,'user',prompt,{'mode':'beast','live_update_batch':batch,'beast_job_id':child['id']})
     with self.connect() as c:c.execute("UPDATE live_updates SET state='started',child_id=?,error='',updated=? WHERE batch_id=?",(child['id'],time.time(),batch))
    except (ValueError,KeyError,PermissionError) as e:
     with self.connect() as c:c.execute("UPDATE live_updates SET state='blocked',error=?,updated=? WHERE user_id=? AND target_id=? AND state IN ('queued','dispatching')",(str(e)[:500],time.time(),head['user_id'],head['target_id']))
    except sqlite3.OperationalError:pass
  finally:self.guard.release()
 def start(self):
  def loop():
   while not self.stopping.wait(1):
    try:self.tick()
    except Exception:pass # Durable rows remain available after a transient worker failure.
  threading.Thread(target=loop,daemon=True,name='synergy-live-updates').start()
class LiveUpdatesHTTP:
 def updates_get(self,user):
  try:return self.response(200,{'updates':self.live_updates.list(user['id'],parse_qs(urlsplit(self.path).query).get('conversation_id',[''])[0])})
  except KeyError:return self.fail(404,'Conversation not found.')
 def updates_post(self,path,d,user):
  try:return self.response(200,self.live_updates.cancel(user['id'],d.get('id')) if path.endswith('/cancel') else self.live_updates.submit(user['id'],d))
  except PermissionError as e:return self.fail(402,str(e))
  except KeyError:return self.fail(404,'Task not found.')
  except (ValueError,TypeError) as e:return self.fail(400,str(e))
