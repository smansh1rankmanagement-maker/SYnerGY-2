"""Authorized free-model failover. No paid fallbacks, account-limit bypass or training.

Credentials live outside source. Provider/model audit records contain no prompts.
The same opt-in gate applies to Chat, Work, Beast and uploaded project content.
"""
import json,os,re,sqlite3,time,urllib.request,urllib.error,uuid
from pathlib import Path
from decimal import Decimal,InvalidOperation

BASE='https://openrouter.ai/api/v1'
PREFERRED=['google/gemma-4-26b-a4b-it:free','google/gemma-4-31b-it:free','nvidia/nemotron-3.5-lightning:free','liquid/lfm-2.5-2.6b:free','cohere/north-mini-code:free','openrouter/free']

def credential():
    p=os.environ.get('SYNERGY_OPENROUTER_KEY_FILE','')
    try:value=Path(p).read_text().strip() if p else ''
    except OSError:return ''
    return value if value.startswith('sk-or-v1-') and len(value)<300 else ''
def gemini_credential():
    try:return Path(os.environ.get('SYNERGY_GEMINI_KEY_FILE','')).read_text().strip()
    except OSError:return ''
def gemini_enabled():return os.environ.get('SYNERGY_GEMINI_FREE_TIER')=='1' and bool(gemini_credential())
def gemini_models():
    names=os.environ.get('SYNERGY_GEMINI_MODELS','gemini-3.1-pro-preview').split(',')
    return [n.strip() for n in names[:3] if re.fullmatch(r'gemini-[a-z0-9.-]{1,80}',n.strip())]
def gemini_paid_access(user_id):
    """Fail closed, reading current subscription state immediately before inference.

    user_id comes from the authenticated job owner, never the request body.
    Administrator role alone and the free Chat trial do not unlock this key.
    Existing administrator-granted Work/Beast subscriptions remain eligible.
    """
    if type(user_id) is not int or user_id<=0:return False
    path=root()/'accounts.sqlite3'
    try:
        with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=5) as c:
            now=time.time()
            return bool(c.execute("SELECT 1 FROM users u JOIN subscriptions s ON s.user_id=u.id WHERE u.id=? AND u.account_state='active' AND s.state='active' AND s.mode IN ('work','beast') AND s.starts<=? AND s.expires>? LIMIT 1",(user_id,now,now)).fetchone())
    except (OSError,ValueError,sqlite3.Error):return False
def enabled():return bool(credential()) or gemini_enabled()
def root():
    p=Path(os.environ.get('SYNERGY_DATA_DIR',str(Path.home()/'.synergy-ai')));p.mkdir(parents=True,exist_ok=True);return p

def database():
    c=sqlite3.connect(root()/'free-routing.sqlite3',timeout=10);c.row_factory=sqlite3.Row
    c.execute('CREATE TABLE IF NOT EXISTS routes(id TEXT PRIMARY KEY, created REAL, model TEXT, status TEXT, http_status INTEGER, seconds REAL)')
    c.execute('CREATE TABLE IF NOT EXISTS cooldown(scope TEXT PRIMARY KEY, until REAL, reason TEXT)')
    return c

def audit(model,status,code,started):
    with database() as c:c.execute('INSERT INTO routes VALUES(?,?,?,?,?,?)',(uuid.uuid4().hex,time.time(),model,status,code,round(time.monotonic()-started,3)))
def cooldown(scope,seconds,reason):
    with database() as c:c.execute('INSERT OR REPLACE INTO cooldown VALUES(?,?,?)',(scope,time.time()+min(max(seconds,1),86400),reason))
def cooling(scope):
    with database() as c:r=c.execute('SELECT until FROM cooldown WHERE scope=?',(scope,)).fetchone()
    return bool(r and r['until']>time.time())

def public_model(m):
    pricing=m.get('pricing',{});architecture=m.get('architecture',{})
    try:free=all(Decimal(str(v))==0 for k,v in pricing.items() if k not in {'discount'}) and all(k in pricing for k in ['prompt','completion'])
    except (InvalidOperation,TypeError):free=False
    return {'id':m['id'],'name':m.get('name',m['id']),'free':free,'pricing':pricing,
            'input_modalities':architecture.get('input_modalities',[]),'output_modalities':architecture.get('output_modalities',[]),'context_length':m.get('context_length',0)}

def catalog(refresh=False):
    path=root()/'free-model-catalog.json';saved={}
    try:saved=json.loads(path.read_text())
    except (OSError,ValueError):pass
    if not refresh or time.time()-saved.get('checked_at',0)<300:return saved
    req=urllib.request.Request(BASE+'/models',headers={'Authorization':'Bearer '+credential()})
    with urllib.request.urlopen(req,timeout=10) as r:raw=json.load(r)
    models=[public_model(m) for m in raw.get('data',[]) if isinstance(m,dict) and isinstance(m.get('id'),str)]
    data={'checked_at':time.time(),'models':models};tmp=path.with_suffix('.'+uuid.uuid4().hex+'.tmp');tmp.write_text(json.dumps(data));tmp.chmod(0o600);os.replace(tmp,path);return data

def candidates(messages,structured=False):
    if not credential() or cooling('account'):return []
    models=catalog(True).get('models',[]);vision=any(m.get('images') for m in messages)
    usable=[m for m in models if m['free'] and 'text' in m['output_modalities'] and 'text' in m['input_modalities'] and (not vision or 'image' in m['input_modalities']) and not cooling(m['id']) and not any(x in m['id'] for x in [':batch','content-safety','stealth/'])]
    preferred=(['cohere/north-mini-code:free'] if structured else [])+PREFERRED
    with database() as c:successful={r['model'] for r in c.execute("SELECT DISTINCT model FROM routes WHERE status='completed' AND created>?",(time.time()-86400,))}
    usable.sort(key=lambda m:(m['id'] not in successful,preferred.index(m['id']) if m['id'] in preferred else len(preferred)))
    return usable[:3]

def messages_for_api(messages):
    result=[]
    for m in messages:
        item={'role':m['role'],'content':m['content']}
        if m.get('images'):
            item['content']=[{'type':'text','text':m['content']}]+[{'type':'image_url','image_url':{'url':('data:image/jpeg;base64,' if i.startswith('/9j/') else 'data:image/png;base64,')+i}} for i in m['images']]
        result.append(item)
    return result

def respond(messages,maximum,permission=False,structured=False,stage=lambda s:None,deadline=None,free_data_permission=False,notice=lambda s:None,user_id=None,preferred=None):
    if not permission:return None,{'status':'local','reason':'External AI is off for this account.','attempts':[]}
    attempts=[]
    try:models=[] if preferred=="gemini" else candidates(messages,structured)
    except Exception:models=[]
    def shifted(local=False):
        if attempts and attempts[-1].get('quota_exhausted'):
            text='Switched to another available service.'
            notice({'id':uuid.uuid4().hex,'message':text,'created':time.time(),'expires':time.time()+8})
    for model in models:
        if deadline and time.monotonic()>=deadline:break
        started=time.monotonic();name=model['id'];stage('ETERNAL is answering with Hybrid' if not attempts else 'Trying another available free route')
        body={'model':name,'messages':messages_for_api(messages),'max_tokens':min(4096,max(64,int(maximum))),
              'stream':False,'provider':{'data_collection':'deny','max_price':{'prompt':0,'completion':0},'allow_fallbacks':True}}
        if structured:body['response_format']={'type':'json_object'}
        req=urllib.request.Request(BASE+'/chat/completions',data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+credential(),'Content-Type':'application/json','HTTP-Referer':'https://synergyai.1rank.in','X-Title':'SYnerGY AI'})
        try:
            with urllib.request.urlopen(req,timeout=max(.2,min(45,(deadline or time.monotonic()+45)-time.monotonic()))) as r:data=json.load(r)
            choice=data.get('choices',[{}])[0];text=choice.get('message',{}).get('content','')
            if not isinstance(text,str) or not text.strip() or choice.get('finish_reason') not in {'stop','end_turn'}:raise ValueError('Incomplete external answer')
            if structured:json.loads(text.strip().removeprefix('```json').removesuffix('```'))
            shifted();actual=data.get('model',name);audit(actual,'completed',200,started);attempts.append({'model':actual,'status':'completed'})
            return text,{'status':'completed','actual_provider':'openrouter','actual_model':actual,'attempts':attempts,'free_only':True,'usage':data.get('usage',{})}
        except urllib.error.HTTPError as e:
            code=e.code
            try:error=json.loads(e.read(16000)).get('error',{});model_limit=bool(error.get('metadata',{}).get('provider_name'))
            except (ValueError,AttributeError):model_limit=False
            # Respect shared account limits. Do not rotate keys/accounts to evade them.
            try:delay=int(e.headers.get('Retry-After','60'))
            except (ValueError,AttributeError):delay=60
            status='model_unavailable' if code in {404,408,502,503,504} or (code==429 and model_limit) else 'account_unavailable'
            audit(name,status,code,started);attempts.append({'model':name,'status':status,'http_status':code,'quota_exhausted':code==429})
            if status=='account_unavailable':cooldown('account',delay if code==429 else 300,status);break
            cooldown(name,delay,status)
        except Exception:
            audit(name,'request_unavailable',None,started);attempts.append({'model':name,'status':'request_unavailable'});cooldown(name,60,'request_unavailable')
    if preferred!="openrouter" and permission and free_data_permission and gemini_enabled() and gemini_paid_access(user_id) and not cooling('gemini_account'):
        # Owner-declared free-tier project only. Never enable billing or upgrade it.
        for name in gemini_models():
            if cooling('gemini/'+name) or (deadline and time.monotonic()>=deadline):continue
            stage('SYNERGY is trying Hybrid');started=time.monotonic()
            contents=[];instructions=[]
            for m in messages:
                if m['role']=='system':instructions.append(m['content']);continue
                parts=[{'text':m['content']}]
                parts += [{'inlineData':{'mimeType':'image/jpeg' if i.startswith('/9j/') else 'image/png','data':i}} for i in m.get('images',[])]
                contents.append({'role':'model' if m['role']=='assistant' else 'user','parts':parts})
            config={'maxOutputTokens':min(8192,max(64,int(maximum)))}
            if structured:config['responseMimeType']='application/json'
            body={'contents':contents,'generationConfig':config,'systemInstruction':{'parts':[{'text':'\n'.join(instructions)}]}}
            req=urllib.request.Request('https://generativelanguage.googleapis.com/v1beta/models/'+name+':generateContent',data=json.dumps(body).encode(),headers={'x-goog-api-key':gemini_credential(),'Content-Type':'application/json'})
            try:
                with urllib.request.urlopen(req,timeout=max(.2,min(45,(deadline or time.monotonic()+45)-time.monotonic()))) as r:data=json.load(r)
                candidate=data.get('candidates',[{}])[0]
                text=''.join(p.get('text','') for p in candidate.get('content',{}).get('parts',[]) if not p.get('thought'))
                if not text.strip() or candidate.get('finishReason')!='STOP':raise ValueError('Incomplete answer')
                if structured:json.loads(text)
                shifted();actual=data.get('modelVersion',name);audit('gemini/'+actual,'completed',200,started);attempts.append({'model':actual,'provider':'gemini','status':'completed'})
                return text,{'status':'completed','actual_provider':'gemini','actual_model':actual,'attempts':attempts,'free_only':True,'billing_basis':'owner-declared free-tier project','usage':data.get('usageMetadata',{})}
            except urllib.error.HTTPError as e:
                code=e.code;status='model_unavailable' if code in {404,408,502,503,504} else 'account_unavailable'
                audit('gemini/'+name,status,code,started);attempts.append({'model':name,'provider':'gemini','status':status,'http_status':code,'quota_exhausted':code==429})
                try:delay=int(e.headers.get('Retry-After','60'))
                except (ValueError,AttributeError):delay=60
                try:
                    details=json.loads(e.read(16000)).get('error',{}).get('details',[])
                    for detail in details:
                        if detail.get('@type','').endswith('/google.rpc.RetryInfo'):
                            value=detail.get('retryDelay','')
                            if re.fullmatch(r'[0-9]+(?:\.[0-9]+)?s',value):delay=max(delay,int(float(value[:-1])))
                except (ValueError,TypeError,AttributeError):pass
                if status=='account_unavailable':cooldown('gemini_account',delay if code==429 else 300,status);break
                cooldown('gemini/'+name,delay,status)
            except Exception:
                audit('gemini/'+name,'request_unavailable',None,started);attempts.append({'model':name,'provider':'gemini','status':'request_unavailable'});cooldown('gemini/'+name,60,'request_unavailable')
    stage('Trying the local SYNERGY model')
    return None,{'status':'local_fallback','reason':'No eligible free route completed this request. Local SYNERGY remains available.','attempts':attempts,'free_only':True}

def status():
    data=catalog();models=data.get('models',[])
    with database() as c:recent=[dict(r) for r in c.execute('SELECT created,model,status,http_status,seconds FROM routes ORDER BY created DESC LIMIT 30')]
    return {'configured':enabled(),'openrouter_configured':bool(credential()),'gemini_configured':gemini_enabled(),'gemini_models':gemini_models(),'gemini_paid_accounts_only':True,'gemini_account_cooling_down':cooling('gemini_account'),'gemini_free_data_consent_required':True,'free_only':True,'paid_fallback_enabled':False,'checked_at':data.get('checked_at'),
            'free_text_models':[m for m in models if m['free'] and 'text' in m['output_modalities']],
            'vendors':{v:[m for m in models if m['id'].startswith(prefix+'/') and 'text' in m['output_modalities'] and ':batch' not in m['id']][:8] for v,prefix in [('Google · Gemini and Gemma','google'),('OpenAI','openai'),('Claude','anthropic'),('Perplexity','perplexity')]},
            'account_cooling_down':cooling('account'),'recent_routes':recent,
            'detail':'Key is stored outside source. Free routes only; proprietary paid models are catalogued, not silently billed. Provider limits still apply. Actual model routing is audited without prompt text.'}
