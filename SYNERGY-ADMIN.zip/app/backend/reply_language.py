"""Shared reply-language contract; no inference of language from identity or history."""
POLICY_VERSION = 1
LANGUAGES = {'english', 'hindi', 'hinglish', 'auto'}

def normalise_settings(settings):
    settings = dict(settings)
    # Old 'auto' was the product default, not an explicit opt-in.
    if settings.get('language') not in LANGUAGES or (settings.get('language') == 'auto' and settings.get('language_policy_version') != POLICY_VERSION):
        settings['language'] = 'english'
    settings['language_policy_version'] = POLICY_VERSION
    return settings

def instruction(settings):
    language = settings.get('language', 'english')
    target = {
        'english': 'Write your reply in English.',
        'hindi': 'Write your reply in Hindi using Devanagari.',
        'hinglish': 'Write your reply in Hinglish: simple Hindi written using Latin letters.',
        'auto': 'Match the language of the latest user message. For a short or ambiguous message such as hi, hello or ok, use English.'
    }.get(language, 'Write your reply in English.')
    return (' Reply language: ' + target +
            ' An explicit language or translation request in the latest user message takes priority for the requested output. '
            'Do not switch languages because of earlier assistant replies, quoted text, source documents, names or location. '
            'For example, hi should receive an English greeting under the default setting. '
            'Preserve exact quotations, code, URLs and proper names when necessary.')


def reminder(prompt, settings):
    """Repeat the language beside the current request for small local models.

    Explicit language/translation requests retain their original wording. This
    is not language detection or a claim of comprehensive language support.
    """
    import re
    if re.search(r"\b(?:reply|respond|answer|write|say|speak|explain|translate|translation)\b[^\n]{0,160}\b(?:in|into|to)\s+[a-z]+|\b(?:hindi|hinglish|english)\s+(?:mein|me|में)\b", prompt, re.I):
        return ''
    language=settings.get('language','english')
    if language=='auto':
        return '\n\nReply in English.' if re.fullmatch(r'\s*(?:hi|hello|hey|ok|okay)[!.?\s]*',prompt,re.I) else ''
    return '\n\n'+{'hindi':'Reply in Hindi using Devanagari.','hinglish':'Reply in Hinglish using Latin letters.'}.get(language,'Reply in English.')

def unexpected_script(reply, prompt, settings):
    """Conservative script check; not comprehensive language detection."""
    import re, unicodedata
    if settings.get('language','english')!='english' or not reminder(prompt,settings):return False
    text=re.sub(r'```[\s\S]*?```|`[^`]*`|https?://\S+|"[^"]*"|“[^”]*”', '', reply)
    text=re.sub(r'(?m)^\s*>.*$', '', text)
    letters=[c for c in text if c.isalpha()]
    other=sum('LATIN' not in unicodedata.name(c,'') for c in letters)
    return other>=8 and other/max(1,len(letters))>.35
