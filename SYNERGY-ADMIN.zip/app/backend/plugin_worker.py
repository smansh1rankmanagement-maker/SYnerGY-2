"""Killable connector worker; no inherited provider credentials or arbitrary tool names."""
from pathlib import Path
import json,os,sys
from mcp_transport import HTTPClient,StdioClient,initialize,unpack

def run(d):
    catalog=json.loads(Path(__file__).with_name('runtime_catalog.json').read_text());key=d['key'];spec=catalog[key]
    tool=d.get('tool')
    if tool and tool not in spec['tools']:raise ValueError('This tool is not enabled in SYnerGY.')
    args=d.get('arguments',{})
    if key=='firecrawl':
        from research.net import validate_url
        if tool=='firecrawl_scrape':validate_url(args.get('url',''))
        client=HTTPClient(spec['endpoint'])
    else:
        workspace=Path(d['workspace']).resolve();profile=Path(d['profile']).resolve()
        if tool:
            if set(args)-{'path','offset','length','depth'}:raise ValueError('Unsupported file-tool option.')
            p=Path(args.get('path','')).resolve()
            if not p.is_relative_to(workspace):raise ValueError('File access is limited to this account\'s tool workspace.')
            if any(x.startswith('.') for x in p.relative_to(workspace).parts):raise ValueError('Hidden files are not shared with the file tool.')
        env={k:os.environ[k] for k in ['PATH','TMPDIR','LANG','SYSTEMROOT'] if k in os.environ}
        env.update(SYNERGY_DESKTOP_PROFILE=str(profile),DO_NOT_TRACK='1',DISABLE_TELEMETRY='1',NODE_ENV='production')
        client=StdioClient([d['node'],'--import',str(Path(__file__).with_name('desktop_bootstrap.mjs')),d['entry'],'--no-onboarding'],env,str(workspace))
    try:
        server=initialize(client)
        if not tool:
            listing=client.request('tools/list');return {'server':server,'tools':[t['name'] for t in listing.get('tools',[]) if t['name'] in spec['tools']]}
        value=unpack(client.request('tools/call',{'name':tool,'arguments':args}));return {'server':server,'tool':tool,'data':value}
    finally:client.close()

if __name__=='__main__':
    p=Path(sys.argv[1])
    try:
        d=json.loads(p.read_text());p.unlink(missing_ok=True);print(json.dumps({'result':run(d)},ensure_ascii=False),flush=True)
    except Exception as e:
        from research.net import redact
        print(json.dumps({'error':redact(str(e))[:1000]}),flush=True);sys.exit(1)
