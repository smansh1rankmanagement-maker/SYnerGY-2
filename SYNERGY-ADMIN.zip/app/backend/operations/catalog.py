"""Finite tool catalog. Neither retrieved text nor models can expand permissions."""
STEPS = [
    {'id':'inputs','role':'Brand Manager','after':[], 'condition':'always','timeout':20},
    {'id':'seo','role':'SEO','after':['inputs'],'condition':'authorised_website','timeout':120},
    {'id':'tasks','role':'Operations','after':['seo'],'condition':'always','timeout':20},
    {'id':'calendar','role':'Content','after':['inputs'],'condition':'always','timeout':100},
    {'id':'xlsx','role':'Reporting','after':['calendar','tasks'],'condition':'always','timeout':30},
    {'id':'pdf','role':'Reporting','after':['calendar','tasks'],'condition':'always','timeout':40},
    {'id':'review','role':'Brand Manager','after':['xlsx','pdf'],'condition':'always','timeout':20},
    {'id':'notify','role':'Operations','after':['review'],'condition':'always','timeout':20},
]
ROLES = [
    ('Brand Manager','Coordinate the brief, review inputs and request approval.',['brand.read','approval.request'],'Input checklist and reviewed artifact versions',True),
    ('Research','Read bounded public sources in existing Chat research.',['public.search','public.read'],'Sources, dates and access limitations',False),
    ('SEO','Inspect an authorised website and prioritise observed issues.',['public.crawl'],'Page evidence, issues, impact and effort',True),
    ('Content','Draft seven organic posts from the brand brief.',['local.aerny','calendar.draft'],'Seven dated drafts; no invented results',True),
    ('Creative','Prepare requests for the existing Aerny image studio.',['creative.request'],'Art direction and required approved assets',False),
    ('Campaign','Plan organic campaigns and UTM links.',['calendar.read','utm.create'],'Campaign brief and tracked destination',False),
    ('CRM','Maintain facts, qualification notes and follow-up dates.',['lead.read','lead.write'],'Deduplicated contact records; opt-outs retained',False),
    ('Reporting','Create spreadsheet, PDF and editable report sources.',['artifact.write'],'Saved files, formulas and source details',True),
    ('Operations','Manage task queues, schedules and in-app notifications.',['task.write','notification.write'],'Idempotent tasks and run status',True),
]

def roles():
    return [dict(name=n,responsibilities=r,allowed_tools=t,output_format=o,
                 status='workflow enabled' if live else 'manual tools / role definition',
                 accessible_data='Selected brand and immutable run snapshot only',
                 completion_checks='Validate output schema, record provenance and unresolved inputs',
                 resource_limits='One worker; at most two attempts per step; 120 seconds per step',
                 escalation='Missing permission, missing input, failed connection or output review')
            for n,r,t,o,live in ROLES]

def definition(schedule=None):
    return {'template':'weekly_brand_review','schema':1,'timezone':'Asia/Kolkata',
            'schedule':schedule or {'kind':'weekly','weekday':0,'time':'09:00','timezone':'Asia/Kolkata'},
            'steps':STEPS,'max_attempts':2,'concurrency':1,
            'inputs':['Brand brief revision','Authorised public website','Approved assets'],
            'approval_points':['Brand inputs before use as approved knowledge','Exact exported version before any external use'],
            'outputs':['Prioritised tasks','Seven-day organic content calendar.xlsx','Brand summary.pdf','Editable summary.md','Evidence.json'],
            'external_actions':False}
