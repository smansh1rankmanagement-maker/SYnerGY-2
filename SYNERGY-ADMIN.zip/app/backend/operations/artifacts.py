"""Fill the versioned workbook template; render real report content locally."""
import datetime as dt, json, re, zipfile, xml.etree.ElementTree as ET
from pathlib import Path
from xml.sax.saxutils import escape
from zoneinfo import ZoneInfo

NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
ET.register_namespace('',NS)
def tag(x):return '{'+NS+'}'+x
def excel_date(value):return (dt.date.fromisoformat(value)-dt.date(1899,12,30)).days

def fill_sheet(raw,values,caches=None):
    root=ET.fromstring(raw);data=root.find(tag('sheetData'))
    for addr,value in values.items():
        rn=int(re.search(r'\d+',addr)[0]);row=data.find(tag('row')+f'[@r="{rn}"]')
        if row is None:row=ET.SubElement(data,tag('row'),{'r':str(rn)})
        cell=row.find(tag('c')+f'[@r="{addr}"]')
        if cell is None:cell=ET.SubElement(row,tag('c'),{'r':addr})
        for child in list(cell):cell.remove(child)
        cell.attrib.pop('t',None)
        if isinstance(value,(int,float)) and not isinstance(value,bool):ET.SubElement(cell,tag('v')).text=str(value)
        else:
            cell.set('t','inlineStr');is_=ET.SubElement(cell,tag('is'));t=ET.SubElement(is_,tag('t'));t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=str(value or '')[:30000]
    for addr,value in (caches or {}).items():
        cell=data.find('.//'+tag('c')+f'[@r="{addr}"]')
        if cell is None or cell.find(tag('f')) is None:raise ValueError('Workbook formula template changed: '+addr)
        v=cell.find(tag('v'))
        if v is None:v=ET.SubElement(cell,tag('v'))
        if isinstance(value,str):cell.set('t','str')
        else:cell.attrib.pop('t',None)
        v.text=str(value)
    return ET.tostring(root,encoding='utf-8',xml_declaration=True)

def workbook(path,snapshot,results,run_id,created):
    template=Path(__file__).resolve().parents[2]/'templates/brand-review-template.xlsx'
    if not template.exists():raise ValueError('The versioned spreadsheet template is missing.')
    brand=snapshot['brand'];cfg=brand['config'];cal=results['calendar'];seo=results.get('seo',{});issues=seo.get('issues',[])[:50];values={}
    for i,p in enumerate(cal['posts'],8):
        row=[excel_date(p['date']),p['channel'],p['format'],p['topic'],p['caption'],p['creative'],p['cta'],p['owner'],p['status'],p['source'],p.get('utm',''),'Review draft; no external publishing']
        for col,value in zip('ABCDEFGHIJKL',row):values[col+str(i)]=value
    values['A2']=brand['name']+' content calendar';values['A5']='Publishing pending. Input revision '+str(brand['revision'])+(' approved.' if cal['inputs_approved'] else ' awaits approval.')
    cache={'B4':len(cal['posts']),'D4':sum(p['status']=='Approved' for p in cal['posts']),'F4':sum(p['status']=='Draft' for p in cal['posts'])}
    taskvalues={'B4':'Complete' if seo.get('state')=='complete' else 'Partial' if seo.get('state')=='partial' else 'Blocked'}
    if not issues and seo.get('state')!='complete':taskvalues.update(A8='Resolve the audit blocker',D8=seo.get('blocker','Audit could not finish.'),G8='Blocked')
    for i,item in enumerate(issues,8):
        date=dt.datetime.fromtimestamp(item['observed_at'],ZoneInfo(snapshot['definition']['timezone'])).date().isoformat()
        for col,value in zip('ABCDEFG',[item['title'],item['impact'],item['effort'],item['evidence'],item['url'],excel_date(date),'Open']):taskvalues[col+str(i)]=value
    stamp=dt.datetime.fromtimestamp(created,ZoneInfo(snapshot['definition']['timezone'])).strftime('%d %b %Y %H:%M %Z')
    info={'B6':brand['name'],'B7':brand['revision'],'B8':'Approved' if cal['inputs_approved'] else 'Pending approval','B9':cfg.get('brief','Not supplied'),'B10':cfg.get('audience','Not supplied'),'B11':cfg.get('services','Not supplied'),'B12':cfg.get('website','Not supplied'),'B13':cfg.get('source','Brand workspace'),'B14':stamp,'B15':snapshot['definition']['timezone'],'B16':cal['method'],'B17':'; '.join(cal['warnings']+[seo.get('blocker','Limited SEO sample; no analytics connection.')]),'B18':run_id}
    with zipfile.ZipFile(template) as src,zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as dst:
        for item in src.infolist():
            data=src.read(item.filename)
            if item.filename=='xl/worksheets/sheet1.xml':data=fill_sheet(data,values,cache)
            elif item.filename=='xl/worksheets/sheet2.xml':data=fill_sheet(data,taskvalues,{'B5':len(issues) if seo.get('state')=='complete' else 'n.a.'})
            elif item.filename=='xl/worksheets/sheet3.xml':data=fill_sheet(data,info)
            elif item.filename=='xl/workbook.xml':
                root=ET.fromstring(data);calc=root.find(tag('calcPr'))
                if calc is None:calc=ET.SubElement(root,tag('calcPr'))
                calc.set('fullCalcOnLoad','1');calc.set('forceFullCalc','1');data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
            dst.writestr(item,data)
    return {'formula_cells':4,'calendar_rows':7,'seo_issue_rows':len(issues),'formula_caches':'Independently computed counts; formulas retained for spreadsheet recalculation'}

def report_data(snapshot,results,run_id,created):
    b=snapshot['brand'];cfg=b['config'];cal=results.get('calendar',{});seo=results.get('seo',{});date=dt.datetime.fromtimestamp(created,ZoneInfo(snapshot['definition']['timezone'])).strftime('%d %B %Y')
    lines=['# '+b['name']+' | Weekly brand review','',date,'','## Review status','',
           'Brand input revision '+str(b['revision'])+(' is approved.' if b['approved_revision']==b['revision'] else ' is awaiting approval.'),
           'Publishing, outreach and paid advertising remain pending authorised connections and version-specific review.','',
           '## Brand brief','',cfg.get('brief') or 'No brand brief supplied.','',
           'Source: '+(cfg.get('source') or 'Brand workspace'),'',
           '## SEO observations','',seo.get('blocker') or ('Read '+str(sum(p.get('status')==200 for p in seo.get('pages',[])))+' pages from the authorised website.'),
           'Search rankings, traffic, keyword volumes and backlinks: unavailable; no analytics connection.','']
    for issue in seo.get('issues',[])[:20]:lines+=['- '+issue['title']+' ('+issue['impact']+' impact / '+issue['effort']+' effort). '+issue['evidence']+' Source: '+issue['url']]
    lines+=['','## Seven-day content calendar','', 'Drafting: '+cal.get('method','Unavailable')+'.']
    for p in cal.get('posts',[]):lines+=['','### '+p['date']+' | '+p['topic'],p['format']+' / '+p['status'],'',p['caption'],'','Creative brief: '+p['creative'],'Call to action: '+p['cta']]
    lines+=['','## Next actions','', '1. Confirm brand inputs and approved assets.','2. Supply or confirm the authorised website.','3. Review the exported calendar and summary.','4. Configure an authorised publishing connection before external use.','','## Run details','', 'Run: '+run_id,'Workflow version: '+str(snapshot.get('workflow_version',1)),'Timezone: '+snapshot['definition']['timezone'],'', 'Sources and limitations are retained in evidence.json. This report records drafts and observations, not performance results.']
    return '\n'.join(lines)+'\n'

def pdf(path,snapshot,results,run_id,created):
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,KeepTogether,PageBreak
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    fonts=Path(__file__).resolve().parents[1]/'image_studio/fonts';normal=fonts/'DejaVuSans.ttf';bold=fonts/'DejaVuSansCondensed-Bold.ttf'
    if normal.exists():pdfmetrics.registerFont(TTFont('SynergyBody',str(normal)))
    if bold.exists():pdfmetrics.registerFont(TTFont('SynergyBold',str(bold)))
    body='SynergyBody' if normal.exists() else 'Helvetica';heavy='SynergyBold' if bold.exists() else 'Helvetica-Bold'
    styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='BodyX',fontName=body,fontSize=10,leading=15,spaceAfter=9,textColor=colors.HexColor('#26312C')));styles.add(ParagraphStyle(name='TitleX',fontName=heavy,fontSize=24,leading=29,spaceAfter=15,textColor=colors.HexColor('#26312C')));styles.add(ParagraphStyle(name='H2X',fontName=heavy,fontSize=14,leading=18,spaceBefore=16,spaceAfter=9));styles.add(ParagraphStyle(name='SmallX',fontName=body,fontSize=8,leading=12,spaceAfter=6,textColor=colors.HexColor('#65706B')))
    def para(v,style='BodyX'):return Paragraph(escape(str(v)).replace('\n','<br/>'),styles[style])
    b=snapshot['brand'];cfg=b['config'];seo=results.get('seo',{});cal=results.get('calendar',{});date=dt.datetime.fromtimestamp(created,ZoneInfo(snapshot['definition']['timezone'])).strftime('%d %B %Y')
    story=[para(b['name'],'TitleX'),para('Weekly brand review · '+date,'SmallX'),para('Brand inputs '+('approved' if b['approved_revision']==b['revision'] else 'awaiting approval')+' · Revision '+str(b['revision'])),para('Brand brief','H2X'),para(cfg.get('brief') or 'No brand brief supplied.'),para('Source: '+(cfg.get('source') or 'Brand workspace'),'SmallX'),para('SEO observations','H2X'),para(seo.get('blocker') or 'A limited audit read '+str(sum(p.get('status')==200 for p in seo.get('pages',[])))+' pages. Findings below apply only to that sample.'),para('Search rankings, traffic, keyword volumes and backlinks are unavailable. No analytics account is connected.','SmallX')]
    for item in seo.get('issues',[])[:20]:story.append(KeepTogether([para(item['title'],'H2X'),para(item['impact'].title()+' impact / '+item['effort']+' effort. '+item['evidence']),para(item['url'],'SmallX')]))
    story += [para('Required inputs and approvals','H2X'),para('Confirm the brand brief and authorised website. Review the calendar and creative references. External publishing, outreach and spending are not enabled.'),PageBreak(),para('Seven-day content calendar','TitleX'),para('Organic draft plan · '+cal.get('method','Unavailable'),'SmallX')]
    for p in cal.get('posts',[]):
        story.append(KeepTogether([para(p['date']+' · '+p['topic'],'H2X'),para(p['format']+' · '+p['status'],'SmallX'),para(p['caption']),para('Creative: '+p['creative'],'SmallX'),para('Call to action: '+p['cta'],'SmallX')]))
    story += [para('Sources and limitations','H2X'),para('; '.join(cal.get('warnings',[])) or 'Draft captions require editorial review.'),para('Limited HTML audit; no performance estimates. The editable report, spreadsheet and evidence are saved with this run. No messages, posts, advertisements or website changes were sent.'),para('Run '+run_id+' · '+snapshot['definition']['timezone'],'SmallX')]
    def footer(canvas,doc):
        canvas.setStrokeColor(colors.HexColor('#DD6937'));canvas.line(42,43,A4[0]-42,43);canvas.setFont(body,8);canvas.setFillColor(colors.HexColor('#65706B'));canvas.drawString(42,29,'SYnerGY Brand Operations');canvas.drawRightString(A4[0]-42,29,str(doc.page))
    doc=SimpleDocTemplate(str(path),pagesize=A4,rightMargin=42,leftMargin=42,topMargin=42,bottomMargin=58,title=b['name']+' weekly review',author='SYnerGY Brand Operations')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)

