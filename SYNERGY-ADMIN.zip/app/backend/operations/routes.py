import json,re,time
from action_boundary import matching_brands
from urllib.parse import parse_qs,urlsplit

class OperationsHTTP:
    def operations_get(self,path,user):
        o=self.operations;uid=user['id'];query=parse_qs(urlsplit(self.path).query)
        try:
            if path=='/api/operations/dashboard':return self.response(200,o.dashboard(uid,query.get('brand_id',[None])[0]))
            if path=='/api/operations/brands':return self.response(200,{'brands':o.brands(uid)})
            m=re.fullmatch(r'/api/operations/(brands|runs|artifacts)/([0-9a-f]{32})',path)
            if m:
                if m[1]=='brands':return self.response(200,o.brand(uid,m[2]))
                if m[1]=='runs':return self.response(200,o.run(uid,m[2]))
                artifact,p=o.artifact(uid,m[2]);return self.research_download(p.read_bytes(),artifact['name'])
        except (KeyError,FileNotFoundError):return self.fail(404,'This item was not found in your brand workspace.')
        except PermissionError as e:return self.fail(403,str(e))
        except (ValueError,TypeError) as e:return self.fail(400,str(e))
        return self.fail(404,'Not found.')
    def operations_post(self,path,d,user):
        o=self.operations;uid=user['id']
        try:
            if path=='/api/operations/brands':return self.response(201,o.save_brand(uid,d))
            if path=='/api/operations/brands/approve':return self.response(200,o.approve_brand(uid,d.get('id'),d.get('revision')))
            if path=='/api/operations/brands/delete':return self.response(200,o.delete_brand(uid,d.get('id'),d.get('confirmation')))
            if path=='/api/operations/members':return self.response(200,o.member(uid,d.get('brand_id'),d.get('username'),d.get('role')))
            if path=='/api/operations/knowledge':return self.response(200,o.knowledge(uid,d.get('brand_id'),d))
            if path=='/api/operations/workflows':return self.response(201,o.save_workflow(uid,d))
            if path=='/api/operations/workflows/action':return self.response(200,o.workflow_action(uid,d.get('id'),d))
            if path=='/api/operations/run':return self.response(202,o.enqueue(uid,d.get('workflow_id'),d.get('idempotency_key')))
            if path=='/api/operations/runs/action':return self.response(200,o.run_action(uid,d.get('id'),d.get('action')))
            if path=='/api/operations/revise':return self.response(202,o.revise(uid,d.get('id'),d.get('posts')))
            if path=='/api/operations/approvals':return self.response(200,o.approve(uid,d.get('id'),d))
            if path=='/api/operations/leads':return self.response(201,o.save_lead(uid,d.get('brand_id'),d))
            if path=='/api/operations/tasks':return self.response(200,o.update_task(uid,d.get('id'),d))
            if path=='/api/operations/utm':return self.response(200,o.utm(uid,d.get('brand_id'),d))
            if path=='/api/operations/webhook-key':return self.response(200,o.webhook_key(uid,d.get('id')))
            if path=='/api/operations/external-action':
                with o.connect() as c:o.require(c,uid,d.get('brand_id'),review=True)
                return self.fail(409,'No publishing, messaging or advertising connection is configured. Nothing was sent or spent.')
            if path=='/api/operations/chat':
                cid=d.get('conversation_id');self.workspace.chat(uid,cid);prompt=d.get('prompt','')
                if not isinstance(prompt,str) or not re.match(r'(?i)^(?:please\s+)?(?:create|build|draft|set up)\b',prompt) or not re.search(r'(?i)\b(?:workflow|automation|weekly brand review)\b',prompt):raise ValueError('Try: Create a weekly automation for InteriFY.')
                brands=o.brands(uid);matches=matching_brands(brands,prompt)
                if len(matches)!=1:raise ValueError('Name one of your brands in the request, for example: Create a weekly automation for InteriFY.')
                weekly=bool(re.search(r'(?i)\bweekly|every week\b',prompt));schedule={'kind':'weekly' if weekly else 'manual','timezone':'Asia/Kolkata','weekday':0,'time':'09:00'}
                days=['monday','tuesday','wednesday','thursday','friday','saturday','sunday']
                for i,day in enumerate(days):
                    if day in prompt.lower():schedule['weekday']=i
                clock=re.search(r'\b([01]?\d|2[0-3]):([0-5]\d)\b',prompt)
                if clock:schedule['time']=clock[1].zfill(2)+':'+clock[2]
                w=o.save_workflow(uid,{'brand_id':matches[0]['id'],'name':matches[0]['name']+' brand review','schedule':schedule})
                reply='The '+matches[0]['name']+' workflow is drafted. Review its trigger, inputs, steps, approval points and outputs in Brand Operations before activating it. '+('Schedule: '+days[schedule['weekday']].title()+' at '+schedule['time']+' Asia/Kolkata.' if weekly else 'Trigger: manual.')
                self.workspace.add(uid,cid,'user',prompt,{'mode':'work'});self.workspace.add(uid,cid,'assistant',reply,{'operations_workflow_id':w['id'],'brand_id':w['brand_id'],'mode':'work'})
                return self.response(201,{'reply':reply,'workflow':w})
        except (KeyError,FileNotFoundError):return self.fail(404,'This item was not found in your brand workspace.')
        except PermissionError as e:return self.fail(403,str(e))
        except (ValueError,TypeError,OverflowError) as e:return self.fail(400,str(e))
        return self.fail(404,'Not found.')
    def operations_hook(self,path):
        m=re.fullmatch(r'/api/operations/hooks/([0-9a-f]{32})',path)
        if not m:return self.fail(404,'Not found.')
        try:
            length=int(self.headers.get('Content-Length','0'))
            if self.headers.get('Transfer-Encoding') or not 1<=length<=65536:raise ValueError('Invalid webhook size.')
            raw=self.rfile.read(length);result=self.operations.webhook(m[1],self.headers.get('X-Synergy-Timestamp',''),self.headers.get('X-Synergy-Event-Id',''),self.headers.get('X-Synergy-Signature',''),raw)
            return self.response(202,result)
        except PermissionError:return self.fail(403,'Invalid or expired webhook signature.')
        except (ValueError,TypeError):return self.fail(400,'Invalid webhook request or inactive workflow.')
