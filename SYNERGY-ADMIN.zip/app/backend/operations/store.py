import contextlib, datetime as dt, hashlib, hmac, json, os, re, secrets, shutil, sqlite3, time, uuid
from pathlib import Path
from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit
from zoneinfo import ZoneInfo
from .catalog import definition, roles

def ident(): return uuid.uuid4().hex
def dump(value): return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def digest(value): return hashlib.sha256(dump(value).encode()).hexdigest()
def text(value,limit=5000):
    if not isinstance(value,str) or len(value)>limit: raise ValueError('Text exceeds its limit or has an invalid type.')
    if re.search(r'(?i)\b(?:api[_ -]?key|password|secret|access[_ -]?token|refresh[_ -]?token)\s*[:=]\s*\S+',value):raise ValueError('Keep credentials in secure configuration, not brand data or exports.')
    return value.strip()
def schedule_check(s):
    if not isinstance(s,dict): raise ValueError('Schedule must be an object.')
    kind=s.get('kind','manual'); tz=text(s.get('timezone','Asia/Kolkata'),80)
    try: ZoneInfo(tz)
    except Exception: raise ValueError('Choose a valid IANA timezone.')
    out={'kind':kind,'timezone':tz}
    if kind=='weekly':
        weekday=s.get('weekday',0); clock=s.get('time','09:00')
        if type(weekday) is not int or weekday not in range(7) or not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',str(clock)): raise ValueError('Invalid weekly day or time.')
        out.update(weekday=weekday,time=clock)
    elif kind=='once':
        try: when=dt.datetime.fromisoformat(s['at'])
        except Exception: raise ValueError('Use a timezone-aware ISO date for a one-time schedule.')
        if when.tzinfo is None: raise ValueError('A schedule requires an explicit timezone.')
        out['at']=when.isoformat()
    elif kind=='event':
        if s.get('event') not in {'brand.updated','task.completed'}: raise ValueError('Unsupported event trigger.')
        out['event']=s['event']
    elif kind not in {'manual','webhook'}: raise ValueError('Unsupported trigger.')
    return out
def next_due(schedule,after=None):
    now=time.time() if after is None else after; s=schedule_check(schedule)
    if s['kind']=='once':
        val=dt.datetime.fromisoformat(s['at']).timestamp()
        return val if val>now else None
    if s['kind']!='weekly': return None
    zone=ZoneInfo(s['timezone']);local=dt.datetime.fromtimestamp(now,zone);hour,minute=map(int,s['time'].split(':'))
    for day in range(9):
        date=local.date()+dt.timedelta(days=day)
        if date.weekday()!=s['weekday']:continue
        candidate=dt.datetime.combine(date,dt.time(hour,minute),zone)
        # Round-trip skips a non-existent DST local time; fold=0 selects the first occurrence.
        if dt.datetime.fromtimestamp(candidate.timestamp(),zone).replace(tzinfo=None)!=candidate.replace(tzinfo=None):continue
        if candidate.timestamp()>now:return candidate.timestamp()
    raise ValueError('No valid weekly time was found.')

SCHEMA='''
CREATE TABLE IF NOT EXISTS ops_brands(id TEXT PRIMARY KEY,name TEXT NOT NULL,owner INTEGER NOT NULL,revision INTEGER NOT NULL,approved_revision INTEGER NOT NULL DEFAULT 0,config TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL);
CREATE TABLE IF NOT EXISTS ops_members(brand_id TEXT NOT NULL,user_id INTEGER NOT NULL,role TEXT NOT NULL,PRIMARY KEY(brand_id,user_id));
CREATE TABLE IF NOT EXISTS ops_knowledge(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL,source TEXT NOT NULL,owner INTEGER NOT NULL,approved INTEGER NOT NULL DEFAULT 0,updated REAL NOT NULL);
CREATE TABLE IF NOT EXISTS ops_workflows(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,name TEXT NOT NULL,version INTEGER NOT NULL,state TEXT NOT NULL,next_run REAL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS ops_versions(workflow_id TEXT NOT NULL,version INTEGER NOT NULL,definition TEXT NOT NULL,hash TEXT NOT NULL,created_by INTEGER NOT NULL,created REAL NOT NULL,activated_by INTEGER,activated REAL,PRIMARY KEY(workflow_id,version));
CREATE TABLE IF NOT EXISTS ops_runs(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,workflow_id TEXT NOT NULL,version INTEGER NOT NULL,trigger_key TEXT NOT NULL,state TEXT NOT NULL,snapshot TEXT NOT NULL,created REAL NOT NULL,started REAL,finished REAL,heartbeat REAL,error TEXT NOT NULL DEFAULT '',revision INTEGER NOT NULL DEFAULT 1,UNIQUE(workflow_id,trigger_key));
CREATE TABLE IF NOT EXISTS ops_steps(run_id TEXT NOT NULL,key TEXT NOT NULL,state TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,result TEXT NOT NULL DEFAULT '{}',started REAL,finished REAL,retry_at REAL,PRIMARY KEY(run_id,key));
CREATE TABLE IF NOT EXISTS ops_tasks(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,run_id TEXT,action_key TEXT NOT NULL,title TEXT NOT NULL,state TEXT NOT NULL,priority TEXT NOT NULL,owner TEXT NOT NULL,due TEXT NOT NULL,detail TEXT NOT NULL,UNIQUE(brand_id,action_key));
CREATE TABLE IF NOT EXISTS ops_artifacts(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,run_id TEXT NOT NULL,revision INTEGER NOT NULL,kind TEXT NOT NULL,name TEXT NOT NULL,path TEXT NOT NULL,sha256 TEXT NOT NULL,size INTEGER NOT NULL,created REAL NOT NULL,UNIQUE(run_id,revision,kind));
CREATE TABLE IF NOT EXISTS ops_approvals(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,run_id TEXT NOT NULL,revision INTEGER NOT NULL,action TEXT NOT NULL,artifact_hash TEXT NOT NULL,state TEXT NOT NULL,reviewer INTEGER,decision_note TEXT NOT NULL DEFAULT '',created REAL NOT NULL,decided REAL,UNIQUE(run_id,revision,action));
CREATE TABLE IF NOT EXISTS ops_leads(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,contact_key TEXT NOT NULL,data TEXT NOT NULL,updated REAL NOT NULL,UNIQUE(brand_id,contact_key));
CREATE TABLE IF NOT EXISTS ops_activity(id INTEGER PRIMARY KEY AUTOINCREMENT,brand_id TEXT NOT NULL,run_id TEXT,actor TEXT NOT NULL,kind TEXT NOT NULL,detail TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS ops_events(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,kind TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS ops_event_receipts(workflow_id TEXT NOT NULL,event_id TEXT NOT NULL,PRIMARY KEY(workflow_id,event_id));
CREATE TABLE IF NOT EXISTS ops_trigger_receipts(workflow_id TEXT NOT NULL,trigger_key TEXT NOT NULL,run_id TEXT NOT NULL,PRIMARY KEY(workflow_id,trigger_key));
CREATE TABLE IF NOT EXISTS ops_notifications(id TEXT PRIMARY KEY,brand_id TEXT NOT NULL,run_id TEXT NOT NULL,message TEXT NOT NULL,created REAL NOT NULL,UNIQUE(run_id,message));
CREATE TABLE IF NOT EXISTS ops_worker(id TEXT PRIMARY KEY,heartbeat REAL NOT NULL,pid INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS ops_runs_queue ON ops_runs(state,created);
CREATE INDEX IF NOT EXISTS ops_activity_brand ON ops_activity(brand_id,id);
'''

class Operations:
    def __init__(self,db,root):
        self.db=Path(db); self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        for name in ('artifacts','secrets','scratch'): (self.root/name).mkdir(exist_ok=True,mode=0o700)
        with self.connect() as c:c.executescript(SCHEMA)
    def connect(self):
        c=sqlite3.connect(self.db,timeout=20);c.row_factory=sqlite3.Row;c.execute('PRAGMA busy_timeout=20000');return c
    def require(self,c,uid,bid,write=False,admin=False,review=False):
        r=c.execute('SELECT b.*,m.role FROM ops_brands b JOIN ops_members m ON m.brand_id=b.id WHERE b.id=? AND m.user_id=?',(bid,uid)).fetchone()
        if not r:raise KeyError('Brand not found.')
        if admin and r['role']!='admin' or write and r['role'] not in {'admin','manager','member'} or review and r['role'] not in {'admin','manager','reviewer'}:raise PermissionError('Your brand role does not allow this action.')
        return {**dict(r),'config':json.loads(r['config'])}
    def log(self,c,bid,kind,detail,uid='worker',run=None):
        c.execute('INSERT INTO ops_activity(brand_id,run_id,actor,kind,detail,created) VALUES(?,?,?,?,?,?)',(bid,run,str(uid),kind,dump(detail),time.time()))
    def event(self,c,bid,kind):c.execute('INSERT INTO ops_events VALUES(?,?,?,?)',(ident(),bid,kind,time.time()))
    def brands(self,uid):
        with self.connect() as c:
            return [{**dict(r),'config':json.loads(r['config'])} for r in c.execute('SELECT b.*,m.role FROM ops_brands b JOIN ops_members m ON m.brand_id=b.id WHERE m.user_id=? ORDER BY b.name',(uid,))]
    def brand(self,uid,bid):
        with self.connect() as c:
            b=self.require(c,uid,bid)
            b['members']=[dict(r) for r in c.execute('SELECT m.user_id,m.role,u.username FROM ops_members m JOIN users u ON u.id=m.user_id WHERE m.brand_id=?',(bid,))]
            b['knowledge']=[dict(r) for r in c.execute('SELECT * FROM ops_knowledge WHERE brand_id=? ORDER BY updated DESC',(bid,))]
            return b
    def save_brand(self,uid,d):
        name=text(d.get('name',''),80)
        if not name:raise ValueError('A brand name is required.')
        raw=d.get('config',{})
        if not isinstance(raw,dict):raise ValueError('Invalid brand fields.')
        allowed={'organisation','client','brief','audience','positioning','services','guidelines','website','website_authorized','source','goals','approval_contacts','projects','campaigns','asset_note','retention_days','review_roles'}
        cfg={k:v for k,v in raw.items() if k in allowed}
        for k,v in cfg.items():
            if k not in {'website_authorized','retention_days','review_roles'}:cfg[k]=text(v,8000 if k=='brief' else 3000)
        if type(cfg.get('website_authorized',False)) is not bool:raise ValueError('Website permission must be explicit.')
        if cfg.get('website_authorized') and not cfg.get('website'):raise ValueError('Add the authorised website URL.')
        if cfg.get('website'):
            u=urlsplit(cfg['website'])
            if u.scheme not in {'http','https'} or not u.hostname or u.username or u.password or u.query or u.fragment:raise ValueError('Use a public website URL without credentials, query or fragment.')
        cfg['retention_days']=int(cfg.get('retention_days',365))
        if not 7<=cfg['retention_days']<=3650:raise ValueError('Retention must be 7 to 3650 days.')
        reviewers=cfg.get('review_roles',['admin','manager','reviewer'])
        if not isinstance(reviewers,list) or not reviewers or any(x not in {'admin','manager','reviewer'} for x in reviewers):raise ValueError('Choose reviewer roles.')
        cfg['review_roles']=reviewers
        bid=d.get('id') or ident();now=time.time()
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if d.get('id'):
                old=self.require(c,uid,bid,write=True)
                if old['role']=='member':raise PermissionError('A manager must edit brand settings.')
                if d.get('revision')!=old['revision']:raise ValueError('Brand changed. Reload before saving.')
                c.execute('UPDATE ops_brands SET name=?,config=?,revision=revision+1,approved_revision=0,updated=? WHERE id=?',(name,dump(cfg),now,bid))
                # Scheduled definitions remain, but the next run uses the new unapproved snapshot.
            else:
                if c.execute('SELECT COUNT(*) FROM ops_members WHERE user_id=?',(uid,)).fetchone()[0]>=50:raise ValueError('Brand workspace limit reached.')
                c.execute('INSERT INTO ops_brands VALUES(?,?,?,?,?,?,?,?)',(bid,name,uid,1,0,dump(cfg),now,now));c.execute('INSERT INTO ops_members VALUES(?,?,?)',(bid,uid,'admin'))
            self.log(c,bid,'brand.saved',{'name':name,'inputs_approved':False},uid);self.event(c,bid,'brand.updated')
        return self.brand(uid,bid)
    def approve_brand(self,uid,bid,revision):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');b=self.require(c,uid,bid,review=True)
            if b['role'] not in b['config'].get('review_roles',['admin','manager','reviewer']):raise PermissionError('Your role is not a configured reviewer.')
            if revision!=b['revision']:raise ValueError('The reviewed brand revision has changed.')
            if not b['config'].get('brief'):raise ValueError('Add a brand brief before approval.')
            c.execute('UPDATE ops_brands SET approved_revision=revision WHERE id=?',(bid,));self.log(c,bid,'brand.approved',{'revision':revision},uid)
        return self.brand(uid,bid)
    def member(self,uid,bid,username,role):
        if role not in {'manager','member','reviewer','remove'}:raise ValueError('Use manager, member, reviewer or remove.')
        with self.connect() as c:
            b=self.require(c,uid,bid,admin=True);u=c.execute('SELECT id FROM users WHERE username=? COLLATE NOCASE',(text(username,32),)).fetchone()
            if not u:raise ValueError('This person must register a SYnerGY account first.')
            if u['id']==b['owner']:raise ValueError('The owner keeps admin access.')
            if role=='remove':c.execute('DELETE FROM ops_members WHERE brand_id=? AND user_id=?',(bid,u['id']))
            else:c.execute('INSERT OR REPLACE INTO ops_members VALUES(?,?,?)',(bid,u['id'],role))
            self.log(c,bid,'membership.changed',{'user_id':u['id'],'role':role},uid)
        return self.brand(uid,bid)
    def knowledge(self,uid,bid,d):
        with self.connect() as c:
            self.require(c,uid,bid,write=True);kid=d.get('id') or ident()
            if d.get('id') and not c.execute('SELECT 1 FROM ops_knowledge WHERE id=? AND brand_id=?',(kid,bid)).fetchone():raise KeyError('Knowledge not found.')
            if d.get('delete'):c.execute('DELETE FROM ops_knowledge WHERE id=? AND brand_id=?',(kid,bid));self.log(c,bid,'knowledge.deleted',{'id':kid},uid)
            else:
                if d.get('approved'):self.require(c,uid,bid,review=True)
                c.execute('INSERT OR REPLACE INTO ops_knowledge VALUES(?,?,?,?,?,?,?,?)',(kid,bid,text(d.get('title',''),120),text(d.get('body',''),12000),text(d.get('source',''),500),uid,int(d.get('approved') is True),time.time()))
                self.log(c,bid,'knowledge.saved',{'id':kid,'approved':d.get('approved') is True},uid)
        return {'id':kid}
    def _workflow(self,c,uid,wid,write=False):
        w=c.execute('SELECT * FROM ops_workflows WHERE id=?',(wid,)).fetchone()
        if not w:raise KeyError('Workflow not found.')
        b=self.require(c,uid,w['brand_id'],write=write)
        if write and b['role'] not in {'admin','manager'}:raise PermissionError('A manager must change workflows.')
        row=dict(w);v=c.execute('SELECT * FROM ops_versions WHERE workflow_id=? AND version=?',(wid,w['version'])).fetchone()
        return {**row,'definition':json.loads(v['definition']),'hash':v['hash'],'activated':v['activated']}
    def save_workflow(self,uid,d):
        bid=d.get('brand_id');wid=d.get('id') or ident();s=schedule_check(d.get('schedule',{'kind':'manual','timezone':'Asia/Kolkata'}));spec=definition(s);spec['timezone']=s['timezone'];now=time.time()
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');b=self.require(c,uid,bid,write=True)
            if b['role'] not in {'admin','manager'}:raise PermissionError('A manager must create workflows.')
            if d.get('id'):
                old=self._workflow(c,uid,wid,write=True)
                if old['brand_id']!=bid or d.get('version')!=old['version']:raise ValueError('Workflow changed. Reload it first.')
                version=old['version']+1;c.execute('UPDATE ops_workflows SET name=?,version=?,state=?,next_run=NULL WHERE id=?',(text(d.get('name','Weekly brand review'),120),version,'draft',wid))
            else:
                version=1;c.execute('INSERT INTO ops_workflows VALUES(?,?,?,?,?,?,?)',(wid,bid,text(d.get('name','Weekly brand review'),120),version,'draft',None,now))
            c.execute('INSERT INTO ops_versions VALUES(?,?,?,?,?,?,?,?)',(wid,version,dump(spec),digest(spec),uid,now,None,None));self.log(c,bid,'workflow.drafted',{'id':wid,'version':version},uid)
            return self._workflow(c,uid,wid)
    def workflow_action(self,uid,wid,d):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');w=self._workflow(c,uid,wid,write=True);action=d.get('action')
            if action=='activate':
                if d.get('reviewed_hash')!=w['hash']:raise ValueError('Review the current trigger, inputs, steps, approvals and outputs first.')
                s=w['definition']['schedule'];due=next_due(s)
                if s['kind']=='once' and due is None:raise ValueError('Choose a future date.')
                c.execute('UPDATE ops_versions SET activated_by=?,activated=? WHERE workflow_id=? AND version=?',(uid,time.time(),wid,w['version']));c.execute('UPDATE ops_workflows SET state=?,next_run=? WHERE id=?',('active',due,wid))
            elif action=='pause':c.execute('UPDATE ops_workflows SET state=?,next_run=NULL WHERE id=?',('paused',wid))
            elif action=='resume':
                if not w['activated']:raise ValueError('Review and activate the draft first.')
                c.execute('UPDATE ops_workflows SET state=?,next_run=? WHERE id=?',('active',next_due(w['definition']['schedule']),wid))
            else:raise ValueError('Unknown workflow action.')
            self.log(c,w['brand_id'],'workflow.'+action,{'id':wid,'version':w['version']},uid)
            return self._workflow(c,uid,wid)
    def _enqueue(self,c,w,key,actor='scheduler'):
        if w['state']!='active':raise ValueError('Activate this reviewed workflow before running it.')
        old=c.execute('SELECT id FROM ops_runs WHERE workflow_id=? AND trigger_key=?',(w['id'],key)).fetchone()
        if old:return old['id']
        if c.execute('SELECT 1 FROM ops_trigger_receipts WHERE workflow_id=? AND trigger_key=?',(w['id'],key)).fetchone():raise ValueError('This trigger was already processed; its run passed the retention period.')
        if c.execute("SELECT count(*) FROM ops_runs WHERE state IN ('queued','running','paused')").fetchone()[0]>=100:raise ValueError('The queue is full; try later.')
        b=dict(c.execute('SELECT * FROM ops_brands WHERE id=?',(w['brand_id'],)).fetchone())
        if getattr(self,'access',None):self.access(b['owner'],'work')
        b['config']=json.loads(b['config']);b['knowledge']=[dict(x) for x in c.execute('SELECT title,body,source,owner,updated FROM ops_knowledge WHERE brand_id=? AND approved=1',(b['id'],))]
        spec=json.loads(c.execute('SELECT definition FROM ops_versions WHERE workflow_id=? AND version=?',(w['id'],w['version'])).fetchone()[0]);rid=ident();now=time.time()
        snap={'brand':b,'definition':spec,'workflow_version':w['version'],'scheduled_for':key,'requested_by':str(actor)}
        c.execute('INSERT INTO ops_runs(id,brand_id,workflow_id,version,trigger_key,state,snapshot,created) VALUES(?,?,?,?,?,?,?,?)',(rid,b['id'],w['id'],w['version'],key,'queued',dump(snap),now))
        c.execute('INSERT INTO ops_trigger_receipts VALUES(?,?,?)',(w['id'],key,rid))
        for s in spec['steps']:c.execute('INSERT INTO ops_steps(run_id,key,state) VALUES(?,?,?)',(rid,s['id'],'pending'))
        self.log(c,b['id'],'run.queued',{'trigger':key,'workflow_version':w['version']},actor,rid);return rid
    def enqueue(self,uid,wid,key=None):
        key=text(key or ident(),160)
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');w=self._workflow(c,uid,wid,write=True);rid=self._enqueue(c,w,'manual:'+key,uid)
        return self.run(uid,rid)
    def tick(self,now=None):
        now=time.time() if now is None else now;made=[]
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            for row in c.execute("SELECT * FROM ops_workflows WHERE state='active'").fetchall():
                if getattr(self,'access',None):
                    owner=c.execute('SELECT owner FROM ops_brands WHERE id=?',(row['brand_id'],)).fetchone()[0]
                    try:self.access(owner,'work')
                    except PermissionError:
                        c.execute("UPDATE ops_workflows SET state='paused',next_run=NULL WHERE id=?",(row['id'],));self.log(c,row['brand_id'],'workflow.access_paused',{'reason':'Work access expired or account inactive. Renew access, then resume the workflow.'});continue
                w=dict(row);spec=json.loads(c.execute('SELECT definition FROM ops_versions WHERE workflow_id=? AND version=?',(w['id'],w['version'])).fetchone()[0]);s=spec['schedule']
                if w['next_run'] is not None and w['next_run']<=now:
                    made.append(self._enqueue(c,w,'schedule:'+str(int(w['next_run']))));c.execute('UPDATE ops_workflows SET next_run=? WHERE id=?',(next_due(s,now),w['id']))
                if s['kind']=='event':
                    events=c.execute('SELECT e.id FROM ops_events e LEFT JOIN ops_event_receipts r ON r.event_id=e.id AND r.workflow_id=? WHERE e.brand_id=? AND e.kind=? AND e.created>=? AND r.event_id IS NULL LIMIT 10',(w['id'],w['brand_id'],s['event'],w['created'])).fetchall()
                    for event in events:
                        made.append(self._enqueue(c,w,'event:'+event['id']));c.execute('INSERT INTO ops_event_receipts VALUES(?,?)',(w['id'],event['id']))
        return made
    def _run(self,c,uid,rid,write=False):
        r=c.execute('SELECT * FROM ops_runs WHERE id=?',(rid,)).fetchone()
        if not r:raise KeyError('Run not found.')
        self.require(c,uid,r['brand_id'],write=write)
        return {**dict(r),'snapshot':json.loads(r['snapshot'])}
    def run(self,uid,rid):
        with self.connect() as c:
            r=self._run(c,uid,rid);r['steps']=[{**dict(x),'result':json.loads(x['result'])} for x in c.execute('SELECT * FROM ops_steps WHERE run_id=? ORDER BY rowid',(rid,))]
            r['artifacts']=self._artifacts(c,rid);r['approvals']=[dict(x) for x in c.execute('SELECT * FROM ops_approvals WHERE run_id=? ORDER BY revision DESC',(rid,))]
            r['activity']=[{**dict(x),'detail':json.loads(x['detail'])} for x in c.execute('SELECT * FROM ops_activity WHERE run_id=? ORDER BY id',(rid,))];return r
    def run_action(self,uid,rid,action):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');r=self._run(c,uid,rid,write=True)
            state=r['state']
            if action=='cancel' and state in {'queued','running','paused'}:
                c.execute("UPDATE ops_runs SET state='cancelled',finished=? WHERE id=?",(time.time(),rid))
            elif action=='pause' and state in {'queued','running'}:c.execute("UPDATE ops_runs SET state='paused' WHERE id=?",(rid,))
            elif action=='resume' and state=='paused':c.execute("UPDATE ops_runs SET state='queued' WHERE id=?",(rid,))
            elif action=='retry' and state=='failed':
                c.execute("UPDATE ops_steps SET state='pending',attempts=0,retry_at=NULL WHERE run_id=? AND state='failed'",(rid,));c.execute("UPDATE ops_runs SET state='queued',error='',finished=NULL WHERE id=?",(rid,))
            else:raise ValueError('This action is unavailable for the current run state.')
            self.log(c,r['brand_id'],'run.'+action,{},uid,rid)
        return self.run(uid,rid)
    def _artifacts(self,c,rid):
        return [dict(x) for x in c.execute('SELECT id,brand_id,run_id,revision,kind,name,sha256,size,created FROM ops_artifacts WHERE run_id=? ORDER BY revision DESC,kind',(rid,))]
    def artifact(self,uid,aid):
        with self.connect() as c:
            a=c.execute('SELECT * FROM ops_artifacts WHERE id=?',(aid,)).fetchone()
            if not a:raise KeyError('File not found.')
            self.require(c,uid,a['brand_id']);p=Path(a['path']).resolve()
            if not p.is_relative_to(self.root/'artifacts'):raise KeyError('File not found.')
            if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=a['sha256']:raise ValueError('The saved file failed its integrity check.')
            return dict(a),p
    def approve(self,uid,aid,d):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');a=c.execute('SELECT * FROM ops_approvals WHERE id=?',(aid,)).fetchone()
            if not a:raise KeyError('Approval not found.')
            b=self.require(c,uid,a['brand_id'],review=True)
            if b['role'] not in b['config'].get('review_roles',['admin','manager','reviewer']):raise PermissionError('Your role is not a configured reviewer.')
            r=c.execute('SELECT revision FROM ops_runs WHERE id=?',(a['run_id'],)).fetchone()
            hashes=[x['sha256'] for x in self._artifacts(c,a['run_id']) if x['revision']==a['revision']]
            current=digest(sorted(hashes))
            if a['state']!='pending' or r['revision']!=a['revision'] or current!=a['artifact_hash'] or d.get('artifact_hash')!=current:raise ValueError('This approval no longer matches the current artifact version.')
            decision=d.get('decision')
            if decision not in {'approved','rejected'}:raise ValueError('Choose approved or rejected.')
            c.execute('UPDATE ops_approvals SET state=?,reviewer=?,decision_note=?,decided=? WHERE id=?',(decision,uid,text(d.get('note',''),1000),time.time(),aid));self.log(c,a['brand_id'],'approval.'+decision,{'approval_id':aid,'revision':a['revision'],'artifact_hash':current,'action':a['action']},uid,a['run_id'])
        return {'state':decision,'external_action_executed':False}
    def save_lead(self,uid,bid,d):
        with self.connect() as c:
            self.require(c,uid,bid,write=True);data={k:text(d.get(k,''),2000) for k in ['name','company','email','phone','source','facts','assumptions','stage','owner','follow_up','history']}
            if not data['name'] and not data['company']:raise ValueError('Add a contact or company.')
            data['opt_out']=d.get('opt_out') is True;data['communication_permission']='not configured'
            key=data['email'].casefold() or re.sub(r'\D','',data['phone']) or (data['name']+'|'+data['company']).casefold()
            old=c.execute('SELECT id,data FROM ops_leads WHERE brand_id=? AND contact_key=?',(bid,key)).fetchone();lid=old['id'] if old else ident()
            if old and json.loads(old['data']).get('opt_out') and not data['opt_out']:raise ValueError('An existing opt-out cannot be cleared by an import or update.')
            c.execute('INSERT INTO ops_leads VALUES(?,?,?,?,?) ON CONFLICT(brand_id,contact_key) DO UPDATE SET data=excluded.data,updated=excluded.updated',(lid,bid,key,dump(data),time.time()));self.log(c,bid,'lead.saved',{'id':lid,'opt_out':data['opt_out']},uid)
            return {'id':lid,'data':data}
    def update_task(self,uid,tid,d):
        with self.connect() as c:
            row=c.execute('SELECT * FROM ops_tasks WHERE id=?',(tid,)).fetchone()
            if not row:raise KeyError('Task not found.')
            self.require(c,uid,row['brand_id'],write=True);state=d.get('state',row['state'])
            if state not in {'open','in_progress','done','blocked'}:raise ValueError('Invalid task status.')
            c.execute('UPDATE ops_tasks SET state=?,owner=?,due=? WHERE id=?',(state,text(d.get('owner',row['owner']),80),text(d.get('due',row['due']),30),tid));self.log(c,row['brand_id'],'task.updated',{'id':tid,'state':state},uid)
            if state=='done' and row['state']!='done':self.event(c,row['brand_id'],'task.completed')
        return {'ok':True}
    def revise(self,uid,rid,posts):
        if not isinstance(posts,list) or len(posts)!=7:raise ValueError('Keep exactly seven calendar entries.')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');r=self._run(c,uid,rid,write=True)
            if r['state'] not in {'completed','completed_with_blockers'}:raise ValueError('Finish this run before revising its calendar.')
            rows={s['key']:dict(s) for s in c.execute('SELECT * FROM ops_steps WHERE run_id=?',(rid,))};cal=json.loads(rows['calendar']['result'])
            for old,new in zip(cal['posts'],posts):
                for field in ('caption','creative','cta','topic','owner','channel','format','date'):
                    if field in new:old[field]=text(new[field],800 if field in {'caption','creative'} else 200)
                try:dt.date.fromisoformat(old['date'])
                except Exception:raise ValueError('Calendar dates must use YYYY-MM-DD.')
                old['status']='Draft'
            cal['method']='User-revised calendar';newid=ident();now=time.time();snap=r['snapshot'];snap['parent_run_id']=rid
            c.execute('INSERT INTO ops_runs(id,brand_id,workflow_id,version,trigger_key,state,snapshot,created) VALUES(?,?,?,?,?,?,?,?)',(newid,r['brand_id'],r['workflow_id'],r['version'],'revision:'+rid+':'+newid,'queued',dump(snap),now))
            for step in snap['definition']['steps']:
                key=step['id'];old=rows[key];copy=key in {'inputs','seo','tasks','calendar'};value=cal if key=='calendar' else json.loads(old['result'])
                c.execute('INSERT INTO ops_steps(run_id,key,state,result) VALUES(?,?,?,?)',(newid,key,('complete' if key=='calendar' else old['state']) if copy else 'pending',dump(value) if copy else '{}'))
            self.log(c,r['brand_id'],'run.revised',{'previous_run':rid,'approval':'New review required; previous approval applies only to previous files'},uid,newid)
        return self.run(uid,newid)
    def utm(self,uid,bid,d):
        with self.connect() as c:self.require(c,uid,bid,write=True)
        url=text(d.get('url',''),2000);u=urlsplit(url)
        if u.scheme not in {'http','https'} or not u.hostname or u.username or u.password:raise ValueError('Use a valid destination URL.')
        q=dict(parse_qsl(u.query));q.update({'utm_'+k:text(d.get(k,''),150) for k in ('source','medium','campaign')})
        if not all(q['utm_'+k] for k in ('source','medium','campaign')):raise ValueError('Source, medium and campaign are required.')
        return {'url':urlunsplit((u.scheme,u.netloc,u.path,urlencode(q),u.fragment))}
    def connections(self):
        return [{'name':'Public website crawler','status':'ready','scope':'Authorised brand domain; maximum five pages and ten link checks'},
                {'name':'Local Aerny / Ollama','status':'configured','scope':'Optional draft generation; availability checked for each run'},
                {'name':'Spreadsheet and PDF exports','status':'local','scope':'Saved versions with authenticated downloads'},
                {'name':'Search Console / analytics','status':'not connected','scope':'No rankings, volumes, traffic or conversion metrics'},
                {'name':'Social publishing / email / paid ads','status':'not connected','scope':'Drafts only; no external send, publish or spend'},
                {'name':'Firecrawl','status':'unavailable without provider access','scope':'Existing explicit free research fallback remains available in Chat'}]
    def dashboard(self,uid,bid=None):
        brands=self.brands(uid)
        if bid and bid not in {b['id'] for b in brands}:raise KeyError('Brand not found.')
        ids=[bid] if bid else [b['id'] for b in brands];marks=','.join('?' for _ in ids) or 'NULL'
        with self.connect() as c:
            def rows(table,order='rowid DESC',limit=200):return [dict(x) for x in c.execute(f'SELECT * FROM {table} WHERE brand_id IN ({marks}) ORDER BY {order} LIMIT ?',(*ids,limit))]
            workflows=[self._workflow(c,uid,x['id']) for x in rows('ops_workflows')]
            runs=rows('ops_runs',limit=50)
            for r in runs:r.pop('snapshot',None)
            artifacts=rows('ops_artifacts')
            for a in artifacts:a.pop('path',None)
            tasks=rows('ops_tasks');leads=rows('ops_leads');activity=rows('ops_activity')
            for r in tasks:r['detail']=json.loads(r['detail'])
            for r in leads:r['data']=json.loads(r['data'])
            for r in activity:r['detail']=json.loads(r['detail'])
            worker=c.execute('SELECT * FROM ops_worker ORDER BY heartbeat DESC LIMIT 1').fetchone()
            return {'brands':brands,'workflows':workflows,'runs':runs,'tasks':tasks,'artifacts':artifacts,'approvals':rows('ops_approvals'),'leads':leads,'activity':activity,'notifications':rows('ops_notifications'),
                    'roles':roles(),'connections':self.connections(),'worker':{'online':bool(worker and time.time()-worker['heartbeat']<20),'last_seen':worker['heartbeat'] if worker else None},
                    'kpis':{'traffic':None,'rankings':None,'leads':None,'source':'No analytics connection','date':None}}
    def webhook_key(self,uid,wid):
        with self.connect() as c:
            w=self._workflow(c,uid,wid,write=True)
            if w['definition']['schedule']['kind']!='webhook':raise ValueError('Choose a webhook trigger first.')
            self.log(c,w['brand_id'],'webhook.key_rotated',{'workflow_id':wid},uid)
        token=secrets.token_hex(32);p=self.root/'secrets'/(wid+'.key');p.write_text(token);os.chmod(p,0o600)
        return {'key':token,'endpoint':'/api/operations/hooks/'+wid,'algorithm':'HMAC-SHA256(timestamp + newline + event_id + newline + exact body)'}
    def webhook(self,wid,timestamp,event_id,signature,body):
        if not re.fullmatch(r'[0-9a-f]{32}',wid) or len(body)>65536:raise PermissionError('Invalid webhook.')
        try:stamp=int(timestamp);key=(self.root/'secrets'/(wid+'.key')).read_text()
        except Exception:raise PermissionError('Invalid webhook.')
        if abs(time.time()-stamp)>300 or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,120}',event_id):raise PermissionError('Expired or invalid webhook.')
        expected=hmac.new(key.encode(),timestamp.encode()+b'\n'+event_id.encode()+b'\n'+body,hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected,signature):raise PermissionError('Invalid webhook signature.')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');row=c.execute('SELECT * FROM ops_workflows WHERE id=?',(wid,)).fetchone()
            if not row:raise PermissionError('Invalid webhook.')
            w=dict(row);spec=json.loads(c.execute('SELECT definition FROM ops_versions WHERE workflow_id=? AND version=?',(wid,w['version'])).fetchone()[0])
            if spec['schedule']['kind']!='webhook':raise PermissionError('Webhook trigger is disabled.')
            rid=self._enqueue(c,w,'webhook:'+event_id,'signed webhook')
        return {'run_id':rid}
    def delete_brand(self,uid,bid,confirmation):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');b=self.require(c,uid,bid,admin=True)
            if confirmation!=b['name']:raise ValueError('Type the exact brand name to delete its workspace.')
            if c.execute("SELECT 1 FROM ops_runs WHERE brand_id=? AND state IN ('queued','running','paused')",(bid,)).fetchone():raise ValueError('Cancel active runs before deleting the brand.')
            wids=[r[0] for r in c.execute('SELECT id FROM ops_workflows WHERE brand_id=?',(bid,))];rids=[r[0] for r in c.execute('SELECT id FROM ops_runs WHERE brand_id=?',(bid,))]
            for rid in rids:c.execute('DELETE FROM ops_steps WHERE run_id=?',(rid,))
            for wid in wids:
                c.execute('DELETE FROM ops_versions WHERE workflow_id=?',(wid,));c.execute('DELETE FROM ops_event_receipts WHERE workflow_id=?',(wid,));c.execute('DELETE FROM ops_trigger_receipts WHERE workflow_id=?',(wid,));(self.root/'secrets'/(wid+'.key')).unlink(missing_ok=True)
            for table in ['ops_members','ops_knowledge','ops_workflows','ops_runs','ops_tasks','ops_artifacts','ops_approvals','ops_leads','ops_activity','ops_events','ops_notifications']:c.execute(f'DELETE FROM {table} WHERE brand_id=?',(bid,))
            c.execute('DELETE FROM ops_brands WHERE id=?',(bid,))
        shutil.rmtree(self.root/'artifacts'/bid,ignore_errors=True)
        for rid in rids:shutil.rmtree(self.root/'scratch'/rid,ignore_errors=True)
        return {'deleted':True,'backup_note':'Existing administrator backups retain their own retention policy.'}
    def purge_expired(self,now=None):
        now=time.time() if now is None else now;folders=[]
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            for b in c.execute('SELECT * FROM ops_brands').fetchall():
                cutoff=now-int(json.loads(b['config']).get('retention_days',365))*86400
                runs=c.execute("SELECT id FROM ops_runs WHERE brand_id=? AND finished<? AND state IN ('completed','completed_with_blockers','failed','cancelled')",(b['id'],cutoff)).fetchall()
                for r in runs:
                    rid=r['id'];folders.append(self.root/'artifacts'/b['id']/rid);folders.append(self.root/'scratch'/rid)
                    for table in ['ops_steps','ops_artifacts','ops_approvals','ops_notifications','ops_activity']:c.execute(f'DELETE FROM {table} WHERE run_id=?',(rid,))
                    c.execute('UPDATE ops_tasks SET run_id=NULL WHERE run_id=?',(rid,));c.execute('DELETE FROM ops_runs WHERE id=?',(rid,))
                if runs:self.log(c,b['id'],'retention.cleaned',{'expired_runs':len(runs),'retention_days':json.loads(b['config']).get('retention_days',365)})
        for folder in folders:shutil.rmtree(folder,ignore_errors=True)
        return len(folders)//2
