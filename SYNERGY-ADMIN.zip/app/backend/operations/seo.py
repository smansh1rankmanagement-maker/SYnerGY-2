"""Bounded, robots-aware public HTML audit. No ranking/performance estimation."""
import hashlib,re,time,xml.etree.ElementTree as ET
from html.parser import HTMLParser
from urllib.parse import urlsplit,urljoin,urlunsplit
from urllib.robotparser import RobotFileParser
from research.net import fetch, safe_log_url, redact

class Page(HTMLParser):
    def __init__(self):
        super().__init__();self.title=[];self.headings=[];self.description='';self.canonical='';self.robots='';self.links=[];self.current=None;self.heading=None
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='title':self.current='title'
        if tag in {'h1','h2','h3'}:self.heading={'level':tag,'text':''};self.headings.append(self.heading)
        if tag=='meta':
            name=a.get('name','').lower()
            if name=='description':self.description=a.get('content','')[:1000]
            if name in {'robots','googlebot'}:self.robots+=' '+a.get('content','')
        if tag=='link' and 'canonical' in a.get('rel','').lower().split():self.canonical=a.get('href','')
        if tag=='a' and a.get('href'):self.links.append(a['href'])
    def handle_endtag(self,tag):
        if tag=='title':self.current=None
        if tag in {'h1','h2','h3'}:self.heading=None
    def handle_data(self,data):
        if self.current=='title':self.title.append(data)
        if self.heading is not None:self.heading['text']+=data[:500]

def audit(brand,fetcher=fetch):
    cfg=brand['config'];url=cfg.get('website','');checked=time.time()
    out={'checked_at':checked,'website':url,'state':'blocked','pages':[],'issues':[],'link_checks':[],'sitemaps':[],'limits':{'pages':5,'link_checks':10},'performance':None}
    if not url or cfg.get('website_authorized') is not True:
        out['blocker']='An authorised InteriFY website URL is required.' if brand['name']=='InteriFY' else 'An authorised website URL is required.';return out
    origin=urlunsplit((urlsplit(url).scheme,urlsplit(url).netloc,'','',''));host=urlsplit(url).hostname;allowed={host}
    def read(u,method='GET'):return fetcher(u,allowed_hosts=allowed,limit=1024*1024,timeout=7,method=method)
    robots=RobotFileParser();robots_url=origin+'/robots.txt'
    try:
        r=read(robots_url);out['robots']={'url':robots_url,'status':r['status'],'checked_at':checked}
        if r['status']==200:robots.parse(r['body'].decode('utf-8',errors='replace').splitlines())
        elif r['status']==404:robots.parse([])
        else:out['blocker']='robots.txt returned HTTP '+str(r['status'])+'; crawl deferred.';return out
    except Exception as e:out['blocker']='robots.txt could not be checked: '+redact(str(e))[:180];return out
    delay=robots.crawl_delay('SYnerGY-Research') or robots.crawl_delay('*') or 0
    if delay>5:out['blocker']='The site requests a crawl delay longer than this bounded audit supports.';return out
    sitemap_urls=(robots.site_maps() or [origin+'/sitemap.xml'])[:2]
    for sm in sitemap_urls:
        if urlsplit(sm).hostname!=host:continue
        try:
            r=read(sm);entry={'url':sm,'status':r['status'],'locations':[]}
            if r['status']==200:
                root=ET.fromstring(r['body']);entry['locations']=[x.text for x in root.iter() if x.tag.rsplit('}',1)[-1]=='loc' and x.text][:100];entry['type']=root.tag.rsplit('}',1)[-1]
            out['sitemaps'].append(entry)
        except Exception as e:out['sitemaps'].append({'url':sm,'error':redact(str(e))[:150]})
    def normal(u):
        p=urlsplit(urljoin(origin,u))
        if p.hostname!=host or p.scheme not in {'http','https'} or p.query or p.username or p.password:return None
        if re.search(r'\.(?:png|jpe?g|webp|gif|pdf|zip|mp4|css|js|svg)$',p.path,re.I):return None
        return urlunsplit((p.scheme,p.netloc,p.path or '/','',''))
    queue=[normal(url)];visited=set();all_links=set();started=time.monotonic()
    while queue and len(out['pages'])<5 and time.monotonic()-started<70:
        u=queue.pop(0)
        if not u or u in visited:continue
        visited.add(u)
        if not robots.can_fetch('SYnerGY-Research',u):out['pages'].append({'url':u,'access':'robots disallowed'});continue
        if delay:time.sleep(delay)
        try:
            r=read(u);p={'url':u,'final_url':r['url'],'status':r['status'],'redirects':r['redirects'],'access':'read','checked_at':checked,'sha256':hashlib.sha256(r['body']).hexdigest()}
            if r['status']!=200:p['access']='http error';out['pages'].append(p);continue
            parser=Page();parser.feed(r['body'].decode('utf-8',errors='replace'));title=' '.join(''.join(parser.title).split());h1=[x['text'].strip() for x in parser.headings if x['level']=='h1'];links=list(dict.fromkeys(filter(None,(normal(urljoin(r['url'],x)) for x in parser.links))))[:60]
            p.update(title=title[:500],description=parser.description,headings=parser.headings[:25],canonical=urljoin(r['url'],parser.canonical) if parser.canonical else '',robots=(parser.robots+' '+r['headers'].get('x-robots-tag','')).strip(),internal_links=links)
            out['pages'].append(p);all_links.update(links)
            for link in links:
                if link not in visited and link not in queue:queue.append(link)
            def issue(code,title,impact,effort,evidence):out['issues'].append({'key':code+':'+hashlib.sha256(u.encode()).hexdigest()[:12],'title':title,'url':u,'impact':impact,'effort':effort,'evidence':evidence,'observed_at':checked})
            if not title:issue('title','Add a descriptive page title','high','low','No title element text was found.')
            if not parser.description:issue('description','Write a page-specific meta description','medium','low','No meta description was found.')
            if len(h1)!=1:issue('h1','Review the main page heading','medium','low',str(len(h1))+' H1 headings observed.')
            if not parser.canonical:issue('canonical','Review whether a canonical URL is needed','medium','low','No canonical link was declared; this alone does not establish a duplication problem.')
            elif urlsplit(p['canonical']).hostname!=host:issue('canonical_external','Review the cross-domain canonical','high','medium',p['canonical'])
            if 'noindex' in p['robots'].lower():issue('noindex','Confirm this page should be excluded from search','high','low','A noindex directive was observed; it may be intentional.')
            if r['redirects']:issue('redirect','Review internal links to this redirected URL','low','low',str(len(r['redirects']))+' redirect(s) observed.')
        except Exception as e:out['pages'].append({'url':u,'access':'failed','error':redact(str(e))[:200]})
    for u in sorted(all_links-visited)[:10]:
        if time.monotonic()-started>90:break
        if not robots.can_fetch('SYnerGY-Research',u):continue
        try:
            r=read(u,'HEAD');out['link_checks'].append({'url':u,'status':r['status'],'redirects':r['redirects']})
            if r['status'] in {404,410}:out['issues'].append({'key':'broken:'+hashlib.sha256(u.encode()).hexdigest()[:12],'title':'Repair the broken internal link','url':u,'impact':'high','effort':'low','evidence':'HTTP '+str(r['status'])+' observed on HEAD request; confirm before changing.','observed_at':checked})
        except Exception as e:out['link_checks'].append({'url':u,'error':redact(str(e))[:150]})
    read_pages=[p for p in out['pages'] if p.get('status')==200]
    out['state']='complete' if read_pages and all(p.get('status')==200 for p in out['pages']) else 'partial' if read_pages else 'blocked'
    if not read_pages:out['blocker']='No permitted HTML page could be read.'
    weights={'high':0,'medium':1,'low':2};out['issues'].sort(key=lambda x:(weights[x['impact']],weights.get(x['effort'],1)))
    out['limitations']=['Limited sample, not a complete site audit.','No JavaScript rendering, Search Console, keyword volume, rankings, traffic or backlink data.','Recommendations require human review; no website changes were made.']
    return out
