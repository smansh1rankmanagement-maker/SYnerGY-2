"""SYnerGY Brand Operations: local, account-authorised durable workflows."""
