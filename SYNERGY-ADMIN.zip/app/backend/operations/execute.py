"""One bounded step process. Returns data; database commits belong to the worker."""
import json,os,sys,threading,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from operations.seo import audit
from operations.content import calendar
from operations.artifacts import workbook,pdf,report_data

def execute(task):
    key=task['key'];snap=task['snapshot'];brand=snap['brand'];results=task['results'];folder=Path(task['folder']);folder.mkdir(parents=True,exist_ok=True,mode=0o700)
    if key=='inputs':
        missing=[]
        if brand['approved_revision']!=brand['revision']:missing.append('Brand brief revision is not approved.')
        if not brand['config'].get('website') or not brand['config'].get('website_authorized'):missing.append('Authorised website URL is missing.')
        return {'state':'blocked' if missing else 'complete','missing':missing,'brand_revision':brand['revision']}
    if key=='seo':return audit(brand)
    if key=='calendar':return calendar(snap,task['created'])
    if key=='tasks':
        items=[]
        for x in results.get('seo',{}).get('issues',[])[:50]:items.append({'key':x['key'],'title':x['title'],'priority':x['impact'],'evidence':x,'kind':'observed issue'})
        for i,missing in enumerate(results.get('inputs',{}).get('missing',[])):items.append({'key':'input-'+str(i),'title':missing,'priority':'high','evidence':{'source':'Brand input check','checked_at':task['created']},'kind':'missing input'})
        if results.get('seo',{}).get('blocker') and not any('website' in x['title'].lower() for x in items):items.append({'key':'audit-blocker','title':results['seo']['blocker'],'priority':'high','evidence':{'source':'SEO audit'},'kind':'blocked audit'})
        return {'items':items,'count':len(items)}
    if key=='xlsx':
        p=folder/'content-calendar.xlsx';check=workbook(p,snap,results,task['run_id'],task['created']);return {'files':[{'path':str(p),'name':brand['name']+'-content-calendar.xlsx','kind':'xlsx'}],'validation':check}
    if key=='pdf':
        p=folder/'brand-summary.pdf';pdf(p,snap,results,task['run_id'],task['created']);m=folder/'brand-summary.md';m.write_text(report_data(snap,results,task['run_id'],task['created']));e=folder/'evidence.json';e.write_text(json.dumps({'run_id':task['run_id'],'snapshot':snap,'results':results},ensure_ascii=False,indent=2));return {'files':[{'path':str(p),'name':brand['name']+'-summary.pdf','kind':'pdf'},{'path':str(m),'name':brand['name']+'-summary.md','kind':'markdown'},{'path':str(e),'name':brand['name']+'-evidence.json','kind':'evidence'}]}
    if key=='review':return {'requested_action':'Review draft deliverables for this exact version. Approval does not send or publish.'}
    if key=='notify':return {'message':'Brand review finished. Review the saved files and any blocked inputs.'}
    raise ValueError('Unknown workflow step.')

def watch_parent(parent):
    # A killed worker must not leave an inference/export subprocess running.
    while os.getppid()==parent:time.sleep(.5)
    os._exit(125)

if __name__=='__main__':
    threading.Thread(target=watch_parent,args=(os.getppid(),),daemon=True).start()
    try:result=execute(json.load(sys.stdin));print(json.dumps({'ok':True,'result':result},ensure_ascii=False))
    except Exception as e:print(json.dumps({'ok':False,'error':str(e)[:400]}));sys.exit(1)
