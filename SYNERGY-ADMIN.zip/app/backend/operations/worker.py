"""Single-owner durable scheduler and bounded subprocess worker, independent of HTTP."""
import argparse,fcntl,hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from operations.store import Operations,ident,dump,digest
from research.net import redact

class Worker:
    def __init__(self,ops):self.ops=ops;self.stopping=False;self.child=None;self.last_cleanup=0
    def heartbeat(self):
        with self.ops.connect() as c:c.execute('INSERT OR REPLACE INTO ops_worker VALUES(?,?,?)',('local',time.time(),os.getpid()))
    def recover(self):
        with self.ops.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            for r in c.execute("SELECT * FROM ops_runs WHERE state='running'").fetchall():
                c.execute("UPDATE ops_runs SET state='queued',error='' WHERE id=?",(r['id'],));self.ops.log(c,r['brand_id'],'run.recovered',{'reason':'Worker restarted; committed steps retained'},run=r['id'])
            c.execute("UPDATE ops_steps SET state='pending',retry_at=NULL WHERE state='running'")
    def stop(self,*_):self.stopping=True;self.kill()
    def kill(self):
        p=self.child
        if p and p.poll() is None:
            try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=2)
            except (ProcessLookupError,subprocess.TimeoutExpired):
                try:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=2)
                except (ProcessLookupError,subprocess.TimeoutExpired):pass
    def claim(self):
        with self.ops.connect() as c:
            c.execute('BEGIN IMMEDIATE');r=c.execute("SELECT * FROM ops_runs WHERE state='queued' ORDER BY created LIMIT 1").fetchone()
            if not r:return None
            c.execute("UPDATE ops_runs SET state='running',started=COALESCE(started,?),heartbeat=? WHERE id=?",(time.time(),time.time(),r['id']));self.ops.log(c,r['brand_id'],'run.started',{},run=r['id']);return r['id']
    def access_ok(self,rid,owner):
        try:
            if getattr(self.ops,'access',None):self.ops.access(owner,'work')
            return True
        except PermissionError as e:
            with self.ops.connect() as c:c.execute("UPDATE ops_runs SET state='paused',error=? WHERE id=? AND state='running'",(str(e),rid))
            return False
    def process(self,rid):
        with self.ops.connect() as c:
            r=dict(c.execute('SELECT * FROM ops_runs WHERE id=?',(rid,)).fetchone());snap=json.loads(r['snapshot']);defs=snap['definition']['steps']
        for step in defs:
            if self.stopping or not self.access_ok(rid,snap['brand']['owner']):return
            with self.ops.connect() as c:
                r=dict(c.execute('SELECT * FROM ops_runs WHERE id=?',(rid,)).fetchone())
                if r['state']!='running':return
                records={x['key']:dict(x) for x in c.execute('SELECT * FROM ops_steps WHERE run_id=?',(rid,))};rec=records[step['id']]
                if rec['state'] in {'complete','blocked','failed','skipped'}:continue
                if rec['retry_at'] and rec['retry_at']>time.time():
                    c.execute("UPDATE ops_runs SET state='queued' WHERE id=?",(rid,));return
                deps=[records[x] for x in step['after']]
                if any(x['state'] not in {'complete','blocked','failed','skipped'} for x in deps):raise RuntimeError('Invalid step dependency order.')
                if step['id'] in {'xlsx','pdf'} and records['calendar']['state']!='complete':
                    c.execute("UPDATE ops_steps SET state='blocked',result=?,finished=? WHERE run_id=? AND key=?",(dump({'blocker':'Calendar step did not complete.'}),time.time(),rid,step['id']));continue
                if rec['attempts']>=2:
                    c.execute("UPDATE ops_steps SET state='failed',result=?,finished=? WHERE run_id=? AND key=?",(dump({'error':'Retry limit reached after worker interruption.'}),time.time(),rid,step['id']));continue
                attempt=rec['attempts']+1;c.execute("UPDATE ops_steps SET state='running',attempts=?,started=?,retry_at=NULL WHERE run_id=? AND key=?",(attempt,time.time(),rid,step['id']));self.ops.log(c,r['brand_id'],'step.started',{'step':step['id'],'role':step['role'],'attempt':attempt},run=rid)
            folder=self.ops.root/'scratch'/rid/(step['id']+'-'+str(attempt)+'-'+ident());folder.mkdir(parents=True,mode=0o700)
            task={'key':step['id'],'snapshot':snap,'results':{k:json.loads(x['result']) for k,x in records.items()},'folder':str(folder),'run_id':rid,'created':r['created']}
            env={k:v for k,v in os.environ.items() if k in {'PATH','PYTHONPATH','LANG','LC_ALL','TMPDIR','SYNERGY_OPERATIONS_AERNY','SYNERGY_OPERATIONS_MODEL','SYNERGY_OLLAMA_URL'}}
            stdout=folder/'result.json';stderr=folder/'error.txt';started=time.monotonic();interrupted=False;timed_out=False
            with stdout.open('wb') as out,stderr.open('wb') as err:
                self.child=subprocess.Popen([sys.executable,str(Path(__file__).with_name('execute.py'))],stdin=subprocess.PIPE,stdout=out,stderr=err,env=env,start_new_session=True)
                self.child.stdin.write(dump(task).encode());self.child.stdin.close()
                while self.child.poll() is None:
                    self.heartbeat()
                    with self.ops.connect() as c:
                        status=c.execute('SELECT state FROM ops_runs WHERE id=?',(rid,)).fetchone()[0];c.execute('UPDATE ops_runs SET heartbeat=? WHERE id=?',(time.time(),rid))
                    if self.stopping or status!='running' or not self.access_ok(rid,snap['brand']['owner']):interrupted=True;self.kill();break
                    if time.monotonic()-started>step['timeout']:timed_out=True;self.kill();break
                    time.sleep(.25)
            self.child=None
            if interrupted:
                with self.ops.connect() as c:c.execute("UPDATE ops_steps SET state='pending',attempts=MAX(0,attempts-1) WHERE run_id=? AND key=?",(rid,step['id']))
                return
            try:
                if timed_out:raise TimeoutError('Step timed out after '+str(step['timeout'])+' seconds.')
                if stdout.stat().st_size>2*1024*1024:raise ValueError('Step output exceeds limit.')
                payload=json.loads(stdout.read_text())
                if not payload.get('ok'):raise ValueError(payload.get('error','Step failed.'))
                result=payload['result'];self.commit(r,step,result,folder)
            except Exception as exc:
                error=redact(str(exc))[:400]
                with self.ops.connect() as c:
                    current=c.execute('SELECT state FROM ops_runs WHERE id=?',(rid,)).fetchone()[0]
                    if current!='running':return
                    state='pending' if attempt<2 else 'failed';c.execute('UPDATE ops_steps SET state=?,result=?,finished=?,retry_at=? WHERE run_id=? AND key=?',(state,dump({'error':error}),time.time(),time.time()+2 if attempt<2 else None,rid,step['id']));self.ops.log(c,r['brand_id'],'step.error',{'step':step['id'],'error':error,'retry':attempt<2},run=rid)
                    if attempt<2:c.execute("UPDATE ops_runs SET state='queued' WHERE id=?",(rid,));return
        with self.ops.connect() as c:
            c.execute('BEGIN IMMEDIATE');states=[x[0] for x in c.execute('SELECT state FROM ops_steps WHERE run_id=?',(rid,))];state='failed' if 'failed' in states else 'completed_with_blockers' if 'blocked' in states else 'completed'
            changed=c.execute("UPDATE ops_runs SET state=?,finished=? WHERE id=? AND state='running'",(state,time.time(),rid))
            if changed.rowcount:self.ops.log(c,r['brand_id'],'run.finished',{'state':state},run=rid)
    def commit(self,r,step,result,folder):
        rid=r['id'];key=step['id'];new_files=[]
        for item in result.pop('files',[]):
            src=Path(item['path']).resolve()
            if not src.is_relative_to(folder) or not src.is_file() or src.stat().st_size>20*1024*1024:raise ValueError('Invalid artifact path or size.')
            data=src.read_bytes();aid=ident();dest=self.ops.root/'artifacts'/r['brand_id']/rid/str(r['revision'])/(aid+src.suffix);dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700);dest.write_bytes(data);os.chmod(dest,0o600)
            new_files.append((aid,r['brand_id'],rid,r['revision'],item['kind'],item['name'],str(dest),hashlib.sha256(data).hexdigest(),len(data),time.time()))
        with self.ops.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute('SELECT state FROM ops_runs WHERE id=?',(rid,)).fetchone()[0]!='running':return
            for a in new_files:c.execute('INSERT OR IGNORE INTO ops_artifacts VALUES(?,?,?,?,?,?,?,?,?,?)',a)
            if new_files:result['artifact_ids']=[a[0] for a in new_files]
            if key=='tasks':
                for item in result.get('items',[]):
                    action_key=rid+':'+item['key'];c.execute('INSERT OR IGNORE INTO ops_tasks VALUES(?,?,?,?,?,?,?,?,?,?)',(ident(),r['brand_id'],rid,action_key,item['title'],'open',item['priority'],'Unassigned','',dump(item)))
            if key=='review':
                artifacts=[a for a in self.ops._artifacts(c,rid) if a['revision']==r['revision']]
                if {'pdf','xlsx'}<={a['kind'] for a in artifacts}:
                    c.execute('INSERT OR IGNORE INTO ops_approvals VALUES(?,?,?,?,?,?,?,?,?,?,?)',(ident(),r['brand_id'],rid,r['revision'],'Review draft deliverables',digest(sorted(a['sha256'] for a in artifacts)),'pending',None,'',time.time(),None))
                else:result.update(state='blocked',blocker='Required spreadsheet or PDF is missing; approval was not requested.')
            if key=='notify':c.execute('INSERT OR IGNORE INTO ops_notifications VALUES(?,?,?,?,?)',(ident(),r['brand_id'],rid,result['message'],time.time()))
            state='blocked' if result.get('state') in {'blocked','partial'} else 'complete';c.execute('UPDATE ops_steps SET state=?,result=?,finished=? WHERE run_id=? AND key=?',(state,dump(result),time.time(),rid,key));self.ops.log(c,r['brand_id'],'step.'+state,{'step':key,'role':step['role'],'artifact_ids':result.get('artifact_ids',[])},run=rid)
    def loop(self):
        self.recover()
        while not self.stopping:
            self.heartbeat()
            try:
                if time.time()-self.last_cleanup>86400:self.ops.purge_expired();self.last_cleanup=time.time()
                self.ops.tick();rid=self.claim()
                if rid:self.process(rid)
            except Exception as exc:print('Worker error: '+redact(str(exc)),flush=True)
            time.sleep(1)
        self.kill()

def main():
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);args=p.parse_args();ops=Operations(args.data/'accounts.sqlite3',args.data/'operations')
    from membership import Membership
    ops.access=Membership(ops.db).require
    lock=(ops.root/'worker.lock').open('w')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit('Another Brand Operations worker owns this data directory.')
    worker=Worker(ops);signal.signal(signal.SIGTERM,worker.stop);signal.signal(signal.SIGINT,worker.stop);worker.loop()

if __name__=='__main__':main()
