"""Administrator-only curated source browsing and non-executing Python tool."""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import threading
import tokenize
import zipfile
from admin_workspace import AdminWorkspace
from beast.store import Conflict

ROOT = Path(__file__).resolve().parents[2]
TOOL = ROOT/'tools/python_scrambler/worker.py'
TOOL_SLOTS = threading.BoundedSemaphore(1)


class SourceVault:
    def __init__(self, root=None):
        self.root = Path(root or os.environ.get('SYNERGY_SOURCE_VAULT', str(ROOT/'source-vault')))

    def catalog(self):
        try:
            manifest = json.loads((self.root/'manifest.json').read_text())
            archive = self.root/'synergy.zip'
            if archive.stat().st_size > 128*1024*1024:
                raise ValueError('Oversized source archive.')
            if manifest.get('folder') != 'synergy' or not 1 <= len(manifest['files']) <= 1500:
                raise ValueError('Invalid source manifest.')
            if hashlib.sha256(archive.read_bytes()).hexdigest() != manifest['archive_sha256']:
                raise ValueError('Source archive checksum mismatch.')
            seen = set()
            for entry in manifest['files']:
                p = PurePosixPath(entry['path'])
                if p.is_absolute() or '..' in p.parts or '\\' in entry['path'] or entry['id'] in seen:
                    raise ValueError('Invalid source entry.')
                if entry['id'] != hashlib.sha256(entry['path'].encode()).hexdigest():
                    raise ValueError('Invalid file identifier.')
                seen.add(entry['id'])
            return manifest
        except FileNotFoundError:
            raise FileNotFoundError('The reviewed source archive is not packaged. Run deploy/build_source_vault.py during deployment.') from None

    def read(self, file_id):
        if not isinstance(file_id, str) or not re.fullmatch('[0-9a-f]{64}', file_id):
            raise KeyError('Unknown file identifier.')
        manifest = self.catalog()
        entry = next((e for e in manifest['files'] if e['id'] == file_id), None)
        if not entry:
            raise KeyError('Unknown file identifier.')
        with zipfile.ZipFile(self.root/'synergy.zip') as archive:
            info = archive.getinfo('synergy/'+entry['path'])
            if info.file_size != entry['size'] or info.file_size > 32*1024*1024:
                raise ValueError('Invalid file size.')
            raw = archive.read(info)
        if hashlib.sha256(raw).hexdigest() != entry['sha256']:
            raise ValueError('Source file checksum mismatch.')
        return entry, raw

    def preview(self, file_id):
        entry, raw = self.read(file_id)
        text = None
        if len(raw) <= 262144:
            try:
                encoding = tokenize.detect_encoding(io.BytesIO(raw).readline)[0] if entry['path'].endswith('.py') else 'utf-8'
                text = raw.decode(encoding)
                if '\x00' in text:
                    text = None
            except (UnicodeError, SyntaxError, LookupError):
                pass
        return {**entry, 'text': text, 'preview_available': text is not None, 'editable_live': False}


def python_scramble(request, vault):
    if not isinstance(request, dict) or set(request)-{'source','file_id','preserved_names','options'}:
        raise ValueError('Use source text or a file_id, preserved_names and options. Host paths are not accepted.')
    if ('source' in request) == ('file_id' in request):
        raise ValueError('Supply exactly one of source or file_id.')
    options = request.get('options', {})
    if not isinstance(options, dict) or set(options)-{'include_mapping','max_source_bytes'}:
        raise ValueError('Unknown scrambler options.')
    if 'include_mapping' in options and type(options['include_mapping']) is not bool:
        raise ValueError('include_mapping must be true or false.')
    filename = 'input.py'
    if 'file_id' in request:
        entry, raw = vault.read(request['file_id'])
        if not entry['path'].endswith('.py') or len(raw)>262144:
            raise ValueError('Select a Python file no larger than 256 KiB.')
        try:
            source = raw.decode(tokenize.detect_encoding(io.BytesIO(raw).readline)[0])
        except (UnicodeError, SyntaxError, LookupError):
            raise ValueError('Cannot decode this Python file.') from None
        filename = entry['path']
    else:
        source = request['source']
    if not isinstance(source, str) or len(source.encode('utf-8')) > 262144:
        raise ValueError('Source must be text no larger than 256 KiB.')
    preserved = request.get('preserved_names', [])
    if not isinstance(preserved, list) or len(preserved)>1000 or any(not isinstance(x,str) or len(x)>1000 for x in preserved):
        raise ValueError('Use an array of preserved identifiers (maximum 1000).')
    if not TOOL_SLOTS.acquire(blocking=False):
        raise BlockingIOError('The scrambler is busy. Try again shortly.')
    try:
        payload = {'source':source,'filename':filename,'preserved_names':preserved,**options}
        run = subprocess.run([sys.executable,'-I',str(TOOL)],input=json.dumps(payload,ensure_ascii=False).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=8,env={'PATH':os.defpath,'PYTHONDONTWRITEBYTECODE':'1'},start_new_session=True)
        if len(run.stdout)>2*1024*1024:
            raise ValueError('Scrambler response limit exceeded.')
        try:
            result = json.loads(run.stdout)
        except (ValueError, UnicodeError):
            raise ValueError('Scrambler stopped at a resource limit; reduce source complexity.') from None
        if run.returncode:
            raise ValueError(result.get('error','Transformation failed.'))
        return result
    except subprocess.TimeoutExpired:
        raise ValueError('Scrambler time limit exceeded; use a smaller file.') from None
    finally:
        TOOL_SLOTS.release()


class AdminSourceHTTP:
    source_vault = SourceVault()

    def _source_admin(self, user):
        self.membership.admin(user['id'])
        if self.headers.get('Authorization'):
            raise PermissionError('Use the signed-in administrator workspace, not an extension token.')

    def _source_audit(self, user, action, target, detail):
        with self.membership.connect() as connection:
            self.membership.audit(connection,user['id'],action,target,detail)

    def source_get(self, path, user):
        try:
            self._source_admin(user)
            if path == '/api/admin/source/workspace':
                return self.response(200,AdminWorkspace(self.beast,self.source_vault).status(user['id']))
            if path == '/api/admin/source/workspace/export':
                raw,name=AdminWorkspace(self.beast,self.source_vault).export(user['id'])
                self._source_audit(user,'admin_source_export','synergy',{'live_deployed':False})
                return self.research_download(raw,name)
            if path == '/api/admin/source':
                return self.response(200,self.source_vault.catalog())
            if path == '/api/admin/source/synergy.zip':
                manifest = self.source_vault.catalog()
                self._source_audit(user,'source_download','synergy',{'version':manifest['version'],'sha256':manifest['archive_sha256']})
                return self.research_download((self.source_vault.root/'synergy.zip').read_bytes(),'synergy.zip')
            match = re.fullmatch(r'/api/admin/source/(file|download)/([0-9a-f]{64})',path)
            if not match:
                return self.fail(404,'Source file not found.')
            if match[1] == 'file':
                return self.response(200,self.source_vault.preview(match[2]))
            entry, raw = self.source_vault.read(match[2])
            self._source_audit(user,'source_file_download',match[2],{'path':entry['path']})
            return self.research_download(raw,PurePosixPath(entry['path']).name)
        except PermissionError as exc:
            return self.fail(403,str(exc))
        except KeyError:
            return self.fail(404,'Source file not found.')
        except FileNotFoundError as exc:
            return self.fail(503,str(exc))
        except (ValueError, OSError, zipfile.BadZipFile):
            return self.fail(503,'Reviewed source archive is unavailable or failed its integrity check.')

    def source_post(self, path, data, user):
        try:
            self._source_admin(user)
            workspace=AdminWorkspace(self.beast,self.source_vault)
            if path == '/api/admin/source/workspace':
                if data:raise ValueError('The source is selected by the server; no paths are accepted.')
                result=workspace.create(user['id'])
                self._source_audit(user,'admin_workspace_open',result['project_id'],{'revision':result['revision']})
                return self.response(200,result)
            if path == '/api/admin/source/workspace/jobs':
                result=workspace.submit(user['id'],data)
                self._source_audit(user,'admin_workspace_task',result['id'],{'mode':data['mode']})
                return self.response(202,result)
            if path == '/api/admin/source/workspace/action':
                result=workspace.action(user['id'],data)
                self._source_audit(user,'admin_workspace_action',result['id'],{'action':data['action'],'live_deployed':False})
                return self.response(200,result)
            if path != '/api/admin/source/scramble':
                return self.fail(404,'Not found.')
            result = python_scramble(data,self.source_vault)
            self._source_audit(user,'python_scramble','source',{'renamed_variables':result['report']['renamed_variables'],'skipped_functions':len(result['skipped']),'behaviour':'not_tested'})
            return self.response(200,result)
        except PermissionError as exc:
            return self.fail(403,str(exc))
        except KeyError:
            return self.fail(404,'Source file not found.')
        except Conflict as exc:
            return self.fail(409,str(exc))
        except BlockingIOError as exc:
            return self.fail(503,str(exc))
        except (ValueError, TypeError, UnicodeError) as exc:
            return self.fail(400,str(exc))
        except (OSError, zipfile.BadZipFile):
            return self.fail(503,'The packaged scrambler/source archive is unavailable.')
