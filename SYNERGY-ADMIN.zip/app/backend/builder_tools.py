"""Default building catalogue with honest provider availability."""
import re
from beast.react_preview import available

def catalog():
 return [
 {'id':'vedics','name':'vedics MCP','description':'Private lessons, original practice, frozen assessments, grading and scorecard exports.','builtin':False,'enabled':True,'status':'ready','source':'SYnerGY · stdio MCP 1.0','default':True,'action':'vedics'},
 {'id':'foundr','name':'Founder MCP','description':'Founder tasks, CRM, documents, payroll workbooks and decision briefs. External email/calendar connections are separate.','builtin':False,'enabled':True,'status':'ready','source':'SYnerGY · stdio MCP 1.0 · FOUNDERFIT compatible','default':True,'action':'foundr'},
 {'id':'observation','name':'SYnerGY Observation MCP','description':'Explicit feedback plus an optional private review queue. Approved examples can inform later replies; no automatic weight training. Manage in Settings → Personalization.','builtin':False,'enabled':True,'status':'ready','source':'On this server · v2.0','default':True,'action':'observation'},
 {'id':'builder','name':'SYnerGY app builder','description':'Saved code projects, reviewable changes, source ZIPs and isolated React previews. Open the development workspace to build.','builtin':False,'enabled':True,'status':'ready','source':'On this server','default':True,'action':'beast'},
 {'id':'uiux','name':'UI/UX Pro Max','description':'Installed local design search. Automatically adds design guidance to interface-building tasks.','builtin':False,'enabled':True,'status':'ready','source':'MIT · Next Level Builder','default':True,'action':'beast'},
 {'id':'motion','name':'Framer Motion','description':'Pinned React animation runtime for interactive project previews.','builtin':False,'enabled':available(),'status':'ready' if available() else 'runtime_missing','source':'MIT · Motion · 14.9.1','default':True,'action':'beast'},
 {'id':'apper','name':'Apper','description':'Available in the default catalogue. Apper requires a separate authorised connection for this SYnerGY deployment; your ChatGPT connection is not shared.','builtin':False,'enabled':False,'status':'connection_required','source':'https://mcp.apper.io/v1.1/connect','default':True,'connect_url':'https://apper.io/learn/docs/mcp/apper-for-chatgpt'}]

def request(prompt):
 if re.search(r'\b(?:use|using|install|connect|with)\s+(?:the\s+)?apper\b|\bapper\s+(?:build|create|app|website)',prompt,re.I) and not re.search(r'\b(?:do not|don.t|without)\s+(?:use\s+)?apper\b',prompt,re.I):
  return 'Apper is listed in your tools, but an Apper account is not connected to this SYnerGY server. I cannot start an Apper build or reuse your ChatGPT sign-in. You can build here with the SYnerGY app builder, UI/UX Pro Max and Framer Motion in the development workspace. Apper setup: https://apper.io/learn/docs/mcp/apper-for-chatgpt . No paid Apper service has been activated.'
 return None
