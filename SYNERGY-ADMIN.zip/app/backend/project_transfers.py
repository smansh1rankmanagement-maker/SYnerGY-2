"""Admin-approved delivery of imported project bundles to one email account.

Pending/revoked records use a unique non-login owner ID. Existing ownership
checks then protect every stored object, including old direct download URLs.
No password, session, subscription or unrelated project is moved.
"""
import json,time
from membership import email_value

def protected(c,pid):
    if not c.execute("SELECT 1 FROM sqlite_master WHERE name='project_transfers'").fetchone():return False
    return bool(c.execute('SELECT 1 FROM project_transfers WHERE project_id=?',(pid,)).fetchone())

class ProjectTransfers:
    def __init__(self,ws,membership):
        self.ws=ws;self.membership=membership
        with ws.connect() as c:c.executescript('''
        CREATE TABLE IF NOT EXISTS project_transfers(project_id TEXT PRIMARY KEY,beast_project_id TEXT NOT NULL,source_owner INTEGER NOT NULL,escrow_owner INTEGER UNIQUE NOT NULL,state TEXT NOT NULL,recipient_id INTEGER,recipient_email TEXT,reviewer INTEGER,note TEXT NOT NULL DEFAULT '',version INTEGER NOT NULL DEFAULT 1,created REAL NOT NULL,updated REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS project_transfer_items(project_id TEXT NOT NULL,table_name TEXT NOT NULL,item_id TEXT NOT NULL,PRIMARY KEY(table_name,item_id));
        ''')
    def tables(self,c):return {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    def collect(self,c,t):
        tables=self.tables(c);pid=t['project_id'];bid=t['beast_project_id'];scope={}
        for r in c.execute('SELECT table_name,item_id FROM project_transfer_items WHERE project_id=?',(pid,)):scope.setdefault(r[0],set()).add(r[1])
        def add(table,ids):
            if table in tables:scope.setdefault(table,set()).update(x for x in ids if x)
        def related(table,col,ids):
            if table not in tables or not ids:return []
            return list(c.execute('SELECT * FROM '+table+' WHERE '+col+' IN ('+','.join('?' for _ in ids)+')',tuple(ids)))
        add('work_projects',[pid]);add('beast_projects',[bid])
        chats=related('conversations','project_id',[pid]);add('conversations',[r['id'] for r in chats]);cids=scope.get('conversations',set())
        tasks=related('research_tasks','conversation_id',cids);add('research_tasks',[r['id'] for r in tasks])
        uploads=related('large_uploads','conversation_id',cids);add('large_uploads',[r['id'] for r in uploads]);add('research_files',[r['research_id'] for r in uploads])
        for table in ['beast_jobs','beast_references']:add(table,[r['id'] for r in related(table,'project_id',[bid])])
        add('live_updates',[r['id'] for r in related('live_updates','conversation_id',cids)])
        tickets={r['id']:r for r in related('support_tickets','project_id',[pid])+related('support_tickets','conversation_id',cids)}
        add('support_tickets',tickets);add('support_notifications',[r['id'] for r in related('support_notifications','ticket_id',tickets)])
        if 'work_project_files' in tables:add('research_files',[r['file_id'] for r in related('work_project_files','project_id',[pid])])
        if 'support_files' in tables:add('research_files',[r['file_id'] for r in related('support_files','ticket_id',tickets)])
        # Stored metadata identifies generated artifacts; never follow external URLs.
        texts=[r['metadata'] for r in related('messages','conversation_id',cids)]
        texts += [r['request'] for r in tasks]+[r['detail'] for r in tasks]
        def refs(value):
            if isinstance(value,dict):
                for k,v in value.items():
                    if isinstance(v,str):
                        if k in {'file_id','research_id'}:add('research_files',[v])
                        if k=='studio_job_id':add('studio_jobs',[v])
                        if k=='project_id':add('studio_projects',[v])
                        if k=='job_id':add('jobs',[v]);add('studio_jobs',[v])
                        if k in {'asset_id','base_asset_id','reference_id','mask_id'}:add('studio_assets',[v])
                    refs(v)
            elif isinstance(value,list):
                for v in value:refs(v)
        for text in texts:
            try:refs(json.loads(text))
            except (TypeError,ValueError):pass
        for r in related('studio_jobs','id',scope.get('studio_jobs',set())):add('studio_projects',[r['project_id']])
        for r in related('studio_jobs','project_id',scope.get('studio_projects',set())):add('studio_jobs',[r['id']])
        for table in ['studio_projects','studio_jobs']:
            for r in related(table,'id',scope.get(table,set())):
                refs(json.loads(r['spec']))
                if table=='studio_jobs' and r['result']:refs(json.loads(r['result']))
        owner=c.execute('SELECT user_id FROM work_projects WHERE id=?',(pid,)).fetchone()[0]
        actual={}
        for table,ids in scope.items():
            rows=related(table,'id',ids);ids={r['id'] for r in rows if r['user_id']==owner}
            if not ids:continue
            actual[table]=ids
            for r in rows:
                if r['id'] not in ids:continue
                if table in {'beast_jobs','research_tasks','studio_jobs'} and r['state'] in {'queued','running'}:raise ValueError('Wait for this project’s running tasks to finish or stop them before changing transfer access.')
                if table=='live_updates' and r['state'] in {'queued','dispatching'}:raise ValueError('Resolve queued suggestions before changing transfer access.')
            for item in ids:
                other=c.execute('SELECT project_id FROM project_transfer_items WHERE table_name=? AND item_id=?',(table,item)).fetchone()
                if other and other[0]!=pid:raise ValueError('An item belongs to another transferred project. Separate shared references first.')
        return owner,actual
    def move(self,c,t,new_owner):
        old,scope=self.collect(c,t)
        for table,ids in scope.items():
            c.executemany('INSERT OR IGNORE INTO project_transfer_items VALUES(?,?,?)',[(t['project_id'],table,i) for i in ids])
            c.executemany('UPDATE '+table+' SET user_id=? WHERE id=? AND user_id=?',[(new_owner,i,old) for i in ids])
        # Pending investigations cannot run under an unassigned account.
        if new_owner<0 and 'support_tickets' in scope:
            c.executemany("UPDATE support_tickets SET status='blocked' WHERE id=? AND status IN ('queued','investigating')",[(i,) for i in scope['support_tickets']])
        return {table:len(ids) for table,ids in scope.items()}
    def bootstrap(self):
        with self.ws.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if 'project_source_bundles' not in self.tables(c):return
            for p in c.execute('SELECT p.* FROM work_projects p JOIN project_source_bundles b ON b.project_id=p.id LEFT JOIN project_transfers t ON t.project_id=p.id WHERE t.project_id IS NULL').fetchall():
                if not p['beast_project_id']:continue
                escrow=min(-1,c.execute('SELECT coalesce(min(escrow_owner),0)-1 FROM project_transfers').fetchone()[0]);now=time.time()
                c.execute("INSERT INTO project_transfers VALUES(?,?,?,?,'pending',NULL,NULL,NULL,'Awaiting administrator approval',1,?,?)",(p['id'],p['beast_project_id'],p['user_id'],escrow,now,now))
                t=dict(c.execute('SELECT * FROM project_transfers WHERE project_id=?',(p['id'],)).fetchone());counts=self.move(c,t,escrow)
                self.membership.audit(c,None,'project_transfer_locked',p['id'],{'items':counts})
    def list(self,actor):
        self.membership.admin(actor)
        with self.ws.connect() as c:return [dict(r) for r in c.execute('SELECT t.*,p.name,p.kind,b.revision FROM project_transfers t JOIN work_projects p ON p.id=t.project_id JOIN beast_projects b ON b.id=t.beast_project_id ORDER BY t.created')]
    def review(self,actor,d):
        self.membership.admin(actor);action=d.get('action');note=d.get('note','').strip()
        if action not in {'approve','revoke'} or not 3<=len(note)<=1500:raise ValueError('Choose Approve or Revoke and record a reason.')
        with self.ws.connect() as c:
            c.execute('BEGIN IMMEDIATE');t=c.execute('SELECT * FROM project_transfers WHERE project_id=?',(d.get('project_id'),)).fetchone()
            if not t:raise KeyError('Transfer not found.')
            t=dict(t)
            if type(d.get('version')) is not int or d['version']!=t['version']:raise ValueError('This transfer changed. Refresh and review the current version.')
            email=None;recipient=None
            if action=='approve':
                email=email_value(d.get('email'))
                if d.get('identity_confirmed') is not True:raise ValueError('Confirm that you verified this recipient before approving access.')
                u=c.execute("SELECT id FROM users WHERE lower(email)=? AND account_state='active'",(email,)).fetchone()
                if not u:raise ValueError('That email must belong to an active registered account. No account was created or changed.')
                recipient=u[0]
            counts=self.move(c,t,recipient if recipient is not None else t['escrow_owner'])
            state='approved' if recipient is not None else 'revoked'
            c.execute('UPDATE project_transfers SET state=?,recipient_id=?,recipient_email=?,reviewer=?,note=?,version=version+1,updated=? WHERE project_id=?',(state,recipient,email,actor,note,time.time(),t['project_id']))
            self.membership.audit(c,actor,'project_transfer_'+state,t['project_id'],{'email':email,'recipient_id':recipient,'previous_email':t['recipient_email'],'note':note,'items':counts})
        return {'ok':True,'state':state,'email':email,'version':t['version']+1}
