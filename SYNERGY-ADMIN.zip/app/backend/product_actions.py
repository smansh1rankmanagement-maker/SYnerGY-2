"""Ground product-help requests in implemented actions, never a model guess."""
import re

def intent(prompt):
    if not isinstance(prompt,str):return None
    from connections.chat import intent as website_intent
    website=website_intent(prompt)
    if website:return website
    p=' '.join(prompt.casefold().split())
    if re.search(r'\b(?:extension|extention|extenstion)\b',p):
        if re.search(r'\b(?:what is|what does|explain|meaning of|file extension)\b',p) and not re.search(r'\b(?:download|send|give)\b',p):return None
        # A request to build or debug an extension still belongs in Beast/chat.
        if re.search(r'\b(?:build|create|develop|code|debug|repair|fix|change|modify)\b',p):return None
        if re.search(r'\b(?:give|send|share|download|provide|get|install|where|file|zip|add)\b',p):return {'tool':'extension_download'}
    if re.search(r'\bcanva\b',p) and re.search(r'\b(?:connect|activate|enable|status|connected|activated|install)\b',p):
        return {'tool':'connection_status','provider':'canva'}
    if re.search(r'\b(?:hostinger|aws)\b',p) and re.search(r'\b(?:connect|connection|connected|status)\b',p):
        return {'tool':'connection_status','provider':'hostinger' if 'hostinger' in p else 'aws'}
    return None

def extension_result():
    return {
        'reply':'Here is the SYnerGY Chrome extension ZIP. Download and extract it, open chrome://extensions, enable Developer mode, and choose Load unpacked. Select the extracted folder containing manifest.json. Then open Settings → Extension in SYnerGY and click Connect extension. If it is already installed, replace its files and click Reload in Chrome.',
        'artifacts':[{'name':'SYnerGY-Chrome-Extension.zip','label':'Download SYnerGY extension','kind':'zip','url':'/api/extension/download'}],
        'actions':[{'label':'Extension setup','settings':'extension'}],
        'metrics':{'actual_tool_output':True,'generation_started':False},
    }
