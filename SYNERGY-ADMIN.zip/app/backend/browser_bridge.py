"""Account-scoped, one-use browser command tickets. No executable code accepted."""
import hashlib,json,secrets,time,uuid
from browser_planner import plan_next
TOOLS={'browser_list_authorised_tabs','browser_read_page','browser_navigate','browser_click','browser_fill','browser_scroll','browser_screenshot','browser_console_errors','browser_network_failures','browser_detach','browser_diagnostics_start'}
def digest(s):return hashlib.sha256(s.encode()).hexdigest()
def validate(d):
 if not isinstance(d,dict) or set(d)-{'tool','tab_id','args'}:raise ValueError('Invalid command fields')
 if d.get('tool') not in TOOLS:raise ValueError('Unsupported browser tool')
 if type(d.get('tab_id')) is not int or d['tab_id']<0:raise ValueError('Select an authorised tab')
 a=d.get('args',{});tool=d['tool'];allowed={'browser_navigate':{'url'},'browser_click':{'ref','observation','approved'},'browser_fill':{'ref','observation','value'},'browser_scroll':{'pixels'}}.get(tool,set())
 if not isinstance(a,dict) or set(a)-allowed:raise ValueError('Invalid tool arguments')
 if tool in {'browser_click','browser_fill'}:
  if not all(isinstance(a.get(k),str) and 0<len(a[k])<=100 for k in ('ref','observation')):raise ValueError('Observe the page first')
 if tool=='browser_click' and a.get('approved') is not True:raise PermissionError('Review this exact click before execution')
 if tool=='browser_fill' and (not isinstance(a.get('value'),str) or len(a['value'])>2000):raise ValueError('Field value limit is 2000 characters')
 if tool=='browser_navigate':
  from urllib.parse import urlsplit
  u=urlsplit(a.get('url',''))
  if u.scheme not in {'http','https'} or not u.hostname or u.username or u.password or u.query or u.fragment:raise ValueError('Use an HTTP(S) URL without credentials, query or fragment')
 if tool=='browser_scroll' and (type(a.get('pixels')) is not int or abs(a['pixels'])>2000):raise ValueError('Scroll up to 2000 pixels')
 return {'tool':tool,'tab_id':d['tab_id'],'args':a}
class BrowserBridge:
 def __init__(self,ws):
  self.ws=ws
  with ws.connect() as c:c.executescript('''CREATE TABLE IF NOT EXISTS browser_leases(id TEXT PRIMARY KEY,user_id INTEGER,device TEXT,session TEXT,secret_hash TEXT,expires REAL,tabs TEXT,state TEXT);CREATE TABLE IF NOT EXISTS browser_commands(id TEXT PRIMARY KEY,lease_id TEXT,user_id INTEGER,payload TEXT,expires REAL,state TEXT,created REAL);''')
  with ws.connect() as c:
   columns={r[1] for r in c.execute('PRAGMA table_info(browser_leases)')}
   for name,definition in [('verified','INTEGER DEFAULT 0'),('heartbeat','REAL DEFAULT 0'),('credential','TEXT DEFAULT ""')]:
    if name not in columns:c.execute('ALTER TABLE browser_leases ADD COLUMN '+name+' '+definition)
   c.execute('CREATE TABLE IF NOT EXISTS browser_receipts(request_id TEXT PRIMARY KEY,user_id INTEGER,tool TEXT,verified INTEGER,finished REAL)')
 def authenticate(self,c,uid,d,ready=True):
  r=c.execute('SELECT * FROM browser_leases WHERE id=? AND user_id=?',(d.get('lease'),uid)).fetchone()
  if not r or r['state']=='revoked' or (ready and r['state']!='ready'):raise PermissionError('Browser stopped or paused')
  if r['device']!=d.get('device') or r['session']!=d.get('session') or not secrets.compare_digest(r['secret_hash'],digest(str(d.get('secret','')))):raise PermissionError('Wrong paired device')
  if r['credential'] and r['credential']!=d.get('_credential'):raise PermissionError('Device pairing changed')
  return r
 def heartbeat(self,uid,d):
  with self.ws.connect() as c:
   r=self.authenticate(c,uid,d,False)
   if r['expires']<time.time()-300:raise PermissionError('Session expired; select tabs again')
   expires=time.time()+900
   c.execute('UPDATE browser_leases SET heartbeat=?,expires=? WHERE id=?',(time.time(),expires,r['id']))
  return {'expires':expires,'state':r['state'],'verified':bool(r['verified'])}
 def complete(self,uid,d):
  with self.ws.connect() as c:
   c.execute('BEGIN IMMEDIATE');r=self.authenticate(c,uid,d)
   job=c.execute('SELECT * FROM browser_commands WHERE id=? AND lease_id=? AND user_id=?',(d.get('request_id'),r['id'],uid)).fetchone()
   if not job or job['state']!='claimed' or job['expires']<time.time()-30:raise PermissionError('Command completion expired or cancelled')
   verified=d.get('verified') is True
   c.execute("UPDATE browser_commands SET state=? WHERE id=?",('done' if verified else 'failed',job['id']))
   c.execute('INSERT INTO browser_receipts VALUES(?,?,?,?,?)',(job['id'],uid,'browser_action',int(verified),time.time()))
   if verified:c.execute('UPDATE browser_leases SET verified=1,heartbeat=? WHERE id=?',(time.time(),r['id']))
   c.execute('DELETE FROM browser_receipts WHERE finished<?',(time.time()-86400,))
  return {'verified':verified}
 def identify(self,uid,d):return {'account_id':uid}
 def plan(self,uid,d):
  with self.ws.connect() as c:
   r=self.lease(c,uid,d.get('lease'))
   if not r['verified'] or r['heartbeat']<time.time()-60:raise PermissionError('Browser unavailable or sleeping. Reconnect and verify a page first.')
   if d.get('tab_id') not in json.loads(r['tabs']):raise PermissionError('Tab was not selected')
  return plan_next(d)
 def connect(self,uid,d):
  if not all(isinstance(d.get(k),str) and 16<=len(d[k])<=100 for k in ('device','session')):raise ValueError('Invalid browser session')
  tabs=d.get('tabs');
  if not isinstance(tabs,list) or not 1<=len(tabs)<=10 or any(type(t) is not int or t<0 for t in tabs):raise ValueError('Select 1–10 tabs')
  token=secrets.token_urlsafe(32);lid=uuid.uuid4().hex;expires=time.time()+900
  with self.ws.connect() as c:
   c.execute("UPDATE browser_leases SET state='revoked' WHERE user_id=? AND device=?",(uid,d['device']))
   c.execute('INSERT INTO browser_leases(id,user_id,device,session,secret_hash,expires,tabs,state,credential) VALUES(?,?,?,?,?,?,?,?,?)',(lid,uid,d['device'],d['session'],digest(token),expires,json.dumps(tabs),'ready',d.get('_credential','')))
  return {'lease':lid,'secret':token,'expires':expires,'verified':False,'probe':self.prepare(uid,{'lease':lid,'command':{'tool':'browser_read_page','tab_id':tabs[0],'args':{}}})}
 def lease(self,c,uid,lid):
  r=c.execute('SELECT * FROM browser_leases WHERE id=? AND user_id=?',(lid,uid)).fetchone()
  if not r or r['expires']<=time.time() or r['state']!='ready':raise PermissionError('Browser session expired, paused or disconnected')
  return r
 def prepare(self,uid,d):
  command=validate(d.get('command'));rid=uuid.uuid4().hex
  with self.ws.connect() as c:
   r=self.lease(c,uid,d.get('lease'))
   c.execute('DELETE FROM browser_commands WHERE expires<?',(time.time()-86400,))
   if c.execute('SELECT COUNT(*) FROM browser_commands WHERE user_id=? AND created>?',(uid,time.time()-60)).fetchone()[0]>=60:raise ValueError('Browser action rate limit reached; wait one minute')
   if command['tab_id'] not in json.loads(r['tabs']):raise PermissionError('Tab was not selected')
   expires=min(r['expires'],time.time()+30)
   c.execute('INSERT INTO browser_commands VALUES(?,?,?,?,?,?,?)',(rid,r['id'],uid,json.dumps(command),expires,'pending',time.time()))
  return {'request_id':rid,'lease':r['id'],'device':r['device'],'session':r['session'],'expires':expires}
 def claim(self,uid,d):
  with self.ws.connect() as c:
   c.execute('BEGIN IMMEDIATE');r=self.lease(c,uid,d.get('lease'));self.authenticate(c,uid,d)
   if not secrets.compare_digest(r['secret_hash'],digest(str(d.get('secret','')))) or r['device']!=d.get('device') or r['session']!=d.get('session'):raise PermissionError('Wrong browser identity')
   job=c.execute('SELECT * FROM browser_commands WHERE id=? AND lease_id=? AND user_id=?',(d.get('request_id'),r['id'],uid)).fetchone()
   if not job or job['expires']<=time.time() or job['state']!='pending':raise PermissionError('Command expired or already claimed; do not retry actions')
   c.execute("UPDATE browser_commands SET state='claimed',payload='{}' WHERE id=?",(job['id'],))
   return {'command':json.loads(job['payload']),'expires':job['expires']}
 def control(self,uid,d):
  action=d.get('action')
  if action not in {'pause','resume','stop'}:raise ValueError('Invalid control')
  with self.ws.connect() as c:
   r=c.execute('SELECT * FROM browser_leases WHERE id=? AND user_id=?',(d.get('lease'),uid)).fetchone()
   if not r:raise PermissionError('Unknown session')
   if r['state']=='revoked' or r['expires']<=time.time():raise PermissionError('Reconnect browser')
   c.execute('UPDATE browser_leases SET state=? WHERE id=?',({'pause':'paused','resume':'ready','stop':'revoked'}[action],r['id']))
   c.execute("UPDATE browser_commands SET state='cancelled',payload='{}' WHERE lease_id=? AND state IN ('pending','claimed')",(r['id'],))
  return {'state':action}
