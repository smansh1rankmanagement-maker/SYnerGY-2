"""Explicit user install requests; pinned workflows and bounded source imports."""
import json,re,urllib.parse
from extensions import install,repository,fetch,parse_skill,ImportError
from beast.safety import path as safe_path,record

START=re.compile(r'^\s*(?:(?:please|can you|could you)\s+)?install\b',re.I)
def intent(prompt):
    if not isinstance(prompt,str) or not START.match(prompt):return None
    urls=re.findall(r'https://github\.com/[^\s<>`]+',prompt)
    code=re.search(r'```([\w+-]*)[^\n]*\n([\s\S]*?)```',prompt)
    kind='skill' if re.search(r'\bskill\b',prompt.split('\n')[0],re.I) else 'plugin'
    if urls:return {'kind':kind,'source':urls[0].rstrip(').,]'),'content':''}
    if code:return {'kind':kind,'source':'','content':code[2],'language':code[1].lower()}
    tail=START.sub('',prompt).strip()
    if tail.startswith('---\n') or re.search(r'\b(?:plugin|skill|repository|repo|jarvis|commander|firecrawl)\b',tail,re.I):
        return {'kind':kind,'source':'','content':tail if tail.startswith('---\n') else ''}
    return None

def execute(ws,beast,uid,request,stage,check):
    source=request['source'];content=request['content'];kind=request['kind']
    if source.rstrip('/').removesuffix('.git').lower()=='https://github.com/open-jarvis/openjarvis':
        ws.toggle(uid,'voice',True)
        return {'reply':'OpenJarvis voice is included in this release and is enabled for your account. Use the microphone beside Send. Voice availability is checked when you start it. The installed speech adapter uses Faster-Whisper and Kokoro; this does not install unrestricted Jarvis agents.','installed':[],'source':source,'status':'enabled'}
    if content:
        is_skill=kind=='skill' or content.lstrip().startswith('---\n') and re.search(r'(?m)^name:\s*\S',content)
        if is_skill:
            stage('Installing the supplied skill');check()
            return install(ws,uid,'skill',content=content)
        if not beast:raise ImportError('The source workspace is unavailable.')
        lang=request.get('language','');ext={'python':'py','javascript':'js','typescript':'ts','rust':'rs','c++':'cpp','bash':'sh','markdown':'md'}.get(lang,lang or 'txt')
        if not re.fullmatch(r'[a-z0-9]{1,12}',ext):ext='txt'
        project=beast.create(uid,{'name':'Imported code','brief':'User supplied code. Source saved for review; no install scripts or application runtime executed.','files':{'main.'+ext:content}})
        return source_result(project,'Pasted code',1,[])
    if not source:raise ImportError('Paste a public GitHub repository link or a fenced SKILL.md/code block after “install”. For a reviewed runtime, use “Install Desktop Commander”.')
    stage('Reading GitHub and pinning the source commit');check()
    repo=repository(source)
    with ws.connect() as c:old=c.execute('SELECT id,status,metadata FROM plugins WHERE user_id=? AND source=?',(uid,repo['source'])).fetchone()
    if old:return {'reply':repo['name']+' is already saved in Plugins. Current status: '+old['status'].replace('_',' ')+'.','installed':[],'plugin_id':old['id'],'status':old['status'],'source':repo['source']}
    if repo['skills']:
        # Reuse pinned repository response; avoid resolving a moving HEAD again.
        stage('Installing '+str(len(repo['skills']))+' workflow(s)');check()
        if kind=='skill' and len(repo['skills'])!=1:raise ImportError('This repository has several skills. Use “install this plugin” for the bundle, or link one SKILL.md file.')
        if kind=='skill':
            existing=next((s for s in ws.skills(uid) if s.get('source')==repo['skills'][0]['source']),None)
            if existing:return {'reply':existing['name']+' is already installed from this commit. It is available in Skills.','installed':[existing['id']],'source':existing['source'],'status':'ready'}
            item=ws.save_skill(uid,repo['skills'][0]);return {'reply':'Installed '+item['name']+'. It is available in every mode; name it in your next message or select it in Skills.','installed':[item['id']],'source':item['source'],'status':'ready'}
        status='skills_ready_runtime_setup' if repo['runtime_manifest'] else 'ready'
        pid=ws.save_plugin(uid,{'name':repo['name'],'description':str(len(repo['skills']))+' pinned GitHub workflows','source':repo['source'],'status':status,'metadata':{'commit':repo['commit'],'skill_count':len(repo['skills'])}})
        ids=[]
        try:
            for item in repo['skills']:check();ids.append(ws.save_skill(uid,{**item,'plugin_id':pid})['id'])
        except BaseException:
            with ws.connect() as c:c.execute('DELETE FROM skills WHERE user_id=? AND plugin_id=?',(uid,pid));c.execute('DELETE FROM plugins WHERE user_id=? AND id=?',(uid,pid))
            raise
        return {'reply':'Installed '+repo['name']+' with '+str(len(ids))+' workflow(s). Name a skill in your next message or select it in Skills, in any mode.'+(' Its executable connector still needs a reviewed runtime configuration.' if repo['runtime_manifest'] else ''),'installed':ids,'plugin_id':pid,'source':repo['source'],'commit':repo['commit'],'status':status}
    if kind=='skill':raise ImportError('No SKILL.md was found. Use “install” with this link to import its source into Beast, or paste a SKILL.md workflow.')
    stage('Importing repository source for review');files={};skipped=[];total=0
    for entry in repo['entries']:
        check();name=entry['path']
        if repo['prefix'] and not (name==repo['prefix'] or name.startswith(repo['prefix'].rstrip('/')+'/')):continue
        try:safe_path(name)
        except ValueError:skipped.append(name);continue
        if entry.get('mode') not in {'100644','100755'} or entry.get('size',0)>180000 or len(files)>=60:skipped.append(name);continue
        raw=fetch('https://raw.githubusercontent.com/'+repo['slug']+'/'+repo['commit']+'/'+urllib.parse.quote(name,safe='/'),200000)
        if total+len(raw)>2_000_000:skipped.append(name);continue
        try:value=record(name,raw.decode('utf-8-sig'))
        except (ValueError,UnicodeError):skipped.append(name);continue
        files[name]=value;total+=len(raw)
    if not files:raise ImportError('No supported source files could be imported. Use a smaller source repository or a SKILL.md folder.')
    check();project=beast.create(uid,{'name':repo['name'][:80],'brief':'Source: '+repo['source']+'\nCommit: '+repo['commit']+'\nImported for review. No runtime or install scripts executed.','files':files})
    result=source_result(project,repo['source'],len(files),skipped);result['commit']=repo['commit']
    result['plugin_id']=ws.save_plugin(uid,{'name':repo['name'],'description':'Source saved in Beast for review and setup.','source':repo['source'],'status':'source_imported_setup','metadata':{'commit':repo['commit'],'beast_project_id':project['id'],'skipped_files':skipped,'runtime_setup_required':True}})
    return result

def source_result(project,source,count,skipped):
    return {'reply':'Saved '+str(count)+' source file(s) in Beast project “'+project['name']+'”. Open it to inspect, edit and export the code. '+('Skipped '+str(len(skipped))+' unsupported, oversized or sensitive file(s). ' if skipped else '')+'Runtime setup is still required; this repository is not yet an executable SYnerGY tool. No repository scripts were run.','installed':[],'status':'source_imported_setup','beast_project_id':project['id'],'source':source,'file_count':count,'skipped_files':skipped}
