"""Import GitHub SKILL.md workflows as data; repository code is never executed."""
import base64,json,posixpath,re,urllib.error,urllib.parse,urllib.request

class ImportError(ValueError):pass

def fetch(url,limit=2_000_000):
 req=urllib.request.Request(url,headers={'User-Agent':'SYnerGY-local-workspace/1.4','Accept':'application/vnd.github+json'})
 try:
  with urllib.request.urlopen(req,timeout=25) as r:
   if urllib.parse.urlsplit(r.url).hostname not in {'api.github.com','raw.githubusercontent.com'}:raise ImportError('Unexpected repository destination.')
   b=r.read(limit+1)
 except urllib.error.HTTPError as e:
  if e.code in {403,429}:raise ImportError('GitHub temporarily limited repository access. Try again later.') from e
  raise ImportError('This public GitHub repository or file could not be read.') from e
 except OSError as e:raise ImportError('GitHub is unreachable. Your existing skills are unchanged.') from e
 if len(b)>limit:raise ImportError('Repository metadata exceeds the import limit.')
 return b

def parse_skill(text,path='SKILL.md'):
 if not isinstance(text,str) or not text.strip() or len(text)>50000:raise ImportError('Skill file is empty or too large.')
 text=text.replace('\r\n','\n');meta={};body=text
 if text.startswith('---\n'):
  parts=text.split('\n---',1)
  if len(parts)==2:
   for line in parts[0].splitlines()[1:]:
    m=re.match(r'(name|description):\s*(.*)',line)
    if m:meta[m[1]]=m[2].strip().strip('\"\'')
   body=parts[1].strip()
 name=meta.get('name') or next((x.lstrip('# ').strip() for x in body.splitlines() if x.startswith('# ')),path.split('/')[-2] if '/' in path else 'Imported skill')
 return {'name':name[:80],'description':meta.get('description','Imported GitHub workflow')[:240],'instructions':body[:16000]}

def repository(source):
 if not isinstance(source,str) or len(source)>1000:raise ImportError('Use a public GitHub repository link.')
 try:u=urllib.parse.urlsplit(source.strip())
 except ValueError:raise ImportError('Use a public github.com repository link.')
 if u.scheme!='https' or u.hostname!='github.com' or u.username or u.password or u.port:raise ImportError('Use an HTTPS github.com repository link.')
 parts=u.path.strip('/').split('/');owner=parts[0] if parts else '';repo=(parts[1] if len(parts)>1 else '').removesuffix('.git')
 if not all(re.fullmatch(r'[A-Za-z0-9_.-]{1,100}',v) and v not in {'.','..'} for v in [owner,repo]):raise ImportError('Invalid GitHub repository link.')
 ref='HEAD';prefix=''
 if len(parts)>2:
  if parts[2] not in {'tree','blob'} or len(parts)<4:raise ImportError('Use a repository, folder, or SKILL.md link.')
  ref=parts[3];prefix='/'.join(parts[4:])
 api=f'https://api.github.com/repos/{owner}/{repo}'
 commit=json.loads(fetch(api+'/commits/'+urllib.parse.quote(ref,safe='')));sha=commit.get('sha','')
 if not re.fullmatch('[0-9a-f]{40}',sha):raise ImportError('GitHub did not return a pinned commit.')
 tree_sha=commit.get('commit',{}).get('tree',{}).get('sha',sha)
 if not re.fullmatch('[0-9a-f]{40}',tree_sha):raise ImportError('GitHub did not return a valid tree.')
 tree=json.loads(fetch(api+'/git/trees/'+tree_sha+'?recursive=1'))
 if tree.get('truncated'):raise ImportError('Repository is too large. Link a smaller skill repository.')
 paths=[x['path'] for x in tree.get('tree',[]) if x.get('type')=='blob' and isinstance(x.get('path'),str)]
 chosen=[p for p in paths if p.rsplit('/',1)[-1]=='SKILL.md' and (not prefix or p==prefix or p.startswith(prefix.rstrip('/')+'/'))]
 if len(chosen)>25:raise ImportError('This repository has more than 25 skills. Link the specific skill folder to import.')
 skills=[]
 for path in chosen:
  text=fetch(f'https://raw.githubusercontent.com/{owner}/{repo}/{sha}/'+urllib.parse.quote(path,safe='/'),100000).decode('utf-8')
  item=parse_skill(text,path)
  # Include small, explicitly linked Markdown references so imported workflows
  # can use their written examples without pretending to execute helper code.
  links=re.findall(r'\[[^\]]*\]\(([^)]+\.md)\)',text)+re.findall(r'`((?:references|examples)/[A-Za-z0-9_./-]+\.md)`',text)
  resources=[];budget=16000-len(item['instructions'])
  for rel in list(dict.fromkeys(links))[:6]:
   if '://' in rel:continue
   linked=posixpath.normpath(posixpath.join(posixpath.dirname(path),rel))
   if linked not in paths or linked==path or budget<300:continue
   raw=fetch(f'https://raw.githubusercontent.com/{owner}/{repo}/{sha}/'+urllib.parse.quote(linked,safe='/'),100000).decode('utf-8')
   block='\n\nReference: '+rel+'\n'+raw
   item['instructions']+=block[:budget];budget-=len(block);resources.append(linked)
  item['source']=f'https://github.com/{owner}/{repo}/blob/{sha}/'+urllib.parse.quote(path,safe='/');skills.append(item)
 runtime=any(p.endswith(('mcp.json','.mcp.json')) for p in paths)
 return {'name':repo,'source':f'https://github.com/{owner}/{repo}'+('/tree/'+ref+'/'+prefix if prefix else ''),'commit':sha,'skills':skills,'runtime_manifest':runtime,'slug':owner+'/'+repo,'prefix':prefix,'entries':[x for x in tree.get('tree',[]) if x.get('type')=='blob' and isinstance(x.get('path'),str)]}

def install(store,uid,kind,source='',content=''):
 if kind not in {'plugin','skill'}:raise ImportError('Choose plugin or skill.')
 if content:
  if kind!='skill':raise ImportError('Paste a SKILL.md file to install a skill, or provide a GitHub link for a plugin bundle.')
  item=parse_skill(content);item['source']='Pasted SKILL.md';saved=store.save_skill(uid,item)
  return {'reply':f'Installed {saved["name"]}. It is available in Skills. Select Use skill to apply its instructions to a conversation.','kind':'skill','installed':[saved['id']]}
 repo=repository(source);skills=repo['skills']
 if kind=='skill':
  if len(skills)!=1:raise ImportError('Link one SKILL.md file or skill folder. Use “install this plugin” to import a bundle of skills.' if skills else 'No SKILL.md was found. This repository needs a compatible skill definition.')
  saved=store.save_skill(uid,skills[0]);return {'reply':f'Installed {saved["name"]} from GitHub. Open Skills and select Use skill.','kind':'skill','installed':[saved['id']],'source':saved['source']}
 if not skills:raise ImportError('This repository does not contain a SKILL.md workflow. Its executable tools need a compatible connector and runtime; no installation scripts were run.')
 status='skills_ready_runtime_setup' if repo['runtime_manifest'] else 'ready'
 pid=store.save_plugin(uid,{'name':repo['name'],'description':f'{len(skills)} reusable GitHub workflow'+('s' if len(skills)!=1 else ''),'source':repo['source'],'status':status,'metadata':{'commit':repo['commit'],'skill_count':len(skills),'runtime_setup_required':repo['runtime_manifest']}})
 ids=[]
 try:
  for item in skills:ids.append(store.save_skill(uid,{**item,'plugin_id':pid})['id'])
 except Exception:
  with store.connect() as c:c.execute('DELETE FROM skills WHERE plugin_id=? AND user_id=?',(pid,uid));c.execute('DELETE FROM plugins WHERE id=? AND user_id=?',(pid,uid))
  raise
 suffix=' The repository also declares a runtime connector; that connector still needs setup.' if repo['runtime_manifest'] else ''
 return {'reply':f'Installed {repo["name"]} with {len(ids)} skill'+('s' if len(ids)!=1 else '')+'. Open Skills to use them.'+suffix,'kind':'plugin','installed':ids,'source':repo['source'],'plugin_id':pid}
