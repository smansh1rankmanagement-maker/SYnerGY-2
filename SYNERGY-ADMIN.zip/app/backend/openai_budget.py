"""Conservative shared request allowance. No keys or prompt text are stored here.

Reservations survive interrupted workers. It is an application allowance, not a
statement of the provider's credit balance. Standard short-context model rates
are conservatively accounted without cached-input discounts.
"""
import json,os,sqlite3,time,uuid
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from pathlib import Path

RATES = {'gpt-6.1-sol': (Decimal('2'), Decimal('10')), 'gpt-6-luna': (Decimal('0.1'), Decimal('0.5'))}

def cost(model, input_tokens, output_tokens):
    if model not in RATES: raise ValueError('This model has no reviewed cost policy.')
    inp,out=RATES[model]
    return int((input_tokens*inp+output_tokens*out).to_integral_value(rounding=ROUND_CEILING))

def db():
    root=Path(os.environ.get('SYNERGY_DATA_DIR',str(Path.home()/'.synergy-ai')));root.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(root/'openai-usage.sqlite3',timeout=20);c.row_factory=sqlite3.Row
    c.execute("CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY, reserved INTEGER NOT NULL, charged INTEGER, state TEXT NOT NULL, created REAL NOT NULL, input_tokens INTEGER, output_tokens INTEGER, model TEXT NOT NULL DEFAULT 'gpt-6.1-sol', user_id INTEGER)")
    columns={r['name'] for r in c.execute('PRAGMA table_info(requests)')}
    for name,definition in [('model',"TEXT NOT NULL DEFAULT 'gpt-6.1-sol'"),('user_id','INTEGER')]:
        if name not in columns:
            try:c.execute('ALTER TABLE requests ADD COLUMN '+name+' '+definition)
            except sqlite3.OperationalError as exc:
                if 'duplicate column name' not in str(exc):raise
    c.execute('CREATE TABLE IF NOT EXISTS budget_policy(id INTEGER PRIMARY KEY CHECK(id=1), total INTEGER NOT NULL, percent INTEGER NOT NULL, revision INTEGER NOT NULL, updated REAL NOT NULL, actor INTEGER NOT NULL)')
    c.execute('CREATE TABLE IF NOT EXISTS budget_audit(id TEXT PRIMARY KEY, actor INTEGER NOT NULL, total INTEGER NOT NULL, percent INTEGER NOT NULL, note TEXT NOT NULL, created REAL NOT NULL)')
    c.execute('CREATE TABLE IF NOT EXISTS provider_health(id INTEGER PRIMARY KEY CHECK(id=1), state TEXT NOT NULL, observed REAL NOT NULL)')
    return c

def policy(c):
    row=c.execute('SELECT * FROM budget_policy WHERE id=1').fetchone()
    if row:return dict(row)
    # Existing installations retain their allowance until the owner configures it.
    total=max(0,min(2_000_000,int(Decimal(os.environ.get('SYNERGY_OPENAI_BUDGET_USD','0'))*1_000_000)))
    return {'total':total,'percent':10000,'revision':0,'updated':None,'actor':None}

def ceiling(c=None):
    if c is None:
        with db() as connection:return ceiling(connection)
    p=policy(c);return p['total']*p['percent']//10000

def configure(total_budget_usd,usage_percent,actor,note,revision):
    if not isinstance(note,str) or not 3<=len(note.strip())<=600:raise ValueError('Record a reason for the usage limit change.')
    try:
        total=Decimal(str(total_budget_usd));percent=Decimal(str(usage_percent))
        if not total.is_finite() or not percent.is_finite() or not 0<=total<=10000 or not 0<=percent<=100:raise ValueError()
        if total!=total.quantize(Decimal('.01')) or percent!=percent.quantize(Decimal('.01')):raise ValueError()
        amount=int(total*1_000_000);basis=int(percent*100)
    except (InvalidOperation,ValueError):raise ValueError('Use a budget from $0 to $10,000 and a percentage from 0 to 100, with at most two decimals.') from None
    if type(actor) is not int or actor<1:raise ValueError('An authenticated administrator is required.')
    with db() as c:
        c.execute('BEGIN IMMEDIATE');old=policy(c)
        if type(revision) is not int or revision!=old['revision']:raise ValueError('The budget changed. Reload the administrator overview before saving.')
        c.execute('INSERT OR REPLACE INTO budget_policy VALUES(1,?,?,?,?,?)',(amount,basis,old['revision']+1,time.time(),actor))
        c.execute('INSERT INTO budget_audit VALUES(?,?,?,?,?,?)',(uuid.uuid4().hex,actor,amount,basis,note.strip(),time.time()))
    return status()

def status():
    with db() as c:
        spent,held=c.execute("SELECT coalesce(sum(charged),0),coalesce(sum(CASE WHEN charged IS NULL THEN reserved ELSE 0 END),0) FROM requests").fetchone()
        p=policy(c);cap=ceiling(c)
        health=c.execute('SELECT state,observed FROM provider_health WHERE id=1').fetchone()
    return {'provider_status':dict(health) if health else {'state':'unverified','observed':None},'total_budget_usd':p['total']/1e6,'usage_percent':p['percent']/100,'revision':p['revision'],'updated':p['updated'],'allowance_usd':cap/1e6,'accounted_usd':spent/1e6,'reserved_usd':held/1e6,'remaining_usd':max(0,cap-spent-held)/1e6,'provider_balance_verified':False,'scope':'Shared by all users; cumulative usage. Changing the cap does not reset spending.','local_requests_limited':False}
def reject(ident,error):
    """Record definite HTTP rejection; never persist provider bodies or keys."""
    try:code=json.loads(error.read()).get('error',{}).get('code')
    except (ValueError,AttributeError):code=None
    state='quota_exhausted' if error.code==429 and code in {'insufficient_quota','credit_balance_exhausted'} else 'authentication_failed' if error.code in {401,403} else 'rate_limited' if error.code==429 else 'request_failed'
    with db() as c:
        # Definite rejection releases this reservation. Ambiguous failures keep it.
        if error.code in {400,401,403,404,422,429}:c.execute("UPDATE requests SET charged=0,state='rejected' WHERE id=? AND charged IS NULL",(ident,))
        c.execute('INSERT OR REPLACE INTO provider_health VALUES(1,?,?)',(state,time.time()))
    return {'quota_exhausted':'OpenAI reports no API credits remaining. SYnerGY will not add credits automatically. Choose SYnerGY or use the local Hybrid fallback.','authentication_failed':'OpenAI rejected the configured credentials. Ask the administrator to check the connection.','rate_limited':'OpenAI is temporarily rate limited. Retry later or choose SYnerGY.','request_failed':'OpenAI rejected this request. Try a shorter request or choose SYnerGY.'}[state]

def reserve(body,user_id=None):
    if body['model'] not in RATES:raise ValueError('This model needs a reviewed cost policy before external requests can run.')
    daily=None
    if user_id is not None:
        from model_router import account_models
        allowed=account_models(user_id)
        if body['model'] not in allowed:raise ValueError('This account cannot use the requested model.')
        setting='SYNERGY_OPENAI_PAID_DAILY_USD' if 'gpt-6.1-sol' in allowed else 'SYNERGY_OPENAI_FREE_DAILY_USD'
        daily=int(Decimal(os.environ.get(setting,'1.00' if 'gpt-6.1-sol' in allowed else '0.10'))*1_000_000)
    body['max_output_tokens']=min(4096,max(16,int(body.get('max_output_tokens',512))))
    body.setdefault('reasoning',{'effort':'low'})
    # UTF-8 byte count plus overhead deliberately overestimates text tokens.
    # Large image payloads exceed this allowance; local vision remains available.
    size=len(json.dumps(body,ensure_ascii=False).encode())
    if size>64000:raise ValueError('This external request is too large for the current allowance. Use fewer files or SYnerGY.')
    amount=cost(body['model'],size+4096,body['max_output_tokens'])
    ident=uuid.uuid4().hex
    with db() as c:
        c.execute('BEGIN IMMEDIATE');used=c.execute('SELECT coalesce(sum(coalesce(charged,reserved)),0) FROM requests').fetchone()[0]
        if used+amount>ceiling(c):raise ValueError('The shared OpenAI allowance is unavailable or exhausted. Choose SYnerGY; no automatic top-up is enabled.')
        if daily is not None:
            start=time.time()//86400*86400
            used_daily=c.execute('SELECT coalesce(sum(coalesce(charged,reserved)),0) FROM requests WHERE user_id=? AND created>=?',(user_id,start)).fetchone()[0]
            if used_daily+amount>daily:raise ValueError('Your daily OpenAI allowance is exhausted. Use SYnerGY or try again tomorrow.')
        c.execute('INSERT INTO requests(id,reserved,charged,state,created,input_tokens,output_tokens,model,user_id) VALUES(?,?,NULL,?,?,NULL,NULL,?,?)',(ident,amount,'reserved',time.time(),body['model'],user_id))
    return ident

def finish(ident,usage):
    if not isinstance(usage,dict) or not all(type(usage.get(k)) is int and usage[k]>=0 for k in ['input_tokens','output_tokens']):return
    # Charge cached input at the full rate as a conservative allowance measure.
    with db() as c:
        row=c.execute('SELECT model FROM requests WHERE id=?',(ident,)).fetchone()
        if not row:return
        charge=cost(row['model'],usage['input_tokens'],usage['output_tokens'])
        c.execute("UPDATE requests SET charged=?,state='completed',input_tokens=?,output_tokens=? WHERE id=? AND charged IS NULL",(charge,usage['input_tokens'],usage['output_tokens'],ident))
        c.execute("INSERT OR REPLACE INTO provider_health VALUES(1,'available',?)",(time.time(),))

def reserve_execution(ident,user_id,model,amount):
    """Reserve full coding-task exposure, shared with ordinary OpenAI requests.

    Managed usage is best-effort and lacks final compute/cache-write charges.
    Keep this reservation until an operator reconciles the provider bill.
    """
    from model_router import account_models
    allowed=account_models(user_id)
    if model not in allowed:raise ValueError('This account cannot use the requested execution model.')
    if type(amount) is not int or not 10000<=amount<=1000000:raise ValueError('Execution allowance must be $0.01–$1.00.')
    setting='SYNERGY_OPENAI_PAID_DAILY_USD' if 'gpt-6.1-sol' in allowed else 'SYNERGY_OPENAI_FREE_DAILY_USD'
    daily=int(Decimal(os.environ.get(setting,'1.00' if 'gpt-6.1-sol' in allowed else '0.10'))*1000000)
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        old=c.execute('SELECT user_id,model,reserved FROM requests WHERE id=?',(ident,)).fetchone()
        if old:
            if tuple(old)!=(user_id,model,amount):raise ValueError('Reservation identity changed.')
            return ident
        total=c.execute('SELECT coalesce(sum(coalesce(charged,reserved)),0) FROM requests').fetchone()[0]
        today=c.execute('SELECT coalesce(sum(coalesce(charged,reserved)),0) FROM requests WHERE user_id=? AND created>=?',(user_id,time.time()//86400*86400)).fetchone()[0]
        if total+amount>ceiling(c):raise ValueError('The shared OpenAI allowance cannot cover this coding task.')
        if today+amount>daily:raise ValueError('Your daily OpenAI allowance cannot cover this coding task.')
        c.execute('INSERT INTO requests(id,reserved,state,created,model,user_id) VALUES(?,?,?,?,?,?)',(ident,amount,'managed_reserved',time.time(),model,user_id))
    return ident

def execution_outcome(ident,state,usage=None,definite_rejection=False):
    with db() as c:
        if definite_rejection:
            c.execute("UPDATE requests SET charged=0,state='managed_rejected' WHERE id=? AND charged IS NULL",(ident,))
        else:
            # Preserve the full reserve: token reports are not a final provider bill.
            valid=isinstance(usage,dict) and all(type(usage.get(k)) is int and usage[k]>=0 for k in ['input_tokens','output_tokens'])
            c.execute('UPDATE requests SET state=?,input_tokens=?,output_tokens=? WHERE id=? AND charged IS NULL',('managed_'+state,usage['input_tokens'] if valid else None,usage['output_tokens'] if valid else None,ident))
