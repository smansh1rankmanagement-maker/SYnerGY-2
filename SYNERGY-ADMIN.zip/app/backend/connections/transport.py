"""Bounded HTTPS to documented provider endpoints. No credential redirects."""
import http.client,json,socket,ssl
from urllib.parse import urlsplit,urlunsplit
from research.net import validate_url

class ConnectionError(ValueError):
    def __init__(self,message,status=None):
        super().__init__(message);self.status=status

def request(url,method='GET',data=None,headers=None,limit=4*1024*1024,timeout=30):
    u,host,port,ips=validate_url(url)
    if u.scheme!='https':raise ConnectionError('Provider connections require HTTPS.')
    conn=http.client.HTTPConnection(host,port,timeout=timeout)
    try:
        conn.sock=socket.create_connection((ips[0],port),timeout=timeout)
        conn.sock=ssl.create_default_context().wrap_socket(conn.sock,server_hostname=host)
        h={'User-Agent':'SYnerGY/2.6 (authorised account integration)','Accept':'application/json','Accept-Encoding':'identity',**(headers or {})}
        if isinstance(data,dict):data=json.dumps(data).encode();h['Content-Type']='application/json'
        conn.request(method,urlunsplit(('','',u.path or '/',u.query,'')),body=data,headers=h)
        r=conn.getresponse();raw=r.read(limit+1)
        if len(raw)>limit:raise ConnectionError('The provider response exceeded the size limit.')
        if not 200<=r.status<300:raise ConnectionError('Provider returned HTTP '+str(r.status)+'. Reconnect if access expired; no action is reported as successful.',status=r.status)
        return raw,dict(r.getheaders())
    except (OSError,TimeoutError,http.client.HTTPException) as exc:raise ConnectionError('The provider could not be reached within the connection limit.') from exc
    finally:conn.close()

def json_request(*a,**kw):
    raw,_=request(*a,**kw)
    try:return json.loads(raw)
    except (ValueError,UnicodeError):raise ConnectionError('The provider returned an invalid JSON response.')

def rpc(url,token,method,params=None):
    headers={'Authorization':'Bearer '+token,'Accept':'application/json, text/event-stream'}
    def send(i,m,p):
        raw,hh=request(url,'POST',{'jsonrpc':'2.0','id':i,'method':m,'params':p},headers,timeout=60)
        session=next((v for k,v in hh.items() if k.lower()=='mcp-session-id'),None)
        if session:headers['Mcp-Session-Id']=session
        try:
            if raw.lstrip().startswith(b'{'):items=[json.loads(raw)]
            else:items=[json.loads(line[5:].strip()) for line in raw.decode().splitlines() if line.startswith('data:') and line[5:].strip()]
            r=next(x for x in reversed(items) if x.get('id')==i)
            if r.get('error'):raise ConnectionError('The MCP server rejected this operation. Check the configured tool and permissions.')
            return r.get('result',{})
        except (StopIteration,ValueError,UnicodeError):raise ConnectionError('The MCP server returned an invalid response.')
    init=send(1,'initialize',{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'SYnerGY','version':'2.6.0'}})
    headers['MCP-Protocol-Version']=init.get('protocolVersion','2025-03-26')
    request(url,'POST',{'jsonrpc':'2.0','method':'notifications/initialized'},headers)
    return send(2,method,params or {})

def tool_data(result):
    if result.get('isError'):raise ConnectionError('The provider tool failed. No change has been confirmed.')
    if isinstance(result.get('structuredContent'),(dict,list)):return result['structuredContent']
    text='\n'.join(c.get('text','') for c in result.get('content',[]) if c.get('type')=='text')
    try:return json.loads(text)
    except ValueError:raise ConnectionError('This provider tool did not return the structured data required for website operations.')
