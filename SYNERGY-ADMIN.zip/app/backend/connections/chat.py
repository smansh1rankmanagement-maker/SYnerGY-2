"""Explicit website commands share the same backend as Connections forms."""
import re,uuid

def intent(prompt):
    if not isinstance(prompt,str):return None
    p=' '.join(prompt.strip().split())
    # Questions/plans must never become publishing actions.
    if re.search(r'\b(?:how|explain|details|would|can i|do not|don.t|not yet|later)\b',p,re.I):return None
    m=re.fullmatch(r'(?:please )?(?:import|load|connect) (?:the )?(?:website |files (?:of|from) )?(?:https?://)?(?:www\.)?([a-z0-9.-]+\.[a-z]{2,})/? (?:from |with |using )?hostinger[.!]?',p,re.I)
    if m:return {'tool':'website_import','domain':m[1].lower()}
    if re.fullmatch(r'(?:please )?(?:review|show|prepare) (?:the )?(?:publishing|publication|deployment) (?:plan|diff)[.!]?',p,re.I):return {'tool':'website_plan'}
    if re.fullmatch(r'(?:please )?(?:publish|deploy|make live) (?:the |these |this )?(?:reviewed |approved )?(?:changes|revision|website|site|it)(?: (?:to|on) (?:https?://)?(?:www\.)?([a-z0-9.-]+\.[a-z]{2,})/?)?(?: now)?[.!]?',p,re.I):return {'tool':'website_publish'}
    return None

def execute(research,uid,req,cid):
    if req['mode']!='beast':return {'reply':'Switch to Beast mode to import website source or review a publication. Your current conversation remains saved.','actions':[{'label':'Website connections','settings':'connections'}]}
    action=req['product_action'];web=research.websites
    if action['tool']=='website_import':
        j=web.submit(uid,'import',{'domain':action['domain'],'request_id':str(uuid.uuid4())})
        return {'reply':'The Hostinger import is queued for '+action['domain']+'. Follow the website job to open the saved Beast project. Nothing is being published.','actions':[{'label':'View import progress','website_job_id':j['id']}]}
    pid=req.get('beast_project_id')
    if not pid:
        chat=research.ws.chat(uid,cid)
        if chat.get('project_id'):pid=research.ws.project(uid,chat['project_id']).get('beast_project_id')
    if not pid:return {'reply':'Open the connected website project in Beast first, then ask “Review the publishing plan”.','actions':[{'label':'Connected websites','settings':'connections'}]}
    # A publish command only acts on a plan already shown in THIS conversation.
    history=research.ws.chat(uid,cid)['messages'][:-1]
    prior=next((a.get('website_plan_id') for m in reversed(history[-12:]) if m['role']=='assistant' for a in m.get('metadata',{}).get('actions',[]) if a.get('website_plan_id')),None)
    if action['tool']=='website_publish' and prior:
        plan=web.get_plan(uid,prior)
        if plan['project_id']!=pid:raise ValueError('The reviewed publication belongs to another project. Review this project’s plan first.')
        explicit=re.search(r'(?:to|on) (?:https?://)?(?:www\.)?([a-z0-9.-]+\.[a-z]{2,})',req['prompt'],re.I)
        if explicit and explicit[1].lower()!=plan['detail']['domain']:raise ValueError('The requested domain does not match the reviewed publishing plan.')
        j=web.submit(uid,'publish',{'plan_id':plan['id'],'reviewed_digest':plan['digest'],'confirmation':'Publish '+plan['detail']['domain'],'request_id':str(uuid.uuid4())})
        return {'reply':'Publishing revision '+str(plan['revision'])+' to '+plan['detail']['domain']+' is queued. The job will verify each uploaded file and report any failure; it is not yet confirmed live.','actions':[{'label':'Publication progress','website_job_id':j['id']}]}
    plan=web.plan(uid,pid)
    return {'reply':'Publication plan prepared for '+plan['detail']['domain']+', revision '+str(plan['revision'])+'. Review the exact diff and preview. Then say “Publish the reviewed changes to '+plan['detail']['domain']+'” or use the publish button. No live files have changed.','actions':[{'label':'Review exact publishing diff','website_plan_id':plan['id']}]}
