import json,re
from urllib.parse import parse_qs,urlsplit
from .hostinger import Hostinger
from .transport import ConnectionError
from .store import digest,canonical

class ConnectionsHTTP:
 def connections_get(self,path,user):
    uid=user['id'];q=parse_qs(urlsplit(self.path).query)
    try:
      if path=='/api/connections':return self.response(200,{'connections':self.connections.list(uid),'websites':self.websites.sites(uid),'jobs':self.websites.jobs(uid)})
      if path=='/api/connections/hostinger/sites':
        self.websites.access(uid);return self.response(200,{'sites':Hostinger(self.connections,uid).sites()})
      if path=='/api/connections/canva/tools':return self.response(200,{'tools':self.connections.tools(uid,'canva')})
      m=re.fullmatch(r'/api/connections/websites/(jobs|plans)/([a-f0-9]{32})',path)
      if m:return self.response(200,(self.websites.job if m[1]=='jobs' else self.websites.get_plan)(uid,m[2]))
    except PermissionError as e:return self.fail(403,str(e))
    except KeyError:return self.fail(404,'Connection item not found in this account.')
    except (ValueError,TypeError) as e:return self.fail(400,str(e))
    return self.fail(404,'Not found.')
 def connections_post(self,path,d,user):
    uid=user['id'];c=self.connections
    try:
      if path=='/api/connections/start':return self.response(200,c.start(uid,d.get('provider')))
      if path=='/api/connections/complete':return self.response(200,c.complete(uid,d))
      if path=='/api/connections/test':return self.response(200,c.test(uid,d.get('provider')))
      if path=='/api/connections/disconnect':return self.response(200,c.disconnect(uid,d.get('provider')))
      if path=='/api/connections/google-calendar/configure':return self.response(200,c.configure_google_calendar(uid,d))
      if path=='/api/connections/canva/configure':return self.response(200,c.configure_canva(uid,d))
      if path=='/api/connections/canva/call':
        tools=c.tools(uid,'canva');tool=next((t for t in tools if t['name']==d.get('name')),None)
        if not tool:raise ValueError('Choose a tool from the current Canva catalogue.')
        # The first release exposes account-owned reads. Creative writes require a reviewed integration workflow.
        if tool['name'] not in {'search-designs','get-design','get-design-content','get-design-pages','get-design-thumbnail','list-brand-kits','get-brand-kit','get-export-formats'}:raise ValueError('This Canva action is not enabled in this first connector release. Search and read tools are available after authorisation; creative writes remain pending implementation and testing.')
        args=d.get('arguments')
        if not isinstance(args,dict) or len(canonical(args))>20000:raise ValueError('Enter a JSON object under 20 KB.')
        from jsonschema import Draft202012Validator
        errors=list(Draft202012Validator(tool.get('inputSchema',{})).iter_errors(args))
        if errors:raise ValueError('Arguments do not match the provider schema: '+errors[0].message[:300])
        return self.response(200,c.call(uid,'canva',tool['name'],args))
      if path=='/api/connections/websites/import':return self.response(202,self.websites.submit(uid,'import',d))
      if path=='/api/connections/websites/plan':return self.response(201,self.websites.plan(uid,d.get('project_id')))
      if path=='/api/connections/websites/publish':return self.response(202,self.websites.submit(uid,'publish',d))
      if path=='/api/connections/websites/cancel':return self.response(200,self.websites.cancel(uid,d.get('id')))
    except PermissionError as e:return self.fail(403,str(e))
    except KeyError:return self.fail(404,'Connection item not found in this account.')
    except (ValueError,TypeError) as e:return self.fail(400,str(e))
    return self.fail(404,'Not found.')
