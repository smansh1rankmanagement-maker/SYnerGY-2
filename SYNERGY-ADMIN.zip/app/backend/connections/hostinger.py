"""Hostinger operations pinned to the user's connected account and site."""
import re
from urllib.parse import quote,urlsplit
from beast.safety import path
from .transport import tool_data,request,ConnectionError

OPERATIONS={'sites':'hosting_listWebsitesV1','files':'hosting_listWebsiteFilesAndDirectoriesV1','read':'hosting_getWebsiteFileContentV1','upload':'hosting_generateUploadURLV1'}
class Hostinger:
 def __init__(self,connections,uid):self.c=connections;self.uid=uid;self.catalog=None
 def call(self,op,values):
    self.c.require_hostinger_domain(self.uid,values.get('domain'))
    name=OPERATIONS[op]
    if self.catalog is None:self.catalog={t['name']:t for t in self.c.tools(self.uid,'hostinger')}
    tool=self.catalog.get(name)
    if not tool:raise ConnectionError('The connected Hostinger server does not expose '+name+'. No replacement action was attempted.')
    schema=tool.get('inputSchema',{});props=schema.get('properties',{});args={}
    for k,s in props.items():
        if k in values:args[k]=values[k]
        elif s.get('type')=='object' or 'properties' in s:
            nested={n:values[n] for n in s.get('properties',{}) if n in values}
            if nested:args[k]=nested
    if any(k not in args for k in schema.get('required',[])):raise ConnectionError('Hostinger changed the required arguments for '+name+'. Update the connector before proceeding.')
    data=tool_data(self.c.call(self.uid,'hostinger',name,args))
    # Generated upstream clients may wrap HTTP bodies in a data property.
    if isinstance(data,dict) and isinstance(data.get('data'),dict) and not any(k in data for k in ['items','content','url']):data=data['data']
    return data
 def sites(self):
    out=[]
    for domain in self.c.hostinger_domains(self.uid):
        for page in range(1,21):
            # Hostinger offers a substring filter. Never retain or expose non-exact matches.
            r=self.call('sites',{'domain':domain,'page':page,'per_page':100});items=r.get('data',[]) if isinstance(r,dict) else r
            if isinstance(items,dict):items=items.get('data',[])
            if not isinstance(items,list):raise ConnectionError('Hostinger website listing format is unsupported.')
            out.extend({k:x.get(k) for k in ['domain','username','website_type','is_enabled']} for x in items if x.get('domain','').lower()==domain)
            meta=r.get('meta',{}) if isinstance(r,dict) else {}
            if len(items)<100 or page>=meta.get('last_page',10000):break
        else:raise ConnectionError('Website listing reached the page limit. No partial list is treated as complete.')
    return out
 def site(self,domain):
    if not isinstance(domain,str) or not re.fullmatch(r'[a-z0-9.-]+\.[a-z]{2,}',domain):raise ValueError('Choose a valid website domain.')
    self.c.require_hostinger_domain(self.uid,domain)
    found=next((s for s in self.sites() if s['domain']==domain),None)
    if not found:raise PermissionError('This domain is not listed in your connected Hostinger account.')
    if not found.get('username') or found['website_type'] in {'builder','horizons'}:raise ValueError('This website uses a managed builder. File publishing is unavailable for this site type.')
    return found
 def files(self,site):
    out=[]
    for offset in range(0,10000,1000):
        r=self.call('files',{**site,'max_depth':10,'max_items':1000,'offset':offset})
        items=r.get('items',[])
        if not isinstance(items,list):raise ConnectionError('Invalid Hostinger directory listing.')
        out+=items
        if len(out)>=r.get('total_items',len(out)):return out
        if not items:break
    raise ConnectionError('Website inventory exceeded 10,000 entries. Select a smaller project source.')
 def read(self,site,name):
    name=path(name);r=self.call('read',{**site,'path':name,'from_line':0,'max_lines':5000})
    content=r.get('content')
    if not isinstance(content,str) or r.get('from_line',0)!=0 or r.get('total_lines',0)>5000:raise ConnectionError('A complete file could not be retrieved: '+name)
    if len(content.encode())!=r.get('size_bytes'):raise ConnectionError('The file response is partial or changed encoding: '+name+'. Import an authorised source ZIP instead.')
    return content
 def upload(self,site,name,content):
    name=path(name);body=content.encode();creds=self.call('upload',{'username':site['username'],'domain':site['domain']})
    u=urlsplit(creds.get('url',''))
    if u.scheme!='https' or not re.fullmatch(r'[a-z0-9-]+\.hstgr\.io',u.hostname or '') or u.username or u.password or u.port not in {None,443} or u.query or u.fragment:raise ConnectionError('Hostinger returned an unsupported upload host. Credentials were not forwarded.')
    target=creds['url'].rstrip('/')+'/'+quote(name,safe='/')+'?override=true'
    h={'X-Auth':creds['auth_key'],'X-Auth-Rest':creds['rest_auth_key'],'Tus-Resumable':'1.0.0','Upload-Length':str(len(body)),'Upload-Offset':'0'}
    request(target,'POST',b'',h,limit=10000)
    _,headers=request(target,'PATCH',body,{**h,'Content-Type':'application/offset+octet-stream'},limit=10000)
    offset=next((v for k,v in headers.items() if k.lower()=='upload-offset'),None)
    if offset!=str(len(body)):raise ConnectionError('The uploaded byte count was not confirmed. Review the publishing job before retrying.')
