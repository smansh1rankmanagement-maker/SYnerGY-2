"""Durable, owner-isolated site import and revision-pinned publishing.
Only trusted network handlers run here. Generated source is never executed.
"""
import difflib,hashlib,json,os,re,threading,time,uuid
from deployment_policy import require_publication_provider
from pathlib import PurePosixPath
from beast.safety import path,record
from beast.checks import run_checks
from .store import canonical
from .hostinger import Hostinger

BRAND_POLICY='Preserve the existing brand name, approved wording, logos, colour tokens, typography, theme and unrelated functionality. Read the current selected files before changing them. Use UI/UX Pro Max guidance; use Framer Motion only where the existing React stack supports it. Show a focused diff and preview. Saving or applying source is not publication. Publish only the exact reviewed revision after an explicit publishing request. Never invent connection, build, test or deployment success.'
STATIC={'.html','.htm','.css','.js','.mjs','.json','.svg','.txt'}
def sha(v):return hashlib.sha256(v.encode()).hexdigest()
class Websites:
 def __init__(self,connections,beast,workspace):
    self.c=connections;self.beast=beast;self.ws=workspace;self.stop=threading.Event()
    with self.c.connect() as c:c.executescript('''
      CREATE TABLE IF NOT EXISTS connected_websites(project_id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,domain TEXT NOT NULL,site TEXT NOT NULL,baseline_revision INTEGER NOT NULL,manifest TEXT NOT NULL,updated REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS website_plans(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,project_id TEXT NOT NULL,revision INTEGER NOT NULL,digest TEXT NOT NULL,detail TEXT NOT NULL,created REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS website_jobs(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,kind TEXT NOT NULL,state TEXT NOT NULL,request TEXT NOT NULL,detail TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL,request_id TEXT NOT NULL,UNIQUE(user_id,request_id));
    ''')
 def access(self,uid):
    if getattr(self.beast,'access',None):self.beast.access(uid,'beast')
 def site(self,uid,pid):
    self.beast.project(uid,pid)
    with self.c.connect() as c:r=c.execute('SELECT * FROM connected_websites WHERE user_id=? AND project_id=?',(uid,pid)).fetchone()
    if not r:raise KeyError('This project has no Hostinger website connection.')
    d=dict(r);d['site']=json.loads(d['site']);d['manifest']=json.loads(d['manifest']);return d
 def sites(self,uid):
    with self.c.connect() as c:rows=[dict(r) for r in c.execute('SELECT project_id,domain,baseline_revision,updated FROM connected_websites WHERE user_id=?',(uid,))]
    return rows
 def job(self,uid,jid):
    with self.c.connect() as c:r=c.execute('SELECT * FROM website_jobs WHERE user_id=? AND id=?',(uid,jid)).fetchone()
    if not r:raise KeyError('Website job not found in this account.')
    d=dict(r);d['request']=json.loads(d['request']);d['detail']=json.loads(d['detail']);return d
 def jobs(self,uid):
    with self.c.connect() as c:ids=[r[0] for r in c.execute('SELECT id FROM website_jobs WHERE user_id=? ORDER BY created DESC LIMIT 30',(uid,))]
    return [self.job(uid,x) for x in ids]
 def event(self,jid,msg,**changes):
    with self.c.connect() as c:
        c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT detail FROM website_jobs WHERE id=?',(jid,)).fetchone();d=json.loads(r[0]);d.update(changes);d['events']=d.get('events',[])[-99:]+[{'time':time.time(),'message':msg}];c.execute('UPDATE website_jobs SET detail=?,updated=? WHERE id=?',(canonical(d),time.time(),jid))
 def check(self,j):
    self.access(j['user_id'])
    current=self.job(j['user_id'],j['id'])
    if current['state']=='cancelled' or self.stop.is_set():raise InterruptedError('Stopped. Any verified uploaded files are listed in this job; publication may be partial.')
    if time.time()-j.get('started',time.time())>600:raise TimeoutError('Website job reached its ten-minute limit. Review saved progress before retrying.')
 def submit(self,uid,kind,d):
    self.access(uid)
    key=d.get('request_id','')
    if not isinstance(key,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{8,100}',key):raise ValueError('A unique request identifier is required.')
    if kind=='import':
        domain=d.get('domain','').lower().strip()
        if not re.fullmatch(r'[a-z0-9.-]+\.[a-z]{2,}',domain):raise ValueError('Choose the domain in your Hostinger account.')
        self.c.require_hostinger_domain(uid,domain)
        names=d.get('paths')
        if names is not None:
            if not isinstance(names,list) or not 1<=len(names)<=200:raise ValueError('Select 1–200 source files.')
            names=[path(x) for x in names]
        req={'domain':domain,'paths':names}
    elif kind=='publish':
        plan=self.get_plan(uid,d.get('plan_id'));self.site(uid,plan['project_id'])
        if d.get('reviewed_digest')!=plan['digest'] or d.get('confirmation')!='Publish '+plan['detail']['domain']:raise ValueError('Review the current diff and confirm its exact domain before publishing.')
        require_publication_provider('hostinger')
        req={'plan_id':plan['id'],'project_id':plan['project_id'],'digest':plan['digest']}
    else:raise ValueError('Unsupported website operation.')
    with self.c.connect() as c:
        c.execute('BEGIN IMMEDIATE');prior=c.execute('SELECT id FROM website_jobs WHERE user_id=? AND request_id=?',(uid,key)).fetchone()
        if prior:return self.job(uid,prior[0])
        if kind=='publish':
            prior=c.execute("SELECT id FROM website_jobs WHERE user_id=? AND kind='publish' AND json_extract(request,'$.plan_id')=?",(uid,req['plan_id'])).fetchone()
            if prior:return self.job(uid,prior[0])
        if c.execute("SELECT 1 FROM website_jobs WHERE user_id=? AND state IN ('queued','running')",(uid,)).fetchone():raise ValueError('Wait for or cancel the current website job first.')
        jid=uuid.uuid4().hex;now=time.time();c.execute('INSERT INTO website_jobs VALUES(?,?,?,?,?,?,?,?,?)',(jid,uid,kind,'queued',canonical(req),canonical({'events':[]}),now,now,key))
    return self.job(uid,jid)
 def cancel(self,uid,jid):
    j=self.job(uid,jid)
    with self.c.connect() as c:c.execute("UPDATE website_jobs SET state='cancelled',updated=? WHERE id=? AND state IN ('queued','running')",(time.time(),jid))
    return self.job(uid,jid)
 def import_site(self,j):
    uid=j['user_id'];api=Hostinger(self.c,uid);site=api.site(j['request']['domain']);self.event(j['id'],'Verified domain access. Reading website inventory.')
    entries=api.files(site);files={};skipped=[];requested=j['request'].get('paths');total=0
    available={x['path']:x for x in entries if x.get('type')=='file'}
    if requested and any(x not in available for x in requested):raise ValueError('A selected file is missing or is not a regular file.')
    for name,item in available.items():
        if requested and name not in requested:continue
        self.check(j)
        try:
            path(name)
            if PurePosixPath(name).suffix.lower() in {'.png','.jpg','.jpeg','.gif','.webp'}:raise ValueError('Binary asset stays on hosting; this connector reads source text only.')
            if item.get('size_bytes',0)>2*1024*1024:raise ValueError('File exceeds the 2 MB source limit.')
            if len(files)>=200 or total+item.get('size_bytes',0)>20*1024*1024:raise ValueError('Import limit: 200 source files or 20 MB. Select a smaller set.')
            content=api.read(site,name);files[name]=record(name,content);total+=len(content.encode())
            self.event(j['id'],'Read '+name,read_count=len(files),inventory_count=len(entries))
        except (ValueError,PermissionError) as e:skipped.append({'path':name,'reason':str(e)[:300]})
    if not files:raise ValueError('No complete source files could be imported. Check the selected paths and connection; use a source ZIP if the API cannot read this site.')
    self.check(j)
    project=self.beast.create(uid,{'name':site['domain']+' · Hostinger','brief':BRAND_POLICY,'files':files})
    # Journal the project immediately. Recovery never repeats an interrupted import automatically.
    self.event(j['id'],'Saved private source project.',project_id=project['id'])
    manifest={'inventory_count':len(entries),'imported':list(files),'skipped':skipped,'import_job':j['id'],'limitations':['Only supported text sources are imported. Binary assets, secrets and excluded files stay on Hostinger.','The website may serve compiled files rather than editable React source. Import the original project before rebuilding a bundled app.']}
    with self.c.connect() as c:c.execute('INSERT INTO connected_websites VALUES(?,?,?,?,?,?,?)',(project['id'],uid,site['domain'],canonical(site),1,canonical(manifest),time.time()))
    workspace=self.ws.save_project(uid,{'name':site['domain'],'instructions':BRAND_POLICY,'kind':'website','beast_project_id':project['id']})
    self.event(j['id'],'Import complete. Open the project in Beast to edit and preview. Nothing has been published.',project_id=project['id'],workspace_id=workspace['id'],manifest=manifest)
 def plan(self,uid,pid):
    self.access(uid);link=self.site(uid,pid);p=self.beast.project(uid,pid)
    with self.beast.connect() as c:base=self.beast.files(c,pid,link['baseline_revision'])
    names=sorted(n for n in set(base)|set(p['files']) if base.get(n)!=p['files'].get(n))
    if not names:raise ValueError('There are no saved source changes to publish.')
    if len(names)>8:raise ValueError('Publish at most eight reviewed files in one operation.')
    if any(n not in base or n not in p['files'] for n in names):raise ValueError('This first publishing release updates existing files only. New files and deletions require a deployment build workflow.')
    if any(PurePosixPath(n).suffix.lower() not in STATIC or p['files'][n]['encoding']!='utf-8' for n in names):raise ValueError('Direct publishing supports existing HTML, CSS, JavaScript, JSON, SVG and text files. PHP and React source need a verified build/deployment step.')
    checks=run_checks({n:p['files'][n] for n in names})
    if checks.get('failed'):raise ValueError('Source diagnostics failed. Fix the reported errors before publishing.')
    changes=[{'path':n,'before_sha256':sha(base[n]['content']),'after_sha256':sha(p['files'][n]['content']),'diff':''.join(difflib.unified_diff(base[n]['content'].splitlines(True),p['files'][n]['content'].splitlines(True),fromfile=n,tofile=n))} for n in names]
    detail={'domain':link['domain'],'revision':p['revision'],'baseline_revision':link['baseline_revision'],'changes':changes,'checks':checks,'impact':'These exact files will be overwritten on the selected live domain. Existing source revisions remain saved. Uploads are sequential, so a failure may leave a partial deployment.','limitations':'Syntax checks are not proof of browser behaviour. Review the preview and diff before publication.'}
    if os.environ.get('SYNERGY_DEPLOYMENT_HOST')=='aws':detail.update(publication_blocked=True,impact='Review only. AWS hosts deployments; Hostinger manages the authorised domain.',limitations='Direct Hostinger file publication is disabled. Export this reviewed revision for the approved AWS pipeline. Moving another site requires a reviewed migration and DNS plan.')
    value=sha(canonical(detail));pidplan=uuid.uuid4().hex
    with self.c.connect() as c:c.execute('INSERT INTO website_plans VALUES(?,?,?,?,?,?,?)',(pidplan,uid,pid,p['revision'],value,canonical(detail),time.time()))
    return self.get_plan(uid,pidplan)
 def get_plan(self,uid,pid):
    with self.c.connect() as c:r=c.execute('SELECT * FROM website_plans WHERE id=? AND user_id=?',(pid,uid)).fetchone()
    if not r:raise KeyError('Publishing plan not found.')
    d=dict(r);d['detail']=json.loads(d['detail']);return d
 def publish(self,j):
    require_publication_provider('hostinger')
    uid=j['user_id'];plan=self.get_plan(uid,j['request']['plan_id']);link=self.site(uid,plan['project_id']);p=self.beast.project(uid,plan['project_id'])
    if plan['digest']!=j['request']['digest'] or p['revision']!=plan['revision'] or link['baseline_revision']!=plan['detail']['baseline_revision'] or time.time()-plan['created']>3600:raise ValueError('The reviewed source changed or the publishing plan expired. Review a new plan.')
    api=Hostinger(self.c,uid);site=api.site(link['domain']);changes=plan['detail']['changes']
    # Check EVERY changed file before the first write. A race after this check is still possible.
    for x in changes:
        self.check(j)
        if sha(api.read(site,x['path']))!=x['before_sha256']:raise ValueError('The live file '+x['path']+' changed outside this project. Import and reconcile it before publishing.')
    self.event(j['id'],'Live file hashes match the saved baseline. Starting the explicitly authorised publication.',uploaded=[])
    uploaded=[]
    for x in changes:
        self.check(j)
        if self.beast.project(uid,p['id'])['revision']!=plan['revision']:raise ValueError('Project changed during publication. Review the partial result before continuing.')
        self.event(j['id'],'Uploading '+x['path'],pending_path=x['path'])
        api.upload(site,x['path'],p['files'][x['path']]['content'])
        if sha(api.read(site,x['path']))!=x['after_sha256']:raise ValueError('Hostinger content verification failed for '+x['path']+'. Publication requires review.')
        uploaded.append(x['path']);self.event(j['id'],'Verified '+x['path'],uploaded=uploaded,pending_path=None)
    with self.c.connect() as c:c.execute('UPDATE connected_websites SET baseline_revision=?,updated=? WHERE project_id=? AND user_id=?',(p['revision'],time.time(),p['id'],uid))
    self.event(j['id'],'Publication complete; Hostinger file content verified. Open the domain for visual acceptance.',url='https://'+link['domain'],published_revision=p['revision'])
 def start(self):
    with self.c.connect() as c:c.execute("UPDATE website_jobs SET state='needs_review',updated=? WHERE state='running'",(time.time(),))
    def loop():
        while not self.stop.wait(.5):
            with self.c.connect() as c:
                c.execute('BEGIN IMMEDIATE');r=c.execute("SELECT id,user_id FROM website_jobs WHERE state='queued' ORDER BY created LIMIT 1").fetchone()
                if not r:continue
                c.execute("UPDATE website_jobs SET state='running',updated=? WHERE id=?",(time.time(),r['id']))
            j=self.job(r['user_id'],r['id']);j['started']=time.time()
            try:
                (self.import_site if j['kind']=='import' else self.publish)(j);state='completed'
            except Exception as e:
                self.event(j['id'],str(e)[:500]);state='cancelled' if isinstance(e,InterruptedError) else 'needs_review' if j['kind']=='publish' else 'failed'
            with self.c.connect() as c:c.execute("UPDATE website_jobs SET state=?,updated=? WHERE id=? AND state='running'",(state,time.time(),j['id']))
    threading.Thread(target=loop,daemon=True,name='synergy-websites').start()
