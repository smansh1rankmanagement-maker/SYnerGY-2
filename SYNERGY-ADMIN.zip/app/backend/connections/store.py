"""OAuth PKCE, per-account encrypted tokens, connection evidence and audit."""
import base64,hashlib,json,os,re,secrets,sqlite3,threading,time
from pathlib import Path
from urllib.parse import urlencode,urlsplit
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .transport import json_request,rpc,ConnectionError

PROVIDERS={
 'google-calendar':{'name':'Google Calendar','server':'https://www.googleapis.com/calendar/v3','auth':'https://accounts.google.com/o/oauth2/v2/auth','token':'https://oauth2.googleapis.com/token','scope':'https://www.googleapis.com/auth/calendar.events.owned'},
 'hostinger':{'name':'Hostinger','server':'https://mcp.hostinger.com','auth':'https://auth.hostinger.com/api/external/v1/oauth-server/authorize','token':'https://auth.hostinger.com/api/external/v1/oauth-server/token','register':'https://auth.hostinger.com/api/external/v1/oauth-server/register','scope':'mcp:use'},
 'canva':{'name':'Canva','server':'https://api.canva.com/connect/v1/mcp','auth':'https://www.canva.com/api/oauth/authorize','token':'https://api.canva.com/auth/v1/oauth/token','scope':'profile:read design:meta:read design:content:read design:content:write asset:read asset:write'},
}

def digest(s):return hashlib.sha256(s.encode()).hexdigest()
def canonical(d):return json.dumps(d,sort_keys=True,separators=(',',':'))

class Connections:
 def __init__(self,db,root,origin):
    self.db=str(db);self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True,mode=0o700);self.origin=origin.rstrip('/');self.locks={};self.guard=threading.RLock()
    key=self.root/'oauth.key'
    try:
        fd=os.open(key,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'wb') as f:f.write(AESGCM.generate_key(bit_length=256))
    except FileExistsError:pass
    self.cipher=AESGCM(key.read_bytes())
    with self.connect() as c:c.executescript('''
      CREATE TABLE IF NOT EXISTS external_connections(user_id INTEGER NOT NULL,provider TEXT NOT NULL,secret BLOB,detail TEXT NOT NULL,updated REAL NOT NULL,PRIMARY KEY(user_id,provider));
      CREATE TABLE IF NOT EXISTS external_clients(provider TEXT PRIMARY KEY,secret BLOB NOT NULL,updated REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS external_oauth(state_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL,provider TEXT NOT NULL,verifier BLOB NOT NULL,expires REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS external_audit(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,provider TEXT NOT NULL,action TEXT NOT NULL,detail TEXT NOT NULL,created REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS external_domain_scopes(user_id INTEGER NOT NULL,domain TEXT NOT NULL,created REAL NOT NULL,PRIMARY KEY(user_id,domain));
    ''')
 def connect(self):
    c=sqlite3.connect(self.db,timeout=20);c.row_factory=sqlite3.Row;return c
 def seal(self,d,binding):
    nonce=os.urandom(12);return nonce+self.cipher.encrypt(nonce,canonical(d).encode(),binding.encode())
 def unseal(self,b,binding):return json.loads(self.cipher.decrypt(b[:12],b[12:],binding.encode()))
 def audit(self,uid,provider,action,detail):
    with self.connect() as c:c.execute('INSERT INTO external_audit(user_id,provider,action,detail,created) VALUES(?,?,?,?,?)',(uid,provider,action,canonical(detail),time.time()))
 def admin(self,uid):
    with self.connect() as c:r=c.execute('SELECT role,account_state FROM users WHERE id=?',(uid,)).fetchone()
    if not r or r['role']!='admin' or r['account_state']!='active':raise PermissionError('Only an active administrator can configure shared provider credentials.')
 def config(self,provider):
    if provider not in PROVIDERS:raise ValueError('Choose a supported connection.')
    with self.connect() as c:r=c.execute('SELECT secret FROM external_clients WHERE provider=?',(provider,)).fetchone()
    return self.unseal(r['secret'],'client:'+provider) if r else None
 def hostinger_domains(self,uid):
    with self.connect() as c:return [r[0] for r in c.execute('SELECT domain FROM external_domain_scopes WHERE user_id=? ORDER BY domain',(uid,))]
 def require_hostinger_domain(self,uid,domain):
    if not isinstance(domain,str) or domain not in self.hostinger_domains(uid):raise PermissionError('This Hostinger connection is not authorised for that domain. Only the exact approved website is accessible; subdomains are not included.')
 def authorise_hostinger_domain(self,uid,domain):
    # Operator-only method: never exposed through HTTP, chat or an MCP handler.
    if not isinstance(domain,str) or not re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}',domain):raise ValueError('Use an exact lowercase domain without a path or wildcard.')
    with self.connect() as c:
        if not c.execute("SELECT 1 FROM users WHERE id=? AND account_state='active'",(uid,)).fetchone():raise ValueError('Choose an active account.')
        c.execute('INSERT OR IGNORE INTO external_domain_scopes VALUES(?,?,?)',(uid,domain,time.time()))
    self.audit(uid,'hostinger','domain_authorised',{'domain':domain})
 def configure_google_calendar(self,uid,d):
    self.admin(uid)
    cid=d.get('client_id','');secret=d.get('client_secret','')
    if not isinstance(cid,str) or not re.fullmatch(r'[A-Za-z0-9_.-]+\.apps\.googleusercontent\.com',cid) or not isinstance(secret,str) or not 8<=len(secret)<=500:raise ValueError('Enter Google OAuth web client credentials.')
    with self.connect() as c:c.execute('INSERT OR REPLACE INTO external_clients VALUES(?,?,?)',('google-calendar',self.seal({'client_id':cid,'client_secret':secret},'client:google-calendar'),time.time()))
    self.audit(uid,'google-calendar','client_configured',{});return {'configured':True}
 def configure_canva(self,uid,d):
    self.admin(uid)
    cid=d.get('client_id','');secret=d.get('client_secret','')
    if not isinstance(cid,str) or not 4<=len(cid)<=200 or not isinstance(secret,str) or not 8<=len(secret)<=500:raise ValueError('Enter the client ID and client secret from the Canva Developer Portal.')
    with self.connect() as c:c.execute('INSERT OR REPLACE INTO external_clients VALUES(?,?,?)',('canva',self.seal({'client_id':cid,'client_secret':secret},'client:canva'),time.time()))
    self.audit(uid,'canva','client_configured',{'redirect_uri':self.origin+'/connect/callback'});return {'configured':True}
 def status(self,uid,provider):
    if provider=='aws':
        self.admin(uid);p=Path(os.environ.get('SYNERGY_AWS_STATUS_FILE',str(self.root/'aws-status.json')))
        try:d=json.loads(p.read_text())
        except (OSError,ValueError):return {'provider':'aws','name':'AWS','connected':False,'status':'not_configured','message':'The AWS status bridge has not been configured.'}
        fresh=time.time()-d.get('checked_at',0)<180
        return {'provider':'aws','name':'AWS','connected':fresh and d.get('verified') is True,'status':'connected' if fresh and d.get('verified') else 'unavailable','scope':'SYnerGY instance status only; no spending or infrastructure changes','evidence':d}
    cfg=PROVIDERS[provider]
    with self.connect() as c:r=c.execute('SELECT secret,detail,updated FROM external_connections WHERE user_id=? AND provider=?',(uid,provider)).fetchone()
    detail=json.loads(r['detail']) if r else {}
    if provider=='hostinger':detail['allowed_domains']=self.hostinger_domains(uid)
    configured=provider=='hostinger' or bool(self.config(provider));connected=bool(r and r['secret'] and detail.get('tested_at'))
    return {'provider':provider,'name':cfg['name'],'configured':configured,'connected':connected,'status':'connected' if connected else 'authorised_untested' if r and r['secret'] else 'not_connected' if configured else 'setup_required','detail':detail,'redirect_uri':self.origin+'/connect/callback'}
 def list(self,uid):
    data=[self.status(uid,p) for p in PROVIDERS]
    try:data.append(self.status(uid,'aws'))
    except PermissionError:pass
    return data
 def catalog(self,uid):
    return [{'id':'connection:'+p,'key':p,'name':PROVIDERS[p]['name']+('' if p=='google-calendar' else ' MCP'),'description':('Save reviewed meetings to your primary calendar and create Google Meet links.' if p=='google-calendar' else 'Private Canva design search and reads; creative writes are not yet enabled.' if p=='canva' else 'Authorised website source import, reviewed file publication and run history.'),'scope':'Your connected account only. Authorisation and a real connection test are required.','status':s['status'],'enabled':s['connected'],'runtime':True,'default':True,'action':'connections','builtin':False} for p in PROVIDERS for s in [self.status(uid,p)]]
 def chat_status(self,uid,provider):
    s=self.status(uid,provider)
    text=s['name']+': '+s['status'].replace('_',' ')+'. '
    if s['connected']:text+='The connection test passed. Open Connections for the permitted tools and your saved website workflow.'
    elif s['status']=='setup_required':text+='A Canva Developer Portal client ID and secret must be configured by the administrator, then each user authorises their own Canva account.'
    else:text+='Open Settings → Connections and connect your account. SYnerGY will test access before showing it as connected.'
    return {'reply':text,'actions':[{'label':'Open Connections','settings':'connections'}]}
 def start(self,uid,provider):
    cfg=PROVIDERS.get(provider)
    if not cfg:raise ValueError('Unsupported OAuth provider.')
    if provider=='hostinger' and not self.hostinger_domains(uid):raise PermissionError('An operator must approve the exact website domain for this account before Hostinger can be connected.')
    if not self.origin.startswith('https://'):raise ValueError('Configure the public HTTPS origin before connecting providers.')
    with self.guard:
        client=self.config(provider)
        if not client:
            if provider!='hostinger':raise ValueError('The administrator must configure provider credentials in Connections first.')
            client=json_request(cfg['register'],'POST',{'client_name':'SYnerGY AI','redirect_uris':[self.origin+'/connect/callback'],'grant_types':['authorization_code','refresh_token'],'response_types':['code'],'token_endpoint_auth_method':'none'})
            if not client.get('client_id'):raise ConnectionError('Hostinger did not register the OAuth client.')
            with self.connect() as c:c.execute('INSERT INTO external_clients VALUES(?,?,?)',(provider,self.seal({'client_id':client['client_id']},'client:'+provider),time.time()))
        state=secrets.token_urlsafe(32);verifier=secrets.token_urlsafe(48);challenge=base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
        with self.connect() as c:
            c.execute('DELETE FROM external_oauth WHERE expires<?',(time.time(),))
            c.execute('INSERT INTO external_oauth VALUES(?,?,?,?,?)',(digest(state),uid,provider,self.seal({'verifier':verifier},'state:'+digest(state)),time.time()+600))
    args={'client_id':client['client_id'],'redirect_uri':self.origin+'/connect/callback','response_type':'code','state':state,'code_challenge':challenge,'code_challenge_method':'S256','scope':cfg['scope'],'resource':cfg['server']}
    if provider=='google-calendar':
        args.pop('resource',None);args.update(access_type='offline',prompt='consent')
    self.audit(uid,provider,'authorisation_started',{})
    return {'url':cfg['auth']+'?'+urlencode(args),'provider':provider}
 def token_request(self,provider,params):
    cfg=PROVIDERS[provider];client=self.config(provider);headers={'Content-Type':'application/x-www-form-urlencoded'}
    params={**params,'client_id':client['client_id']}
    if provider=='google-calendar':
        params.pop('resource',None);params['client_secret']=client['client_secret']
    elif client.get('client_secret'):headers['Authorization']='Basic '+base64.b64encode((client['client_id']+':'+client['client_secret']).encode()).decode()
    d=json_request(cfg['token'],'POST',urlencode(params).encode(),headers)
    if not isinstance(d.get('access_token'),str):raise ConnectionError('Provider did not return a usable access token.')
    d['expires_at']=time.time()+int(d.get('expires_in',3600));return d
 def complete(self,uid,d):
    state=d.get('state','');code=d.get('code','')
    if not isinstance(state,str) or not 20<=len(state)<=200 or not isinstance(code,str) or not 1<=len(code)<=4000:raise ValueError('Invalid authorisation response. Start the connection again.')
    with self.connect() as c:
        c.execute('BEGIN IMMEDIATE');row=c.execute('SELECT * FROM external_oauth WHERE state_hash=? AND user_id=?',(digest(state),uid)).fetchone()
        if not row or row['expires']<time.time():raise PermissionError('This authorisation expired or belongs to another account. Start again from Connections.')
        c.execute('DELETE FROM external_oauth WHERE state_hash=?',(digest(state),))
    provider=row['provider'];verifier=self.unseal(row['verifier'],'state:'+digest(state))['verifier']
    tokens=self.token_request(provider,{'grant_type':'authorization_code','code':code,'code_verifier':verifier,'redirect_uri':self.origin+'/connect/callback','resource':PROVIDERS[provider]['server']})
    self.save_tokens(uid,provider,tokens,{'authorised_at':time.time()});self.audit(uid,provider,'authorised',{})
    return self.test(uid,provider)
 def save_tokens(self,uid,provider,tokens,detail=None):
    with self.connect() as c:
        row=c.execute('SELECT detail FROM external_connections WHERE user_id=? AND provider=?',(uid,provider)).fetchone()
        metadata=json.loads(row['detail']) if row else {};metadata.update(detail or {})
        c.execute('INSERT OR REPLACE INTO external_connections VALUES(?,?,?,?,?)',(uid,provider,self.seal(tokens,str(uid)+':'+provider),canonical(metadata),time.time()))
 def token(self,uid,provider):
    with self.guard:lock=self.locks.setdefault((uid,provider),threading.Lock())
    with lock:
        with self.connect() as c:r=c.execute('SELECT secret FROM external_connections WHERE user_id=? AND provider=?',(uid,provider)).fetchone()
        if not r or not r['secret']:raise PermissionError('Connect your '+provider+' account in Settings → Connections first.')
        t=self.unseal(r['secret'],str(uid)+':'+provider)
        if t.get('expires_at',0)<time.time()+60:
            if not t.get('refresh_token'):raise PermissionError('This connection expired. Reconnect in Settings.')
            fresh=self.token_request(provider,{'grant_type':'refresh_token','refresh_token':t['refresh_token'],'resource':PROVIDERS[provider]['server']});t={**t,**fresh};self.save_tokens(uid,provider,t)
        return t['access_token']
 def tools(self,uid,provider):
    token=self.token(uid,provider);found=[];cursor=None
    if provider=='google-calendar':
        json_request('https://www.googleapis.com/calendar/v3/calendars/primary/events?maxResults=1',headers={'Authorization':'Bearer '+token})
        return [{'name':'calendar.events.owned'}]
    for _ in range(8):
        r=rpc(PROVIDERS[provider]['server'],token,'tools/list',{'cursor':cursor} if cursor else {})
        found.extend(r.get('tools',[]));cursor=r.get('nextCursor')
        if not cursor:break
    if cursor or len(found)>600:raise ConnectionError('Provider tool catalogue exceeds this release’s supported limit.')
    return found
 def test(self,uid,provider):
    if provider=='aws':return self.status(uid,provider)
    try:
        found=self.tools(uid,provider)
        if not found:raise ConnectionError('The connection returned no usable tools.')
    except (ValueError,PermissionError):
        with self.connect() as c:
            row=c.execute('SELECT detail FROM external_connections WHERE user_id=? AND provider=?',(uid,provider)).fetchone()
            if row:
                prior=json.loads(row['detail']);prior.update(tested_at=None,last_failure_at=time.time(),last_error='Connection test failed; reconnect or retry the test.')
                c.execute('UPDATE external_connections SET detail=? WHERE user_id=? AND provider=?',(canonical(prior),uid,provider))
        self.audit(uid,provider,'connection_test_failed',{})
        raise
    detail={'tested_at':time.time(),'tool_count':len(found),'tools':[t['name'] for t in found]}
    with self.connect() as c:
        row=c.execute('SELECT detail FROM external_connections WHERE user_id=? AND provider=?',(uid,provider)).fetchone();prior=json.loads(row['detail']);prior.update(detail)
        c.execute('UPDATE external_connections SET detail=?,updated=? WHERE user_id=? AND provider=?',(canonical(prior),time.time(),uid,provider))
    self.audit(uid,provider,'connection_test_passed',{'tool_count':len(found)});return self.status(uid,provider)
 def call(self,uid,provider,name,arguments):
    # Only trusted product workflows call Hostinger; no remote arbitrary-tool endpoint.
    if provider=='hostinger':
        from .hostinger import OPERATIONS
        if name not in OPERATIONS.values():raise PermissionError('This Hostinger operation is not enabled. Account, billing, subscription and domain-administration tools are blocked.')
        def domains(value):
            if not isinstance(value,dict):return []
            return [v for k,v in value.items() if k=='domain']+[d for v in value.values() if isinstance(v,dict) for d in domains(v)]
        requested=domains(arguments)
        if len(requested)!=1:raise PermissionError('Hostinger calls require one exact approved domain; unfiltered account listing is blocked.')
        self.require_hostinger_domain(uid,requested[0])
    result=rpc(PROVIDERS[provider]['server'],self.token(uid,provider),'tools/call',{'name':name,'arguments':arguments})
    self.audit(uid,provider,'tool_call',{'tool':name,'success':not result.get('isError',False)})
    return result
 def disconnect(self,uid,provider):
    if provider not in PROVIDERS:raise ValueError('Unsupported connection.')
    with self.connect() as c:
        c.execute('DELETE FROM external_connections WHERE user_id=? AND provider=?',(uid,provider));c.execute('DELETE FROM external_oauth WHERE user_id=? AND provider=?',(uid,provider))
    self.audit(uid,provider,'disconnected',{});return {'disconnected':True,'message':'Stored access was removed. You can also revoke SYnerGY in the provider’s authorised-app settings.'}
