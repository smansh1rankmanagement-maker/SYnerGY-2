"""Owner-pinned production destination, shared by admin visibility and operator checks."""
import json,os,time
from pathlib import Path

def target():
    path=Path(__file__).resolve().parents[2]/'deploy/target.json'
    value=json.loads(path.read_text())
    if value['hosting_provider']!='aws' or value['domain_provider']!='hostinger':raise ValueError('Production hosting must use AWS; domain management must use Hostinger.')
    return value

def validate(identity,origin):
    t=target()
    for a,b in [('account_id','aws_account_id'),('region','aws_region'),('instance_id','aws_instance_id')]:
        if identity.get(a)!=t[b]:raise PermissionError('Deployment identity does not match the approved AWS destination.')
    if identity.get('verified') is not True or origin!=t['public_origin']:raise PermissionError('Deployment requires the verified AWS host and exact approved public origin.')
    return t

def status():
    t=target();path=Path(os.environ.get('SYNERGY_AWS_STATUS_FILE','/run/synergy-aws/aws-status.json'))
    try:
        observed=json.loads(path.read_text());validate(observed,os.environ.get('SYNERGY_PUBLIC_ORIGIN',''))
        verified=time.time()-observed.get('checked_at',0)<180
    except (OSError,ValueError,PermissionError):verified=False;observed={}
    return {**t,'aws_identity_verified':verified,'checked_at':observed.get('checked_at'),'execution':'Existing operator release pipeline; the admin assistant edits private source and cannot execute production shell commands.','domain_connection':'Domain-management authentication is separate. This policy does not grant Hostinger account-wide access.'}

def require_publication_provider(provider):
    if os.environ.get('SYNERGY_DEPLOYMENT_HOST')=='aws' and provider!='aws':
        raise ValueError('AWS hosting is required by the owner. This legacy Hostinger file publisher is disabled. Keep the reviewed source and deploy through the approved AWS release pipeline; Hostinger is for authorised domain management.')
