"""Permanent, transactional launch cohorts; legacy purchases are never repriced."""
import time
LIMIT=501
PRICES={'early':[('work',7,99,'7-day trial'),('work',30,299,'Monthly'),('beast',30,2999,'Monthly'),('beast',365,11999,'Yearly')], 'regular':[('work',30,1999,'Monthly'),('work',365,11999,'Yearly'),('beast',30,4999,'Monthly'),('beast',365,49999,'Yearly')]}
PLANS={f'{tier}-{mode}-{days}':{'id':f'{tier}-{mode}-{days}','tier':tier,'mode':mode,'days':days,'label':label,'amount_paise':price*100,'currency':'INR'} for tier,rows in PRICES.items() for mode,days,price,label in rows}
def allocate(c,uid,now=None):
 old=c.execute('SELECT * FROM launch_members WHERE user_id=?',(uid,)).fetchone()
 if old:return dict(old)
 u=c.execute('SELECT role,email FROM users WHERE id=?',(uid,)).fetchone()
 if not u:return None
 eligible=u['role']!='admin' and not (u['email'] or '').lower().endswith(('@qa.invalid','@test.invalid'))
 ordinal=(c.execute('SELECT COALESCE(MAX(ordinal),0)+1 FROM launch_members').fetchone()[0] if eligible else None)
 now=time.time() if now is None else now
 c.execute('INSERT INTO launch_members VALUES(?,?,?,?,?)',(uid,ordinal,'early' if ordinal and ordinal<=LIMIT else 'regular',now,now+7*86400))
 return dict(c.execute('SELECT * FROM launch_members WHERE user_id=?',(uid,)).fetchone())
def initialize(c):
 c.execute('CREATE TABLE IF NOT EXISTS launch_members(user_id INTEGER PRIMARY KEY,ordinal INTEGER UNIQUE,tier TEXT NOT NULL,started REAL NOT NULL,trial_expires REAL NOT NULL)')
 c.execute('BEGIN IMMEDIATE')
 for r in c.execute('SELECT id FROM users WHERE id>0 ORDER BY COALESCE(created,0),id').fetchall():allocate(c,r['id'])
def member(db,uid):
 with db.connect() as c:
  row=c.execute('SELECT * FROM launch_members WHERE user_id=?',(uid,)).fetchone()
  if row:return dict(row)
  c.execute('BEGIN IMMEDIATE');return allocate(c,uid)
def catalog(db,uid=None):
 with db.connect() as c:n=c.execute('SELECT COUNT(*) FROM launch_members WHERE ordinal IS NOT NULL').fetchone()[0]
 m=member(db,uid) if uid else None;tier=m['tier'] if m else ('early' if n<LIMIT else 'regular')
 return {'plans':[p for p in PLANS.values() if p['tier']==tier], 'all_prices':list(PLANS.values()),'tier':tier,'member_number':m['ordinal'] if m else None,'early_members_limit':LIMIT,'early_slots_remaining':max(0,LIMIT-n),'chat_trial_days':7,'trial_expires':m['trial_expires'] if m else None,'chat_free':True,'notice':'Early access prices apply to the first 501 registered members. Your cohort is retained; existing purchases keep their expiry. Aerny 2.0 Chat is always free. ETERNAL Chat and extension Work tools are included for 7 days, then with an active subscription. Monthly means 30 days; yearly means 365 days.'}
