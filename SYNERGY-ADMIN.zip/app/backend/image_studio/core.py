"""CPU-only job manager; no imports from the model environment in the web server."""
from __future__ import annotations
import base64, binascii, json, os, secrets, subprocess, threading, time, uuid
from pathlib import Path
from quality import finishing
from super_resolution import available

ROOT = Path(__file__).resolve().parent
STYLES = {
    'natural': '', 'cinematic': 'cinematic lighting, film still, atmospheric composition',
    'anime': 'anime illustration, expressive linework, cel shading',
    '3d': 'stylized 3D render, soft studio lighting',
    'product': 'product photography, clean backdrop, studio lighting',
    'graphic': 'editorial graphic illustration, simple shapes, clear composition',
}
CANVASES=json.loads((ROOT/'canvas_presets.json').read_text())
SIZES={p['id']:(p['render_width'],p['render_height']) for p in CANVASES}
EXPORT_SIZES={p['id']:(p['width'],p['height']) for p in CANVASES}
MODEL_ID = 'stable-diffusion-v1-5/stable-diffusion-v1-5'
REQUIRED = ['model_index.json', 'unet/diffusion_pytorch_model.safetensors',
            'vae/diffusion_pytorch_model.safetensors', 'text_encoder/model.safetensors',
            'safety_checker/model.safetensors', 'tokenizer/vocab.json',
            'tokenizer/merges.txt', 'feature_extractor/preprocessor_config.json',
            'unet/config.json', 'vae/config.json', 'text_encoder/config.json',
            'safety_checker/config.json', 'scheduler/scheduler_config.json',
            'tokenizer/tokenizer_config.json']

def atomic_json(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.chmod(temp, 0o600)
    os.replace(temp, path)

def validate(payload):
    if not isinstance(payload, dict): raise ValueError('Expected a JSON object.')
    if not isinstance(payload.get('prompt'), str) or not payload['prompt'].strip():
        raise ValueError('Describe the image you want to create.')
    if len(payload['prompt']) > 1000: raise ValueError('Use a prompt up to 1,000 characters.')
    negative = payload.get('negative', '')
    if not isinstance(negative, str) or len(negative) > 500: raise ValueError('Negative prompt limit: 500 characters.')
    style, size = payload.get('style', 'natural'), payload.get('size', 'square')
    if style not in STYLES or size not in SIZES: raise ValueError('Invalid style or size.')
    steps, seed = payload.get('steps', 12), payload.get('seed', -1)
    if type(steps) is not int or not 4 <= steps <= 30: raise ValueError('Steps must be an integer from 4 to 30.')
    if type(seed) is not int or not -1 <= seed <= 2147483647: raise ValueError('Seed must be -1 or an integer up to 2147483647.')
    quality=payload.get('quality','draft')
    if quality not in {'draft','fast','balanced','detail'}:raise ValueError('Choose Draft, Fast, Balanced or Detail quality.')
    if quality in {'balanced','detail'}:steps=max(steps,24)
    strength=payload.get('strength',0.35)
    if type(strength) not in {int,float} or not 0.1<=strength<=0.9:raise ValueError('Change strength must be between 0.1 and 0.9.')
    if payload.get('reference') and int(steps*strength)<1:raise ValueError('Increase steps or reference change strength.')
    finish=finishing(payload.get('finish'))
    return dict(quality=quality,finish=finish,strength=float(strength),reference=bool(payload.get('reference')),prompt=payload['prompt'].strip(), negative=negative, style=style, size=size,
                steps=steps, seed=secrets.randbelow(2147483648) if seed == -1 else seed)

class Jobs:
    def __init__(self, data, runner=None):
        self.data = Path(data).resolve(); self.data.mkdir(parents=True, exist_ok=True)
        os.chmod(self.data, 0o700)
        self.output = self.data / 'jobs'; self.output.mkdir(exist_ok=True)
        self.lock = threading.RLock(); self.active = None; self.process = None
        self.runner = runner or self._run
        self.token_file = self.data / 'bridge.key'
        if not self.token_file.exists():
            fd = os.open(str(self.token_file), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w') as handle: handle.write(secrets.token_urlsafe(48))
        os.chmod(self.token_file, 0o600)
        self.token = self.token_file.read_text().strip()
        # A process interrupted by a restart cannot leave a permanently running job.
        for path in self.output.glob('*/job.json'):
            try:
                job = json.loads(path.read_text())
                if job['state'] in {'queued', 'running', 'cancelling'}:
                    job.update(state='failed', error='Image service stopped before this job completed.')
                    atomic_json(path, job)
            except (OSError, ValueError, KeyError): pass

    def status(self):
        python = Path(os.getenv('SYNERGY_IMAGE_PYTHON',str(ROOT / '.venv-image' / 'bin/python')))
        manifest = self.data / 'model.json'
        model_path = None
        try:
            model_path = Path(json.loads(manifest.read_text())['path'])
            ready = all((model_path / name).is_file() for name in REQUIRED)
        except (OSError, ValueError, KeyError, TypeError): ready = False
        installed = python.is_file() and (python.parent.parent / 'verified.json').is_file()
        finish_python=Path(os.getenv('SYNERGY_FINISH_PYTHON',str(python)))
        finish_ready=installed or (finish_python.is_file() and (finish_python.parent.parent/'aerny-requirements.sha256').is_file())
        return dict(name='AeRny Image Studio v1.4 · 4K',version='1.4-4k',super_resolution=available(self.data),preservation_supported=False,hd_pipeline=bool(finish_ready),finish_ready=bool(finish_ready),reference_supported=True, engine='epiCRealism (Stable Diffusion 1.5)', device=os.getenv('SYNERGY_DEVICE','cpu'),
                    dependencies=installed, model_ready=ready, ready=installed and ready,
                    active=self.active, styles=list(STYLES), sizes=list(SIZES),canvases=CANVASES,
                    detail='Ready for local generation' if installed and ready else
                    'Local image engine is unavailable; cloud-image finishing is ready' if finish_ready and not installed else 'Install the isolated image engine' if not installed else 'The configured local image model files are missing')

    def folder(self, jid):
        if not isinstance(jid, str) or len(jid) != 32 or any(c not in '0123456789abcdef' for c in jid):
            raise KeyError('Image job not found.')
        return self.output / jid

    def get(self, jid):
        folder = self.folder(jid)
        try: job = json.loads((folder / 'job.json').read_text())
        except (OSError, ValueError): raise KeyError('Image job not found.')
        if job['state'] == 'running':
            try: job['progress'] = json.loads((folder / 'progress.json').read_text())
            except (OSError, ValueError): pass
        if job['state'] == 'succeeded': job['image_url'] = '/api/images/' + jid + '.png'
        return job

    def list(self):
        paths = sorted(self.output.glob('*/job.json'), key=lambda p: p.stat().st_mtime, reverse=True)[:30]
        return [self.get(p.parent.name) for p in paths]

    def submit(self, payload):
        spec = validate(payload)
        reference=None;source=None
        if payload.get('source_b64'):
            encoded=payload['source_b64']
            if not isinstance(encoded,str) or len(encoded)>172*1024*1024:raise ValueError('Provider image upload is too large.')
            try:source=base64.b64decode(encoded,validate=True)
            except (ValueError,binascii.Error):raise ValueError('Invalid provider image encoding.')
            if len(source)>128*1024*1024 or not source.startswith((b'\x89PNG\r\n\x1a\n',b'\xff\xd8\xff',b'RIFF')):raise ValueError('Invalid provider image.')
            spec['finish_only']=True
        if payload.get('reference_b64'):
            if not isinstance(payload['reference_b64'],str) or len(payload['reference_b64'])>172*1024*1024:raise ValueError('Reference upload is too large.')
            try:reference=base64.b64decode(payload['reference_b64'],validate=True)
            except (ValueError,binascii.Error):raise ValueError('Invalid reference image encoding.')
            if not (reference.startswith(b'\x89PNG\r\n\x1a\n') or reference.startswith(b'\xff\xd8\xff')):raise ValueError('Use a PNG or JPEG reference.')
            spec['reference']=True
            if int(spec['steps']*spec['strength'])<1:raise ValueError('Increase steps or change strength.')
        elif spec['reference']:raise ValueError('Reference image bytes were not supplied.')
        with self.lock:
            if self.active: raise RuntimeError('One image is already running. Wait for it or cancel it first.')
            status=self.status()
            if not (status.get('finish_ready',status.get('dependencies')) if source else status.get('ready')): raise RuntimeError(status['detail'] + '. See the setup instructions.')
            jid = uuid.uuid4().hex; folder = self.folder(jid); folder.mkdir(mode=0o700)
            job = dict(id=jid, state='queued', created=time.time(), **spec)
            if reference:(folder/'reference.bin').write_bytes(reference)
            if source:(folder/'source.bin').write_bytes(source)
            atomic_json(folder / 'job.json', job); self.active = jid
            threading.Thread(target=self._execute, args=(jid,), daemon=True).start()
        return job

    def _update(self, jid, **changes):
        job = self.get(jid); job.pop('progress', None); job.pop('image_url', None)
        job.update(changes); atomic_json(self.folder(jid) / 'job.json', job)

    def _execute(self, jid):
        try:
            with self.lock:
                if self.get(jid)['state'] == 'cancelled': return
                self._update(jid, state='running', started=time.time())
            self.runner(jid)
            with self.lock:
                job = self.get(jid)
                if job['state'] in {'cancelled', 'cancelling'}:
                    (self.folder(jid) / 'image.png').unlink(missing_ok=True)
                    self._update(jid, state='cancelled', finished=time.time())
                else:
                    result = json.loads((self.folder(jid) / 'result.json').read_text())
                    if result.get('blocked'): raise RuntimeError('The model safety checker did not return an image. Try a different prompt.')
                    if not (self.folder(jid) / 'image.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n'):
                        raise RuntimeError('The engine did not produce a valid PNG.')
                    self._update(jid, state='succeeded', finished=time.time(), result=result)
        except Exception as exc:
            with self.lock:
                current = self.get(jid)
                if current['state'] in {'cancelled', 'cancelling'}:
                    self._update(jid, state='cancelled', finished=time.time())
                else:
                    with (self.folder(jid)/'engine.log').open('a') as log:
                        log.write('\nJob failed: '+type(exc).__name__+': '+str(exc)+'\n')
                    self._update(jid, state='failed', finished=time.time(),
                                 error=str(exc)[:300] if isinstance(exc,RuntimeError) else
                                 'Generation failed. Check this job’s engine.log in the configured image data directory for the cause.')
                (self.folder(jid) / 'image.png').unlink(missing_ok=True)
        finally:
            with self.lock:
                self.active = None; self.process = None

    def _run(self, jid):
        folder = self.folder(jid)
        env = dict(os.environ, PYTHONPATH=os.getenv('SYNERGY_STUDIO_WORKER_PATH',os.getenv('PYTHONPATH','')), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1',
                   CUDA_VISIBLE_DEVICES=os.getenv('CUDA_VISIBLE_DEVICES','0') if os.getenv('SYNERGY_DEVICE')=='cuda' else '', PYTORCH_ENABLE_MPS_FALLBACK='0')
        with (folder / 'engine.log').open('wb') as log:
            with self.lock:
                if self.get(jid)['state'] in {'cancelled', 'cancelling'}: return
                finish_only=self.get(jid).get('finish_only')
                python=os.getenv('SYNERGY_FINISH_PYTHON') if finish_only and self.get(jid).get('finish',{}).get('reference_mode')!='enhance' else None
                python=python or os.getenv('SYNERGY_IMAGE_PYTHON',str(ROOT / '.venv-image/bin/python'))
                self.process = subprocess.Popen([python, str(ROOT / ('finish.py' if finish_only else 'inference.py')),
                                                 str(folder), str(self.data / 'model.json')],
                                                stdout=log, stderr=subprocess.STDOUT, env=env)
                process = self.process
            code = process.wait()
            if code: raise RuntimeError('Image inference stopped. Check engine.log.')

    def cancel(self, jid):
        with self.lock:
            job = self.get(jid)
            if job['state'] not in {'queued', 'running', 'cancelling'}: return job
            self._update(jid, state='cancelling' if job['state'] == 'running' else 'cancelled')
            if self.active == jid and self.process:
                self.process.terminate()
                try: self.process.wait(timeout=3)
                except subprocess.TimeoutExpired: self.process.kill()
        return self.get(jid)

    def close(self):
        if self.active: self.cancel(self.active)
