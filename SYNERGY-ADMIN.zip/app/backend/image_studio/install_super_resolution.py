"""Install the pinned 4.9 MB official model without running repository setup scripts."""
import argparse,hashlib,os,urllib.request
from pathlib import Path
from super_resolution import model_path,SHA256,URL

def install(data):
 path=model_path(data);path.parent.mkdir(parents=True,exist_ok=True)
 if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==SHA256:return path
 with urllib.request.urlopen(URL,timeout=60) as response:payload=response.read(10000001)
 if hashlib.sha256(payload).hexdigest()!=SHA256:raise RuntimeError('Official model download failed checksum verification; no model was installed.')
 temporary=path.with_suffix('.tmp');temporary.write_bytes(payload);os.chmod(temporary,0o600);os.replace(temporary,path)
 return path

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--data-dir',default=os.getenv('SYNERGY_IMAGE_DATA',str(Path.home()/'Library/Application Support/SYnerGY/image_studio')))
 args=parser.parse_args();print('Verified local 4× super-resolution model:',install(args.data_dir))
