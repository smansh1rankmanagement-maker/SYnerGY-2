"""Pillow export and exact-copy editorial composition in the existing image environment."""
from pathlib import Path
import io,json,os,re,sys,time
from PIL import Image,ImageOps,ImageDraw,ImageFont
from PIL.PngImagePlugin import PngInfo
from core import EXPORT_SIZES,atomic_json
ROOT=Path(__file__).resolve().parent

from quality import finishing as config, export_size

def font(size,bold=False):
 override=os.getenv('AERNY_POSTER_FONT','')
 path=Path(override) if override else ROOT/'fonts'/('DejaVuSansCondensed-Bold.ttf' if bold else 'DejaVuSans.ttf')
 if not path.is_file():raise RuntimeError('The bundled poster font is missing. Re-extract the complete upgrade.')
 return ImageFont.truetype(str(path),size)

def wrap(draw,text,typeface,width):
 lines=[]
 for paragraph in text.splitlines() or ['']:
  line=''
  for word in paragraph.split():
   candidate=(line+' '+word).strip()
   if line and draw.textbbox((0,0),candidate,font=typeface)[2]>width:lines.append(line);line=word
   else:line=candidate
  lines.append(line)
 return '\n'.join(lines)

def fit_text(draw,text,width,height,size,bold=False):
 for n in range(size,11,-2):
  f=font(n,bold);wrapped=wrap(draw,text,f,width);box=draw.multiline_textbbox((0,0),wrapped,font=f,spacing=max(2,n//15))
  if box[2]-box[0]<=width and box[3]-box[1]<=height:return f,wrapped,box,max(2,n//15)
 raise RuntimeError('The requested copy does not fit this canvas. Shorten it or choose a larger poster.')

def finish_image(image,size,finish=None):
 finish=config(finish);source=image.size;width,height=export_size(EXPORT_SIZES[size],finish,source)
 if finish.get('reference_mode') in {'preserve','enhance'}:
  out=image.resize((width,height),Image.Resampling.LANCZOS)
  return out,dict(width=width,height=height,source_width=source[0],source_height=source[1],enlarged=max(width/source[0],height/source[1])>1,typography='none',export_method='Lanczos, original aspect ratio; no crop',reference_mode=finish['reference_mode'],face_regenerated=False,quality_note='Original composition retained. Resampling cannot recover detail absent from the original.')
 headline=finish.get('headline','');subtitle=finish.get('subtitle','')
 if (headline or subtitle) and re.search(r'[^\u0000-\u024f\u2000-\u206f\n]',headline+subtitle) and not os.getenv('AERNY_POSTER_FONT'):
  raise RuntimeError('This local font supports Latin copy. For Hindi lettering, set AERNY_POSTER_FONT to a suitable Devanagari font, or use a text-capable cloud image without the exact-copy overlay.')
 if headline:
  palettes={'cream':('#e9e2d1','#171917','#e75d25'),'orange':('#e6a73b','#161a18','#eee8d5'),'olive':('#303b29','#f1ebd5','#e27531'),'charcoal':('#202322','#f2eee5','#e96725')}
  bg,fg,accent=palettes.get(finish.get('theme','cream'),palettes['cream'])
  out=Image.new('RGB',(width,height),bg);draw=ImageDraw.Draw(out);margin=max(16,int(min(width,height)*.055));top=int(height*.04)
  title_height=int(height*.24);title_font,title,box,spacing=fit_text(draw,headline,width-2*margin,title_height,int(height*.19),True)
  draw.multiline_text((margin-box[0],top-box[1]),title,font=title_font,fill=accent,spacing=spacing)
  photo_top=int(height*.33);photo_bottom=height-margin-(int(height*.105) if subtitle else 0)
  photo=ImageOps.fit(image.convert('RGB'),(width-2*margin,photo_bottom-photo_top),method=Image.Resampling.LANCZOS)
  out.paste(photo,(margin,photo_top));photo_target=(photo.width,photo.height)
  if subtitle:
   f,text,box,spacing=fit_text(draw,subtitle,width-2*margin,int(height*.075),max(18,int(height*.027)))
   draw.multiline_text((margin-box[0],photo_bottom+int(height*.025)-box[1]),text,font=f,fill=fg,spacing=spacing)
 else:
  out=ImageOps.fit(image.convert('RGB'),(width,height),method=Image.Resampling.LANCZOS);photo_target=(width,height)
  if subtitle:
   draw=ImageDraw.Draw(out);margin=max(16,int(min(width,height)*.05));bar=int(height*.16)
   draw.rectangle((0,height-bar,width,height),fill='#171917')
   f,text,box,spacing=fit_text(draw,subtitle,width-2*margin,bar-2*margin,max(18,int(height*.035)))
   draw.multiline_text((margin-box[0],height-bar+margin-box[1]),text,font=f,fill='#f2eee5',spacing=spacing)
 return out,{'width':width,'height':height,'source_width':source[0],'source_height':source[1],
             'enlarged':max(photo_target[0]/source[0],photo_target[1]/source[1])>1, 'typography':'exact-copy Pillow overlay' if headline else 'none',
             'headline':headline,'subtitle':subtitle,'export_method':'Editorial composition and Lanczos fit' if headline else 'Lanczos aspect fit',
             'quality_note':'Export dimensions are verified; enlargement does not create missing photographic detail.'}

def write_png(image,folder,metadata):
 info=PngInfo();info.add_text('AeRny',json.dumps(metadata,ensure_ascii=False));image.save(folder/'image.png',pnginfo=info,icc_profile=image.info.get('icc_profile'))

def main():
 folder=Path(sys.argv[1]);job=json.loads((folder/'job.json').read_text());Image.MAX_IMAGE_PIXELS=40000000;start=time.monotonic()
 finish=job.get('finish',{});mode=finish.get('reference_mode','generate')
 atomic_json(folder/'progress.json',{'stage':'Preserving original photo and exporting 4K' if mode=='preserve' else 'Preparing final image export','step':0,'total':0})
 with Image.open(folder/'source.bin') as im:
  if im.format not in {'PNG','JPEG','WEBP'} or im.width*im.height>40000000:raise RuntimeError('Source image format or size is unsupported.')
  image=ImageOps.exif_transpose(im).copy()
 original=image.size;has_alpha='A' in image.getbands() and image.getchannel('A').getextrema()[0]<255;sr={}
 if mode=='enhance':
  from super_resolution import upscale
  image,sr=upscale(image,Path(sys.argv[2]).parent,lambda step,total:atomic_json(folder/'progress.json',{'stage':'Local super-resolution · no face restoration','step':step,'total':total}),target=export_size(EXPORT_SIZES[job['size']],finish,image.size))
 out,meta=finish_image(image,job['size'],finish)
 meta.update(sr,blocked=False,seed=None,provider=finish.get('provider','local'),model=finish.get('engine','photo-preservation'),render_width=original[0],render_height=original[1],original_width=original[0],original_height=original[1],device='cpu',seconds=round(time.monotonic()-start,2))
 if mode=='preserve':meta.update(super_resolution='none',face_restoration=False,reference_mode=mode,quality_note='Original face and texture are not regenerated; only image resampling. No crop. Missing detail is not invented.')
 if mode=='preserve':
  meta.update(asset_kind=finish.get('asset_kind','image'),transparency_preserved=has_alpha,alpha=has_alpha,content_regenerated=False)
  if finish.get('asset_kind')=='logo':meta.update(model='logo-preservation',quality_note='Original logo retained: no AI redraw, no typography changes, no crop. Transparent PNG; interpolation adds no invented detail.' if has_alpha else 'Original logo retained: no AI redraw, no typography changes, no crop. PNG export; interpolation adds no invented detail.')
 if mode=='enhance':meta.update(reference_mode=mode,quality_note='Gentle AI enhancement blends 75% original detail with 25% super-resolution. Fine texture may change; no separate face restoration. Review against the original.')
 write_png(out,folder,meta);atomic_json(folder/'result.json',meta)
if __name__=='__main__':main()
