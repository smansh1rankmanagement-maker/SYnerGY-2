"""Offline, bounded CPU super-resolution. Never restores or synthesizes faces separately."""
import hashlib
from pathlib import Path

MODEL='realesr-general-x4v3.pth'
SHA256='8dc7edb9ac80ccdc30c3a5dca6616509367f05fbc184ad95b731f05bece96292'
URL='https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/'+MODEL

def model_path(data):return Path(data)/'super_resolution'/MODEL

def available(data):
 path=model_path(data)
 return path.is_file() and path.stat().st_size==4885111

def upscale(image,data,progress=None,tile=192,target=None):
 import numpy as np
 import torch
 from PIL import Image
 from realesrgan_arch import SRVGGNetCompact
 path=model_path(data)
 if not path.is_file():raise RuntimeError('Local super-resolution weights are not installed. Run image_studio/install_super_resolution.py with the image environment.')
 if hashlib.sha256(path.read_bytes()).hexdigest()!=SHA256:raise RuntimeError('Super-resolution weights failed verification. Reinstall the official model.')
 if image.width*image.height>40000000:raise RuntimeError('The decoded image exceeds 40 megapixels.')
 torch.set_num_threads(4)
 network=SRVGGNetCompact(num_conv=32).eval()
 weights=torch.load(str(path),map_location='cpu',weights_only=True)
 network.load_state_dict(weights['params'],strict=True)
 # A 40px halo covers all 34 convolution layers, preventing tile seams.
 image=image.convert('RGB');width,height=image.size;target=target or (width*4,height*4)
 if target[0]*target[1]>32000000:raise RuntimeError('Super-resolution output exceeds the supported allocation.')
 out=Image.new('RGB',target);pad=40;sx,sy=target[0]/width,target[1]/height
 total=((width+tile-1)//tile)*((height+tile-1)//tile);done=0
 with torch.inference_mode():
  for y in range(0,height,tile):
   for x in range(0,width,tile):
    endx,endy=min(x+tile,width),min(y+tile,height)
    left,top,right,bottom=max(0,x-pad),max(0,y-pad),min(width,endx+pad),min(height,endy+pad)
    patch=np.asarray(image.crop((left,top,right,bottom)),dtype=np.float32)/255
    tensor=torch.from_numpy(patch.transpose(2,0,1).copy()).unsqueeze(0)
    output=network(tensor)[0].clamp_(0,1)
    pixels=(output.permute(1,2,0).numpy()*255).round().astype(np.uint8)
    dx,dy,ex,ey=round(x*sx),round(y*sy),round(endx*sx),round(endy*sy)
    box=((dx/sx-left)*4,(dy/sy-top)*4,(ex/sx-left)*4,(ey/sy-top)*4)
    box=tuple(max(0,min(v,pixels.shape[1] if i%2==0 else pixels.shape[0])) for i,v in enumerate(box))
    patch=Image.fromarray(pixels).resize((ex-dx,ey-dy),Image.Resampling.LANCZOS,box=box)
    out.paste(patch,(dx,dy));done+=1
    if progress:progress(done,total)
 # Retain original skin, grain and fabric detail; the full GAN output can look waxy.
 out=Image.blend(image.resize(target,Image.Resampling.LANCZOS),out,.25)
 return out,{'original_detail_blend':0.75,'super_resolution':'Real-ESRGAN general x4v3','super_resolution_scale':4,'super_resolution_export_scale':round(max(sx,sy),4),'super_resolution_width':out.width,'super_resolution_height':out.height,'face_restoration':False,'weights_sha256':SHA256}
