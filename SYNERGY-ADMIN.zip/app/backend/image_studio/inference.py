"""One local CPU inference per process; exiting returns model RAM to the OS."""
from pathlib import Path
import json, os, sys, time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import STYLES, SIZES, EXPORT_SIZES, atomic_json, validate
from quality import render_size
from super_resolution import upscale,available
from finish import finish_image,write_png

def main():
    folder, manifest = Path(sys.argv[1]), Path(sys.argv[2])
    job = validate(json.loads((folder / 'job.json').read_text()))
    model_info=json.loads(manifest.read_text())
    model = Path(model_info['path'])
    atomic_json(folder / 'progress.json', {'stage':'Loading local model on CPU', 'step':0, 'total':job['steps']})
    import torch
    device=os.environ.get('SYNERGY_DEVICE','cpu')
    if device not in {'cpu','cuda'} or (device=='cuda' and not torch.cuda.is_available()):raise RuntimeError('The requested inference device is unavailable.')
    from diffusers import StableDiffusionPipeline, StableDiffusionImg2ImgPipeline, DPMSolverMultistepScheduler
    torch.set_num_threads(max(1, min(4, (os.cpu_count() or 2) // 2)))
    torch.set_num_interop_threads(1)
    start = time.monotonic()
    Pipeline=StableDiffusionImg2ImgPipeline if job['reference'] else StableDiffusionPipeline
    pipe = Pipeline.from_pretrained(str(model), torch_dtype=torch.float16 if device=='cuda' else torch.float32,
                                                  use_safetensors=True, local_files_only=True)
    # Preserve the bundled safety checker. Never deserialize arbitrary pickle weights.
    if pipe.safety_checker is None: raise RuntimeError('Required safety checker is missing.')
    pipe = pipe.to(device)
    pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config,algorithm_type='dpmsolver++',solver_order=2,use_karras_sigmas=True)
    pipe.enable_attention_slicing(); pipe.enable_vae_slicing(); pipe.set_progress_bar_config(disable=True)
    width,height=render_size(EXPORT_SIZES[job['size']],SIZES[job['size']],job['quality'])
    if job['quality'] in {'balanced','detail'}:job['steps']=max(job['steps'],28 if job['quality']=='balanced' else 30)
    prompt = job['prompt'] + (', ' + STYLES[job['style']] if STYLES[job['style']] else '')
    clipped = len(pipe.tokenizer(prompt, truncation=False)['input_ids']) > pipe.tokenizer.model_max_length
    actual_steps=int(job['steps']*job['strength']) if job['reference'] else job['steps']
    phase='Generating the base photo'
    def progress(pipeline, step, timestep, kwargs):
        atomic_json(folder / 'progress.json', {'stage':phase, 'step':step+1, 'total':actual_steps})
        return kwargs
    extra={}
    if job['reference']:
        from PIL import Image,ImageOps
        Image.MAX_IMAGE_PIXELS=40000000
        with Image.open(folder/'reference.bin') as ref:
            if ref.format not in {'PNG','JPEG'} or ref.width*ref.height>40000000:raise RuntimeError('Reference image exceeds the supported format or dimensions.')
            ref=ImageOps.exif_transpose(ref).convert('RGB')
            extra['image']=ImageOps.pad(ref,(width,height),method=Image.Resampling.LANCZOS,color='white')
        extra['strength']=job['strength']
    else:extra.update(width=width,height=height)
    with torch.inference_mode():
        result = pipe(prompt=prompt, negative_prompt=job['negative'], **extra,
                      num_inference_steps=job['steps'], guidance_scale=7.0,
                      generator=torch.Generator(device='cpu').manual_seed(job['seed']),
                      callback_on_step_end=progress)
    blocked = bool(result.nsfw_content_detected and result.nsfw_content_detected[0])
    detail_pass=False
    if not blocked and job['quality']=='detail' and not job['reference'] and not available(manifest.parent):
        from PIL import Image,ImageOps
        refined_width=round(width*1.5/8)*8;refined_height=round(height*1.5/8)*8
        base=ImageOps.fit(result.images[0],(refined_width,refined_height),method=Image.Resampling.LANCZOS)
        refiner=pipe if job['reference'] else StableDiffusionImg2ImgPipeline(**pipe.components)
        actual_steps=8;phase='Local detail refinement'
        atomic_json(folder/'progress.json',{'stage':'Local detail refinement (slower on CPU)','step':0,'total':8})
        with torch.inference_mode():
            result=refiner(prompt=prompt,negative_prompt=job['negative'],image=base,strength=.35,num_inference_steps=24,guidance_scale=6.5,
                           generator=torch.Generator(device='cpu').manual_seed((job['seed']+1)%2147483648),callback_on_step_end=progress)
        blocked=bool(result.nsfw_content_detected and result.nsfw_content_detected[0]);detail_pass=True
    metadata=dict(blocked=blocked,seconds=round(time.monotonic()-start,2),seed=job['seed'],device=device,provider='local',model=model_info.get('model_id','Stable Diffusion 1.5'),scheduler='DPM++ 2M Karras',steps=job['steps'],
                  reference=job['reference'],strength=job['strength'],prompt_truncated=clipped,quality=job['quality'],detail_pass=detail_pass,base_render_width=width,base_render_height=height)
    if not blocked:
        image=result.images[0];native=image.size;sr={}
        if job['quality'] in {'balanced','detail'} and available(manifest.parent):
            # Free diffusion RAM before loading the small super-resolution network.
            del pipe
            import gc
            gc.collect()
            image,sr=upscale(image,manifest.parent,lambda step,total:atomic_json(folder/'progress.json',{'stage':'Refining texture and edges','step':step,'total':total}),target=EXPORT_SIZES[job['size']])
        out,export=finish_image(image,job['size'],job.get('finish'));metadata.update(export,render_width=native[0],render_height=native[1],face_restoration=False,reference_mode='generate',face_regenerated=bool(job['reference']))
        metadata.update(sr)
        if not sr:metadata['super_resolution']='unavailable' if job['quality']=='detail' else 'not requested'
        metadata['quality_note']='AI-generated image with '+('local super-resolution blended with 75% original detail' if sr else 'resampled export')+'. Reference identity and texture need visual review; export is not native 4K inference.'
        metadata.update(native_width=native[0],native_height=native[1],enlarged=out.width>native[0] or out.height>native[1],seconds=round(time.monotonic()-start,2))
        write_png(out,folder,metadata)
    metadata['seconds']=round(time.monotonic()-start,2)
    atomic_json(folder/'result.json',metadata)

if __name__ == '__main__':
    from media_compute import inference_slot
    with inference_slot(Path(sys.argv[1])):main()
