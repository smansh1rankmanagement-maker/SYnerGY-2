"""Lightweight image quality validation; safe to import without Pillow or torch."""
import math

def finishing(value):
 if value is None:return {}
 if not isinstance(value,dict):raise ValueError('Invalid image finishing configuration.')
 result={k:str(value.get(k,''))[:limit] for k,limit in [('headline',120),('subtitle',200),('theme',20),('provider',80),('engine',100)]}
 if result['theme'] not in {'','cream','orange','olive','charcoal'}:raise ValueError('Choose a supported poster palette.')
 result['asset_kind']='logo' if value.get('asset_kind')=='logo' else 'image'
 result['resolution']=value.get('resolution','canvas')
 result['reference_mode']=value.get('reference_mode','generate')
 if result['resolution'] not in {'canvas','4k'}:raise ValueError('Choose canvas or 4K export.')
 if result['reference_mode'] not in {'generate','preserve','enhance'}:raise ValueError('Invalid reference operation.')
 return result

def export_size(canvas,finish,source=None):
 # Preservation keeps the complete photograph, regardless of the default social canvas.
 size=source if source and finish.get('reference_mode') in {'preserve','enhance'} else canvas
 if finish.get('resolution')!='4k':return size
 scale=3840/max(size)
 return tuple(max(1,round(n*scale)) for n in size)

def render_size(export_size,draft_size,quality):
 if quality=='draft':return draft_size
 ratio=export_size[0]/export_size[1]
 area={'fast':512*512,'balanced':768*432,'detail':896*504}.get(quality,512*512)
 w=round(math.sqrt(area*ratio)/8)*8;h=round(math.sqrt(area/ratio)/8)*8
 return max(256,min(1024,w)),max(256,min(1024,h))
