"""Private desktop image studio. Bind only to loopback; no external model calls."""
from __future__ import annotations
import argparse, hmac, json, mimetypes, re, secrets
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from core import Jobs, ROOT

def handler_for(jobs, port):
    session = secrets.token_urlsafe(48)
    allowed_hosts = {'127.0.0.1:'+str(port), 'localhost:'+str(port)}
    origins = {'http://'+h for h in allowed_hosts}
    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.0'
        def setup(self):
            super().setup(); self.connection.settimeout(15)
        def log_message(self, fmt, *args): pass
        def send(self, code, body, mime='application/json', cookie=False, download=False):
            if isinstance(body, (dict, list)): body = json.dumps(body, ensure_ascii=False).encode()
            if isinstance(body, str): body = body.encode()
            self.send_response(code)
            self.send_header('Content-Type', mime); self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store'); self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('X-Frame-Options', 'DENY'); self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; form-action 'self'")
            if cookie: self.send_header('Set-Cookie', 'image_session='+session+'; HttpOnly; SameSite=Strict; Path=/')
            if download: self.send_header('Content-Disposition', 'attachment; filename="aerny-image.png"')
            self.end_headers(); self.wfile.write(body)
        def authorized(self):
            token = self.headers.get('Authorization', '')
            if token.startswith('Bearer ') and hmac.compare_digest(token[7:], jobs.token): return True
            cookie = SimpleCookie()
            try: cookie.load(self.headers.get('Cookie', ''))
            except Exception: return False
            return bool(cookie.get('image_session') and hmac.compare_digest(cookie['image_session'].value, session))
        def dispatch(self, post=False):
            if self.headers.get('Host') not in allowed_hosts: return self.send(403, {'error':'Invalid local host.'})
            path = urlsplit(self.path).path
            if not post and path in {'/', '/style.css', '/studio.js', '/synergy-logo.png'}:
                p = ROOT / 'static' / ('index.html' if path == '/' else path.lstrip('/'))
                return self.send(200, p.read_bytes(), mimetypes.guess_type(str(p))[0] or 'application/octet-stream', cookie=path == '/')
            if not self.authorized(): return self.send(401, {'error':'Open the image studio to begin a local session.'})
            # A bearer is for the backend bridge; browser requests also need a same-origin POST.
            if post and (self.headers.get('Origin') not in origins and not
                         hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer '+jobs.token)):
                return self.send(403, {'error':'Invalid request origin.'})
            try:
                if not post and path == '/api/status': return self.send(200, jobs.status())
                if not post and path == '/api/jobs': return self.send(200, jobs.list())
                m = re.fullmatch(r'/api/jobs/([0-9a-f]{32})', path)
                if not post and m: return self.send(200, jobs.get(m[1]))
                m = re.fullmatch(r'/api/images/([0-9a-f]{32})\.png', path)
                if not post and m:
                    job = jobs.get(m[1])
                    if job['state'] != 'succeeded': return self.send(404, {'error':'Image is not available.'})
                    return self.send(200, (jobs.folder(m[1]) / 'image.png').read_bytes(), 'image/png',
                                     download=urlsplit(self.path).query == 'download=1')
                if post:
                    if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                        return self.send(415, {'error':'Send application/json.'})
                    if self.headers.get('Transfer-Encoding'): return self.send(400, {'error':'Unsupported transfer encoding.'})
                    length = int(self.headers.get('Content-Length', '0'))
                    if not 0 < length <= 176*1024*1024: return self.send(413, {'error':'Image bridge request is too large.'})
                    payload = json.loads(self.rfile.read(length))
                    if path == '/api/jobs': return self.send(202, jobs.submit(payload))
                    m = re.fullmatch(r'/api/jobs/([0-9a-f]{32})/cancel', path)
                    if m: return self.send(200, jobs.cancel(m[1]))
                return self.send(404, {'error':'Not found.'})
            except KeyError: return self.send(404, {'error':'Image job not found.'})
            except (ValueError, TypeError): return self.send(400, {'error':'Invalid image request. Check the prompt and settings.'})
            except RuntimeError as exc: return self.send(409, {'error':str(exc)})
            except OSError: return self.send(500, {'error':'Local image storage could not be read or written.'})
        def do_GET(self): self.dispatch()
        def do_POST(self): self.dispatch(True)
    return Handler

def main():
    p = argparse.ArgumentParser(); p.add_argument('--port', type=int, default=8012); p.add_argument('--data-dir'); args = p.parse_args()
    if not 1024 <= args.port <= 65535: p.error('Use a port from 1024 to 65535.')
    jobs = Jobs(Path(args.data_dir).expanduser() if args.data_dir else ROOT / 'data')
    server = ThreadingHTTPServer(('127.0.0.1', args.port), handler_for(jobs, args.port))
    server.daemon_threads = True
    print('AeRny Image Studio v1.3: http://127.0.0.1:'+str(args.port)+' — keep this Terminal open.', flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: jobs.close(); server.server_close()

if __name__ == '__main__': main()
