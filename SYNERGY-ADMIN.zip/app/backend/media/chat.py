"""Natural-language edit routing. Missing edit parameters produce a question, not a render."""
import json,os,re,sys,time
from pathlib import Path
from .schema import validate

def intent(prompt):
    p=prompt.strip()
    if re.search(r'\b(pdf|docx?|spreadsheet|xlsx?|excel|csv|markdown|document)\b',p,re.I) and not re.search(r'\b(image|photo|video|clip|media|diffusers|img2img|inpaint)\b',p,re.I):return False
    if re.search(r'\b(code|function|repository|css|html|navbar|nav bar|button|app|website)\b',p,re.I) and not re.search(r'\b(image|photo|video|clip|media|diffusers|img2img|inpaint)\b',p,re.I):return False
    if p.lower().startswith('/media '):return True
    if re.search(r'\b(how (?:do|can|to)|explain|what (?:is|are)|details|can (?:it|synergy)|do not|don.t|without (?:editing|generating))\b',p,re.I):return False
    return bool(re.search(r'\b(trim|compress|resize|crop|rotate|brighten|darken|inpaint|img2img|diffusers|join|merge|convert|add (?:the |a |an )?(?:logo|text|caption|subtitle)|mix (?:the |a )?audio|replace (?:the )?audio|make (?:it|this) (?:brighter|darker)|analy[sz]e (?:this |the )?(?:image|video|photo|media))\b',p,re.I))

def plan(prompt,names,upload_ids,previous=None):
    if not intent(prompt):return None
    if re.search(r'\b(remove (?:the )?background|track (?:the )?(?:face|object)|motion tracking|slow motion|speed up|stabili[sz]e|transcribe)\b',prompt,re.I):return {'question':'This media editor does not yet support that operation. It supports image layout/editing, trim/join, supplied timed captions, audio mixing and compression. Select a supported edit; I have not changed the file.'}
    p=prompt.strip();low=p.lower();previous=previous or {}
    common={'upload_ids':upload_ids}
    if not upload_ids and previous.get('asset_id'):common.update(source_id=previous['asset_id'],project_id=previous['project_id'])
    if low.startswith('/media '):
        try:recipe=validate(json.loads(p[7:]))
        except (ValueError,TypeError) as e:return {'question':'The media recipe needs correction: '+str(e)}
        return {**common,'recipe':recipe}
    video=bool(names and re.search(r'\.(mp4|mov|mkv|webm|avi)$',names[0],re.I)) or bool(previous.get('file','').endswith('.mp4')) or bool(re.search(r'\b(video|clip|caption|subtitle|audio|soundtrack)\b',low))
    if re.search(r'\banaly[sz]e\b',low):recipe={'kind':'analyze'}
    elif re.search(r'\b(diffusers|img2img|inpaint)\b',low):
        op='inpaint' if 'inpaint' in low else 'img2img' if 'img2img' in low or upload_ids or previous else 'generate'
        if op=='inpaint' and len(upload_ids)<2:return {'question':'Attach the source image first and its mask second. White marks the area to change; black preserves it. Then describe the edit.'}
        brief=re.sub(r'^.*?\b(?:diffusers|img2img|inpaint)\b\s*[:—-]?\s*','',p,flags=re.I)
        recipe={'kind':'ai','operation':op,'prompt':brief or p}
        if op=='inpaint':recipe['mask_upload_id']=upload_ids[1]
    else:
        ops=[];dims=re.search(r'\b(\d{2,4})\s*[x×]\s*(\d{2,4})\b',p)
        if video:
            trim=re.search(r'\btrim\b.*?(?:from\s+)?(\d+(?:\.\d+)?)\s*(?:s|sec(?:onds)?)?\s*(?:to|[-–])\s*(\d+(?:\.\d+)?)',low)
            if trim:ops.append({'op':'trim','start':float(trim[1]),'end':float(trim[2])})
            elif 'trim' in low:return {'question':'Which range should I keep? For example: “Trim this video from 2 to 8 seconds.”'}
            if re.search(r'\b(join|merge)\b',low):
                if len(upload_ids)<2:return {'question':'Attach two to five videos in the order you want them joined.'}
                ops.append({'op':'join','upload_ids':upload_ids[1:]})
            if re.search(r'\b(caption|subtitle)s?\b',low):
                cap=re.search(r'[“"]([^”"]+)[”"]\s*(?:from|at)?\s*(\d+(?:\.\d+)?)\s*(?:s|seconds)?\s*(?:to|[-–])\s*(\d+(?:\.\d+)?)',p)
                if not cap:return {'question':'Give the exact caption and its time range in the edited video. Example: Add caption “Welcome to InteriFY” from 0 to 3 seconds. For multiple captions, use Media tools → Video captions.'}
                ops.append({'op':'captions','cues':[{'text':cap[1],'start':float(cap[2]),'end':float(cap[3])}]})
            if re.search(r'\b(mix|replace)\b.*\b(audio|soundtrack)\b',low):
                if len(upload_ids)<2:return {'question':'Attach the video first and the audio file second. Tell me whether to mix or replace the original audio.'}
                ops.append({'op':'audio','upload_id':upload_ids[1],'volume':.5 if 'mix' in low else 1,'original_volume':1 if 'mix' in low else 0})
            if re.search(r'\b(compress|resize|convert)\b',low):ops.append({'op':'compress','width':int(dims[1]) if dims else 1280,'crf':28})
            recipe={'kind':'video','operations':ops}
        else:
            if 'resize' in low:
                if not dims:return {'question':'What dimensions should I use? For example: “Resize this image to 1080 × 1350.”'}
                ops.append({'op':'resize','width':int(dims[1]),'height':int(dims[2]),'fit':'cover' if re.search(r'\b(fill|cover)\b',low) else 'contain'})
            if 'crop' in low:
                crop=re.search(r'crop.*?(\d+)\s*[x×]\s*(\d+).*?(?:at|from)\s*\(?\s*(\d+)\s*[,x]\s*(\d+)',low)
                if not crop:return {'question':'Give crop width × height and the top-left x, y position. Example: “Crop to 600 × 400 at 20, 30.”'}
                ops.append({'op':'crop','width':int(crop[1]),'height':int(crop[2]),'x':int(crop[3]),'y':int(crop[4])})
            angle=re.search(r'rotate.*?(-?(?:90|180|270))',low)
            if angle:ops.append({'op':'rotate','angle':int(angle[1])})
            elif 'rotate' in low:return {'question':'Rotate clockwise by 90, 180 or 270 degrees?'}
            if re.search(r'brighten|brighter|darken|darker',low):ops.append({'op':'adjust','brightness':.8 if re.search('darken|darker',low) else 1.2})
            exact=re.search(r'\badd\s+(?:the\s+)?text\s*[“"]([^”"]+)[”"]',p,re.I)
            if exact:
                xy=re.search(r'\bat\s*\(?\s*(\d+)\s*,\s*(\d+)',low);size=re.search(r'\bsize\s*(\d+)',low);color=re.search(r'#[a-f0-9]{6}',low)
                ops.append({'op':'text','text':exact[1],'x':int(xy[1]) if xy else 24,'y':int(xy[2]) if xy else 24,'size':int(size[1]) if size else 32,'colour':color[0] if color else '#FFFFFF'})
            elif re.search(r'\badd\b.*\btext\b',low):return {'question':'What exact text should I place? Put it in quotation marks, and optionally give x, y, size and a hex colour.'}
            if re.search(r'\badd\b.*\blogo\b',low):
                if len(upload_ids)<2:return {'question':'Attach the base image first and the approved logo second. I will use the original logo rather than redraw it.'}
                ops.append({'op':'logo','upload_id':upload_ids[1]})
            fmt=re.search(r'\b(?:to|as)\s+(png|jpe?g|webp)\b',low)
            if fmt and not ops:ops.append({'op':'convert'})
            recipe={'kind':'image','operations':ops,'format':'jpeg' if fmt and fmt[1] in {'jpg','jpeg'} else fmt[1] if fmt else 'png'}
        if not ops:return {'question':'Tell me the edit and its settings: resize, crop, rotate, brightness, exact text/logo, trim, join, timed captions, audio mix or compression. Media tools also has a checked recipe editor.'}
    if not upload_ids and not previous and not(recipe['kind']=='ai' and recipe['operation']=='generate'):return {'question':'Attach the media file you want to edit, then send the request. Your original will be preserved.'}
    try:return {**common,'recipe':validate(recipe)}
    except ValueError as e:return {'question':'Please adjust the media settings: '+str(e)}

def execute(research,uid,jid,stop):
    from mcp_transport import StdioClient,initialize,unpack
    t=research.task(uid,jid);req=t['request'];proposal=req['media'];m=research.media
    if proposal.get('question'):return proposal['question']
    research.stage(uid,jid,'SYNERGY MEDIA · validating edit recipe')
    env={k:v for k,v in os.environ.items() if k in {'PATH','LANG','PYTHONDONTWRITEBYTECODE'}}
    client=StdioClient([sys.executable,str(Path(__file__).with_name('mcp.py')),'--data',str(m.data),'--user',str(uid),'--mode',req['mode']],env,str(m.data))
    try:
        initialize(client);job=unpack(client.request('tools/call',{'name':'media_submit','arguments':{**proposal,'conversation_id':t['conversation_id'],'request_id':'chat-'+jid,'title':req['prompt'][:100]}}))
    finally:client.close()
    research.update(uid,jid,detail={'media_job_id':job['id'],'creation':{'kind':'video' if proposal['recipe']['kind']=='video' else 'image'},'media_recipe':proposal['recipe']})
    last=''
    try:
        while job['state'] in {'queued','running','cancelling'}:
            research.check(stop);job=m.job(uid,job['id'])
            if job['stage']!=last:research.stage(uid,jid,job['stage']);last=job['stage']
            research.update(uid,jid,detail={'progress':{'step':round(job['progress']*100),'total':100},'media_job_id':job['id']})
            stop.wait(.5)
    except BaseException:m.cancel(uid,job['id']);raise
    if job['state']=='cancelled':raise InterruptedError('Media processing cancelled.')
    if job['state']!='succeeded':raise ValueError(job['error'] or 'Media processing did not finish.')
    result=job['result'];kind='video' if result['file'].endswith('.mp4') else 'image' if result['file'].endswith(('.png','.jpg','.webp')) else 'json'
    research.update(uid,jid,detail={'media_result':result,'artifacts':[{'name':result['file'],'label':'Download '+result['file'],'url':result['url'],'kind':kind}],'creation':{'kind':kind},'actions':[{'label':'Open media versions','media_project_id':result['project_id']}]})
    return ('Your media analysis is ready.\n\n'+json.dumps(result['metadata'],ensure_ascii=False,indent=2) if kind=='json' else 'Your edited '+('video' if kind=='video' else 'image')+' is ready.')+'\n\nSaved as version '+str(result['version'])+'. The original is preserved. Preview or download the verified file, or ask for another edit.'
