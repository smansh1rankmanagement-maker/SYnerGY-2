"""Durable account-owned media records. All external references are opaque IDs."""
import hashlib,json,os,shutil,sqlite3,time,uuid
from pathlib import Path
from .schema import validate,ident,upload_references,MAX_BYTES
from . import VERSION

ACTIVE=('queued','running','cancelling')
def token():return uuid.uuid4().hex
def atomic(p,value):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False));tmp.chmod(0o600);tmp.replace(p)
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

class Media:
    def __init__(self,data,access=None):
        self.data=Path(data);self.db=self.data/'accounts.sqlite3';self.root=self.data/'media-tools';self.root.mkdir(parents=True,exist_ok=True,mode=0o700);self.access=access
        with self.connect() as c:c.executescript('''
        CREATE TABLE IF NOT EXISTS media_projects(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,conversation_id TEXT NOT NULL,title TEXT NOT NULL,created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS media_assets(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,project_id TEXT NOT NULL,version INTEGER NOT NULL,name TEXT NOT NULL,path TEXT NOT NULL,sha256 TEXT NOT NULL,size INTEGER NOT NULL,origin_upload TEXT,parent_id TEXT,job_id TEXT,metadata TEXT NOT NULL,created REAL NOT NULL,UNIQUE(project_id,version));
        CREATE TABLE IF NOT EXISTS media_jobs(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,project_id TEXT NOT NULL,conversation_id TEXT NOT NULL,request_id TEXT NOT NULL,source_id TEXT,recipe TEXT NOT NULL,inputs TEXT NOT NULL,mode TEXT NOT NULL,state TEXT NOT NULL,stage TEXT NOT NULL,progress REAL NOT NULL DEFAULT 0,created REAL NOT NULL,started REAL,finished REAL,attempt INTEGER NOT NULL DEFAULT 0,result TEXT NOT NULL DEFAULT '{}',error TEXT,engine_version TEXT NOT NULL,UNIQUE(user_id,request_id));
        CREATE TABLE IF NOT EXISTS media_events(id INTEGER PRIMARY KEY AUTOINCREMENT,job_id TEXT NOT NULL,created REAL NOT NULL,state TEXT NOT NULL,message TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS media_worker(id INTEGER PRIMARY KEY,updated REAL NOT NULL);
        CREATE INDEX IF NOT EXISTS media_queue ON media_jobs(state,created);
        ''')
    def connect(self):
        c=sqlite3.connect(self.db,timeout=20);c.row_factory=sqlite3.Row;return c
    def conversation(self,uid,cid):
        ident(cid)
        with self.connect() as c:r=c.execute('SELECT id FROM conversations WHERE id=? AND user_id=? AND archived=0',(cid,uid)).fetchone()
        if not r:raise KeyError('Conversation not found in this account.')
    def allowed(self,uid,mode):
        if mode not in {'chat','work','beast'}:raise ValueError('Choose Chat, Work or Beast.')
        if self.access:self.access(uid,mode)
        with self.connect() as c:
            pref=c.execute('SELECT value FROM preferences WHERE user_id=? AND name=?',(uid,'tool:synergy-media')).fetchone()
        if pref and pref[0]=='false':raise ValueError('Enable SYNERGY MEDIA in Plugins first.')
    def project(self,uid,pid):
        ident(pid)
        with self.connect() as c:r=c.execute('SELECT * FROM media_projects WHERE id=? AND user_id=?',(pid,uid)).fetchone()
        if not r:raise KeyError('Media project not found in this account.')
        return dict(r)
    def projects(self,uid,cid=None):
        if cid:self.conversation(uid,cid)
        with self.connect() as c:
            return [dict(r) for r in c.execute('SELECT p.id,p.title,p.conversation_id,p.created,COUNT(a.id) versions FROM media_projects p LEFT JOIN media_assets a ON a.project_id=p.id WHERE p.user_id=?'+(' AND p.conversation_id=?' if cid else '')+' GROUP BY p.id ORDER BY p.created DESC LIMIT 100',(uid,cid) if cid else (uid,))]
    def asset(self,uid,aid):
        ident(aid)
        with self.connect() as c:r=c.execute('SELECT * FROM media_assets WHERE id=? AND user_id=?',(aid,uid)).fetchone()
        if not r:raise KeyError('Media version not found in this account.')
        d=dict(r);d['metadata']=json.loads(d['metadata']);d.pop('path');d.pop('user_id');d['url']='/api/media-tools/assets/'+aid;d['download_url']=d['url']+'?download=1';return d
    def asset_path(self,uid,aid):
        self.asset(uid,aid)
        with self.connect() as c:r=c.execute('SELECT path FROM media_assets WHERE id=? AND user_id=?',(aid,uid)).fetchone()
        p=self.root/r[0]
        if not p.is_file() or not p.resolve().is_relative_to(self.root.resolve()):raise KeyError('Media file is unavailable.')
        return p
    def versions(self,uid,pid):
        self.project(uid,pid)
        with self.connect() as c:ids=[r[0] for r in c.execute('SELECT id FROM media_assets WHERE project_id=? AND user_id=? ORDER BY version DESC LIMIT 200',(pid,uid))]
        return [self.asset(uid,x) for x in reversed(ids)]
    def upload(self,uid,rid,cid):
        ident(rid)
        with self.connect() as c:r=c.execute('SELECT * FROM large_uploads WHERE id=? AND user_id=? AND state=?',(rid,uid,'ready')).fetchone()
        if not r:raise KeyError('Complete an authorised upload in this account first.')
        if r['conversation_id']!=cid:raise ValueError('Select uploads belonging to this conversation.')
        if not 0<r['size']<=MAX_BYTES:raise ValueError('Use a non-empty upload up to 200 MB.')
        p=self.data/'uploads'/rid/'original'
        if not p.is_file() or p.stat().st_size!=r['size'] or digest(p)!=r['sha256']:raise ValueError('Upload integrity verification failed. Upload the original again.')
        return dict(r),p
    def import_upload(self,uid,cid,rid,pid):
        row,source=self.upload(uid,rid,cid)
        with self.connect() as c:old=c.execute('SELECT id FROM media_assets WHERE project_id=? AND origin_upload=? AND user_id=?',(pid,rid,uid)).fetchone()
        if old:return self.asset(uid,old[0])
        aid=token();relative=Path('assets')/aid/'original';p=self.root/relative;p.parent.mkdir(parents=True,mode=0o700)
        try:
            shutil.copyfile(source,p);p.chmod(0o600)
            with self.connect() as c:
                c.execute('BEGIN IMMEDIATE');self._quota(c,uid,row['size'])
                version=c.execute('SELECT coalesce(max(version),0)+1 FROM media_assets WHERE project_id=?',(pid,)).fetchone()[0]
                c.execute('INSERT INTO media_assets VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(aid,uid,pid,version,Path(row['name']).name,str(relative),row['sha256'],row['size'],rid,None,None,json.dumps({'original':True}),time.time()))
        except BaseException:shutil.rmtree(p.parent,ignore_errors=True);raise
        return self.asset(uid,aid)
    def _quota(self,c,uid,extra):
        used=c.execute('SELECT coalesce(sum(size),0) FROM media_assets WHERE user_id=?',(uid,)).fetchone()[0]
        reserved=c.execute("SELECT count(*) FROM media_jobs WHERE user_id=? AND state IN ('queued','running','cancelling')",(uid,)).fetchone()[0]*MAX_BYTES
        if used+reserved+extra>1024*1024*1024:raise ValueError('Media storage is full. Delete an unused media project before continuing.')
    def submit(self,uid,d):
        from .schema import obj,text
        obj(d,('conversation_id','project_id','source_id','upload_ids','recipe','mode','request_id','title'),('conversation_id','recipe'))
        mode=d.get('mode','chat');self.allowed(uid,mode);cid=d['conversation_id'];self.conversation(uid,cid)
        recipe=validate(d['recipe']);rid=d.get('request_id') or token()
        if not isinstance(rid,str) or not 8<=len(rid)<=80 or not all(c.isalnum() or c in '-_' for c in rid):raise ValueError('Invalid request identifier.')
        with self.connect() as c:old=c.execute('SELECT * FROM media_jobs WHERE user_id=? AND request_id=?',(uid,rid)).fetchone()
        if old:
            if old['conversation_id']!=cid or old['mode']!=mode or json.loads(old['recipe'])!=recipe or (d.get('source_id') and d['source_id']!=old['source_id']) or any(x not in json.loads(old['inputs']) for x in d.get('upload_ids',[])):raise ValueError('This request ID belongs to different media settings. Use a new request ID.')
            return self.job(uid,old['id'])
        upload_ids=d.get('upload_ids',[])
        if not isinstance(upload_ids,list) or len(upload_ids)>5 or any(not isinstance(x,str) for x in upload_ids) or len(set(upload_ids))!=len(upload_ids):raise ValueError('Choose up to five uploaded media files.')
        for x in upload_ids+upload_references(recipe):self.upload(uid,x,cid)
        pid=d.get('project_id');source=d.get('source_id')
        if source:
            a=self.asset(uid,source)
            if pid and pid!=a['project_id']:raise ValueError('Source version belongs to a different project.')
            pid=a['project_id']
        if pid:
            project=self.project(uid,pid)
            if project['conversation_id']!=cid:raise ValueError('Open this media project’s conversation to edit it.')
        else:
            pid=token();title=text(d.get('title','Media project'),120)
            with self.connect() as c:
                c.execute('BEGIN IMMEDIATE')
                if c.execute('SELECT count(*) FROM media_projects WHERE user_id=?',(uid,)).fetchone()[0]>=200:raise ValueError('You have 200 media projects. Delete an unused project before creating another.')
                c.execute('INSERT INTO media_projects VALUES(?,?,?,?,?)',(pid,uid,cid,title,time.time()))
        # Every dependency is snapshotted as a private immutable asset before queueing.
        inputs={}
        for x in dict.fromkeys(upload_ids+upload_references(recipe)):inputs[x]=self.import_upload(uid,cid,x,pid)['id']
        if not source and upload_ids:source=inputs[upload_ids[0]]
        if not source and not(recipe['kind']=='ai' and recipe['operation']=='generate'):raise ValueError('Attach an image, video or audio file first.')
        jid=token();now=time.time()
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            # Race-safe retry idempotency, including independent MCP and HTTP requests.
            old=c.execute('SELECT id FROM media_jobs WHERE user_id=? AND request_id=?',(uid,rid)).fetchone()
            if old:return self.job(uid,old[0])
            if c.execute("SELECT count(*) FROM media_jobs WHERE state IN ('queued','running','cancelling')").fetchone()[0]>=20 or c.execute("SELECT count(*) FROM media_jobs WHERE user_id=? AND state IN ('queued','running','cancelling')",(uid,)).fetchone()[0]>=4:raise ValueError('Media processing is busy. Wait for a queued job to finish.')
            self._quota(c,uid,MAX_BYTES)
            if shutil.disk_usage(self.root).free<2*1024**3:raise ValueError('Server storage is temporarily full. Try later.')
            c.execute('INSERT INTO media_jobs(id,user_id,project_id,conversation_id,request_id,source_id,recipe,inputs,mode,state,stage,created,engine_version) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(jid,uid,pid,cid,rid,source,json.dumps(recipe),json.dumps(inputs),mode,'queued','Queued for media worker',now,VERSION))
            c.execute('INSERT INTO media_events(job_id,created,state,message) VALUES(?,?,?,?)',(jid,now,'queued','Validated recipe; originals preserved; engine '+VERSION))
        return self.job(uid,jid)
    def job(self,uid,jid):
        ident(jid)
        with self.connect() as c:
            r=c.execute('SELECT * FROM media_jobs WHERE id=? AND user_id=?',(jid,uid)).fetchone()
            if not r:raise KeyError('Media job not found in this account.')
            events=[dict(x) for x in c.execute('SELECT created,state,message FROM media_events WHERE job_id=? ORDER BY id DESC LIMIT 60',(jid,))][::-1]
        d=dict(r);d.pop('user_id');d.pop('inputs');d['recipe']=json.loads(d['recipe']);d['result']=json.loads(d['result']);d['events']=events;d['elapsed']=round((d['finished'] or time.time())-(d['started'] or d['created']),1);return d
    def jobs(self,uid,cid=None):
        if cid:self.conversation(uid,cid)
        with self.connect() as c:ids=[x[0] for x in c.execute('SELECT id FROM media_jobs WHERE user_id=?'+(' AND conversation_id=?' if cid else '')+' ORDER BY created DESC LIMIT 50',(uid,cid) if cid else (uid,))]
        return [self.job(uid,j) for j in ids]
    def latest_result(self,uid,cid):
        self.conversation(uid,cid)
        with self.connect() as c:
            row=c.execute("SELECT result FROM media_jobs WHERE user_id=? AND conversation_id=? AND state='succeeded' ORDER BY finished DESC LIMIT 1",(uid,cid)).fetchone()
        return json.loads(row[0]) if row else None
    def cancel(self,uid,jid):
        j=self.job(uid,jid)
        with self.connect() as c:
            if j['state']=='queued':c.execute("UPDATE media_jobs SET state='cancelled',stage='Cancelled before processing',finished=? WHERE id=? AND state='queued'",(time.time(),jid))
            else:c.execute("UPDATE media_jobs SET state='cancelling',stage='Stopping media process' WHERE id=? AND state='running'",(jid,))
        return self.job(uid,jid)
    def delete_project(self,uid,pid):
        self.project(uid,pid)
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute("SELECT 1 FROM media_jobs WHERE project_id=? AND state IN ('queued','running','cancelling')",(pid,)).fetchone():raise ValueError('Cancel active jobs and wait for them to stop before deleting this project.')
            assets=[r[0] for r in c.execute('SELECT id FROM media_assets WHERE project_id=?',(pid,))];jobs=[r[0] for r in c.execute('SELECT id FROM media_jobs WHERE project_id=?',(pid,))]
            c.execute('DELETE FROM media_events WHERE job_id IN (SELECT id FROM media_jobs WHERE project_id=?)',(pid,));c.execute('DELETE FROM media_jobs WHERE project_id=?',(pid,));c.execute('DELETE FROM media_assets WHERE project_id=?',(pid,));c.execute('DELETE FROM media_projects WHERE id=?',(pid,))
        for aid in assets:shutil.rmtree(self.root/'assets'/aid,ignore_errors=True)
        for jid in jobs:shutil.rmtree(self.root/'jobs'/jid,ignore_errors=True)
        return {'deleted':True,'original_uploads_preserved':True}
    def status(self):
        with self.connect() as c:
            beat=c.execute('SELECT updated FROM media_worker WHERE id=1').fetchone();queued=c.execute("SELECT count(*) FROM media_jobs WHERE state='queued'").fetchone()[0]
        return {'name':'SYNERGY MEDIA','version':VERSION,'worker_ready':bool(beat and time.time()-beat[0]<90),'queue_length':queued,'max_upload_bytes':MAX_BYTES,'video_export_seconds':120,'cpu_only':True,'ai_native_max_dimension':768}
