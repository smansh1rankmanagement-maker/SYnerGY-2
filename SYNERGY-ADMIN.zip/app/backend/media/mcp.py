"""SYNERGY MEDIA newline JSON-RPC MCP server. UID/mode are trusted host configuration."""
import argparse,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from media.schema import RECIPE_SCHEMA,obj
from media.store import Media
from media import VERSION
def schema(properties,required=()):return {'type':'object','properties':properties,'required':list(required),'additionalProperties':False}
ID={'type':'string','pattern':'^[a-f0-9]{32}$'}
TOOLS=[
 {'name':'media_submit','description':'Queue a validated image/video edit or local Diffusers request. Uses authorised uploads or a saved version. Preserves originals; returns a job ID.','inputSchema':schema({'conversation_id':ID,'project_id':ID,'source_id':ID,'upload_ids':{'type':'array','items':ID,'maxItems':5},'recipe':RECIPE_SCHEMA,'request_id':{'type':'string'},'title':{'type':'string','maxLength':120}},('conversation_id','recipe')),'annotations':{'readOnlyHint':False,'destructiveHint':False,'idempotentHint':False,'openWorldHint':False}},
 {'name':'media_job_status','description':'Read real progress, events, errors and verified download links for your job.','inputSchema':schema({'job_id':ID},('job_id',)),'annotations':{'readOnlyHint':True,'openWorldHint':False}},
 {'name':'media_cancel','description':'Cancel a queued job or terminate active processing. Originals remain unchanged.','inputSchema':schema({'job_id':ID},('job_id',)),'annotations':{'readOnlyHint':False,'destructiveHint':False,'idempotentHint':True,'openWorldHint':False}},
 {'name':'media_projects','description':'List your private media projects, optionally for this conversation.','inputSchema':schema({'conversation_id':ID}),'annotations':{'readOnlyHint':True,'openWorldHint':False}},
 {'name':'media_versions','description':'Read immutable versions, parents, measurements and download links for your project.','inputSchema':schema({'project_id':ID},('project_id',)),'annotations':{'readOnlyHint':True,'openWorldHint':False}}
]
def call(service,uid,mode,name,args):
    tool=next((x for x in TOOLS if x['name']==name),None)
    if not tool:raise ValueError('Unknown SYNERGY MEDIA tool.')
    obj(args,tool['inputSchema']['properties'],tool['inputSchema']['required']);service.allowed(uid,mode)
    if name=='media_submit':return service.submit(uid,{**args,'mode':mode})
    if name=='media_job_status':return service.job(uid,args['job_id'])
    if name=='media_cancel':return service.cancel(uid,args['job_id'])
    if name=='media_projects':return {'projects':service.projects(uid,args.get('conversation_id'))}
    return {'versions':service.versions(uid,args['project_id'])}
def main():
    p=argparse.ArgumentParser();p.add_argument('--data',required=True,type=Path);p.add_argument('--user',required=True,type=int);p.add_argument('--mode',choices=['chat','work','beast'],default='chat');a=p.parse_args()
    from membership import Membership
    m=Media(a.data,Membership(a.data/'accounts.sqlite3').require);ready=False;initial=False
    while True:
        raw=sys.stdin.buffer.readline(65537)
        if not raw:break
        q={}
        try:
            if len(raw)>65536:raise ValueError('MCP request exceeds 64 KB.')
            q=json.loads(raw)
            if not isinstance(q,dict) or q.get('jsonrpc')!='2.0':raise ValueError('Invalid JSON-RPC request.')
            method=q.get('method');params=q.get('params',{})
            if not isinstance(params,dict):raise ValueError('Invalid params.')
            if method=='initialize':initial=True;out={'protocolVersion':'2024-11-05','capabilities':{'tools':{'listChanged':False}},'serverInfo':{'name':'SYNERGY MEDIA','version':VERSION}}
            elif method=='notifications/initialized':ready=initial;continue
            elif method=='ping':out={}
            elif not ready:raise ValueError('Initialize the session first.')
            elif method=='tools/list':out={'tools':TOOLS}
            elif method=='tools/call':
                try:
                    result=call(m,a.user,a.mode,params.get('name'),params.get('arguments',{}));out={'content':[{'type':'text','text':json.dumps(result)}],'structuredContent':result,'isError':False}
                except (ValueError,KeyError,PermissionError) as e:out={'content':[{'type':'text','text':str(e)}],'isError':True}
            elif isinstance(method,str) and method.startswith('notifications/'):continue
            else:raise ValueError('Unsupported MCP method.')
            if 'id' in q:print(json.dumps({'jsonrpc':'2.0','id':q['id'],'result':out}),flush=True)
        except Exception as e:print(json.dumps({'jsonrpc':'2.0','id':q.get('id') if isinstance(q,dict) else None,'error':{'code':-32602,'message':str(e)[:200]}}),flush=True)
if __name__=='__main__':main()
