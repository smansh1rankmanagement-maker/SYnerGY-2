"""Isolated media process. Consumes only a validated job folder, never user commands."""
import json,math,os,subprocess,sys,time,warnings
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from media.schema import validate,MAX_BYTES,MAX_SECONDS
from media.store import atomic,digest
from PIL import Image,ImageOps,ImageDraw,ImageFont,ImageEnhance
Image.MAX_IMAGE_PIXELS=24_000_000
warnings.simplefilter('error',Image.DecompressionBombWarning)
FORMATS='mov,matroska,avi,mp3,wav,flac,ogg,aac,ac3'
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'

def image(path):
    with Image.open(path) as im:
        if im.format not in {'PNG','JPEG','WEBP','GIF','TIFF','BMP'} or im.width*im.height>24_000_000 or max(im.size)>8192:raise ValueError('Use a supported image under 24 megapixels.')
        if getattr(im,'n_frames',1)>1:raise ValueError('Animated/multipage images need individual frame selection; they are not flattened silently.')
        im.load();return ImageOps.exif_transpose(im).convert('RGBA')

def probe(path):
    r=subprocess.run(['ffprobe','-v','error','-protocol_whitelist','file,pipe','-format_whitelist',FORMATS,'-show_format','-show_streams','-of','json',str(path)],capture_output=True,timeout=20)
    if r.returncode or len(r.stdout)>512000:raise ValueError('FFprobe could not read this supported media container.')
    d=json.loads(r.stdout);streams=d.get('streams',[])
    duration=float(d.get('format',{}).get('duration') or 0)
    if not math.isfinite(duration) or not .01<=duration<=600 or len(streams)>8:raise ValueError('Source media must be at most 10 minutes with at most eight streams.')
    video=next((s for s in streams if s.get('codec_type')=='video' and not s.get('disposition',{}).get('attached_pic')),None)
    audio=next((s for s in streams if s.get('codec_type')=='audio'),None)
    if video:
        w=video.get('width',0);h=video.get('height',0)
        if not 1<=w<=4096 or not 1<=h<=4096 or w*h>8_847_360:raise ValueError('Video source exceeds 4K processing dimensions.')
        num,den=map(float,video.get('avg_frame_rate','0/1').split('/'));fps=num/den if den else 0
        if not 0<fps<=120:raise ValueError('Unsupported source frame rate.')
    return {'duration':duration,'video':video,'audio':audio,'format':d.get('format',{}).get('format_name')}

class Processor:
    def __init__(self,folder):
        self.folder=Path(folder).resolve();self.data=json.loads((self.folder/'input.json').read_text());self.recipe=validate(self.data['recipe']);self.started=time.monotonic()
        self.source=self.path(self.data['source']) if self.data.get('source') else None
        self.inputs={k:self.path(v) for k,v in self.data.get('inputs',{}).items()}
    def path(self,name):
        p=(self.folder/name).resolve()
        if not p.is_relative_to(self.folder) or not p.is_file() or p.stat().st_size>MAX_BYTES:raise ValueError('Invalid private input snapshot.')
        return p
    def progress(self,stage,value=0):atomic(self.folder/'progress.json',{'stage':stage,'progress':min(.99,max(0,value)),'elapsed':round(time.monotonic()-self.started,1)})
    def ffmpeg(self,args,stage,duration,base=0,span=.8):
        self.progress(stage,base)
        with (self.folder/'ffmpeg.log').open('w') as err:
            p=subprocess.Popen(['ffmpeg','-hide_banner','-nostdin','-loglevel','error','-y','-threads','2','-filter_threads','2','-filter_complex_threads','2','-progress','pipe:1','-nostats',*args],cwd=self.folder,stdout=subprocess.PIPE,stderr=err,text=True)
            for line in p.stdout:
                if line.startswith('out_time_us='):
                    try:self.progress(stage,base+span*min(1,float(line.split('=')[1])/1e6/max(duration,.1)))
                    except ValueError:pass
            if p.wait():raise ValueError('Media encoding failed. Check the selected files, time range and recipe; originals are unchanged.')
    def read_args(self,p):return ['-protocol_whitelist','file,pipe','-format_whitelist',FORMATS,'-i',str(p)]
    def image_edit(self):
        im=image(self.source);checks=[]
        for i,op in enumerate(self.recipe['operations']):
            self.progress('Image · '+op['op'],.1+.7*i/len(self.recipe['operations']));kind=op['op']
            if kind=='resize':
                size=op['width'],op['height'];fit=op['fit']
                im=im.resize(size,Image.Resampling.LANCZOS) if fit=='stretch' else ImageOps.fit(im,size,method=Image.Resampling.LANCZOS) if fit=='cover' else ImageOps.pad(im,size,method=Image.Resampling.LANCZOS,color=(255,255,255,0))
            elif kind=='crop':
                box=op['x'],op['y'],op['x']+op['width'],op['y']+op['height']
                if box[2]>im.width or box[3]>im.height:raise ValueError('Crop extends outside the source image.')
                im=im.crop(box)
            elif kind=='rotate':im=im.rotate(-op['angle'],expand=True)
            elif kind=='adjust':
                for key,klass in [('brightness',ImageEnhance.Brightness),('contrast',ImageEnhance.Contrast),('sharpness',ImageEnhance.Sharpness)]:im=klass(im).enhance(op[key])
            elif kind=='text':
                draw=ImageDraw.Draw(im);font=ImageFont.truetype(FONT,op['size']);box=draw.multiline_textbbox((op['x'],op['y']),op['text'],font=font)
                if box[2]>im.width or box[3]>im.height:raise ValueError('Text would clip outside the image. Reduce its size or move it.')
                draw.multiline_text((op['x'],op['y']),op['text'],font=font,fill=op['colour']);checks.append('Exact text rendered with DejaVu Sans; review complex-script shaping visually.')
            elif kind=='logo':
                logo=image(self.inputs[op['upload_id']]);h=max(1,round(logo.height*op['width']/logo.width));logo=logo.resize((op['width'],h),Image.Resampling.LANCZOS)
                if op['x']+logo.width>im.width or op['y']+logo.height>im.height:raise ValueError('Logo would extend outside the canvas.')
                logo.putalpha(logo.getchannel('A').point(lambda a:round(a*op['opacity'])));im.alpha_composite(logo,(op['x'],op['y']));checks.append('Supplied logo used; no redrawing.')
        if max(im.size)>4096:raise ValueError('Resize the export to at most 4096 pixels per dimension before saving.')
        fmt=self.recipe['format'];out=self.folder/('output.'+('jpg' if fmt=='jpeg' else fmt))
        if fmt=='jpeg':background=Image.new('RGB',im.size,'white');background.paste(im,mask=im.getchannel('A'));im=background
        im.save(out,format=fmt.upper(),**({'quality':94} if fmt in {'jpeg','webp'} else {}))
        return out,{'engine':'Pillow','dimensions':list(im.size),'checks':checks,'analysis':self.image_analysis(out)}
    def image_analysis(self,path):
        import cv2,numpy as np
        cv2.setNumThreads(2)
        im=image(path);small=ImageOps.contain(im,(1024,1024));gray=cv2.cvtColor(np.array(small.convert('RGB')),cv2.COLOR_RGB2GRAY)
        return {'width':im.width,'height':im.height,'mean_luminance':round(float(gray.mean()),2),'laplacian_variance':round(float(cv2.Laplacian(gray,cv2.CV_64F).var()),2),'component':'OpenCV','note':'Measured brightness and edge contrast; not a subjective quality score.'}
    def captions(self,cues,size,w,h,duration):
        def stamp(n):return f'{int(n//3600)}:{int(n//60)%60:02}:{n%60:05.2f}'
        lines=['[Script Info]','ScriptType: v4.00+',f'PlayResX: {w}',f'PlayResY: {h}','[V4+ Styles]','Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding',f'Style: Default,DejaVu Sans,{size},&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,2,0,2,20,20,20,1','[Events]','Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text']
        for cue in cues:
            if cue['end']>duration+.05:raise ValueError('Caption timing extends beyond the edited video.')
            # Literal supplied text cannot inject ASS drawing/position commands.
            t=cue['text'].replace('\\','＼').replace('{','｛').replace('}','｝').replace('\n',r'\N')
            lines.append(f"Dialogue: 0,{stamp(cue['start'])},{stamp(cue['end'])},Default,,0,0,0,,{t}")
        (self.folder/'captions.ass').write_text('\n'.join(lines),encoding='utf-8')
    def video_edit(self):
        src=probe(self.source)
        if not src['video']:raise ValueError('Choose a video as the primary source.')
        ops={o['op']:o for o in self.recipe['operations']};trim=ops.get('trim',{});start=trim.get('start',0);end=trim.get('end',src['duration'])
        if end>src['duration']+.05:raise ValueError('Trim endpoint extends beyond the source duration.')
        clips=[(self.source,src,start,end-start)]+[(self.inputs[x],probe(self.inputs[x]),0,None) for x in ops.get('join',{}).get('upload_ids',[])]
        total=sum(d if d is not None else m['duration'] for _,m,_,d in clips)
        if total>MAX_SECONDS+.05:raise ValueError('The edited video exceeds 120 seconds. Trim it or use shorter clips.')
        comp=ops.get('compress',{});w=min(comp.get('width',1280),src['video']['width']);w=max(2,w//2*2);h=max(2,round(src['video']['height']*w/src['video']['width']/2)*2);fps=comp.get('fps',30);crf=comp.get('crf',23)
        if max(w,h)>1920:
            scale=1920/max(w,h);w=max(2,int(w*scale)//2*2);h=max(2,int(h*scale)//2*2)
        normalized=[];elapsed=0
        for i,(p,info,seek,duration) in enumerate(clips):
            if not info['video']:raise ValueError('All joined inputs must contain video.')
            duration=duration or info['duration'];part=self.folder/f'part-{i}.mp4';args=self.read_args(p)
            if not info['audio']:args+=['-f','lavfi','-i','anullsrc=r=48000:cl=stereo']
            args+=['-ss',str(seek),'-t',str(duration),'-map','0:v:0','-map','0:a:0' if info['audio'] else '1:a:0','-vf',f'scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps}','-af','aresample=48000','-c:v','libx264','-preset','veryfast','-crf',str(crf),'-pix_fmt','yuv420p','-threads','2','-c:a','aac','-b:a','128k','-ac','2','-map_metadata','-1','-sn','-dn','-movflags','+faststart',str(part)]
            self.ffmpeg(args,f'Encoding clip {i+1} of {len(clips)}',duration,.05+.5*elapsed/total,.5*duration/total);elapsed+=duration;normalized.append(part)
        base=normalized[0]
        if len(normalized)>1:
            # Generated concat entries name only internal files, never caller paths.
            (self.folder/'concat.txt').write_text('\n'.join("file '"+p.name+"'" for p in normalized))
            base=self.folder/'joined.mp4';self.ffmpeg(['-f','concat','-safe','1','-protocol_whitelist','file,pipe','-i','concat.txt','-c','copy','-t',str(total),str(base)],'Joining clips',total,.55,.08)
        out=self.folder/'output.mp4';args=self.read_args(base);filters=[]
        if 'captions' in ops:
            cap=ops['captions'];self.captions(cap['cues'],cap['size'],w,h,total);filters.append('subtitles=captions.ass')
        if 'audio' in ops:
            mix=ops['audio'];p=self.inputs[mix['upload_id']];aud=probe(p)
            if not aud['audio']:raise ValueError('The selected soundtrack has no audio stream.')
            if mix['offset']>=total:raise ValueError('Audio offset is outside this video.')
            args+=self.read_args(p)
            graph=f"[0:a]volume={mix['original_volume']}[original];[1:a]volume={mix['volume']},adelay={round(mix['offset']*1000)}:all=1[added];[original][added]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[mix]"
            args+=['-filter_complex',graph,'-map','0:v:0','-map','[mix]','-c:a','aac','-b:a','128k']
        else:args+=['-map','0:v:0','-map','0:a:0','-c:a','copy']
        if filters:args+=['-vf',','.join(filters),'-c:v','libx264','-preset','veryfast','-crf',str(crf),'-pix_fmt','yuv420p','-threads','2']
        else:args+=['-c:v','copy']
        args+=['-map_metadata','-1','-sn','-dn','-t',str(total),'-movflags','+faststart',str(out)]
        self.ffmpeg(args,'Applying captions and audio' if filters or 'audio' in ops else 'Finalising export',total,.65,.2)
        info=probe(out)
        if abs(info['duration']-total)>.2:raise ValueError('Export duration verification failed.')
        self.ffmpeg(self.read_args(out)+['-map','0:v:0','-map','0:a:0?','-f','null','-'],'Verifying video and audio decoding',total,.86,.08)
        self.video_frames(out,info)
        return out,{'engine':'FFmpeg/FFprobe + OpenCV','duration':info['duration'],'width':w,'height':h,'fps':fps,'audio':bool(info['audio']),'input_bytes':self.source.stat().st_size,'output_bytes':out.stat().st_size,'compression_ratio':round(out.stat().st_size/self.source.stat().st_size,3),'note':'Compression size depends on source codec and content. Captions use supplied text; no transcription was inferred.'}
    def video_frames(self,path,info):
        import cv2
        cv2.setNumThreads(2);cap=cv2.VideoCapture(str(path));frames=[]
        try:
            for i in range(4):
                cap.set(cv2.CAP_PROP_POS_MSEC,info['duration']*1000*(i+.25)/4);ok,bgr=cap.read()
                if ok:frames.append(ImageOps.pad(Image.fromarray(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)),(320,180),color='black'))
        finally:cap.release()
        if not frames:raise ValueError('OpenCV could not decode the exported frames.')
        sheet=Image.new('RGB',(640,360),'black')
        for i,frame in enumerate(frames):sheet.paste(frame,((i%2)*320,(i//2)*180))
        sheet.save(self.folder/'preview.jpg',quality=88)
        return len(frames)
    def analyze(self):
        try:result=self.image_analysis(self.source)
        except (OSError,Image.UnidentifiedImageError):
            info=probe(self.source);result={'engine':'FFprobe','duration':info['duration'],'has_audio':bool(info['audio']),'has_video':bool(info['video'])}
            if info['video']:result['sampled_frames']=self.video_frames(self.source,info);result['width']=info['video']['width'];result['height']=info['video']['height']
        out=self.folder/'analysis.json';atomic(out,result);return out,result
    def ai(self):
        import torch
        from diffusers import StableDiffusionPipeline,StableDiffusionImg2ImgPipeline,StableDiffusionInpaintPipeline,LCMScheduler,DPMSolverMultistepScheduler
        s=self.recipe;op=s['operation'];self.progress('Loading local Diffusers model',.03)
        torch.set_num_threads(2);torch.set_num_interop_threads(1)
        model=Path(os.environ.get('SYNERGY_MEDIA_MODEL','/models/epicrealism'));adapter=Path(os.environ.get('SYNERGY_LCM_ADAPTER','/models/lcm'))
        if not(model/'model_index.json').is_file():raise ValueError('Local image weights are unavailable. No hosted generation service was substituted.')
        klass={'generate':StableDiffusionPipeline,'img2img':StableDiffusionImg2ImgPipeline,'inpaint':StableDiffusionInpaintPipeline}[op]
        pipe=klass.from_pretrained(str(model),torch_dtype=torch.float32,use_safetensors=True,local_files_only=True)
        if pipe.safety_checker is None:raise ValueError('The local model safety checker is unavailable.')
        pipe.to('cpu');pipe.enable_attention_slicing();pipe.enable_vae_slicing();pipe.set_progress_bar_config(disable=True)
        fast=s['steps']<=12
        if fast:
            if not(adapter/'verified.json').is_file():raise ValueError('The verified local LCM adapter is unavailable.')
            pipe.load_lora_weights(str(adapter),weight_name='pytorch_lora_weights.safetensors',local_files_only=True);pipe.fuse_lora();pipe.scheduler=LCMScheduler.from_config(pipe.scheduler.config)
        else:pipe.scheduler=DPMSolverMultistepScheduler.from_config(pipe.scheduler.config,use_karras_sigmas=True)
        size=s['width'],s['height'];extra={};ref=None;mask=None
        if op!='generate':
            ref=ImageOps.fit(image(self.source).convert('RGB'),size,method=Image.Resampling.LANCZOS);extra.update(image=ref,strength=s['strength'])
        if op=='inpaint':
            mask=image(self.inputs[s['mask_upload_id']]).convert('L').resize(size,Image.Resampling.NEAREST)
            if not mask.getbbox():raise ValueError('The mask is empty. White pixels mark the area to edit.')
            extra['mask_image']=mask
        if op in {'generate','inpaint'}:extra.update(width=size[0],height=size[1])
        total=max(1,int(s['steps']*s['strength'])) if op!='generate' else s['steps']
        def step(pipeline,i,t,kwargs):self.progress('Diffusers · '+op+f' · step {i+1}/{total}',.12+.68*(i+1)/total);return kwargs
        with torch.inference_mode():r=pipe(prompt=s['prompt'],negative_prompt=s['negative'],num_inference_steps=s['steps'],guidance_scale=1.5 if fast else 7,generator=torch.Generator('cpu').manual_seed(s['seed']),callback_on_step_end=step,**extra)
        if r.nsfw_content_detected and any(r.nsfw_content_detected):raise ValueError('The image safety check blocked this output. Revise the brief.')
        im=r.images[0]
        if mask is not None:im=Image.composite(im,ref,mask)
        out=self.folder/'output.png';im.save(out)
        return out,{'engine':klass.__name__,'package':'diffusers','package_version':'0.30.3','model':'emilianJR/epiCRealism','revision':'6522cf856b8c8e14638a0aaa7bd89b1b098aed17','adapter':'latent-consistency/lcm-lora-sdv1-5' if fast else None,'scheduler':pipe.scheduler.__class__.__name__,'device':'cpu','native_dimensions':list(size),'steps':s['steps'],'seed':s['seed'],'mask_protected_pixels_exact':mask is not None,'note':'Existing SD1.5 four-channel weights; selective editing uses Diffusers inpainting with protected-pixel compositing. This is inference, not training. Face/body identity and subjective quality require visual review.','analysis':self.image_analysis(out)}
    def run(self):
        self.progress('Validating media input',.01)
        kind=self.recipe['kind']
        if kind=='ai':
            from media_compute import inference_slot
            with inference_slot(self.folder):out,meta=self.ai()
        else:out,meta={'image':self.image_edit,'video':self.video_edit,'analyze':self.analyze}[kind]()
        if not out.is_file() or not 0<out.stat().st_size<=MAX_BYTES:raise ValueError('Export exceeds the 200 MB output limit.')
        if kind in {'image','ai'}:
            with Image.open(out) as im:im.verify()
            thumb=ImageOps.contain(image(out).convert('RGB'),(960,720));thumb.save(self.folder/'preview.jpg',quality=88)
        self.progress('Saving verified output',.98)
        atomic(self.folder/'result.json',{'file':out.name,'sha256':digest(out),'size':out.stat().st_size,'metadata':meta,'seconds':round(time.monotonic()-self.started,2)})

def main():
    import resource
    os.umask(0o077);resource.setrlimit(resource.RLIMIT_FSIZE,(MAX_BYTES,MAX_BYTES));resource.setrlimit(resource.RLIMIT_NOFILE,(128,128))
    resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    folder=Path(sys.argv[1])
    try:Processor(folder).run()
    except Exception as e:
        atomic(folder/'error.json',{'error':str(e)[:400]});raise
if __name__=='__main__':main()
