"""Closed recipe language. No expressions, host paths, URLs or encoder arguments."""
import math,re

MAX_BYTES=200*1024*1024
MAX_SECONDS=120
FORMATS={'png','jpeg','webp'}
def obj(value,allowed,required=()):
    if not isinstance(value,dict) or set(value)-set(allowed) or set(required)-set(value):
        raise ValueError('Recipe contains missing or unsupported fields: '+', '.join(required))
    return value
def number(v,lo,hi,integer=False):
    if type(v) not in (int,float) or not math.isfinite(v) or not lo<=v<=hi or (integer and type(v) is not int):
        raise ValueError(f'Expected {"an integer" if integer else "a number"} from {lo} to {hi}.')
    return v
def text(v,maximum=1000):
    if not isinstance(v,str) or not v.strip() or len(v)>maximum or any(ord(c)<32 and c not in '\n\t' for c in v):
        raise ValueError('Text is empty, too long or contains control characters.')
    return v
def ident(v):
    if not isinstance(v,str) or not re.fullmatch('[a-f0-9]{32}',v):raise ValueError('Choose a saved media identifier.')
    return v
def colour(v):
    if not isinstance(v,str) or not re.fullmatch('#[a-fA-F0-9]{6}',v):raise ValueError('Use a six-digit hex colour.')
    return v
def validate(value):
    s=obj(value,('kind','operations','format','operation','prompt','negative','width','height','seed','steps','strength','mask_upload_id'),('kind',))
    kind=s['kind']
    if kind=='analyze':
        obj(s,('kind',));return {'kind':kind}
    if kind=='ai':
        obj(s,('kind','operation','prompt','negative','width','height','seed','steps','strength','mask_upload_id'),('kind','operation','prompt'))
        op=s['operation']
        if op not in {'generate','img2img','inpaint'}:raise ValueError('Choose generate, img2img or inpaint.')
        out={'kind':kind,'operation':op,'prompt':text(s['prompt'],2000),'negative':text(s.get('negative','blur, watermark, distorted details'),1000),'width':number(s.get('width',512),256,768,True),'height':number(s.get('height',512),256,768,True),'seed':number(s.get('seed',42),0,2147483647,True),'steps':number(s.get('steps',20 if op=='inpaint' else 8),20 if op=='inpaint' else 4,32,True),'strength':number(s.get('strength',.65),.25,1)}
        if out['width']%8 or out['height']%8:raise ValueError('AI dimensions must be multiples of eight.')
        if op=='inpaint':out['mask_upload_id']=ident(s.get('mask_upload_id'))
        elif 'mask_upload_id' in s:raise ValueError('Masks require the inpaint operation.')
        return out
    if kind not in {'image','video'}:raise ValueError('Choose image, video, ai or analyze.')
    obj(s,('kind','operations','format'),('kind','operations'))
    ops=s['operations']
    if not isinstance(ops,list) or not 1<=len(ops)<=12:raise ValueError('Use one to twelve edit operations.')
    out={'kind':kind,'operations':[],'format':s.get('format','png' if kind=='image' else 'mp4')}
    if out['format'] not in (FORMATS if kind=='image' else {'mp4'}):raise ValueError('Unsupported export format.')
    seen=set()
    for raw in ops:
        if not isinstance(raw,dict):raise ValueError('Invalid operation.')
        op=raw.get('op');r={'op':op}
        if kind=='image':
            if op=='resize':
                obj(raw,('op','width','height','fit'),('width','height'));r.update(width=number(raw['width'],16,4096,True),height=number(raw['height'],16,4096,True),fit=raw.get('fit','contain'))
                if r['fit'] not in {'contain','cover','stretch'}:raise ValueError('Choose contain, cover or stretch.')
            elif op=='crop':
                obj(raw,('op','x','y','width','height'),('x','y','width','height'))
                r.update({k:number(raw[k],0 if k in {'x','y'} else 1,8192,True) for k in ['x','y','width','height']})
            elif op=='rotate':
                obj(raw,('op','angle'),('angle',));r['angle']=number(raw['angle'],-270,270,True)
                if r['angle'] not in {-270,-180,-90,90,180,270}:raise ValueError('Use a right-angle rotation.')
            elif op=='adjust':
                obj(raw,('op','brightness','contrast','sharpness'));r.update({k:number(raw.get(k,1),0,3) for k in ['brightness','contrast','sharpness']})
            elif op=='text':
                obj(raw,('op','text','x','y','size','colour'),('text',));r.update(text=text(raw['text'],500),x=number(raw.get('x',24),0,4096,True),y=number(raw.get('y',24),0,4096,True),size=number(raw.get('size',40),8,256,True),colour=colour(raw.get('colour','#FFFFFF')))
            elif op=='logo':
                obj(raw,('op','upload_id','x','y','width','opacity'),('upload_id',));r.update(upload_id=ident(raw['upload_id']),x=number(raw.get('x',24),0,4096,True),y=number(raw.get('y',24),0,4096,True),width=number(raw.get('width',160),8,2048,True),opacity=number(raw.get('opacity',1),0,1))
            elif op=='convert':obj(raw,('op',))
            else:raise ValueError('Unsupported image operation.')
        else:
            if op in seen:raise ValueError('Use each video operation once.')
            seen.add(op)
            if op=='trim':
                obj(raw,('op','start','end'),('start','end'));r.update(start=number(raw['start'],0,600),end=number(raw['end'],.05,600))
                if not .05<=r['end']-r['start']<=MAX_SECONDS:raise ValueError('A trimmed clip must be 0.05–120 seconds.')
            elif op=='join':
                obj(raw,('op','upload_ids'),('upload_ids',));ids=raw['upload_ids']
                if not isinstance(ids,list) or not 1<=len(ids)<=4 or len(set(ids))!=len(ids):raise ValueError('Join one to four additional clips.')
                r['upload_ids']=[ident(x) for x in ids]
            elif op=='captions':
                obj(raw,('op','cues','size'),('cues',));cues=raw['cues']
                if not isinstance(cues,list) or not 1<=len(cues)<=100:raise ValueError('Supply one to 100 timed captions.')
                r['size']=number(raw.get('size',28),12,72,True);r['cues']=[];last=0
                for cue in cues:
                    obj(cue,('start','end','text'),('start','end','text'));start=number(cue['start'],0,MAX_SECONDS);end=number(cue['end'],.05,MAX_SECONDS)
                    if end<=start or start<last:raise ValueError('Captions must be ordered, non-overlapping intervals.')
                    last=end;r['cues'].append({'start':start,'end':end,'text':text(cue['text'],300)})
            elif op=='audio':
                obj(raw,('op','upload_id','volume','original_volume','offset'),('upload_id',));r.update(upload_id=ident(raw['upload_id']),volume=number(raw.get('volume',.5),0,2),original_volume=number(raw.get('original_volume',1),0,2),offset=number(raw.get('offset',0),0,MAX_SECONDS))
            elif op=='compress':
                obj(raw,('op','crf','width','fps'));r.update(crf=number(raw.get('crf',28),18,40,True),width=number(raw.get('width',1280),160,1920,True),fps=number(raw.get('fps',30),1,30,True))
                if r['width']%2:raise ValueError('Video export width must be even.')
            else:raise ValueError('Unsupported video operation.')
        out['operations'].append(r)
    return out

def upload_references(recipe):
    ids=[]
    if recipe.get('mask_upload_id'):ids.append(recipe['mask_upload_id'])
    for o in recipe.get('operations',[]):
        ids.extend(o.get('upload_ids',[]))
        if o.get('upload_id'):ids.append(o['upload_id'])
    return list(dict.fromkeys(ids))

RECIPE_SCHEMA={'type':'object','description':'Validated edit recipe. kind=image: resize/crop/rotate/adjust/text/logo/convert; kind=video: trim/join/captions/audio/compress; kind=ai: generate/img2img/inpaint; kind=analyze. All processing is bounded; input paths and commands are forbidden.','properties':{'kind':{'enum':['image','video','ai','analyze']},'operations':{'type':'array','maxItems':12,'items':{'type':'object'}},'format':{'enum':['png','jpeg','webp','mp4']},'operation':{'enum':['generate','img2img','inpaint']},'prompt':{'type':'string','maxLength':2000},'negative':{'type':'string','maxLength':1000},'width':{'type':'integer'},'height':{'type':'integer'},'seed':{'type':'integer'},'steps':{'type':'integer'},'strength':{'type':'number'},'mask_upload_id':{'type':'string'}},'required':['kind'],'additionalProperties':False}
