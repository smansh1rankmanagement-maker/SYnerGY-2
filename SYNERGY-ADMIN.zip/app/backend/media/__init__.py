"""SYNERGY MEDIA: validated recipes, private assets and durable processing."""
VERSION = '1.0.0'
