"""Single durable worker; restart recovery, bounded subprocesses and cancellation."""
import argparse,fcntl,json,os,shutil,signal,subprocess,sys,threading,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from media.store import Media,atomic,digest,token
from media.schema import MAX_BYTES
from media import VERSION

class Worker:
    def __init__(self,media,python=None):self.m=media;self.python=python or os.environ.get('SYNERGY_IMAGE_PYTHON',sys.executable);self.stop=threading.Event();self.process=None
    def heartbeat(self):
        with self.m.connect() as c:c.execute('INSERT OR REPLACE INTO media_worker VALUES(1,?)',(time.time(),))
    def event(self,jid,state,message):
        with self.m.connect() as c:c.execute('INSERT INTO media_events(job_id,created,state,message) VALUES(?,?,?,?)',(jid,time.time(),state,message))
    def recover(self):
        with self.m.connect() as c:
            for j in c.execute("SELECT * FROM media_jobs WHERE state IN ('running','cancelling')").fetchall():
                state='cancelled' if j['state']=='cancelling' else 'queued' if j['attempt']<2 else 'failed'
                message='Recovered after worker restart; original and pinned recipe preserved.' if state=='queued' else 'Stopped after restart. Retry the saved recipe.'
                c.execute('UPDATE media_jobs SET state=?,stage=?,finished=?,error=? WHERE id=?',(state,message,None if state=='queued' else time.time(),message if state=='failed' else None,j['id']))
                c.execute('INSERT INTO media_events(job_id,created,state,message) VALUES(?,?,?,?)',(j['id'],time.time(),state,message))
    def claim(self):
        with self.m.connect() as c:
            c.execute('BEGIN IMMEDIATE');r=c.execute("SELECT * FROM media_jobs WHERE state='queued' ORDER BY created LIMIT 1").fetchone()
            if not r:return None
            c.execute("UPDATE media_jobs SET state='running',stage='Starting media processor',started=?,attempt=attempt+1,progress=0,error=NULL WHERE id=?",(time.time(),r['id']))
            return dict(r)
    def terminate(self):
        p=self.process
        if p and p.poll() is None:
            try:os.killpg(p.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:p.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                p.wait(timeout=3)
    def execute(self,j):
        jid=j['id'];uid=j['user_id'];folder=self.m.root/'jobs'/jid;folder.mkdir(parents=True,exist_ok=True,mode=0o700)
        stage='';last_beat=0;last_access=0;started=time.monotonic();state='failed';error=None
        try:
            if j['engine_version']!=VERSION:raise ValueError('This job pins a different media engine version. Re-submit its recipe after reviewing the upgrade.')
            self.m.allowed(uid,j['mode']);self.m.conversation(uid,j['conversation_id'])
            # The processor receives copies only; it never writes stored originals.
            inputs={};source=None
            def snapshot(aid):
                original=self.m.asset_path(uid,aid);a=self.m.asset(uid,aid)
                if digest(original)!=a['sha256']:raise ValueError('A saved input failed integrity verification.')
                dst=folder/('input-'+aid)
                if dst.exists():
                    if digest(dst)==a['sha256']:return dst.name
                    dst.unlink()
                shutil.copyfile(original,dst);dst.chmod(0o400);return dst.name
            if j['source_id']:source=snapshot(j['source_id'])
            for key,aid in json.loads(j['inputs']).items():inputs[key]=snapshot(aid)
            recipe=json.loads(j['recipe'])
            for name in ['result.json','error.json','progress.json']:(folder/name).unlink(missing_ok=True)
            atomic(folder/'input.json',{'recipe':recipe,'source':source,'inputs':inputs})
            env={'SYNERGY_DATA_DIR':str(self.m.data),'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':str(folder),'TMPDIR':str(folder),'PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_HUB_DISABLE_TELEMETRY':'1','DO_NOT_TRACK':'1','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','MKL_NUM_THREADS':'2','SYNERGY_MEDIA_MODEL':os.environ.get('SYNERGY_MEDIA_MODEL','/models/epicrealism'),'SYNERGY_LCM_ADAPTER':os.environ.get('SYNERGY_LCM_ADAPTER','/models/lcm')}
            timeout=1200 if recipe['kind']=='ai' else 600
            with (folder/'worker.log').open('w') as log:
                self.process=subprocess.Popen([self.python,str(Path(__file__).with_name('processor.py')),str(folder)],env=env,cwd=folder,stdout=log,stderr=log,start_new_session=True)
                while self.process.poll() is None:
                    current=self.m.job(uid,jid)
                    if self.stop.is_set():raise InterruptedError('Worker is restarting; saved job will resume.')
                    if current['state']=='cancelling':raise InterruptedError('Cancelled by you.')
                    if time.monotonic()-started>timeout:raise TimeoutError('Processing time limit reached. Try a shorter clip, smaller image or fewer AI steps.')
                    if time.monotonic()-last_beat>5:self.heartbeat();last_beat=time.monotonic()
                    if time.monotonic()-last_access>15:self.m.allowed(uid,j['mode']);last_access=time.monotonic()
                    try:
                        p=json.loads((folder/'progress.json').read_text());value=min(.99,max(0,float(p['progress'])));new=str(p['stage'])[:180]
                        with self.m.connect() as c:c.execute("UPDATE media_jobs SET stage=?,progress=? WHERE id=? AND state='running'",(new,value,jid))
                        if stage!=new:self.event(jid,'running',new);stage=new
                    except (FileNotFoundError,json.JSONDecodeError,KeyError):pass
                    self.stop.wait(.3)
            self.m.allowed(uid,j['mode'])
            if self.m.job(uid,jid)['state']=='cancelling':raise InterruptedError('Cancelled by you.')
            if self.process.returncode:
                message='The isolated media processor failed. Retry with a smaller or supported file.'
                if (folder/'error.json').exists():message=json.loads((folder/'error.json').read_text())['error']
                raise ValueError(message)
            result=json.loads((folder/'result.json').read_text());name=result['file']
            if name not in {'output.png','output.jpg','output.webp','output.mp4','analysis.json'}:raise ValueError('Unexpected export file.')
            output=folder/name
            if not output.is_file() or not 0<output.stat().st_size<=MAX_BYTES or output.stat().st_size!=result['size'] or digest(output)!=result['sha256']:raise ValueError('Export integrity verification failed.')
            aid=token();relative=Path('assets')/aid/name;destination=self.m.root/relative;destination.parent.mkdir(parents=True,mode=0o700);shutil.copyfile(output,destination);destination.chmod(0o600)
            if (folder/'preview.jpg').is_file():shutil.copyfile(folder/'preview.jpg',destination.parent/'preview.jpg')
            try:
                with self.m.connect() as c:
                    c.execute('BEGIN IMMEDIATE');row=c.execute('SELECT state FROM media_jobs WHERE id=?',(jid,)).fetchone()
                    if row['state']!='running':raise InterruptedError('Cancelled before saving.')
                    version=c.execute('SELECT coalesce(max(version),0)+1 FROM media_assets WHERE project_id=?',(j['project_id'],)).fetchone()[0]
                    c.execute('INSERT INTO media_assets VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(aid,uid,j['project_id'],version,name,str(relative),result['sha256'],result['size'],None,j['source_id'],jid,json.dumps(result['metadata']),time.time()))
                    result.update(asset_id=aid,project_id=j['project_id'],version=version,url='/api/media-tools/assets/'+aid,download_url='/api/media-tools/assets/'+aid+'?download=1',preview_url='/api/media-tools/assets/'+aid+'/preview')
                    c.execute("UPDATE media_jobs SET state='succeeded',stage='Complete · output verified',progress=1,finished=?,result=? WHERE id=?",(time.time(),json.dumps(result),jid))
            except BaseException:shutil.rmtree(destination.parent,ignore_errors=True);raise
            state='succeeded';self.event(jid,state,'Saved immutable version '+str(version)+'; output digest and decode checks passed.')
        except InterruptedError as e:
            self.terminate();state='queued' if self.stop.is_set() else 'cancelled';error=str(e)
        except Exception as e:self.terminate();state='failed';error=str(e)[:500]
        finally:
            self.terminate();self.process=None
            if state!='succeeded':
                with self.m.connect() as c:c.execute('UPDATE media_jobs SET state=?,stage=?,finished=?,error=? WHERE id=?',(state,error,None if state=='queued' else time.time(),error if state=='failed' else None,jid))
                self.event(jid,state,error or state)
            # Temporary copies, decoder logs and partial outputs are not retained.
            for p in folder.iterdir():
                if p.is_file():p.unlink(missing_ok=True)
            self.heartbeat()
        return self.m.job(uid,jid)
    def run(self):
        with (self.m.root/'worker.lock').open('a') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:raise SystemExit('A media worker already holds this data directory.')
            self.recover()
            while not self.stop.is_set():
                self.heartbeat();j=self.claim()
                if j:self.execute(j)
                else:self.stop.wait(1)

def main():
    p=argparse.ArgumentParser();p.add_argument('--data',required=True,type=Path);args=p.parse_args()
    from membership import Membership
    membership=Membership(args.data/'accounts.sqlite3');worker=Worker(Media(args.data,membership.require))
    for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,lambda *_:worker.stop.set())
    worker.run()
if __name__=='__main__':main()
