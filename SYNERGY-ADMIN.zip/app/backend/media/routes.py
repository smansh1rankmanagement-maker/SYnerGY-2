"""Authenticated media routes. Inline files support bounded byte ranges for video preview."""
import mimetypes,re
from urllib.parse import parse_qs,urlsplit,quote
from .mcp import call,TOOLS

class MediaHTTP:
    def media_tools_get(self,path,user):
        m=self.media;uid=user['id'];q=parse_qs(urlsplit(self.path).query)
        try:
            if path=='/api/media-tools':return self.response(200,{**m.status(),'tools':TOOLS,'projects':m.projects(uid)})
            if path=='/api/media-tools/jobs':return self.response(200,{'jobs':m.jobs(uid,q.get('conversation_id',[None])[0])})
            match=re.fullmatch(r'/api/media-tools/(jobs|projects|assets)/([a-f0-9]{32})(/preview)?',path)
            if not match:raise KeyError()
            kind,rid,preview=match.groups()
            if kind=='jobs':return self.response(200,m.job(uid,rid))
            if kind=='projects':return self.response(200,{'project':m.project(uid,rid),'versions':m.versions(uid,rid)})
            a=m.asset(uid,rid);p=m.asset_path(uid,rid);name=a['name'];mime=mimetypes.guess_type(name)[0] or 'application/octet-stream'
            if preview:p=p.parent/'preview.jpg';name='preview.jpg';mime='image/jpeg'
            if not p.is_file():raise KeyError()
            if q.get('download')==['1']:return self.research_download_path(p,name)
            if mime not in {'image/png','image/jpeg','image/webp','video/mp4','audio/mpeg','audio/wav','application/json'}:return self.research_download_path(p,name)
            size=p.stat().st_size;start=0;end=size-1;status=200;requested=self.headers.get('Range')
            if requested:
                r=re.fullmatch(r'bytes=(\d*)-(\d*)',requested)
                if not r or not any(r.groups()):return self.fail(416,'Unsupported byte range.')
                if r[1]:start=int(r[1]);end=min(end,int(r[2])) if r[2] else end
                else:start=max(0,size-int(r[2]))
                if start>end or start>=size:self.send_response(416);self.send_header('Content-Range',f'bytes */{size}');self.send_header('Content-Length','0');self.end_headers();return
                status=206
            self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(end-start+1));self.send_header('Accept-Ranges','bytes');self.send_header('Cache-Control','private, no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Disposition',"inline; filename*=UTF-8''"+quote(name))
            if status==206:self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
            self.end_headers()
            with p.open('rb') as f:
                f.seek(start);remaining=end-start+1
                while remaining:
                    b=f.read(min(256*1024,remaining))
                    if not b:break
                    self.wfile.write(b);remaining-=len(b)
        except (KeyError,FileNotFoundError):return self.fail(404,'Media not found in this account.')
        except (ValueError,TypeError) as e:return self.fail(400,str(e))
        except (BrokenPipeError,ConnectionResetError):return
    def media_tools_post(self,path,d,user):
        m=self.media;uid=user['id']
        try:
            if path=='/api/media-tools/call':result=call(m,uid,d.get('mode','chat'),d.get('tool'),d.get('arguments',{}))
            elif path=='/api/media-tools/submit':result=m.submit(uid,d)
            elif path=='/api/media-tools/cancel':result=m.cancel(uid,d.get('id'))
            elif path=='/api/media-tools/delete':result=m.delete_project(uid,d.get('id'))
            else:raise KeyError()
            return self.response(200,result)
        except PermissionError as e:return self.fail(403,str(e))
        except (KeyError,FileNotFoundError):return self.fail(404,'Media not found in this account.')
        except (ValueError,TypeError) as e:return self.fail(400,str(e))
