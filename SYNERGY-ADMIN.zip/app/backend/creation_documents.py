"""Local document rendering from actual content. No remote images or HTML fetches."""
import html
import re
import threading
import zipfile
from pathlib import Path

FONT_LOCK = threading.Lock()


def fonts():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    root = Path(__file__).parent / 'image_studio' / 'fonts'
    with FONT_LOCK:
        for name, file in [('CreationBody','DejaVuSans.ttf'),('CreationBold','DejaVuSansCondensed-Bold.ttf')]:
            if name not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont(name,str(root/file)))


def pdf(path, content):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from pypdf import PdfReader
    fonts()
    body=ParagraphStyle('Body',fontName='CreationBody',fontSize=10,leading=15,spaceAfter=8,splitLongWords=True)
    heading=ParagraphStyle('Heading',parent=body,fontName='CreationBold',fontSize=16,leading=21,spaceBefore=12,spaceAfter=8)
    small=ParagraphStyle('Small',parent=body,fontSize=8,leading=12)
    def para(text,style=body):
        text=html.escape(text)
        text=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',text)
        return Paragraph(text,style)
    story=[];lines=content.splitlines();i=0;code=False
    width=A4[0]-88
    while i<len(lines):
        line=lines[i];i+=1
        if line.startswith('```'):code=not code;continue
        if not line.strip():story.append(Spacer(1,5));continue
        if not code and '|' in line and i<len(lines) and re.fullmatch(r'\s*\|?[\s:|-]+\|[\s:|-]*',lines[i]):
            cells=lambda s:[x.strip() for x in s.strip().strip('|').split('|')]
            rows=[cells(line)];i+=1
            while i<len(lines) and '|' in lines[i]:rows.append(cells(lines[i]));i+=1
            n=max(len(row) for row in rows)
            data=[[para(v,small) for v in row+['']*(n-len(row))] for row in rows]
            table=Table(data,colWidths=[width/n]*n,repeatRows=1,hAlign='LEFT',splitByRow=1,splitInRow=1)
            table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#f7e8df')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.5,colors.HexColor('#d95e27')),('BOTTOMPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7)]))
            story.extend([table,Spacer(1,10)]);continue
        match=re.match(r'^#{1,6}\s+(.+)',line)
        story.append(para(match[1],heading) if match and not code else para(line,small if code else body))
    if not story:raise ValueError('The document has no readable content.')
    def footer(canvas,doc):
        canvas.setFont('CreationBody',8);canvas.setFillColor(colors.HexColor('#71695f'));canvas.drawString(44,28,'SYnerGY');canvas.drawRightString(A4[0]-44,28,str(doc.page))
    tmp=path.with_suffix('.pending.pdf')
    SimpleDocTemplate(str(tmp),pagesize=A4,leftMargin=44,rightMargin=44,topMargin=42,bottomMargin=50,title='SYnerGY document',author='SYnerGY').build(story,onFirstPage=footer,onLaterPages=footer)
    reader=PdfReader(str(tmp))
    if not reader.pages or not any((p.extract_text() or '').strip() for p in reader.pages):raise RuntimeError('PDF validation failed: no readable pages.')
    tmp.replace(path)


def image_pdf(source, target):
    from PIL import Image, ImageOps
    from pypdf import PdfReader
    with Image.open(source) as img:
        img=ImageOps.exif_transpose(img).convert('RGB')
        img.save(target,'PDF',resolution=144)
    if len(PdfReader(str(target)).pages)!=1:raise RuntimeError('Image PDF validation failed.')


def png_pages(folder, content):
    """Exact A4 typography, never text drawn by a diffusion model."""
    from PIL import Image, ImageDraw, ImageFont
    root=Path(__file__).parent/'image_studio'/'fonts'
    regular=ImageFont.truetype(str(root/'DejaVuSans.ttf'),34)
    heavy=ImageFont.truetype(str(root/'DejaVuSansCondensed-Bold.ttf'),52)
    small=ImageFont.truetype(str(root/'DejaVuSans.ttf'),26)
    width,height=2480,3508;left=170;right=width-left;bottom=height-180
    pages=[];canvas=Image.new('RGB',(width,height),'white');draw=ImageDraw.Draw(canvas);y=170
    def finish():
        draw.line((left,height-125,right,height-125),fill='#dc6937',width=3)
        draw.text((left,height-100),'SYnerGY',font=small,fill='#70685f')
        draw.text((right-30,height-100),str(len(pages)+1),font=small,fill='#70685f')
        path=folder/('page-%03d.png'%(len(pages)+1));canvas.save(path,dpi=(300,300));pages.append(path)
    for paragraph in content.splitlines():
        if paragraph.startswith('```') or re.fullmatch(r'[\s|:-]+',paragraph):continue
        heading=re.match(r'^#{1,6}\s+(.+)',paragraph)
        text=heading[1] if heading else paragraph
        text=re.sub(r'\*\*(.+?)\*\*',r'\1',text)
        font=heavy if heading else regular;line_height=72 if heading else 52
        lines=[];line=''
        for word in text.split(' '):
            candidate=(line+' '+word).strip()
            if draw.textlength(candidate,font=font)>right-left:
                if line:lines.append(line);line=''
                # Long URLs and identifiers also wrap within page bounds.
                while draw.textlength(word,font=font)>right-left:
                    end=1
                    while end<len(word) and draw.textlength(word[:end+1],font=font)<=right-left:end+=1
                    lines.append(word[:end]);word=word[end:]
            line=(line+' '+word).strip()
        lines.append(line)
        for line in lines:
            if y+line_height>bottom:
                finish()
                if len(pages)>=30:raise ValueError('PNG document exceeds 30 pages. Export as PDF or split the document.')
                canvas=Image.new('RGB',(width,height),'white');draw=ImageDraw.Draw(canvas);y=170
            draw.text((left,y),line,font=font,fill='#28221c');y+=line_height
        y+=24 if heading else 12
    finish()
    import shutil
    shutil.copyfile(pages[0],folder/'output.png')
    if len(pages)>1:
        with zipfile.ZipFile(folder/'pages.zip','w',zipfile.ZIP_DEFLATED) as archive:
            for page in pages:archive.write(page,page.name)
    return len(pages)


def export(folder, content, formats, sources=()):
    if not isinstance(content,str) or not content.strip() or len(content)>100000:raise ValueError('Use between 1 and 100,000 characters for a document.')
    # Strip fabricated links to nonexistent local files from generated prose.
    content=re.sub(r'\[([^\]]+)\]\((?:sandbox:|file:|/mnt/data/)[^)]+\)',r'\1',content)
    if sources:
        content+='\n\n## Sources\n\n'+'\n'.join('- ['+s['id']+'] '+s['title']+' — '+s['source'] for s in sources if s.get('access')=='read')
    (folder/'document.md').write_text(content,encoding='utf-8')
    out=[]
    for ext in formats:
        if ext=='pdf':pdf(folder/'output.pdf',content);out.append(('output.pdf','pdf','Download PDF'))
        elif ext=='docx':
            from docx import Document
            doc=Document()
            for line in content.splitlines():
                h=re.match(r'^(#{1,6})\s+(.+)',line)
                if h:doc.add_heading(h[2],min(3,len(h[1])))
                else:doc.add_paragraph(line)
            doc.save(folder/'output.docx');Document(folder/'output.docx')
            out.append(('output.docx','document','Download Word document'))
        elif ext=='txt':(folder/'output.txt').write_text(content,encoding='utf-8');out.append(('output.txt','document','Download text'))
        elif ext=='png':
            count=png_pages(folder,content)
            out.append(('output.png','image','Download PNG' if count==1 else 'Download first page PNG'))
            if count>1:out.append(('pages.zip','document','Download all '+str(count)+' PNG pages'))
        elif ext!='md':raise ValueError('Unsupported document format.')
    out.append(('document.md','source','Download editable text'))
    return out
