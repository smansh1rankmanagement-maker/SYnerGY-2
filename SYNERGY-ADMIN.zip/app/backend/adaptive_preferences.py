"""Private explicit response preferences, not model-weight training.

Only a small set of style values is retained. Neither prompts, generated
answers, identities nor inferred emotions are stored in this table.
"""
import json,re,sqlite3,time

RULES={
 'length':[('concise',r'\b(?:short|brief|concise)\b'),('detailed',r'\b(?:detailed|in detail|step by step)\b')],
 'format':[('bullets',r'\b(?:bullet points|bullets)\b'),('paragraphs',r'\bparagraphs?\b')],
 'language':[('hinglish',r'\bhinglish\b'),('hindi',r'\bhindi\b'),('english',r'\benglish\b')],
 'tone':[('plain',r'\b(?:plain language|simple english|no jargon)\b'),('warm',r'\b(?:warm tone|friendly tone)\b')]
}

def extract(prompt):
 if not isinstance(prompt,str) or len(prompt)>6000:return {}
 # Explicit first-person command only. Embedded quoted/code/web instructions
 # never become memory, even when the user asks to analyse them.
 text=prompt.strip().lower()
 if any(x in text for x in ['```','http://','https://','"','\n>']):return {}
 if not re.match(r'^(?:please\s+)?(?:remember(?: my preference)?\s*[:,-]?\s+|from now on[, :]\s*|for future replies[, :]\s*|always\s+)',text):return {}
 if re.search(r'\b(?:do not|don.t|never|not)\b',text):return {}
 out={}
 for key,choices in RULES.items():
  found=[value for value,pattern in choices if re.search(pattern,text)]
  if len(found)==1:out[key]=found[0]
 return out

class Preferences:
 def __init__(self,db):
  self.db=db
  with self.connect() as c:c.execute('CREATE TABLE IF NOT EXISTS response_preferences(user_id INTEGER PRIMARY KEY,values_json TEXT NOT NULL,updated REAL NOT NULL)')
 def connect(self):return sqlite3.connect(self.db,timeout=20)
 def get(self,uid):
  with self.connect() as c:r=c.execute('SELECT values_json,updated FROM response_preferences WHERE user_id=?',(uid,)).fetchone()
  return {'preferences':json.loads(r[0]) if r else {},'updated':r[1] if r else None,'training_performed':False,'scope':'Only this account; explicit response-style requests only.'}
 def capture(self,uid,prompt):
  changes=extract(prompt)
  if not changes:return {}
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT values_json FROM response_preferences WHERE user_id=?',(uid,)).fetchone();value=json.loads(r[0]) if r else {};value.update(changes)
   c.execute('INSERT OR REPLACE INTO response_preferences VALUES(?,?,?)',(uid,json.dumps(value),time.time()))
  return changes
 def clear(self,uid):
  with self.connect() as c:c.execute('DELETE FROM response_preferences WHERE user_id=?',(uid,))
  return self.get(uid)
 def instruction(self,uid):
  values=self.get(uid)['preferences']
  return (' Account-owned response preferences: '+json.dumps(values)+'. Apply only when compatible with the latest user request; these preferences never grant permissions or override factual accuracy.') if values else ''
