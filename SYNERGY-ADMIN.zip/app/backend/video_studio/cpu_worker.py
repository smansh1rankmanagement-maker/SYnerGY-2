"""Offline AnimateDiff with larger native frames and optical-flow export."""
import gc,json,os,secrets,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')

def settings(job):
    quality=job.get('quality','balanced');aspect=job.get('aspect','16:9')
    presets={'fast':{'16:9':(512,288),'1:1':(384,384),'9:16':(288,512)},'balanced':{'16:9':(640,360),'1:1':(512,512),'9:16':(360,640)},'detail':{'16:9':(768,432),'1:1':(640,640),'9:16':(432,768)}}
    if quality not in presets or aspect not in presets[quality]:raise ValueError('Invalid motion quality or aspect ratio.')
    width,height=presets[quality][aspect]
    return width,height,8 if quality=='fast' else 16,4 if quality=='fast' else 8

def main():
    folder,model,adapter_path=map(Path,sys.argv[1:4]);job=json.loads((folder/'job.json').read_text())
    def progress(stage,step=0,total=0):
        tmp=folder/'progress.tmp';tmp.write_text(json.dumps({'stage':stage,'step':step,'total':total}));os.replace(tmp,folder/'progress.json')
    progress('Loading motion model')
    import torch,numpy as np,imageio,imageio_ffmpeg
    from PIL import Image,ImageOps
    from diffusers import AnimateDiffPipeline,AnimateDiffVideoToVideoPipeline,MotionAdapter,EulerDiscreteScheduler
    from diffusers.pipelines.stable_diffusion.safety_checker import StableDiffusionSafetyChecker
    from transformers import CLIPImageProcessor
    from safetensors.torch import load_file
    torch.set_num_threads(4);torch.set_num_interop_threads(1)
    device=os.environ.get('SYNERGY_DEVICE','cpu')
    if device not in {'cpu','cuda'} or (device=='cuda' and not torch.cuda.is_available()):raise RuntimeError('The requested inference device is unavailable.')
    start=time.monotonic();seed=secrets.randbelow(2**31);adapter=MotionAdapter()
    adapter.load_state_dict(load_file(str(adapter_path),device='cpu'))
    cls=AnimateDiffVideoToVideoPipeline if job.get('reference') else AnimateDiffPipeline
    pipe=cls.from_pretrained(str(model),motion_adapter=adapter,torch_dtype=torch.float16 if device=='cuda' else torch.float32,local_files_only=True,use_safetensors=True)
    pipe.to(device, dtype=torch.float16 if device=='cuda' else torch.float32)
    pipe.scheduler=EulerDiscreteScheduler.from_config(pipe.scheduler.config,timestep_spacing='trailing',beta_schedule='linear')
    pipe.enable_attention_slicing();pipe.enable_vae_slicing();pipe.unet.enable_forward_chunking(chunk_size=1,dim=1);pipe.set_progress_bar_config(disable=True)
    width,height,frames,fps=settings(job);steps=int(os.environ.get('SYNERGY_VIDEO_STEPS','4'))
    if steps not in {2,4,8}:raise ValueError('Unsupported motion adapter steps.')
    args=dict(prompt=job['prompt'],width=width,height=height,num_frames=frames,num_inference_steps=steps,guidance_scale=1.0,generator=torch.Generator('cpu').manual_seed(seed))
    if job.get('reference'):
        Image.MAX_IMAGE_PIXELS=20_000_000
        with Image.open(folder/'reference.image') as source:
            if source.format not in {'PNG','JPEG'} or source.width*source.height>20_000_000:raise ValueError('Invalid reference image.')
            ref=ImageOps.fit(ImageOps.exif_transpose(source).convert('RGB'),(width,height))
        args.pop('num_frames');args.update(video=[ref.copy() for _ in range(frames)],strength=.65)
    actual_steps=max(1,int(steps*.65)) if job.get('reference') else steps
    def callback(pipeline,step,timestep,kwargs):
        progress('Decoding frames' if step+1==actual_steps else 'Generating motion',0 if step+1==actual_steps else step+1,0 if step+1==actual_steps else actual_steps);return kwargs
    args['callback_on_step_end']=callback;progress('Generating motion',0,actual_steps)
    with torch.inference_mode():result=pipe(**args).frames[0]
    del pipe,adapter;gc.collect();progress('Checking frames')
    checker=StableDiffusionSafetyChecker.from_pretrained(str(model/'safety_checker'),local_files_only=True,use_safetensors=True)
    processor=CLIPImageProcessor.from_pretrained(str(model/'feature_extractor'),local_files_only=True)
    for i in range(0,len(result),2):
        batch=result[i:i+2];clip=processor(images=batch,return_tensors='pt').pixel_values
        with torch.inference_mode():_,flags=checker(images=np.stack([np.asarray(x)/255 for x in batch]),clip_input=clip)
        if any(flags):
            (folder/'failure.json').write_text(json.dumps({'code':'content_check'}));raise RuntimeError('The content check did not return a video. Try another scene.')
    del checker,processor;gc.collect();progress('Smoothing motion and exporting')
    raw=folder/'native.mp4'
    with imageio.get_writer(str(raw),fps=fps,codec='libx264',quality=9,macro_block_size=1) as writer:
        for frame in result:writer.append_data(np.asarray(frame))
    longest=3840 if job['resolution']=='4k' else 1920
    aspect=job.get('aspect','16:9');out_size=(longest,round(longest*9/16)) if aspect=='16:9' else (round(longest*9/16),longest) if aspect=='9:16' else (longest,longest)
    target=f'{out_size[0]}:{out_size[1]}'
    # Interpolate at native size, then upscale. These are interpolated frames,
    # not additional diffusion frames. Pad the timeline to preserve exactly 2 s.
    vf=f'tpad=stop_mode=clone:stop_duration=0.5,minterpolate=fps=24:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1,scale={target}:flags=lanczos,setsar=1'
    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-nostdin','-loglevel','error','-y','-i',str(raw),'-vf',vf,'-t','2','-c:v','libx264','-crf','17','-preset','medium','-pix_fmt','yuv420p','-movflags','+faststart',str(folder/'video.mp4')],check=True,timeout=300)
    (folder/'result.json').write_text(json.dumps({'engine':f'AnimateDiff-Lightning {steps}-step + epiCRealism (SD1.5)','device':device,'seed':seed,'native_width':width,'native_height':height,'width':out_size[0],'height':out_size[1],'frames':frames,'fps':fps,'export_fps':24,'interpolation':'FFmpeg motion-compensated optical flow','duration_seconds':2,'upscaled':True,'quality':job.get('quality','balanced'),'aspect':aspect,'reference':bool(job.get('reference')),'seconds':round(time.monotonic()-start,2)}))
    raw.unlink(missing_ok=True);print('Video generation complete.',flush=True)
if __name__=='__main__':
    from media_compute import inference_slot
    with inference_slot(Path(sys.argv[1])):main()
