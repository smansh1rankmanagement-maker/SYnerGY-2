"""Offline Wan text/image-to-video jobs; web process never imports ML packages."""
import json, os, re, shutil, subprocess, threading, time, uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def atomic_json(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    os.chmod(temp, 0o600)
    os.replace(temp, path)

class VideoJobs:
    def __init__(self, data, runner=None):
        self.data = Path(data).resolve(); self.data.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.data, 0o700)
        self.output = self.data / 'jobs'; self.output.mkdir(exist_ok=True, mode=0o700)
        self.lock = threading.RLock(); self.active = None; self.process = None
        self.runner = runner or self._run
        self._probe = (0, None, None)
        for path in self.output.glob('*/job.json'):
            try:
                job=json.loads(path.read_text())
                if job['state'] in {'queued','running'}:
                    job.update(state='failed', error='Video generation stopped before completion.')
                    atomic_json(path,job)
            except (OSError, ValueError, KeyError): pass

    def status(self):
        python=os.getenv('SYNERGY_VIDEO_PYTHON',''); model=os.getenv('SYNERGY_VIDEO_MODEL','')
        if os.getenv('SYNERGY_VIDEO_ENGINE') == 'animatediff':
            adapter=Path(os.getenv('SYNERGY_VIDEO_ADAPTER',''))
            base=Path(model)
            ready=(bool(python) and Path(python).is_file() and adapter.is_file() and
                   (adapter.parent/'verified.json').is_file() and (base/'model_index.json').is_file())
            if not ready: return {'ready':False,'detail':'Local video model is being prepared.'}
            return {'ready':True,'detail':'Enhanced motion · 16 model frames · smooth 24 fps export. Runs locally; export is upscaled.'}
        ffmpeg=shutil.which('ffmpeg')
        if not (python and Path(python).is_absolute() and Path(python).is_file() and model and Path(model).is_absolute() and (Path(model)/'model_index.json').is_file() and ffmpeg):
            return {'ready':False, 'detail':'Configure the video runtime, local model and FFmpeg.'}
        key=(python, model, ffmpeg)
        now=time.monotonic()
        if self._probe[1] != key or now-self._probe[0] > 30:
            try:
                # Local readiness only. The model files are verified by the worker when loaded.
                cmd=[python,'-c','import torch, diffusers, accelerate, PIL; from diffusers import WanPipeline, WanImageToVideoPipeline, AutoencoderKLWan; from diffusers.utils import export_to_video; import imageio, imageio_ffmpeg; assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()']
                env=dict(os.environ, PYTHONPATH=os.getenv('SYNERGY_STUDIO_WORKER_PATH',os.getenv('PYTHONPATH','')), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
                result=subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20, env=env)
                ready=result.returncode == 0
            except (OSError, subprocess.SubprocessError): ready=False
            self._probe=(now,key,ready)
        if not self._probe[2]: return {'ready':False,'detail':'Video runtime dependencies or CUDA GPU are unavailable.'}
        return {'ready':True,'detail':'Local video runtime detected; model files and generation are not verified. Reference images guide the first frame; 1080p and 4K are upscaled exports.'}

    def folder(self,jid):
        if not isinstance(jid,str) or not re.fullmatch(r'[0-9a-f]{32}',jid): raise KeyError('Video job not found.')
        return self.output/jid

    def get(self,jid):
        try:
            job=json.loads((self.folder(jid)/'job.json').read_text())
            if job['state']=='running':
                try: job['progress']=json.loads((self.folder(jid)/'progress.json').read_text())
                except (OSError,ValueError): pass
            return job
        except (OSError, ValueError): raise KeyError('Video job not found.')

    def submit(self, prompt, resolution, reference=None,quality='balanced',aspect='16:9'):
        if not isinstance(prompt,str) or not 1<=len(prompt.strip())<=1000 or resolution not in {'1080p','4k'}: raise ValueError('Invalid video request.')
        if quality not in {'fast','balanced','detail'} or aspect not in {'16:9','1:1','9:16'}:raise ValueError('Choose a supported quality and aspect ratio.')
        if reference is not None and (not isinstance(reference,bytes) or not 0<len(reference)<=8*1024*1024 or not reference.startswith((b'\x89PNG\r\n\x1a\n',b'\xff\xd8\xff'))):
            raise ValueError('Reference must be a PNG or JPEG under 8 MB.')
        with self.lock:
            if self.active: raise RuntimeError('A video is already generating. Please wait.')
            status=self.status()
            if not status['ready']: raise RuntimeError(status['detail'])
            jid=uuid.uuid4().hex; folder=self.folder(jid); folder.mkdir(mode=0o700)
            if reference is not None:
                refpath=folder/'reference.image'; refpath.write_bytes(reference); os.chmod(refpath,0o600)
            job={'id':jid,'kind':'video','state':'queued','prompt':prompt.strip(),'resolution':resolution,'quality':quality,'aspect':aspect,'reference':reference is not None,'created':time.time()}
            atomic_json(folder/'job.json',job); self.active=jid
            threading.Thread(target=self._execute,args=(jid,),daemon=True).start()
            return job

    def _update(self,jid,**changes):
        job=self.get(jid); job.update(changes); atomic_json(self.folder(jid)/'job.json',job)

    def _execute(self,jid):
        folder=self.folder(jid)
        try:
            with self.lock:
                if self.get(jid)['state']=='cancelled':return
                self._update(jid,state='running',started=time.time())
            self.runner(jid)
            if self.get(jid)['state']=='cancelled':return
            output=folder/'video.mp4'
            with output.open('rb') as f: header=f.read(12)
            if len(header)<12 or header[4:8]!=b'ftyp': raise RuntimeError('The video engine did not produce a valid MP4.')
            metadata={}
            if (folder/'result.json').is_file(): metadata=json.loads((folder/'result.json').read_text())
            with self.lock:
                if self.get(jid)['state']!='cancelled':self._update(jid,state='succeeded',finished=time.time(),result=metadata)
        except Exception as exc:
            (folder/'video.mp4').unlink(missing_ok=True)
            with (folder/'engine.log').open('a') as log: log.write('\nJob failed: '+type(exc).__name__+': '+str(exc)+'\n')
            if self.get(jid)['state']=='cancelled':return
            message='Video generation failed. Check the local engine log and retry using Instant effort.'
            try:
                failure=json.loads((folder/'failure.json').read_text())
                if failure.get('code')=='content_check': message='The video content check did not return a result. Try a different scene.'
            except (OSError,ValueError): pass
            self._update(jid,state='failed',finished=time.time(),error=message)
        finally:
            with self.lock: self.active=None; self.process=None

    def _run(self,jid):
        folder=self.folder(jid)
        env=dict(os.environ, PYTHONPATH=os.getenv('SYNERGY_STUDIO_WORKER_PATH',os.getenv('PYTHONPATH','')), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
        with (folder/'engine.log').open('wb') as log:
            with self.lock:
                if self.get(jid)['state']=='cancelled':return
                cpu=os.getenv('SYNERGY_VIDEO_ENGINE')=='animatediff'
                args=[os.environ['SYNERGY_VIDEO_PYTHON'],str(ROOT/('cpu_worker.py' if cpu else 'worker.py')),str(folder),os.environ['SYNERGY_VIDEO_MODEL']]
                if cpu: args.append(os.environ['SYNERGY_VIDEO_ADAPTER'])
                self.process=subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT,env=env)
                proc=self.process
            try:code=proc.wait(timeout=7200)
            except subprocess.TimeoutExpired:
                proc.kill();proc.wait();raise RuntimeError('Video generation exceeded two hours.')
            if code!=0: raise RuntimeError('Video inference stopped.')

    def cancel(self,jid):
        with self.lock:
            job=self.get(jid)
            if job['state'] in {'queued','running'}:
                self._update(jid,state='cancelled',finished=time.time())
                if self.active==jid and self.process and self.process.poll() is None:self.process.terminate()
        return self.get(jid)

    def close(self):
        with self.lock:
            if self.process and self.process.poll() is None: self.process.terminate()
