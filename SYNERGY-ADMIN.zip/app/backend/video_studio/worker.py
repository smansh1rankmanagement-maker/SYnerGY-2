"""Offline Wan2.2 TI2V Diffusers worker. Requires a trusted local checkpoint."""
import json, os, subprocess, sys
from pathlib import Path

# Force offline mode before importing Hugging Face libraries.
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TRANSFORMERS_OFFLINE']='1'
os.environ['HF_HUB_DISABLE_TELEMETRY']='1'

def main():
    folder=Path(sys.argv[1]).resolve(); model=Path(sys.argv[2]).resolve()
    job=json.loads((folder/'job.json').read_text())
    import torch
    from diffusers import AutoencoderKLWan, WanPipeline, WanImageToVideoPipeline
    from diffusers.utils import export_to_video
    if not torch.cuda.is_available(): raise RuntimeError('A CUDA GPU is required.')
    if not torch.cuda.is_bf16_supported(): raise RuntimeError('A CUDA GPU with bfloat16 support is required.')
    vae=AutoencoderKLWan.from_pretrained(str(model),subfolder='vae',torch_dtype=torch.float32,local_files_only=True,use_safetensors=True)
    pipeline_class=WanImageToVideoPipeline if job.get('reference') else WanPipeline
    pipe=pipeline_class.from_pretrained(str(model),vae=vae,torch_dtype=torch.bfloat16,local_files_only=True,use_safetensors=True,trust_remote_code=False)
    pipe.enable_model_cpu_offload()
    pipe.vae.enable_tiling()
    args={'prompt':job['prompt'],'height':704,'width':1280,'num_frames':49,'num_inference_steps':40,'guidance_scale':5.0}
    if job.get('reference'):
        from PIL import Image, ImageOps
        # Decode a local upload only, limiting decompression and applying orientation.
        Image.MAX_IMAGE_PIXELS=20_000_000
        with Image.open(folder/'reference.image') as original:
            if original.format not in {'PNG','JPEG'}: raise ValueError('Reference must be PNG or JPEG.')
            if original.width * original.height > 20_000_000: raise ValueError('Reference image dimensions are too large.')
            original.load()
            args['image']=ImageOps.fit(ImageOps.exif_transpose(original).convert('RGB'),(1280,704),method=Image.Resampling.LANCZOS)
    with torch.inference_mode(): frames=pipe(**args).frames[0]
    raw=folder/'native.mp4'
    export_to_video(frames,output_video_path=str(raw),fps=24)
    size='3840:2160' if job['resolution']=='4k' else '1920:1080'
    vf=f'scale={size}:force_original_aspect_ratio=decrease,pad={size}:(ow-iw)/2:(oh-ih)/2'
    subprocess.run(['ffmpeg','-nostdin','-loglevel','error','-y','-i',str(raw),'-vf',vf,'-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart',str(folder/'video.mp4')],check=True,timeout=1800)
    raw.unlink(missing_ok=True)

if __name__=='__main__': main()
