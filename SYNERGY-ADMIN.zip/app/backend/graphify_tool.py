"""Pinned Graphify local code analysis. Never executes project code or loads its config."""
import json,os,re,shutil,signal,subprocess,threading,time
from pathlib import Path
from beast.safety import path,no_secrets
COMMIT='16218bfc80d4ca2799734d045039f7ed1a5fa9fb'
BINARY=Path('/opt/graphify/bin/graphify')
CODE={'.py','.pyi','.js','.mjs','.cjs','.jsx','.ts','.tsx','.go','.rs','.java','.c','.h','.cpp','.hpp','.cs','.rb','.php','.swift','.kt','.lua','.vue','.svelte'}
GATE=threading.BoundedSemaphore(1)
def intent(prompt):return bool(re.search(r'(?i)(?:\b(?:use|run|map|analyse|analyze|explain|query)\b.{0,50}\bgraphify\b|^\s*/graphify\b)',prompt))
def catalog():return {'id':'graphify','name':'Graphify code maps','description':'Map the current saved code project with local AST extraction. Ask: Use Graphify to map this project. No code execution or hosted inference.','enabled':BINARY.is_file(),'default':True,'builtin':True,'runtime':True,'status':'ready' if BINARY.is_file() else 'runtime_setup_required','version':'0.9.103','scope':'Owned linked code projects · pinned revision · 200 files / 5 MB · 90 seconds','action':'graphify','commit':COMMIT}
def execute(beast,uid,pid,folder,prompt,stop,stage):
 if not BINARY.is_file():raise ValueError('Graphify runtime is not installed on this host.')
 if not pid:raise ValueError('Choose a project with a linked code workspace, then ask Graphify to map it.')
 project=beast.project(uid,pid);selected={};skipped=[];total=0
 for name,value in sorted(project['files'].items()):
  if Path(name).suffix.lower() not in CODE or value.get('encoding')!='utf-8':skipped.append(name);continue
  path(name);text=value['content'];no_secrets(text);size=len(text.encode())
  if len(selected)>=200 or total+size>5*1024*1024:raise ValueError('Graphify supports up to 200 source files / 5 MB per map. Split this project before mapping.')
  selected[name]=text;total+=size
 if not selected:raise ValueError('No supported code files were found in this project.')
 work=Path(folder)/'graphify';work.mkdir(mode=0o700);source=work/'source';source.mkdir(mode=0o700)
 for name,text in selected.items():
  dest=source/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text);dest.chmod(0o600)
 env={'PATH':'/opt/graphify/bin:/usr/bin:/bin','HOME':str(work.resolve()),'GRAPHIFY_OUT':'graphify-out','GRAPHIFY_MAX_WORKERS':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','DO_NOT_TRACK':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1','NO_PROXY':'*'}
 def run(args):
  command=['/usr/bin/prlimit','--as=3221225472','--cpu=60','--fsize=16777216','--nofile=128','--',str(BINARY),*args]
  log=work/'process.log'
  with log.open('wb') as out:
   proc=subprocess.Popen(command,cwd=work,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
   try:
    deadline=time.monotonic()+90
    while proc.poll() is None:
     if stop.is_set():raise InterruptedError('Graphify stopped. Source files were not changed.')
     if time.monotonic()>deadline:raise ValueError('Graphify exceeded its 90-second processing limit. Try a smaller project.')
     time.sleep(.1)
    if proc.returncode not in {0,3,4}:raise ValueError('Graphify could not finish this code map. The original project is unchanged.')
    return log.read_text(errors='replace')[-12000:]
   finally:
    if proc.poll() is None:
     os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=5)
 stage('Waiting for local code analysis')
 while not GATE.acquire(timeout=.2):
  if stop.is_set():raise InterruptedError('Graphify stopped while waiting.')
 try:
  stage('Mapping code with Graphify · local AST extraction')
  run(['extract',str(source.resolve()),'--code-only','--no-cluster','--max-workers','1','--out',str(work.resolve())])
  files=list(work.glob('**/graph.json'))
  if len(files)!=1 or files[0].stat().st_size>16*1024*1024:raise ValueError('Graphify did not produce a bounded graph file.')
  graph=json.loads(files[0].read_text());nodes=graph.get('nodes',[]);edges=graph.get('edges',graph.get('links',[]))
  if not nodes:raise ValueError('Graphify found no extractable code symbols in this project.')
  # Keep exports portable: remove only the private materialisation prefix, never user text globally.
  raw=files[0].read_text().replace(str(source.resolve())+'/', '').replace(str(work.resolve())+'/', '')
  (Path(folder)/'graph.json').write_text(raw)
  query=re.sub(r'(?i)^\s*(?:/graphify|use graphify|run graphify)\s*','',prompt).strip()[:800]
  stage('Checking code relationships')
  result=run(['query',query or 'functions classes imports','--graph',str(files[0].resolve()),'--budget','1200','--depth','2'])
  result=result.replace(str(source.resolve())+'/', '').replace(str(work.resolve())+'/', '')
  summary=f"Graphify mapped **{project['name']} · revision {project['revision']}** locally.\n\n- {len(selected)} code files; {len(nodes)} symbols; {len(edges)} relationships.\n- {len(skipped)} non-code files excluded.\n- Original files are unchanged.\n\n```text\n{result[:8000].replace('```','---')}\n```\n\nAST relationships are extracted from source; they do not prove runtime behaviour. Document/media semantic analysis and external model calls are disabled."
  return {'reply':summary,'revision':project['revision'],'files':len(selected),'nodes':len(nodes),'edges':len(edges),'commit':COMMIT}
 finally:
  GATE.release();shutil.rmtree(work,ignore_errors=True)
