"""Keep original project assets beside revisioned editable source. No execution."""
import io,json,re,zipfile,shutil,hashlib,time
from pathlib import Path,PurePosixPath
from beast.safety import bytes_of
class SourceBundles:
 def __init__(self,workspace,beast,root):
  self.workspace=workspace;self.beast=beast;self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
  with workspace.connect() as c:c.execute('CREATE TABLE IF NOT EXISTS project_source_bundles(project_id TEXT PRIMARY KEY,manifest TEXT NOT NULL,created REAL NOT NULL)')
 def attach(self,user,pid,archive,manifest):
  p=self.workspace.project(user,pid)
  if not p.get('beast_project_id'):raise ValueError('Link a code workspace first.')
  archive=Path(archive)
  if archive.stat().st_size>300*1024*1024:raise ValueError('Source bundle exceeds 300 MB.')
  with zipfile.ZipFile(archive) as z:
   if len(z.infolist())>1500 or sum(i.file_size for i in z.infolist())>500*1024*1024:raise ValueError('Source bundle extraction limit exceeded.')
   for i in z.infolist():
    n=PurePosixPath(i.filename)
    if n.is_absolute() or '..' in n.parts or '\\' in i.filename or (i.external_attr>>16)&0o170000==0o120000:raise ValueError('Unsafe source bundle path.')
  folder=self.root/pid;folder.mkdir(mode=0o700,exist_ok=True);target=folder/'base.zip';shutil.copyfile(archive,target);target.chmod(0o600)
  with self.workspace.connect() as c:c.execute('INSERT OR REPLACE INTO project_source_bundles VALUES(?,?,?)',(pid,json.dumps(manifest),time.time()))
 def export(self,user,pid):
  p=self.workspace.project(user,pid)
  if not p.get('beast_project_id'):raise KeyError('No source is linked.')
  source=self.beast.project(user,p['beast_project_id']);folder=self.root/pid
  with self.workspace.connect() as c:r=c.execute('SELECT manifest FROM project_source_bundles WHERE project_id=?',(pid,)).fetchone()
  if not r:return re.sub(r'[^\w.-]+','-',p['name'])+'.zip',self.beast.export(user,source['id'])[0]
  meta=json.loads(r[0]);cached=folder/('source-r'+str(source['revision'])+'.zip')
  if not cached.exists():
   temp=folder/('source-r'+str(source['revision'])+'-'+__import__('uuid').uuid4().hex+'.partial')
   editable=set(meta['editable_paths'])
   try:
    with zipfile.ZipFile(folder/'base.zip') as base,zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as out:
     for i in base.infolist():
      if not i.is_dir() and i.filename not in editable and i.filename not in source['files']:out.writestr(i.filename,base.read(i))
     for name,v in source['files'].items():out.writestr(name,bytes_of(v))
     out.writestr('SYNERGY-EXPORT.json',json.dumps({'project':p['name'],'revision':source['revision'],'provenance':meta,'runtime':'Source and assets. Use the included deployment instructions; editor preview does not execute application services.'},indent=2))
    temp.replace(cached);cached.chmod(0o600)
   finally:temp.unlink(missing_ok=True)
  return re.sub(r'[^\w.-]+','-',p['name'])+'-r'+str(source['revision'])+'.zip',cached.read_bytes()
