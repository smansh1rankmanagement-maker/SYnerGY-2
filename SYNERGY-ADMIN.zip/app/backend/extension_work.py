"""Account-owned notes, tasks and meetings. No background external publication."""
import datetime as dt
import json
import re
import time
import uuid
from urllib.parse import urlencode
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

class ExtensionWork:
    def __init__(self, ws):
        self.ws = ws
        with ws.connect() as c:
            c.execute('''CREATE TABLE IF NOT EXISTS extension_work_items(
                id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,kind TEXT NOT NULL,
                revision INTEGER NOT NULL,body TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL)''')
            c.execute('CREATE INDEX IF NOT EXISTS extension_work_owner ON extension_work_items(user_id,kind)')

    def rows(self, uid):
        with self.ws.connect() as c:
            return [self.unpack(r) for r in c.execute('SELECT * FROM extension_work_items WHERE user_id=? ORDER BY updated DESC LIMIT 500', (uid,))]

    @staticmethod
    def unpack(r):
        return {'id':r['id'],'kind':r['kind'],'revision':r['revision'],**json.loads(r['body']),'created':r['created'],'updated':r['updated']}

    def get(self, uid, ident):
        with self.ws.connect() as c:
            r=c.execute('SELECT * FROM extension_work_items WHERE id=? AND user_id=?',(ident,uid)).fetchone()
        if not r: raise KeyError('Work item not found')
        return self.unpack(r)

    def save(self, uid, d):
        kind=d.get('kind');ident=d.get('id') or uuid.uuid4().hex
        if kind not in {'note','todo','meeting'} or not isinstance(ident,str) or not re.fullmatch('[a-f0-9]{32}',ident): raise ValueError('Choose a note, to-do or meeting.')
        body={}
        for key,limit in [('title',180),('text',10000)]:
            value=d.get(key,'')
            if not isinstance(value,str) or len(value)>limit or (key=='title' and not value.strip()): raise ValueError('Enter a title under 180 characters and notes under 10,000.')
            body[key]=value.strip()
        body['done']=d.get('done') is True
        if kind=='meeting':
            try:
                zone=d.get('timezone','Asia/Kolkata'); ZoneInfo(zone)
                start=dt.datetime.fromisoformat(d['start']);end=dt.datetime.fromisoformat(d['end'])
                if not start.tzinfo or not end.tzinfo: raise ValueError()
                seconds=(end-start).total_seconds()
                if not 60<=seconds<=86400 or start.timestamp()>time.time()+366*86400: raise ValueError()
            except (KeyError,TypeError,ValueError,ZoneInfoNotFoundError): raise ValueError('Use valid timezone-aware dates, an end after the start, and a duration of up to 24 hours.')
            meet=d.get('meet_url','').strip()
            if meet and not re.fullmatch(r'https://meet\.google\.com/[a-z]{3}-[a-z]{4}-[a-z]{3}',meet): raise ValueError('Use a Google Meet joining link.')
            body.update(start=start.isoformat(),end=end.isoformat(),timezone=zone,meet_url=meet,calendar_state='not_synced')
        with self.ws.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            old=c.execute('SELECT * FROM extension_work_items WHERE id=?',(ident,)).fetchone()
            if old:
                if old['user_id']!=uid: raise KeyError('Work item not found')
                if d.get('revision')!=old['revision']: raise ValueError('This item changed. Refresh before saving.')
                # Editing an externally synced event requires an explicit resync.
                revision=old['revision']+1
                c.execute('UPDATE extension_work_items SET kind=?,revision=?,body=?,updated=? WHERE id=?',(kind,revision,json.dumps(body),time.time(),ident))
            else:
                if d.get('revision') is not None: raise KeyError('Work item not found')
                if c.execute('SELECT COUNT(*) FROM extension_work_items WHERE user_id=?',(uid,)).fetchone()[0]>=500: raise ValueError('Archive or delete an item before adding more (500 saved items).')
                c.execute('INSERT INTO extension_work_items VALUES(?,?,?,?,?,?,?)',(ident,uid,kind,1,json.dumps(body),time.time(),time.time()))
        return self.get(uid,ident)

    def delete(self, uid, d):
        with self.ws.connect() as c:
            n=c.execute('DELETE FROM extension_work_items WHERE id=? AND user_id=? AND revision=?',(d.get('id'),uid,d.get('revision'))).rowcount
        if not n: raise KeyError('Work item missing or changed')
        return {'deleted':True}

    def calendar_link(self, uid, ident):
        item=self.get(uid,ident)
        if item['kind']!='meeting': raise ValueError('Choose a meeting.')
        stamp=lambda s:dt.datetime.fromisoformat(s).astimezone(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        return {'url':'https://calendar.google.com/calendar/render?'+urlencode({'action':'TEMPLATE','text':item['title'],'dates':stamp(item['start'])+'/'+stamp(item['end']),'ctz':item['timezone'],'details':item['text'],'location':item['meet_url']}),'status':'review_in_google_calendar','message':'Review and save in Google Calendar. Add Google Meet there if you need a new link. This handoff does not confirm that the event was saved.'}

    def publish(self, uid, ident, revision, connections):
        item=self.get(uid,ident)
        if item['kind']!='meeting' or item['revision']!=revision: raise ValueError('Review the latest meeting version first.')
        # Stable event ID prevents duplicate events after retries or explicit resync.
        import hashlib
        from connections.transport import json_request, ConnectionError
        eventid=hashlib.sha256(f'{uid}:{ident}'.encode()).hexdigest()
        body={'id':eventid,'summary':item['title'],'description':item['text'],'start':{'dateTime':item['start'],'timeZone':item['timezone']},'end':{'dateTime':item['end'],'timeZone':item['timezone']},'reminders':{'useDefault':False,'overrides':[{'method':'popup','minutes':0}]}}
        if item['meet_url']: body['location']=item['meet_url']
        else: body['conferenceData']={'createRequest':{'requestId':eventid,'conferenceSolutionKey':{'type':'hangoutsMeet'}}}
        headers={'Authorization':'Bearer '+connections.token(uid,'google-calendar')}
        url='https://www.googleapis.com/calendar/v3/calendars/primary/events'
        # Retry a prior uncertain request by reading the same event id first.
        try:
            result=json_request(url+'/'+eventid,headers=headers)
            if item.get('calendar_state')!='synced':
                body.pop('conferenceData',None)
                result=json_request(url+'/'+eventid+'?sendUpdates=none','PATCH',body,headers)
        except ConnectionError as e:
            if getattr(e,'status',None)!=404: raise
            result=json_request(url+'?conferenceDataVersion=1&sendUpdates=none','POST',body,headers)
        detail={'calendar_state':'synced','google_event_id':result.get('id'), 'google_url':result.get('htmlLink',''),'meet_url':result.get('hangoutLink',item['meet_url'])}
        with self.ws.connect() as c:
            current=c.execute('SELECT body FROM extension_work_items WHERE id=? AND user_id=? AND revision=?',(ident,uid,revision)).fetchone()
            if not current: raise ValueError('Meeting changed during sync; review Google Calendar before retrying.')
            c.execute('UPDATE extension_work_items SET body=?,updated=? WHERE id=?',(json.dumps({**json.loads(current['body']),**detail}),time.time(),ident))
        connections.audit(uid,'google-calendar','event_created',{'item_id':ident,'revision':revision,'event_id':result.get('id')})
        return self.get(uid,ident)
