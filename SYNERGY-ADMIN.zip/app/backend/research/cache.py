"""Bounded account-private answer cache. No credentials, cookies or model training."""
import hashlib,json,re,sqlite3,time

def key(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def ttl(prompt):
    # Always re-fetch explicitly fresh and high-stakes information.
    if re.search(r'\b(today|now|latest|current|news|price|stock|weather|live|refresh|verify again|medical|diagnos\w*|legal|law|invest\w*)\b',prompt,re.I):return 0
    return 300

class AnswerCache:
    def __init__(self, db):
        self.db=str(db)
        with self.connect() as c:
            c.execute('CREATE TABLE IF NOT EXISTS response_cache(user_id INTEGER NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, created REAL NOT NULL, expires REAL NOT NULL, PRIMARY KEY(user_id,key))')
    def connect(self):return sqlite3.connect(self.db,timeout=5)
    def get(self, uid, fingerprint):
        with self.connect() as c:
            r=c.execute('SELECT value,created,expires FROM response_cache WHERE user_id=? AND key=?',(uid,fingerprint)).fetchone()
        if not r or r[2]<=time.time():return None
        return {**json.loads(r[0]),'cache':{'hit':True,'created':r[1],'expires':r[2],'age_seconds':round(time.time()-r[1],2),'scope':'This account only; sources were not fetched again.'}}
    def put(self, uid, fingerprint, value, seconds):
        if seconds<=0:return
        raw=json.dumps(value,ensure_ascii=False)
        if len(raw.encode())>256000:return
        now=time.time()
        with self.connect() as c:
            c.execute('DELETE FROM response_cache WHERE expires<=?',(now,))
            c.execute('INSERT OR REPLACE INTO response_cache VALUES(?,?,?,?,?)',(uid,fingerprint,raw,now,now+min(300,seconds)))
            c.execute('DELETE FROM response_cache WHERE user_id=? AND key NOT IN (SELECT key FROM response_cache WHERE user_id=? ORDER BY created DESC LIMIT 20)',(uid,uid))
            c.execute('DELETE FROM response_cache WHERE rowid NOT IN (SELECT rowid FROM response_cache ORDER BY created DESC LIMIT 1000)')
    def clear(self, uid):
        with self.connect() as c:c.execute('DELETE FROM response_cache WHERE user_id=?',(uid,))
