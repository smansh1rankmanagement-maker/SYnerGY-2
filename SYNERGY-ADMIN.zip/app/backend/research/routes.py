"""Same-origin, authenticated research API. No public task/file URLs."""
import copy,json,re,time,mimetypes
from urllib.parse import parse_qs,urlsplit,quote

def public_task(task):
    d=copy.deepcopy(task)
    for s in d['detail'].get('sources',[]):s.pop('text',None)
    return d

class ResearchHTTP:
    def research_get(self,path,user):
        r=self.research;uid=user['id'];query=parse_qs(urlsplit(self.path).query)
        try:
            if path=='/api/research/pins':return self.response(200,r.pins(uid))
            if path=='/api/research/settings':
                from .latency import catalog
                return self.response(200,{**r.settings(uid),'response_budgets':catalog()})
            if path=='/api/research/observations':return self.response(200,r.observations.list(uid))
            if path=='/api/research/preferences':return self.response(200,r.learning.get(uid))
            if path=='/api/research/history':return self.response(200,{'conversations':r.history_search(uid,query.get('q',[''])[0])})
            if path=='/api/research/files':return self.response(200,{'files':r.files(uid)})
            if path=='/api/research/tasks':return self.response(200,{'tasks':[public_task(t) for t in r.list(uid,query.get('conversation_id',[None])[0])]})
            m=re.fullmatch(r'/api/research/files/([0-9a-f]{32})(/original)?',path)
            if m:
                f=r.file(uid,m[1])
                if not m[2]:return self.response(200,f)
                return self.research_download_path(r.root/'files'/m[1]/'original',f['name'])
            m=re.fullmatch(r'/api/research/tasks/([0-9a-f]{32})(?:/(events|report.md|evidence.json|screenshot.png|before.png|download-[0-2]|source|output\.pdf|output\.png|output\.svg|video\.mp4|output\.docx|document\.md|output\.txt|pages\.zip|graph\.json))?',path)
            if m:
                t=r.task(uid,m[1]);action=m[2]
                if not action:return self.response(200,public_task(t))
                if action=='source':return self.response(200,r.source(uid,m[1],query.get('id',[''])[0],query.get('find',[''])[0]))
                if action=='events':
                    self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Connection','close');self.end_headers()
                    last=None;deadline=time.monotonic()+1800
                    try:
                        while time.monotonic()<deadline:
                            # A logout or expired session also closes this stream.
                            if not self.user():break
                            t=r.task(uid,m[1]);payload=json.dumps(public_task(t),ensure_ascii=False)
                            if payload!=last:self.wfile.write(('data: '+payload+'\n\n').encode());self.wfile.flush();last=payload
                            if t['state'] not in {'queued','running'}:break
                            time.sleep(.4)
                    except (BrokenPipeError,ConnectionResetError):pass
                    self.close_connection=True;return
                if action in {'output.pdf','output.png','output.svg','video.mp4','output.docx','document.md','output.txt','pages.zip','graph.json'}:
                    if t['state']!='succeeded' or not any(a['name']==action for a in t['detail'].get('artifacts',[])):raise FileNotFoundError()
                    data=(r.folder(m[1])/action).read_bytes()
                    types={'output.pdf':'application/pdf','output.png':'image/png','video.mp4':'video/mp4'}
                    if action in types and query.get('download')!=['1']:return self.response(200,data,types[action])
                    return self.research_download(data,'synergy-'+action)
                f=r.folder(m[1])/action
                if not f.is_file():raise FileNotFoundError()
                if action.endswith('.png'):return self.response(200,f.read_bytes(),'image/png')
                return self.research_download(f.read_bytes(),'synergy-'+action)
        except (KeyError,FileNotFoundError):return self.fail(404,'Research item not found in this account.')
        except PermissionError as exc:return self.fail(402,str(exc))
        except (ValueError,TypeError):return self.fail(400,'Invalid research request.')
        return self.fail(404,'Not found.')
    def research_download_path(self,path,name):
        self.send_response(200);self.send_header('Content-Type','application/octet-stream');self.send_header('Content-Length',str(path.stat().st_size));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(name));self.end_headers()
        with path.open('rb') as f:
            for block in iter(lambda:f.read(256*1024),b''):self.wfile.write(block)
    def research_download(self,data,name):
        self.send_response(200);self.send_header('Content-Type','application/octet-stream');self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(name));self.end_headers();self.wfile.write(data)
    def research_post(self,path,d,user):
        r=self.research;uid=user['id']
        try:
            if path=='/api/research/cache/clear':r.answer_cache.clear(uid);r.web.clear(uid);return self.response(200,{'cleared':True})
            if path=='/api/research/pins':return self.response(200,r.pins(uid,d.get('conversation_id'),d.get('pinned')))
            if path=='/api/research/settings':return self.response(200,r.settings(uid,d))
            if path=='/api/research/observations/review':
                result=r.observations.review(uid,d.get('id'),d.get('decision'));r.answer_cache.clear(uid);return self.response(200,result)
            if path=='/api/research/observations/clear':
                result=r.observations.clear(uid);r.answer_cache.clear(uid);return self.response(200,result)
            if path=='/api/research/preferences/clear':return self.response(200,r.learning.clear(uid))
            if path=='/api/research/files/delete':
                r.delete_file(uid,d.get('id'));return self.response(200,{'ok':True})
            if path=='/api/research/files':return self.response(201,r.upload(uid,d.get('file'),d.get('name','')))
            if path=='/api/research/tasks':
                if d.get('page_context'):d={**d,'_extension_readonly':True}
                return self.response(202,public_task(r.submit(uid,d)))
            if path=='/api/research/cancel':return self.response(200,public_task(r.cancel(uid,d.get('id'))))
            if path=='/api/research/retry':return self.response(202,public_task(r.retry(uid,d.get('id'))))
            if path=='/api/research/branch':return self.response(201,r.branch(uid,d.get('conversation_id'),d.get('message_id')))
        except (KeyError,FileNotFoundError):return self.fail(404,'Research item not found in this account.')
        except PermissionError as exc:return self.fail(402,str(exc))
        except (ValueError,TypeError,OverflowError) as exc:return self.fail(400,str(exc))
        return self.fail(404,'Not found.')
