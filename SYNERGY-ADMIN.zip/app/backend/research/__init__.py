"""Local research tools. Retrieved content never authorizes actions."""
