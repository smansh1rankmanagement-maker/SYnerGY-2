"""Disposable browser inspection. Never attaches to a person's Chrome profile."""
from pathlib import Path
import json,os,re,select,socket,sys,threading,time,signal,http.client
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlsplit
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from research.net import validate_url,redact,safe_log_url,fetch

class Proxy(BaseHTTPRequestHandler):
    allowed=()
    def log_message(self,*args):pass
    def do_CONNECT(self):
        try:
            u,h,p,ips=validate_url('https://'+self.path,self.allowed)
            upstream=socket.create_connection((ips[0],p),timeout=12)
            self.send_response(200);self.end_headers()
            until=time.monotonic()+80
            try:
                while time.monotonic()<until:
                    ready,_,_=select.select([self.connection,upstream],[],[],2)
                    for src in ready:
                        data=src.recv(65536)
                        if not data:return
                        (upstream if src is self.connection else self.connection).sendall(data)
            finally:upstream.close()
        except (OSError,ValueError):
            try:self.send_error(403,'Destination unavailable')
            except OSError:pass
    def do_GET(self):
        connection=None
        try:
            u,h,p,ips=validate_url(self.path,self.allowed)
            if u.scheme!='http':raise ValueError('HTTPS must use CONNECT')
            connection=http.client.HTTPConnection(h,p,timeout=15);connection.sock=socket.create_connection((ips[0],p),timeout=15)
            headers={k:v for k,v in self.headers.items() if k.lower() in {'accept','accept-language','user-agent','cookie','referer','range','if-none-match','if-modified-since'}}
            headers['Host']=u.netloc;headers['Accept-Encoding']='identity'
            connection.request(self.command,u.path+('?' +u.query if u.query else '') or '/',headers=headers)
            response=connection.getresponse()
            if int(response.getheader('Content-Length','0') or 0)>8*1024*1024:raise ValueError('Response too large')
            data=response.read(8*1024*1024+1)
            if len(data)>8*1024*1024:raise ValueError('Response too large')
            self.send_response(response.status)
            for k,v in response.getheaders():
                if k.lower() not in {'connection','transfer-encoding','content-length'}:self.send_header(k,v)
            self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
        except Exception:
            try:self.send_error(403,'Destination unavailable')
            except OSError:pass
        finally:
            if connection:connection.close()
    do_HEAD=do_GET
    def do_POST(self):self.send_error(403,'Page mutations are disabled')

def run(folder):
    from playwright.sync_api import sync_playwright
    req=json.loads((folder/'browser-input.json').read_text());url=req['url'];allowed=tuple(req.get('allowed_origins',[]));validate_url(url,allowed)
    actions=req.get('actions',[])
    if len(actions)>8:raise ValueError('Use at most eight explicit browser actions.')
    if actions and not req.get('authorised_actions'):raise ValueError('Authorise the listed browser actions first.')
    Proxy.allowed=allowed;proxy=ThreadingHTTPServer(('127.0.0.1',0),Proxy);threading.Thread(target=proxy.serve_forever,daemon=True).start()
    errors=[];failed=[];responses=[];steps=[];downloads=[];blocked=[];started=time.monotonic()
    with sync_playwright() as pw:
        browser=pw.chromium.launch(channel=os.environ.get('SYNERGY_BROWSER_CHANNEL','chrome') or None,headless=True,proxy={'server':'http://127.0.0.1:'+str(proxy.server_port)},args=['--proxy-bypass-list=<-loopback>','--disable-background-networking','--disable-sync','--disable-extensions','--force-webrtc-ip-handling-policy=disable_non_proxied_udp'])
        context=browser.new_context(viewport={'width':1280,'height':900},accept_downloads=True,service_workers='block')
        page=context.new_page();page.set_default_timeout(8000)
        def route(request):
            r=request.request
            try:
                if r.method not in {'GET','HEAD'}:raise ValueError('Page mutations are disabled')
                if r.url.startswith(('data:','blob:')):return request.continue_()
                validate_url(r.url,allowed)
                if re.search(r'/(?:logout|delete|unsubscribe|purchase|checkout)(?:/|\?|$)',r.url,re.I):raise ValueError('Consequential action blocked')
                request.continue_()
            except Exception as e:
                if len(blocked)<30:blocked.append({'url':safe_log_url(r.url),'reason':redact(e)[:180]})
                request.abort('blockedbyclient')
        context.route('**/*',route)
        def console(msg):
            if msg.type in {'error','warning'} and len(errors)<30:errors.append({'kind':msg.type,'message':redact(msg.text)[:1200]})
        page.on('console',console);page.on('pageerror',lambda e:errors.append({'kind':'pageerror','message':redact(e)[:1200]}) if len(errors)<30 else None)
        page.on('requestfailed',lambda r:failed.append({'url':safe_log_url(r.url),'method':r.method,'failure':redact(r.failure)}) if len(failed)<30 else None)
        def response(r):
            if len(responses)<80:responses.append({'url':safe_log_url(r.url),'status':r.status,'resource':r.request.resource_type,'redirected':bool(r.request.redirected_from),'timing':r.request.timing})
        page.on('response',response)
        def finished(r):
            for item in reversed(responses):
                if item['url']==safe_log_url(r.url) and item['resource']==r.resource_type:
                    item['timing']=r.timing;break
        page.on('requestfinished',finished)
        def download(d):
            n=len(downloads)
            if n>=3:d.cancel();return
            target=folder/('download-'+str(n));d.save_as(target)
            if target.stat().st_size>8*1024*1024:target.unlink();downloads.append({'error':'Download exceeded 8 MB.'});return
            downloads.append({'url':safe_log_url(d.url),'file':target.name,'name':Path(d.suggested_filename).name[:100],'bytes':target.stat().st_size})
        page.on('download',download);page.on('dialog',lambda d:d.dismiss())
        try:
            response=page.goto(url,wait_until='domcontentloaded',timeout=25000)
            page.wait_for_timeout(700)
            initial=redact(page.locator('body').inner_text(timeout=5000))
            if re.search(r'verify (?:you are|that you are) human|captcha|access denied',initial[:1800],re.I):raise ValueError('The page requires verification. Browser inspection stopped without bypassing it.')
            page.screenshot(path=str(folder/'before.png'),mask=[page.locator('input'),page.locator('textarea'),page.locator('[data-private]')])
            for a in actions:
                kind=a.get('type');target=a.get('target','')
                if kind not in {'click','type','scroll','wait'}:raise ValueError('Unsupported browser action.')
                if kind in {'click','type'}:
                    if re.search(r'send|publish|delete|buy|pay|purchase|sign.?in|log.?in|register|subscribe|password|token|secret|security',target,re.I):raise ValueError('Sensitive actions are not enabled in the research browser.')
                    locator=page.get_by_role('button',name=target,exact=True) if a.get('by','text')=='button' else page.get_by_text(target,exact=True) if a.get('by','text')=='text' else page.locator(target)
                    if locator.count()!=1:raise ValueError('The target must match exactly one visible element.')
                    if kind=='click':locator.click()
                    else:
                        if (locator.get_attribute('type') or '').lower()=='password' or re.search(r'password|token|secret|credential',str(locator.get_attribute('name'))+' '+str(locator.get_attribute('id')),re.I):raise ValueError('Credential entry is not enabled.')
                        locator.fill(str(a.get('value',''))[:500])
                elif kind=='scroll':page.mouse.wheel(0,max(-1500,min(1500,int(a.get('amount',600)))))
                else:page.wait_for_timeout(min(2000,max(100,int(a.get('milliseconds',500)))))
                steps.append({'type':kind,'target':redact(target),'result':'completed'});page.wait_for_timeout(250)
            text=redact(page.locator('body').inner_text(timeout=5000));page.screenshot(path=str(folder/'screenshot.png'),mask=[page.locator('input'),page.locator('textarea'),page.locator('[data-private]')])
            accessibility=redact(page.locator('body').aria_snapshot())
            cookies=[{k:c[k] for k in ['name','domain','path','httpOnly','secure','sameSite']} for c in context.cookies()]
            result={'url':safe_log_url(page.url),'title':redact(page.title()),'browser':'Isolated Google Chrome via Playwright 1.56.0','user_chrome_connected':False,'status':response.status if response else None,'before_text':initial,'text':text,'accessibility':accessibility,'console':errors,'failed_requests':failed,'responses':responses,'blocked_requests':blocked,'cookies':cookies,'steps':steps,'downloads':downloads,'seconds':round(time.monotonic()-started,2),'screenshots':['before.png','screenshot.png'],'limitations':['Public isolated session; no access to your Chrome logins or tabs.','Page-changing HTTP methods and sensitive actions are blocked.','DOM/network evidence alone does not prove a backend root cause.']}
            (folder/'browser-result.json').write_text(json.dumps(result,ensure_ascii=False))
        finally:context.close();browser.close();proxy.shutdown()
    (folder/'browser-input.json').unlink(missing_ok=True)

if __name__=='__main__':
    def cancelled(*_):raise InterruptedError('Browser inspection cancelled.')
    signal.signal(signal.SIGTERM,cancelled)
    folder=Path(sys.argv[1])
    try:run(folder)
    except Exception as e:
        (folder/'browser-result.json').write_text(json.dumps({'error':redact(e)[:1000],'user_chrome_connected':False}));(folder/'browser-input.json').unlink(missing_ok=True);sys.exit(1)
