"""Search, page reading and source provenance; snippets are never full reads."""
from html.parser import HTMLParser
from urllib.parse import urljoin,urlsplit,urlencode,parse_qs
import concurrent.futures,copy,datetime,hashlib,json,re,threading,time
from .latency import remaining
from .net import fetch,validate_url,safe_log_url,redact
from .documents import parse_limited

class Page(HTMLParser):
    def __init__(self):super().__init__();self.skip=0;self.title_on=False;self.title=[];self.parts=[];self.links=[];self.date=None;self.modified=None
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag in {'script','style','noscript','nav','footer','header','svg'}:self.skip+=1
        if tag=='title':self.title_on=True
        if tag=='meta':
            key=a.get('property',a.get('name','')).lower()
            if key in {'article:published_time','date','datepublished','dc.date.issued'}:self.date=a.get('content')
            if key in {'article:modified_time','datemodified'}:self.modified=a.get('content')
        if tag=='a' and a.get('href'):self.links.append(a['href'])
        if tag in {'p','br','div','li','h1','h2','h3','tr'}:self.parts.append('\n')
    def handle_endtag(self,tag):
        if tag in {'script','style','noscript','nav','footer','header','svg'}:self.skip=max(0,self.skip-1)
        if tag=='title':self.title_on=False
    def handle_data(self,data):
        if self.title_on:self.title.append(data)
        if not self.skip:self.parts.append(data+' ')

def relevance(text,question,limit=4200):
    question=re.sub(r'https?://\S+','',question)
    identifiers=re.findall(r'\b[a-zA-Z_]\w*(?:\.\w+)+\b',question)
    for identifier in identifiers:text=re.sub(re.escape(identifier).replace(r'\.',r'\.[ \t]*'),lambda m:identifier,text)
    words={x for x in re.findall(r'\w+',question.casefold()) if len(x)>2 and x not in {'read','explain','source','sources','brief','points','using','with','what','does','cite','three','give','short','table','https'}}
    paras=[x.strip() for x in re.split(r'\n+',text) if x.strip()]
    if not paras:paras=[text]
    chunks=[]
    for p in paras:
        for i in range(0,len(p),1400):chunks.append(p[i:i+1400])
    ranked=sorted(enumerate(chunks),key=lambda x:(sum(w in x[1].casefold() for w in words)+20*sum(w.casefold() in x[1].casefold() for w in identifiers),-x[0]),reverse=True)[:4]
    return '\n\n'.join(c for _,c in ranked)[:limit]

def search_match(query,title,url,snippet):
    """Reject clearly unrelated SERPs; this is lexical relevance, not fact checking."""
    filler={'the','and','for','with','from','about','what','when','where','who','how','why','are','was','this','that','current','latest','recent','today','please','research','search','find','official','documentation','sources'}
    terms={w.rstrip('s') if len(w)>4 else w for w in re.findall(r'\w+',query.casefold()) if len(w)>2 and w not in filler}
    if not terms:return True
    text=(title+' '+url+' '+snippet).casefold()
    return sum(t in text for t in terms)>=min(2,len(terms))

def available_search_engines():
    # Unknown engine names trigger an implicit automatic/Wikipedia fallback.
    # Select only engines enabled in the installed version.
    from ddgs.engines import ENGINES
    engines=[x for x in ['google','yahoo','bing','duckduckgo','brave','mojeek','startpage'] if x in ENGINES.get('text',{})]
    return engines if 'google' in engines else ['google_public']+engines

class GoogleLinks(HTMLParser):
    """Read public search links only. No sign-in, cookies or verification bypass."""
    def __init__(self):super().__init__();self.href=None;self.title=[];self.results=[]
    def handle_starttag(self,tag,attrs):
        if tag=='a':self.href=dict(attrs).get('href');self.title=[]
    def handle_data(self,text):
        if self.href:self.title.append(text)
    def handle_endtag(self,tag):
        if tag!='a' or not self.href:return
        href=self.href;title=' '.join(self.title).strip();self.href=None
        if href.startswith('/url?'):href=parse_qs(urlsplit(href).query).get('q',parse_qs(urlsplit(href).query).get('url',['']))[0]
        host=urlsplit(href).hostname or ''
        if href.startswith('https://') and title and not any(host==x or host.endswith('.'+x) for x in ['google.com','google.co.in','googleusercontent.com','youtube.com']):self.results.append({'href':href,'title':title,'body':''})

def google_public_search(query,limit,timelimit,cancel):
    args={'q':query,'num':str(min(limit,10)),'gbv':'1'}
    if timelimit:args['tbs']='qdr:'+timelimit
    r=fetch('https://www.google.com/search?'+urlencode(args),cancel=cancel,timeout=max(.2,min(5,remaining(cancel,8))))
    if r['status']>=400:raise ValueError('Google returned HTTP '+str(r['status']))
    text=r['body'].decode('utf-8',errors='replace')
    if re.search(r'captcha|unusual traffic|verify (?:you are|that you are) human|before you continue to google',text[:100000],re.I):raise ValueError('Google requested an access check; no bypass was attempted.')
    p=GoogleLinks();p.feed(text)
    if not p.results:raise ValueError('Google did not expose readable public results; use the extension Google button for an interactive search.')
    return p.results[:limit]

def search_variants(query):
    filler={'current','latest','recent','the','a','an','in','for','of','with','please'}
    compact=' '.join(w for w in query.split() if w.casefold() not in filler)
    compact=re.sub(r'\bjob opening\b','job openings',compact,flags=re.I)
    return [query]+([compact] if compact!=query and len(compact.split())>=2 else [])

class Web:
    def __init__(self):self.cache={};self.pages={};self.lock=threading.Lock()
    def search(self,query,limit=5,timelimit=None,domains=(),cancel=None):
        if cancel and cancel.is_set():raise InterruptedError('Stopped')
        query=query[:400];subject=query
        suffix=' ('+' OR '.join('site:'+d for d in domains)+')' if domains else ''
        key=(query,timelimit,limit,tuple(domains),getattr(cancel,'owner',None))
        use_cache=getattr(cancel,'cache_allowed',True)
        with self.lock:cached=self.cache.get(key)
        if use_cache and cached and time.time()-cached[0]<300:return {'results':cached[1],'cached':True,'engine':cached[2]}
        from ddgs import DDGS
        # Try different engines before repeating a rewritten query on one engine.
        errors=[];attempts=[(engine,q) for q in search_variants(query) for engine in available_search_engines()][:7]
        for backend,search_query in attempts:
            if cancel and cancel.is_set():raise InterruptedError('Stopped')
            try:
                rows=google_public_search(search_query+suffix,limit,timelimit,cancel) if backend=='google_public' else DDGS(timeout=max(.2,min(4,remaining(cancel,10)))).text(search_query+suffix,region='us-en',safesearch='moderate',timelimit=timelimit,max_results=limit,backend=backend)
                clean=[]
                for r in rows:
                    url=r.get('href') or r.get('url')
                    try:validate_url(url)
                    except (OSError,ValueError):continue
                    host=urlsplit(url).hostname
                    if host in {'www.bing.com','bing.com'} and urlsplit(url).path.startswith('/aclick'):continue
                    if host.endswith(('doubleclick.net','googleadservices.com')):continue
                    if domains and not any(host==d or host.endswith('.'+d) for d in domains):continue
                    if not search_match(subject,r.get('title',''),url,r.get('body','')):continue
                    clean.append({'url':url,'title':r.get('title',host),'snippet':r.get('body','')[:1000],'access':'snippet_only','published':r.get('date'),'engine':backend})
                if clean:
                    with self.lock:
                        if len(self.cache)>100:self.cache.clear()
                        if use_cache:self.cache[key]=(time.time(),clean,backend)
                    return {'results':clean,'cached':False,'engine':backend,'query_used':search_query,'previous_failures':errors}
                errors.append(backend+': no relevant public results')
            except Exception as e:errors.append(backend+': '+redact(str(e))[:180])
        return {'results':[],'error':'Search unavailable or no results. '+ '; '.join(errors),'engine':'DDGS public search'}
    def read(self,url,question='',cancel=None,allowed_origins=()):
        started=time.time();item={'url':url,'source':url,'title':safe_log_url(url),'access':'unread','retrieved':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        use_cache=getattr(cancel,'cache_allowed',False);cache_key=(url,tuple(allowed_origins),getattr(cancel,'owner',None))
        with self.lock:cached=self.pages.get(cache_key) if use_cache else None
        if cached and time.time()-cached[0]<cached[2]:
            item=copy.deepcopy(cached[1]);item['excerpt']=relevance(item['text'],question);item['cached']=True;item['cache_age_seconds']=round(time.time()-cached[0],2);return item
        try:
            r=fetch(url,cancel=cancel,allowed_origins=allowed_origins,timeout=max(.2,min(8,remaining(cancel,15))));item.update(url=r['url'],source=r['url'],http_status=r['status'],seconds=r['seconds'],redirects=r['redirects'])
            if r['status']>=400:raise ValueError('HTTP '+str(r['status'])+'; page content was not used.')
            body=r['body'];mime=r['mime'].lower()
            if 'pdf' in mime or body.startswith(b'%PDF'):
                d=parse_limited(body,'source.pdf');item['segments']=d['sections'];text='\n'.join(s['label']+': '+s['text'] for s in d['sections']);item['warnings']=d['warnings'];item['title']=urlsplit(r['url']).path.rsplit('/',1)[-1];item['format']='pdf'
            elif 'html' in mime or b'<html' in body[:1000].lower():
                charset=re.search(r'charset=([\w-]+)',mime);p=Page();p.feed(body.decode(charset[1] if charset else 'utf-8',errors='replace'));text=re.sub(r'[ \t]+',' ',''.join(p.parts));item.update(title=' '.join(p.title).strip() or item['title'],published=p.date,modified=p.modified,links=list(dict.fromkeys(urljoin(r['url'],x) for x in p.links if x.startswith(('http','/'))))[:150])
            elif mime.startswith(('text/','application/json')):text=body.decode('utf-8',errors='replace')
            else:raise ValueError('Unsupported page format: '+mime[:80])
            if len(text.strip())<80:raise ValueError('This page has little readable text; it may require JavaScript or sign-in.')
            if re.search(r'verify (?:you are|that you are) human|access denied|captcha|enable javascript and cookies',text[:1500],re.I):raise ValueError('The page requested a verification or access check; no bypass was attempted.')
            item.update(access='read',text=text[:120000],excerpt=relevance(text,question),content_sha256=hashlib.sha256(body).hexdigest(),partial=len(text)>120000,bytes=len(body))
            headers=r.get('headers',{});cache_control=headers.get('cache-control','').lower()
            max_age=re.search(r'max-age=(\d+)',cache_control);lifetime=min(300,int(max_age[1])) if max_age else 300
            item['cache_ttl_seconds']=lifetime if not r.get('sets_cookie') and not any(x in cache_control for x in ['no-store','private','no-cache']) else 0
            if use_cache and item['cache_ttl_seconds']>0:
                with self.lock:
                    if len(self.pages)>=80:self.pages.pop(next(iter(self.pages)))
                    self.pages[cache_key]=(time.time(),copy.deepcopy(item),lifetime)
        except InterruptedError:raise
        except Exception as e:item.update(access='blocked',error=redact(str(e))[:300])
        return item
    def clear(self,uid):
        with self.lock:
            self.cache={k:v for k,v in self.cache.items() if k[-1]!=uid}
            self.pages={k:v for k,v in self.pages.items() if k[-1]!=uid}
    def find(self,source,term):
        text=source.get('text',source.get('excerpt',''));matches=[]
        for m in re.finditer(re.escape(term),text,re.I):
            matches.append(text[max(0,m.start()-180):m.end()+260])
            if len(matches)>=12:break
        return matches

def general_guidance_fallback(prompt,search_mode,urls):
    """Keep ordinary planning usable when optional search fails; never fake evidence."""
    if search_mode!='auto' or urls:return False
    if re.search(r'\b(research|search|verify|cite|citations?|sources?|official|documentation|latest|current|today|news|price|cost|budget|law|legal|medical|diagnos|health|tax|invest|security|exploit|version|API|rankings?|statistics?|studies)\w*\b',prompt,re.I):return False
    # A narrow set of low-stakes planning/explanation requests. Other requests
    # retain the evidence requirement rather than silently becoming guesses.
    return bool(re.search(r'\b(?:how (?:to|can I|do I) (?:plan|brainstorm|outline)|(?:plan|outline) (?:a|an|my|the) (?:website|presentation|story|draft)|brainstorm (?:ideas|topics))\b',prompt,re.I))

def plan(prompt,effort,mode,search_mode='auto',has_private=False):
    urls=list(dict.fromkeys(x.rstrip(').,;') for x in re.findall(r'https?://[^\s<>`]+',prompt)))[:8]
    requested=bool(re.search(r'\b(research|verify|search|find|browse|look up|weather|what is|what are|how does|how to|how can|how do|learn how|where is|when was|latest|current|today|news|sources?|compare|recommend|price|law|medical|documentation|fact.check|who is|debug|inspect)\b|खोज|ताज़ा|ताजा|जानकारी|जांच|research|dhundo',prompt,re.I))
    deep=bool(re.search(r'deep research|every detail|in.depth|comprehensive|हर जानकारी',prompt,re.I)) or mode=='beast'
    limits={'instant':(1,2,800),'medium':(1,3,1600),'high':(3,6,4200),'max':(4,8,5200),'ultra':(5,10,6500)}
    q,n,chars=limits[effort]
    if deep and effort in {'high','max','ultra'}:q=max(q,3);n=max(n,6);chars=max(chars,4200)
    broader=bool(re.search(r'\b(search|find|look up|additional sources|other sources|verify independently)\b',re.sub(r'https?://\S+','',prompt),re.I))
    search=search_mode=='on' or (search_mode=='auto' and requested and not has_private and (not urls or broader))
    if search_mode=='off':search=False
    base=re.sub(r'https?://\S+','',prompt).strip()[:300]
    # Search terms omit answer-format instructions, which otherwise degrade recall.
    base=re.split(r'[.!?](?:\s|$)',base)[0]
    # Remove conversational lead-ins without changing the subject/location.
    for _ in range(4):
        base=re.sub(r'(?i)^(?:(?:please|can you|could you)\s+|do\s+(?:some\s+)?research\s+(?:and\s+)?|help\s+me\s+(?:with\s+)?|tell\s+me\s+(?:about\s+)?)','',base).strip()
    base=re.sub(r'(?i)^(?:please\s+)?(?:research|search(?: for)?|find(?: information about)?|verify|compare)\s+','',base)
    base=re.sub(r'(?i)\s+(?:using|with|from)\s+(?:current\s+|official\s+)?(?:documentation|sources|citations).*','',base)
    base=' '.join(base.split()[:22])
    queries=[x.strip() for x in re.split(r';|\n',base) if len(x.strip())>8][:q] or [base or prompt[:200]]
    if search and deep and len(queries)==1:queries+=( [base+' official documentation',base+' limitations evidence'][:q-1])
    # "Current" pages (for example a live careers board) may be undated.
    # Only infer a strict date window when the user actually supplies one.
    time_filter='d' if re.search(r'\btoday\b|आज',prompt,re.I) else 'm' if re.search(r'\bthis month\b',prompt,re.I) else None
    return {'general_fallback':general_guidance_fallback(prompt,search_mode,urls),'search':search,'queries':queries[:q],'urls':urls,'max_sources':n,'excerpt_chars':chars,'deep':deep,'time_filter':time_filter,'follow_links':not urls or broader,'debug':bool(urls and re.search(r'\b(debug|inspect|broken|console|button|website issue)\b',prompt,re.I)),'scope':'Comprehensive bounded research' if deep else 'Focused answer','private_web_blocked':has_private and search_mode=='auto' and requested}
