"""Deterministic arithmetic for explicit numeric questions; no eval or code execution."""
import ast,decimal,re

def calculate(prompt):
    text=prompt.strip().lower().split('?')[0].strip().rstrip('.')
    text=re.sub(r'^(?:what is|what\'s|calculate|compute|evaluate|solve)\s+','',text)
    for word,value in {'zero':'0','one':'1','two':'2','three':'3','four':'4','five':'5','six':'6','seven':'7','eight':'8','nine':'9','ten':'10','plus':'+','minus':'-','multiplied by':'*','times':'*','divided by':'/','to the power of':'**'}.items():text=re.sub(r'\b'+word+r'\b',value,text)
    text=text.replace('×','*').replace('÷','/').replace('^','**')
    if len(text)>160 or not re.fullmatch(r'[0-9.()+*/%\s-]+',text) or not re.search(r'[+*/%-]',text):return None
    try:tree=ast.parse(text,mode='eval')
    except SyntaxError:return None
    if len(list(ast.walk(tree)))>60:raise ValueError('The arithmetic expression is too long.')
    def run(n):
        if isinstance(n,ast.Expression):return run(n.body)
        if isinstance(n,ast.Constant) and type(n.value) in {int,float}:return decimal.Decimal(str(n.value))
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):return run(n.operand)*(-1 if isinstance(n.op,ast.USub) else 1)
        if not isinstance(n,ast.BinOp):raise ValueError('Unsupported arithmetic.')
        a,b=run(n.left),run(n.right)
        if isinstance(n.op,ast.Add):v=a+b
        elif isinstance(n.op,ast.Sub):v=a-b
        elif isinstance(n.op,ast.Mult):v=a*b
        elif isinstance(n.op,ast.Div):v=a/b
        elif isinstance(n.op,ast.Mod):v=a%b
        elif isinstance(n.op,ast.Pow):
            if b!=b.to_integral_value() or abs(b)>12:raise ValueError('Use an integer exponent between -12 and 12.')
            v=a**int(b)
        else:raise ValueError('Unsupported arithmetic.')
        if not v.is_finite() or abs(v)>decimal.Decimal('1e40'):raise ValueError('The arithmetic result exceeds the supported range.')
        return v
    try:
        with decimal.localcontext() as ctx:ctx.prec=28;value=run(tree)
    except decimal.DecimalException:raise ValueError('This expression cannot be evaluated, for example because it divides by zero.')
    answer=format(value,'f')
    if '.' in answer:answer=answer.rstrip('0').rstrip('.')
    return {'expression':text,'answer':answer,'precision_digits':28}
