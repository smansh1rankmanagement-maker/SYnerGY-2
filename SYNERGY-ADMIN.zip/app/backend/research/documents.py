"""Bounded parsers; originals remain separate from extracted evidence."""
from pathlib import Path
from io import BytesIO, StringIO
import csv, json, zipfile, threading
_PARSE_SLOTS=threading.BoundedSemaphore(2)

TEXT={'.txt','.md','.csv','.json','.py','.js','.ts','.tsx','.jsx','.html','.css','.php','.sql','.yaml','.yml','.xml','.log','.sh','.java','.c','.cpp','.go','.rs'}
SUPPORTED=TEXT|{'.pdf','.docx','.xlsx','.png','.jpg','.jpeg','.webp','.gif','.tif','.tiff','.mp4','.mov','.webm'}

def parse_path(path,name):
    if not _PARSE_SLOTS.acquire(blocking=False):raise ValueError("Your original is saved. File analysis is busy; try again shortly.")
    try:return _parse_path(path,name)
    finally:_PARSE_SLOTS.release()

def _parse_path(path,name):
    import tempfile,subprocess,sys
    with tempfile.TemporaryDirectory(prefix='synergy-read-') as tmp:
        out=Path(tmp)/'result.json'
        try:r=subprocess.run([sys.executable,str(Path(__file__)),str(path),name,str(out)],capture_output=True,timeout=95)
        except subprocess.TimeoutExpired:raise ValueError('The original is saved, but analysis exceeded 95 seconds. Use a smaller document or excerpt.')
        if not out.exists():raise ValueError('The original is saved; analysis stopped at its memory or format limit.')
        result=json.loads(out.read_text())
        if r.returncode or result.get('error'):raise ValueError(result.get('error','The document could not be read.'))
        return result

def parse_limited(data,name):
    import tempfile
    with tempfile.TemporaryDirectory(prefix='synergy-input-') as tmp:
        path=Path(tmp)/'original';path.write_bytes(data);path.chmod(0o600)
        return parse_path(path,name)

def parse(data,name):
    ext=Path(name).suffix.lower();sections=[];warnings=[];total=0
    if ext not in SUPPORTED:raise ValueError('Supported: PDF, DOCX, XLSX, UTF-8 text/code, CSV, PNG and JPEG.')
    if not data or len(data)>200*1024*1024:raise ValueError('Use a file up to 200 MB.')
    def add(label,text):
        nonlocal total
        text=str(text).strip();remaining=max(0,120000-total)
        if len(text)>min(12000,remaining):warnings.append(label+' was shortened to the extraction limit.')
        text=text[:min(12000,remaining)];total+=len(text)
        if text:sections.append({'label':label,'text':text})
    if ext in {'.png','.jpg','.jpeg','.webp','.gif','.tif','.tiff'}:
        from PIL import Image,ImageOps
        import base64
        with Image.open(BytesIO(data)) as im:
            if im.format not in {'PNG','JPEG','WEBP','GIF','TIFF'} or im.width*im.height>80000000:raise ValueError('Original saved. Image analysis supports up to 80 megapixels.')
            im=ImageOps.exif_transpose(im);im.thumbnail((1280,1280));preview=BytesIO();im.convert('RGB').save(preview,format='JPEG',quality=85)
        return {'sections':[],'warnings':['The original is preserved. Vision reads a preview up to 1280 pixels; fine print and OCR require verification. Animated images use the first frame.'],'kind':'image','partial':True,'preview_image':base64.b64encode(preview.getvalue()).decode()}
    if ext=='.pdf':
        from pypdf import PdfReader
        reader=PdfReader(BytesIO(data))
        if reader.is_encrypted:raise ValueError('Password-protected PDFs are not supported. Upload an unlocked copy you may read.')
        if len(reader.pages)>50:warnings.append('Only the first 50 PDF pages were processed.')
        for i,page in enumerate(reader.pages[:50]):
            if total>=120000:break
            content=page.get_contents()
            if content and len(content.get_data())>8*1024*1024:warnings.append(f'Page {i+1} skipped: content stream too large.');continue
            text=page.extract_text() or ''
            if not text.strip():warnings.append(f'Page {i+1}: no extractable text; scanned pages need OCR.')
            add(f'Page {i+1}',text)
        page_count=len(reader.pages)
    elif ext in {'.docx','.xlsx'}:
        with zipfile.ZipFile(BytesIO(data)) as archive:
            if sum(x.file_size for x in archive.infolist())>40*1024*1024:raise ValueError('The expanded document exceeds 40 MB.')
            if any(x.flag_bits&1 for x in archive.infolist()):raise ValueError('Encrypted documents are not supported.')
        if ext=='.docx':
            from docx import Document
            doc=Document(BytesIO(data))
            for i,p in enumerate(doc.paragraphs):
                if total>=120000:break
                add(f'Paragraph {i+1}',p.text)
            for i,t in enumerate(doc.tables[:30]):add(f'Table {i+1}','\n'.join(' | '.join(c.text for c in row.cells) for row in t.rows[:200]))
            warnings.append('DOCX page numbers, text boxes, drawings, tracked changes and headers are not fully represented.')
        else:
            from openpyxl import load_workbook
            book=load_workbook(BytesIO(data),read_only=True,data_only=True,keep_links=False)
            try:
                for sheet in list(book.worksheets)[:8]:
                    for start in range(1,min(sheet.max_row or 1,1000)+1,100):
                        rows=list(sheet.iter_rows(min_row=start,max_row=min(start+99,sheet.max_row or 1,1000),max_col=min(sheet.max_column or 1,30),values_only=True))
                        add(f'Sheet {sheet.title}, rows {start}–{start+len(rows)-1}','\n'.join(' | '.join('' if c is None else str(c) for c in row) for row in rows))
                    if (sheet.max_row or 0)>1000 or (sheet.max_column or 0)>30:warnings.append(f'{sheet.title}: read at most 1,000 rows and 30 columns.')
                if len(book.worksheets)>8:warnings.append('Only the first 8 sheets were read.')
                warnings.append('Formula cells use saved cached values; formulas and macros are not executed.')
            finally:book.close()
    else:
        try:text=data.decode('utf-8-sig')
        except UnicodeError:raise ValueError('Text files must use UTF-8 encoding.')
        lines=text.splitlines()
        for i in range(0,len(lines),80):
            if total>=120000:warnings.append('The text file was shortened to 120,000 characters.');break
            add(f'Lines {i+1}–{min(i+80,len(lines))}','\n'.join(lines[i:i+80]))
    return {'sections':sections,'warnings':warnings,'kind':ext.lstrip('.'),'partial':bool(warnings),'page_count':locals().get('page_count')}

if __name__=='__main__':
    import sys,resource
    try:resource.setrlimit(resource.RLIMIT_AS,(1536*1024*1024,1536*1024*1024))
    except (ValueError,OSError):pass
    try:
        p=Path(sys.argv[1]);name=sys.argv[2]
        if Path(name).suffix.lower() in {'.mp4','.mov','.webm'}:
            import subprocess,tempfile,base64,math
            probe=subprocess.run(['ffprobe','-v','error','-protocol_whitelist','file,pipe','-show_format','-show_streams','-of','json',str(p)],capture_output=True,timeout=20,check=True);info=json.loads(probe.stdout);duration=float(info['format']['duration']);v=next(x for x in info['streams'] if x.get('codec_type')=='video')
            if not math.isfinite(duration) or not 0<duration<=1800 or int(v['width'])*int(v['height'])>8294400:raise ValueError('Original saved. Video analysis supports up to 30 minutes and 4K frames.')
            images=[];times=[]
            with tempfile.TemporaryDirectory() as tmp:
                for i,f in enumerate([.02,.33,.66,.95]):
                    frame=Path(tmp)/f'{i}.jpg';second=round(min(duration*f,max(0,duration-.5)),3)
                    subprocess.run(['ffmpeg','-v','error','-nostdin','-protocol_whitelist','file,pipe','-threads','1','-ss',str(second),'-i',str(p),'-map','0:v:0','-frames:v','1','-vf','scale=960:960:force_original_aspect_ratio=decrease','-threads','1','-q:v','4',str(frame)],capture_output=True,timeout=15,check=True)
                    images.append(base64.b64encode(frame.read_bytes()).decode());times.append(second)
            result={'sections':[],'kind':'video','partial':True,'preview_images':images,'warnings':['Only four sampled video frames at '+str(times)+' seconds were analysed. Audio, unsampled scenes and exact animation timing were not analysed. Original preserved.']}
        else:result=parse(p.read_bytes(),name)
        Path(sys.argv[3]).write_text(json.dumps(result,ensure_ascii=False))
    except Exception as e:Path(sys.argv[3]).write_text(json.dumps({'error':str(e)[:300]}));sys.exit(1)
