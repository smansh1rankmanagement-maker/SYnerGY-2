"""Bounded public HTTP reads with DNS pinning and redirect validation."""
import http.client, ipaddress, re, socket, ssl, time
from urllib.parse import urlsplit, urlunsplit, urljoin, parse_qsl, urlencode

SENSITIVE=re.compile(r'password|passwd|secret|token|api.?key|authorization|session|signature|credential',re.I)

def redact(text):
    text=str(text)
    text=re.sub(r'(?i)(Bearer\s+)[\w.\-]+',r'\1[redacted]',text)
    text=re.sub(r'(?i)((?:password|token|api.?key|secret|session|authorization)(?:"\s*:\s*"?|\s*[=:]\s*))[^\s,;"<>]+',r'\1[redacted]',text)
    text=re.sub(r'(?i)((?:set-cookie|cookie|authorization)\s*:\s*)[^\n]+',r'\1[redacted]',text)
    text=re.sub(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', '[email redacted]',text)
    return text[:12000]

def safe_log_url(url):
    try:
        u=urlsplit(url)
        host=u.hostname or ''
        if ':' in host:host='['+host+']'
        if u.port:host+=':'+str(u.port)
        return urlunsplit((u.scheme,host,u.path,'',''))[:500]
    except ValueError:return '[invalid URL]'

def validate_url(url,allowed_origins=()):
    if not isinstance(url,str) or len(url)>2500 or re.search(r'[\x00-\x20\\]',url):raise ValueError('Use a normal HTTP or HTTPS URL.')
    u=urlsplit(url)
    if u.scheme not in {'http','https'} or not u.hostname or u.username or u.password:raise ValueError('Only HTTP(S) URLs without embedded credentials are supported.')
    try:port=u.port or (443 if u.scheme=='https' else 80)
    except ValueError:raise ValueError('Invalid URL port.')
    origin=f'{u.scheme}://{u.netloc}'
    local_allowed=origin in allowed_origins
    if port not in {80,443} and not local_allowed:raise ValueError('This port is not enabled for website inspection.')
    if any(SENSITIVE.search(k) for k,v in parse_qsl(u.query)):raise ValueError('Remove credential or session parameters from the URL.')
    host=u.hostname.encode('idna').decode('ascii')
    resolved=socket.getaddrinfo(host,port,type=socket.SOCK_STREAM)
    ips=list(dict.fromkeys(r[4][0] for r in resolved))
    if not ips or (not local_allowed and any(not ipaddress.ip_address(ip).is_global for ip in ips)):
        raise ValueError('Private, local and metadata addresses are blocked. Use an authorised public website.')
    return u,host,port,ips

def fetch(url,*,allowed_origins=(),limit=8*1024*1024,timeout=15,cancel=None,method='GET',allowed_hosts=None):
    redirects=[];started=time.monotonic()
    for _ in range(6):
        if cancel and cancel.is_set():raise InterruptedError('Stopped')
        if allowed_hosts is not None and urlsplit(url).hostname not in allowed_hosts:raise ValueError('Redirect outside the authorised website was not followed.')
        u,host,port,ips=validate_url(url,allowed_origins)
        if cancel and hasattr(cancel,'deadline'):timeout=max(.1,min(timeout,cancel.deadline-time.monotonic()))
        sock=socket.create_connection((ips[0],port),timeout=timeout)
        if u.scheme=='https':sock=ssl.create_default_context().wrap_socket(sock,server_hostname=host)
        conn=http.client.HTTPConnection(host,port,timeout=timeout);conn.sock=sock
        try:
            conn.request(method,urlunsplit(('','',u.path or '/',u.query,'')),headers={'Host':u.netloc,'User-Agent':'SYnerGY-Research/1.5.1 (public page reader)','Accept':'text/html,application/pdf,text/plain;q=0.9,*/*;q=0.1','Accept-Encoding':'identity'})
            resp=conn.getresponse();headers={k.lower():v for k,v in resp.getheaders()};status=resp.status
            if status in {301,302,303,307,308} and headers.get('location'):
                redirects.append({'url':safe_log_url(url),'status':status});url=urljoin(url,headers['location']);continue
            if int(headers.get('content-length','0') or 0)>limit:raise ValueError('The page or file exceeds the download limit.')
            chunks=[];size=0
            while True:
                if cancel and cancel.is_set():raise InterruptedError('Stopped')
                data=resp.read(min(65536,limit+1-size))
                if not data:break
                chunks.append(data);size+=len(data)
                if size>limit:raise ValueError('The page or file exceeds the download limit.')
                if time.monotonic()-started>45:raise TimeoutError('Page read timed out.')
            return {'url':url,'status':status,'mime':headers.get('content-type',''),'body':b''.join(chunks),'redirects':redirects,'seconds':round(time.monotonic()-started,3),'sets_cookie':'set-cookie' in headers,'headers':{k:headers[k] for k in ['content-type','last-modified','content-security-policy','access-control-allow-origin','x-robots-tag','cache-control'] if k in headers}}
        finally:conn.close()
    raise ValueError('Too many redirects.')
