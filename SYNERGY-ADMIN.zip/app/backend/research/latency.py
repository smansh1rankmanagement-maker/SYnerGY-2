"""Soft response targets plus a separate operational watchdog, never a usage quota."""
import time

LEVELS = {
    'instant': {'seconds': 5, 'research_seconds': 20, 'num_ctx': 4096, 'num_predict': 256, 'label': '3–5 seconds target'},
    'medium': {'seconds': 10, 'research_seconds': 30, 'num_ctx': 6144, 'num_predict': 512, 'label': '5–10 seconds target'},
    'high': {'seconds': 60, 'research_seconds': 45, 'num_ctx': 8192, 'num_predict': 1200, 'label': '1 minute target'},
    'max': {'seconds': 120, 'research_seconds': 60, 'num_ctx': 12288, 'num_predict': 2000, 'label': '2 minutes target'},
    'ultra': {'seconds': 120, 'research_seconds': 90, 'num_ctx': 16384, 'num_predict': 3000, 'label': '2 minutes target'},
}
JOB_TIMEOUT_SECONDS = 900

class BudgetExpired(TimeoutError):
    pass

class PhaseStop:
    """Limit retrieval without cancelling a completed answer or a parent job."""
    def __init__(self, parent, deadline, cache_allowed=True, owner=None):
        self.parent, self.deadline = parent, deadline
        self.cache_allowed, self.owner = cache_allowed, owner
    def is_set(self):
        return self.parent.is_set() or time.monotonic() >= self.deadline
    def wait(self, seconds):
        return self.parent.wait(min(seconds, remaining(self))) or self.is_set()

def remaining(stop, default=30):
    return max(0, getattr(stop, 'deadline', time.monotonic()+default)-time.monotonic())

def policy(effort):
    return {**LEVELS[effort], 'soft_target': True, 'job_timeout_seconds': JOB_TIMEOUT_SECONDS, 'message_quota': None}

def catalog():
    return {'levels': {k: policy(k) for k in LEVELS}, 'scope': 'Text answers and research; media rendering, code builds and external actions have separate job limits.', 'guaranteed': False}
