"""Email accounts, prepaid access and auditable manual UPI reconciliation.

Payment references are customer declarations. They grant provisional access by
owner policy; only an administrator can mark bank receipt verified.
"""
import launch_pricing
import csv, hashlib, hmac, io, json, re, secrets, sqlite3, time, uuid
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from urllib.parse import urlencode
from zoneinfo import ZoneInfo

IST=ZoneInfo('Asia/Kolkata')
PLANS={f'{mode}-{days}':{'id':f'{mode}-{days}','mode':mode,'days':days,'amount_paise':amount*100,'currency':'INR'} for mode,prices in [('work',[(7,99),(15,200),(30,300)]),('beast',[(7,649),(15,1149),(30,1500)])] for days,amount in prices}
UPI='smanshonerank@ptyes'
BENEFICIARY='SATISH KUMAR SINGH'
EMAIL='synergyai@1rank.in'
PHONE='919113432032'
NOTICE='These prices are only for early access. Prices may vary by country once we officially launch.'
class AccessRequired(PermissionError):pass

def digest(s):return hashlib.sha256(s.encode()).hexdigest()
def derive(p,s):return hashlib.scrypt(p.encode('utf-8'),salt=s,n=2**14,r=8,p=1,dklen=32)
def email_value(v):
 if not isinstance(v,str) or len(v)>254 or not re.fullmatch(r'[^\s@]+@[^\s@.]+(?:\.[^\s@.]+)+',v.strip()):raise ValueError('Enter a valid email address.')
 return v.strip().lower()
def password_value(p):
 if not isinstance(p,str) or not 12<=len(p)<=128:raise ValueError('Use a password with 12–128 characters.')
 return p
def reference(v):
 if not isinstance(v,str):raise ValueError('Enter the payment reference.')
 v=re.sub(r'[ -]','',v).upper()
 if not re.fullmatch(r'[A-Z0-9]{6,64}',v):raise ValueError('Use the 6–64 letters or digits shown in the transaction ID and UTR.')
 return v
def money(v):
 try:
  n=Decimal(str(v).replace(',','').replace('₹','').strip())
  if not n.is_finite() or n<=0 or n!=n.quantize(Decimal('.01')):raise ValueError()
  return int(n*100)
 except (ValueError,InvalidOperation):raise ValueError('Use a positive INR amount with up to two decimal places.')

class Membership:
 def __init__(self,db):
  self.db=db
  with self.connect() as c:
   columns={r['name'] for r in c.execute('PRAGMA table_info(users)')}
   for name,sql in [('email','TEXT'),('full_name',"TEXT NOT NULL DEFAULT ''"),('phone',"TEXT NOT NULL DEFAULT ''"),('role',"TEXT NOT NULL DEFAULT 'user'"),('account_state',"TEXT NOT NULL DEFAULT 'active'"),('created','REAL'),('email_verified','INTEGER NOT NULL DEFAULT 0')]:
    if name not in columns:c.execute('ALTER TABLE users ADD COLUMN '+name+' '+sql)
   c.executescript('''
    CREATE UNIQUE INDEX IF NOT EXISTS users_unique_email ON users(lower(email)) WHERE email IS NOT NULL;
    CREATE TABLE IF NOT EXISTS account_recovery(user_id INTEGER PRIMARY KEY,key_hash TEXT NOT NULL,expires REAL,updated REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS payment_orders(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,plan_id TEXT NOT NULL,amount_paise INTEGER NOT NULL,currency TEXT NOT NULL,state TEXT NOT NULL,created REAL NOT NULL,submitted REAL,verified REAL,paid_at REAL,utr TEXT,transaction_id TEXT,review_note TEXT NOT NULL DEFAULT '',reviewer INTEGER,request_key TEXT NOT NULL,UNIQUE(user_id,request_key));
    CREATE TABLE IF NOT EXISTS payment_refs(value TEXT PRIMARY KEY,payment_id TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS subscriptions(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,mode TEXT NOT NULL,starts REAL NOT NULL,expires REAL NOT NULL,state TEXT NOT NULL,payment_id TEXT UNIQUE,created REAL NOT NULL,source TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS subscription_user ON subscriptions(user_id,expires);
    CREATE TABLE IF NOT EXISTS membership_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,actor INTEGER,kind TEXT NOT NULL,target TEXT NOT NULL,details TEXT NOT NULL,created REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS bank_reviews(id TEXT PRIMARY KEY,actor INTEGER NOT NULL,payload TEXT NOT NULL,created REAL NOT NULL,applied REAL);
    CREATE TABLE IF NOT EXISTS subscription_exceptions(id TEXT PRIMARY KEY,email TEXT NOT NULL,full_name TEXT NOT NULL,plan_id TEXT NOT NULL,state TEXT NOT NULL,user_id INTEGER,subscription_id TEXT,created REAL NOT NULL,activated REAL,actor INTEGER NOT NULL,note TEXT NOT NULL,request_key TEXT NOT NULL UNIQUE);
    CREATE UNIQUE INDEX IF NOT EXISTS exception_pending_email ON subscription_exceptions(email) WHERE state='pending';
   ''')
  with self.connect() as c:launch_pricing.initialize(c)
 def connect(self):
  c=sqlite3.connect(self.db,timeout=20);c.row_factory=sqlite3.Row;return c
 def audit(self,c,actor,kind,target,details):c.execute('INSERT INTO membership_audit(actor,kind,target,details,created) VALUES(?,?,?,?,?)',(actor,kind,str(target),json.dumps(details),time.time()))
 def profile(self,uid):
  with self.connect() as c:r=c.execute('SELECT id,username,email,full_name,phone,role,account_state,created,email_verified FROM users WHERE id=?',(uid,)).fetchone()
  if not r:raise KeyError('Account not found.')
  return dict(r)
 def active_user(self,uid):
  p=self.profile(uid);return p if p['account_state']=='active' else None
 def register(self,d):
  email=email_value(d.get('email'));password=password_value(d.get('password'))
  username=d.get('username') or email
  if not isinstance(username,str) or len(username)>254 or (username!=email and not re.fullmatch(r'[A-Za-z0-9_.-]{3,32}',username)):raise ValueError('Use your email address to register.')
  key='SYN-'+secrets.token_urlsafe(32);salt=secrets.token_bytes(16)
  with self.connect() as c:
   try:
    c.execute('BEGIN IMMEDIATE')
    if c.execute('SELECT 1 FROM users WHERE username=? COLLATE NOCASE OR lower(email)=?',(email,username.lower())).fetchone():raise ValueError('This email or username already has an account.')
    cur=c.execute('INSERT INTO users(username,salt,password,email,full_name,created) VALUES(?,?,?,?,?,?)',(username,salt,derive(password,salt),email,str(d.get('full_name','')).strip()[:100],time.time()));uid=cur.lastrowid;launch_pricing.allocate(c,uid)
    c.execute('INSERT INTO account_recovery VALUES(?,?,NULL,?)',(uid,digest(key),time.time()));self.audit(c,uid,'registered',uid,{'method':'email_password'})
   except sqlite3.IntegrityError:raise ValueError('This email or username already has an account. Sign in or use your recovery key.')
  return {**self.profile(uid),'recovery_key':key}
 def login(self,d):
  identity=d.get('email') or d.get('username','');password=d.get('password','')
  if not isinstance(identity,str) or not isinstance(password,str):raise ValueError('Invalid credentials.')
  with self.connect() as c:r=c.execute('SELECT * FROM users WHERE lower(email)=? OR username=? COLLATE NOCASE',(identity.strip().lower(),identity.strip())).fetchone()
  actual=derive(password[:128],r['salt'] if r else bytes(16))
  if not r or len(password)>128 or not hmac.compare_digest(actual,r['password']):raise PermissionError('Invalid email or password.')
  if r['account_state']!='active':raise PermissionError('This account is inactive. Contact SYnerGY support.')
  return self.profile(r['id'])
 def reset_password(self,d):
  email=email_value(d.get('email'));password=password_value(d.get('password'));key=d.get('recovery_key','')
  if not isinstance(key,str) or len(key)>200:raise ValueError('Invalid recovery key.')
  new_key='SYN-'+secrets.token_urlsafe(32);salt=secrets.token_bytes(16)
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT u.id,u.account_state,r.key_hash,r.expires FROM users u JOIN account_recovery r ON r.user_id=u.id WHERE lower(u.email)=?',(email,)).fetchone()
   if not r or r['account_state']!='active' or (r['expires'] and r['expires']<time.time()) or not hmac.compare_digest(r['key_hash'],digest(key)):raise PermissionError('Email or recovery key is invalid or expired.')
   c.execute('UPDATE users SET salt=?,password=? WHERE id=?',(salt,derive(password,salt),r['id']));c.execute('DELETE FROM sessions WHERE user_id=?',(r['id'],));c.execute('UPDATE account_recovery SET key_hash=?,expires=NULL,updated=? WHERE user_id=?',(digest(new_key),time.time(),r['id']))
   if c.execute("SELECT 1 FROM sqlite_master WHERE name='extension_tokens'").fetchone():c.execute('DELETE FROM extension_tokens WHERE user_id=?',(r['id'],))
   self.audit(c,r['id'],'password_reset',r['id'],{'subscriptions_preserved':True})
  return {'ok':True,'recovery_key':new_key,'message':'Password reset. Your subscription and payment history are unchanged. Save the new recovery key.'}
 def update_profile(self,uid,d):
  email=email_value(d.get('email'));name=str(d.get('full_name','')).strip()[:100];phone=str(d.get('phone','')).strip()
  if phone and not re.fullmatch(r'[+0-9 ()-]{7,24}',phone):raise ValueError('Enter a valid contact number.')
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE');u=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone();changed=email!=u['email']
   if changed and not hmac.compare_digest(derive(str(d.get('password',''))[:128],u['salt']),u['password']):raise PermissionError('Confirm your current password to change or add an email.')
   if changed and c.execute("SELECT 1 FROM sqlite_master WHERE name='project_transfers'").fetchone() and c.execute("SELECT 1 FROM project_transfers WHERE recipient_id=? AND state='approved'",(uid,)).fetchone():raise ValueError('This email has approved project transfers. Ask the administrator to revoke or reassign them before changing the email.')
   if changed and c.execute('SELECT 1 FROM users WHERE username=? COLLATE NOCASE AND id!=?',(email,uid)).fetchone():raise ValueError('That email already belongs to an account.')
   try:c.execute('UPDATE users SET email=?,full_name=?,phone=?,email_verified=CASE WHEN ? THEN 0 ELSE email_verified END WHERE id=?',(email,name,phone,changed,uid))
   except sqlite3.IntegrityError:raise ValueError('That email already belongs to an account.')
   self.audit(c,uid,'profile_updated',uid,{'email_changed':changed})
  return self.profile(uid)
 def recovery_key(self,uid,password):
  key='SYN-'+secrets.token_urlsafe(32)
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
   if not r['email']:raise ValueError('Save an email address first.')
   if not isinstance(password,str) or not hmac.compare_digest(derive(password[:128],r['salt']),r['password']):raise PermissionError('Confirm your current password.')
   c.execute('INSERT OR REPLACE INTO account_recovery VALUES(?,?,NULL,?)',(uid,digest(key),time.time()));self.audit(c,uid,'recovery_key_rotated',uid,{})
  return {'recovery_key':key}
 def entitlement(self,uid):
  u=self.profile(uid);now=time.time()
  with self.connect() as c:rows=[dict(r) for r in c.execute('SELECT * FROM subscriptions WHERE user_id=? ORDER BY expires DESC',(uid,))]
  active=[r for r in rows if r['state']=='active' and r['starts']<=now<r['expires']]
  cohort=launch_pricing.member(self,uid)
  access={'chat':u['account_state']=='active','work':False,'beast':False}
  if u['account_state']=='active':
   access['work']=u['role']=='admin' or any(r['mode'] in {'work','beast'} for r in active);access['beast']=u['role']=='admin' or any(r['mode']=='beast' for r in active)
  best=max(active,key=lambda r:(r['mode']=='beast',r['expires']),default=None)
  summary={'label':'Administrator' if u['role']=='admin' else ('ETERNAL '+best['mode'].title() if best else ('ETERNAL Chat trial' if now<cohort['trial_expires'] else 'Aerny 2.0 · Free Chat')),'mode':'beast' if u['role']=='admin' else best['mode'] if best else 'chat','expires':None if u['role']=='admin' else best['expires'] if best else cohort['trial_expires'] if now<cohort['trial_expires'] else None,'source':'administrator' if u['role']=='admin' else best['source'] if best else 'free','email':u['email'],'account_state':u['account_state']}
  if u['account_state']!='active':summary.update(label='Account inactive',mode='chat',expires=None)
  monthly=u['account_state']=='active'
  return {'chat_model':'eternal' if u['role']=='admin' or bool(active) or now<cohort['trial_expires'] else 'aerny','extension_work':u['account_state']=='active' and (u['role']=='admin' or bool(active) or now<cohort['trial_expires']),'cohort':cohort,'access':access,'subscriptions':rows,'profile':u,'plan':summary,'provider_access':{'synergy':access['chat'],'openai':monthly,'hybrid':monthly},'usage_policy':{'local_requests':'unmetered','daily_request_limit':None,'monthly_request_limit':None,'credits_required':False,'subscribed':bool(active) or u['role']=='admin','modes':access,'operational_limits':'Queues, per-request size, timeouts and storage safeguards still apply.','external_modes':['chat','work','beast'],'external_plan':'All active accounts in their included modes; shared provider allowance and privacy opt-in still apply'}}
 def chat_family(self,uid,family,mode='chat'):
  if family not in {'eternal','aerny'}:raise ValueError('Choose ETERNAL or Aerny.')
  return 'aerny' if mode=='chat' and self.entitlement(uid)['chat_model']=='aerny' else family
 def require_extension_work(self,uid):
  if not self.entitlement(uid)['extension_work']:raise AccessRequired('Extension Work is included during your Chat trial and with an active subscription. Your saved items are retained. Aerny Chat remains available.')
 def require(self,uid,mode):
  if mode not in {'chat','work','beast'}:raise ValueError('Choose Chat, Work or Beast.')
  if not self.active_user(uid):raise AccessRequired('This account is inactive. Contact SYnerGY support.')
  if not self.entitlement(uid)['access'][mode]:raise AccessRequired('ETERNAL '+mode.title()+' needs an active subscription. Open Settings → Subscriptions to activate access.')
 def require_provider(self,uid,provider,mode='chat'):
  if provider not in {'synergy','openai','hybrid'}:raise ValueError('Choose a supported provider.')
  self.require(uid,mode)
  if not self.entitlement(uid)['provider_access'][provider]:raise AccessRequired('This account cannot use external providers.')
 def provider_catalog(self,uid,catalog,mode='chat'):
  if mode not in {'chat','work','beast'}:mode='chat'
  entitlement=self.entitlement(uid);access={k:v and entitlement['access'][mode] for k,v in entitlement['provider_access'].items()}
  reason='This mode needs active account access'
  paid=entitlement['usage_policy']['subscribed']
  models=[{**m,'locked':not access['openai'] or (m.get('paid',False) and not paid),'available':m['available'] and access['openai'] and (not m.get('paid',False) or paid),'lock_reason':'Paid subscription or administrator required' if m.get('paid',False) and not paid else None} for m in catalog.get('openai_models',[])]
  default='gpt-6.1-sol' if paid else 'gpt-6-luna'
  return {**catalog,'mode':mode,'openai_models':models,'openai_model':default if catalog.get('openai_model') else None,'providers':[{**p,'locked':not access[p['id']],'lock_reason':None if access[p['id']] else reason,'available':p['available'] and access[p['id']]} for p in catalog['providers']],'provider_access':access,'usage_policy':{**entitlement['usage_policy'],'openai_default_model':default}}
 def admin(self,uid):
  u=self.active_user(uid)
  if not u or u['role']!='admin':raise PermissionError('Administrator access required.')
 def catalog(self,uid=None):return {'plans':list(PLANS.values()),'chat_free':True,'notice':NOTICE,'upi_id':UPI,'display_name':'SYnerGY','bank_beneficiary':BENEFICIARY,'qr_url':'/synergy-upi.png','whatsapp':'https://wa.me/'+PHONE,'email':EMAIL,'activation':'Access starts after reference submission. Bank verification follows separately.','currency':'INR','timezone':'Asia/Kolkata',**launch_pricing.catalog(self,uid)}
 def orders(self,uid):
  with self.connect() as c:return [dict(r) for r in c.execute('SELECT * FROM payment_orders WHERE user_id=? ORDER BY created DESC LIMIT 100',(uid,))]
 def checkout(self,uid,d):
  u=self.active_user(uid)
  if not u or not u['email']:raise ValueError('Save your email in Account before choosing a plan.')
  key=d.get('request_key','')
  if not isinstance(key,str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,100}',key):raise ValueError('Use a valid payment request key.')
  with self.connect() as c:existing=c.execute('SELECT * FROM payment_orders WHERE user_id=? AND request_key=?',(uid,key)).fetchone()
  plan={**PLANS,**launch_pricing.PLANS}.get(existing['plan_id']) if existing else launch_pricing.PLANS.get(d.get('plan_id'))
  if not existing and (not plan or plan['tier']!=launch_pricing.member(self,uid)['tier']):raise ValueError('Choose a plan available to your membership cohort.')
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT * FROM payment_orders WHERE user_id=? AND request_key=?',(uid,key)).fetchone()
   if not r:
    if c.execute('SELECT count(*) FROM payment_orders WHERE user_id=? AND created>?',(uid,time.time()-86400)).fetchone()[0]>=20:raise ValueError('You have several recent payment requests. Use an existing request or contact support.')
    oid='SY'+uuid.uuid4().hex[:24];c.execute('INSERT INTO payment_orders(id,user_id,plan_id,amount_paise,currency,state,created,request_key) VALUES(?,?,?,?,?,?,?,?)',(oid,uid,plan['id'],plan['amount_paise'],'INR','created',time.time(),key));r=c.execute('SELECT * FROM payment_orders WHERE id=?',(oid,)).fetchone();self.audit(c,uid,'checkout_created',oid,{'plan':plan['id'],'amount_paise':plan['amount_paise']})
  r=dict(r);r['upi_url']='upi://pay?'+urlencode({'pa':UPI,'pn':'SYnerGY','tr':r['id'],'tn':'SYnerGY ETERNAL '+r['plan_id'],'am':f'{r["amount_paise"]/100:.2f}','cu':'INR'});r['qr_url']='/synergy-upi.png';return r
 def submit_payment(self,uid,d):
  utr=reference(d.get('utr'));txn=reference(d.get('transaction_id'));oid=d.get('id')
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT * FROM payment_orders WHERE id=? AND user_id=?',(oid,uid)).fetchone()
   if not r:raise KeyError('Payment request not found.')
   if r['state']!='created':
    if r['utr']!=utr or r['transaction_id']!=txn:raise ValueError('This request has already been submitted. Contact support for a correction.')
   else:
    if r['created']<time.time()-86400:raise ValueError('This payment request expired. Choose the plan again before paying.')
    for ref in {utr,txn}:
     prior=c.execute('SELECT payment_id FROM payment_refs WHERE value=?',(ref,)).fetchone()
     if prior and prior[0]!=oid:raise ValueError('This payment reference has already been used. Contact support if you need help.')
    for ref in {utr,txn}:c.execute('INSERT INTO payment_refs VALUES(?,?)',(ref,oid))
    now=time.time();plan={**PLANS,**launch_pricing.PLANS}[r['plan_id']];last=c.execute("SELECT max(expires) FROM subscriptions WHERE user_id=? AND mode=? AND state='active'",(uid,plan['mode'])).fetchone()[0];start=max(now,last or now)
    c.execute('UPDATE payment_orders SET state=?,submitted=?,utr=?,transaction_id=? WHERE id=?',('submitted',now,utr,txn,oid));c.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?,?,?,?,?)',(uuid.uuid4().hex,uid,plan['mode'],start,start+plan['days']*86400,'active',oid,now,'upi_provisional'));self.audit(c,uid,'payment_submitted_access_activated',oid,{'bank_verified':False})
   u=c.execute('SELECT email FROM users WHERE id=?',(uid,)).fetchone()
  msg=f'SYnerGY subscription activation\nEmail: {u[0]}\nOrder: {oid}\nPlan: {r["plan_id"]}\nAmount: INR {r["amount_paise"]/100:.2f}\nUTR: {utr}\nTransaction ID: {txn}\nPlease reconcile this payment.'
  return {'order_id':oid,'membership':self.entitlement(uid),'verification':'pending_bank_verification' if r['state'] in {'created','submitted'} else r['state'],'whatsapp_url':'https://wa.me/'+PHONE+'?'+urlencode({'text':msg}),'email_url':'mailto:'+EMAIL+'?'+urlencode({'subject':'SYnerGY payment '+oid,'body':msg})}
 def _review_payment(self,c,actor,oid,decision,note,paid_at=None):
  r=c.execute('SELECT * FROM payment_orders WHERE id=?',(oid,)).fetchone()
  if not r or r['state'] not in {'submitted','verified','rejected'}:raise ValueError('Select a submitted payment.')
  if decision not in {'verify','reject'} or not isinstance(note,str) or not note.strip():raise ValueError('Choose Verify or Reject and record the evidence or reason.')
  desired='verified' if decision=='verify' else 'rejected'
  if r['state']==desired:return
  paid_at=paid_at or r['submitted']
  if type(paid_at) not in (int,float) or not 0<paid_at<=time.time()+86400:raise ValueError('Choose a valid bank payment date.')
  c.execute('UPDATE payment_orders SET state=?,verified=?,paid_at=?,review_note=?,reviewer=? WHERE id=?',(desired,time.time() if decision=='verify' else None,paid_at,note[:1500],actor,oid));c.execute('UPDATE subscriptions SET state=?,source=? WHERE payment_id=?',('active' if decision=='verify' else 'revoked','upi_verified' if decision=='verify' else 'upi_rejected',oid));self.audit(c,actor,'payment_'+desired,oid,{'note':note[:1500],'paid_at':paid_at,'amount_paise':r['amount_paise']})
 def review_payment(self,actor,d):
  self.admin(actor)
  with self.connect() as c:c.execute('BEGIN IMMEDIATE');self._review_payment(c,actor,d.get('id'),d.get('decision'),d.get('note'),d.get('paid_at'))
  return {'ok':True}
 def account_action(self,actor,d):
  self.admin(actor);uid=int(d.get('user_id',0));action=d.get('action');note=str(d.get('note','')).strip()
  if not note:raise ValueError('Record a reason for this change.')
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE');u=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
   if not u:raise KeyError('Account not found.')
   if action in {'suspend','activate'}:
    if u['role']=='admin':raise ValueError('Administrator accounts cannot be suspended from this panel.')
    c.execute('UPDATE users SET account_state=? WHERE id=?',('suspended' if action=='suspend' else 'active',uid))
    if action=='suspend':
     c.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
     if c.execute("SELECT 1 FROM sqlite_master WHERE name='extension_tokens'").fetchone():c.execute('DELETE FROM extension_tokens WHERE user_id=?',(uid,))
    result={'ok':True}
   elif action=='reset_key':
    if not u['email']:raise ValueError('This account needs an email before key-based reset.')
    key='SYN-'+secrets.token_urlsafe(32);expires=time.time()+1800;c.execute('INSERT OR REPLACE INTO account_recovery VALUES(?,?,?,?)',(uid,digest(key),expires,time.time()));result={'reset_key':key,'expires':expires,'email':u['email']}
   else:raise ValueError('Choose Activate, Terminate access, or Issue reset key.')
   self.audit(c,actor,'account_'+action,uid,{'note':note[:1500]})
  return result
 def subscription_action(self,actor,d):
  self.admin(actor);action=d.get('action');note=str(d.get('note','')).strip()
  if not note:raise ValueError('Record a reason for this change.')
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE')
   if action=='grant':
    plan={**PLANS,**launch_pricing.PLANS}.get(d.get('plan_id'));uid=int(d.get('user_id',0))
    if not plan or not c.execute('SELECT 1 FROM users WHERE id=?',(uid,)).fetchone():raise ValueError('Choose an account and a listed plan.')
    sid=uuid.uuid4().hex;now=time.time();c.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?,?,NULL,?,?)',(sid,uid,plan['mode'],now,now+plan['days']*86400,'active',now,'admin_grant'));target=sid
   elif action=='revoke':
    target=d.get('id');r=c.execute('UPDATE subscriptions SET state=? WHERE id=?',('revoked',target))
    if not r.rowcount:raise KeyError('Subscription not found.')
   else:raise ValueError('Choose Activate or Terminate subscription.')
   self.audit(c,actor,'subscription_'+action,target,{'note':note[:1500]})
  return {'ok':True}
 def dashboard(self,actor):
  self.admin(actor);now=datetime.now(IST);today=now.replace(hour=0,minute=0,second=0,microsecond=0);starts={'today':today,'week':today-timedelta(days=today.weekday()),'month':today.replace(day=1)}
  with self.connect() as c:
   users=[dict(r) for r in c.execute('SELECT id,username,email,full_name,phone,role,account_state,email_verified,created FROM users ORDER BY id DESC LIMIT 1000')]
   for u in users:
    last=c.execute("SELECT id,amount_paise,state,submitted,utr,transaction_id FROM payment_orders WHERE user_id=? AND submitted IS NOT NULL ORDER BY submitted DESC LIMIT 1",(u['id'],)).fetchone();u['last_payment']=dict(last) if last else None
   payments=[dict(r) for r in c.execute('SELECT p.*,u.email,u.username FROM payment_orders p JOIN users u ON u.id=p.user_id ORDER BY p.created DESC LIMIT 1000')]
   subs=[dict(r) for r in c.execute('SELECT s.*,u.email,u.username FROM subscriptions s JOIN users u ON u.id=s.user_id ORDER BY s.created DESC LIMIT 1000')]
   totals={k:c.execute("SELECT coalesce(sum(amount_paise),0) FROM payment_orders WHERE state='verified' AND paid_at>=? AND paid_at<?",(v.timestamp(),time.time()+1)).fetchone()[0] for k,v in starts.items()}
   pending=c.execute("SELECT count(*),coalesce(sum(amount_paise),0) FROM payment_orders WHERE state='submitted'").fetchone()
   tickets=[dict(r) for r in c.execute('SELECT t.*,u.email,u.username FROM support_tickets t JOIN users u ON u.id=t.user_id ORDER BY t.updated DESC LIMIT 500')] if c.execute("SELECT 1 FROM sqlite_master WHERE name='support_tickets'").fetchone() else []
   audit=[dict(r) for r in c.execute('SELECT id,actor,kind,target,details,created FROM membership_audit ORDER BY id DESC LIMIT 100')]
   exceptions=[dict(r) for r in c.execute('SELECT e.*,s.starts,s.expires,s.state AS subscription_state FROM subscription_exceptions e LEFT JOIN subscriptions s ON s.id=e.subscription_id ORDER BY e.created DESC LIMIT 1000')]
  return {'users':users,'payments':payments,'subscriptions':subs,'exceptions':exceptions,'tickets':tickets,'audit':audit,'confirmed_income_paise':totals,'pending_count':pending[0],'pending_amount_paise':pending[1],'timezone':'Asia/Kolkata','limits':{'users':1000,'payments':1000,'subscriptions':1000,'tickets':500}}
 def exception_action(self,actor,d):
  """Owner-authorised complimentary access; pending profiles never auto-claim."""
  self.admin(actor);action=d.get('action','create');now=time.time()
  if action not in {'create','activate','revoke'}:raise ValueError('Choose create, activate or revoke.')
  note=d.get('note','')
  if not isinstance(note,str) or not 3<=len(note.strip())<=1500:raise ValueError('Record a reason (3–1,500 characters).')
  note=note.strip()
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE')
   if action=='create':
    email=email_value(d.get('email'));plan={**PLANS,**launch_pricing.PLANS}.get(d.get('plan_id'));key=d.get('request_key','');name=d.get('full_name','')
    if not plan or not isinstance(key,str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,100}',key):raise ValueError('Choose a listed subscription and retry.')
    if not isinstance(name,str) or len(name)>100:raise ValueError('Use a name up to 100 characters.')
    existing=c.execute('SELECT * FROM subscription_exceptions WHERE request_key=?',(key,)).fetchone()
    if existing:
     if existing['email']!=email or existing['plan_id']!=plan['id'] or existing['actor']!=actor:raise ValueError('This request was already used for a different grant.')
     return dict(existing)
    if c.execute("SELECT 1 FROM subscription_exceptions WHERE email=? AND state='pending'",(email,)).fetchone():raise ValueError('This email already has a pending profile. Activate or revoke that entry first.')
    eid=uuid.uuid4().hex
    c.execute('INSERT INTO subscription_exceptions VALUES(?,?,?,?,?,NULL,NULL,?,NULL,?,?,?)',(eid,email,name.strip(),plan['id'],'pending',now,actor,note,key))
    row=c.execute('SELECT * FROM subscription_exceptions WHERE id=?',(eid,)).fetchone()
   else:
    row=c.execute('SELECT * FROM subscription_exceptions WHERE id=?',(d.get('id'),)).fetchone()
    if not row:raise KeyError('Exceptional profile not found.')
    eid=row['id']
   if action=='revoke':
    c.execute("UPDATE subscription_exceptions SET state='revoked' WHERE id=?",(eid,))
    if row['subscription_id']:c.execute("UPDATE subscriptions SET state='revoked' WHERE id=?",(row['subscription_id'],))
   elif row['state']=='pending':
    u=c.execute('SELECT id,account_state FROM users WHERE lower(email)=?',(row['email'],)).fetchone()
    if u:
     if u['account_state']!='active':raise ValueError('Activate this user account before granting a subscription.')
     if d.get('identity_confirmed') is not True:raise ValueError('Confirm that you verified the recipient email before activating access.')
     plan={**PLANS,**launch_pricing.PLANS}[row['plan_id']];sid=uuid.uuid4().hex
     c.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?,?,NULL,?,?)',(sid,u['id'],plan['mode'],now,now+plan['days']*86400,'active',now,'admin_exception'))
     c.execute("UPDATE subscription_exceptions SET state='active',user_id=?,subscription_id=?,activated=? WHERE id=?",(u['id'],sid,now,eid))
    elif action=='activate':raise ValueError('This email has not registered yet. Keep the profile pending until registration.')
   elif action=='activate' and row['state']!='active':raise ValueError('This profile was revoked. Create a new grant if needed.')
   self.audit(c,actor,'exception_'+action,eid,{'email':row['email'],'plan_id':row['plan_id'],'note':note})
   return dict(c.execute('SELECT * FROM subscription_exceptions WHERE id=?',(eid,)).fetchone())
 def reconcile_preview(self,actor,text):
  self.admin(actor)
  if not isinstance(text,str) or len(text)>500000:raise ValueError('Use a CSV under 500 KB with UTR, Transaction ID, Amount and Date columns.')
  reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')));rows=[]
  with self.connect() as c:
   for i,row in enumerate(reader):
    if i>=1000:raise ValueError('Use up to 1,000 bank rows per review.')
    row={re.sub(r'[^a-z]','',k.lower()):v for k,v in row.items() if isinstance(k,str)}
    try:
     if row.get('type','credit').strip().lower() not in {'credit','cr','c'}:raise ValueError('Debit row excluded.')
     refs={reference(row[k]) for k in ['utr','transactionid'] if row.get(k)}
     if not refs:raise ValueError('No UTR or transaction ID.')
     amount=money(row.get('amount'));bankdate=datetime.fromisoformat(row.get('date',''));date=(bankdate if bankdate.tzinfo else bankdate.replace(tzinfo=IST)).timestamp()
     if not 0<date<=time.time()+86400:raise ValueError('Invalid payment date.')
     ids=set()
     for ref in refs:
      hit=c.execute('SELECT payment_id FROM payment_refs WHERE value=?',(ref,)).fetchone()
      if hit:ids.add(hit[0])
     if len(ids)!=1:raise ValueError('No unique submitted payment match.')
     pid=ids.pop();p=c.execute('SELECT * FROM payment_orders WHERE id=?',(pid,)).fetchone()
     if p['amount_paise']!=amount:raise ValueError('Amount does not match the selected plan.')
     if any(x.get('payment_id')==pid for x in rows):raise ValueError('Duplicate statement row.')
     rows.append({'row':i+2,'payment_id':pid,'amount_paise':amount,'paid_at':date,'current_state':p['state'],'status':'match' if p['state']=='submitted' else 'already_reviewed'})
    except (ValueError,TypeError) as e:rows.append({'row':i+2,'status':'unmatched','reason':str(e)})
   rid=uuid.uuid4().hex;c.execute('INSERT INTO bank_reviews VALUES(?,?,?,?,NULL)',(rid,actor,json.dumps(rows),time.time()));self.audit(c,actor,'bank_preview',rid,{'rows':len(rows),'matches':sum(r['status']=='match' for r in rows)})
  return {'id':rid,'rows':rows,'message':'Review matched rows before confirming. Unmatched or previously reviewed rows will not be applied.'}
 def reconcile_apply(self,actor,rid):
  self.admin(actor)
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT * FROM bank_reviews WHERE id=? AND actor=?',(rid,actor)).fetchone()
   if not r or r['created']<time.time()-3600:raise ValueError('This review expired. Upload and review the statement again.')
   if r['applied']:return {'ok':True,'already_applied':True}
   matched=[x for x in json.loads(r['payload']) if x['status']=='match']
   for row in matched:
    p=c.execute('SELECT state FROM payment_orders WHERE id=?',(row['payment_id'],)).fetchone()
    if not p or p[0]!='submitted':raise ValueError('A payment changed after preview. Create a new review.')
    self._review_payment(c,actor,row['payment_id'],'verify','Matched bank CSV review '+rid,row['paid_at'])
   c.execute('UPDATE bank_reviews SET applied=? WHERE id=?',(time.time(),rid));self.audit(c,actor,'bank_review_applied',rid,{'verified':len(matched)})
  return {'ok':True,'verified':len(matched)}
