"""Bounded, local creation tools. Only the current user's request selects actions.

The text model never manufactures download URLs or executes arbitrary skills.
Existing image and motion workers produce the media; verified files are attached
to the durable, account-owned chat task only after a successful worker receipt.
"""
import copy,base64
import hashlib
import json
import re
import shutil
import time
from pathlib import Path
from studio.planner import plan as image_plan


def _candidate(prompt, previous=None, messages=()):
    if not isinstance(prompt, str):
        return None
    p = prompt.strip()
    # Supplied document contents and quoted headlines cannot select another tool.
    p = re.split(r'(?i)\b(?:exact(?:ly)?\s+(?:text|content)|content|text)\s*:', p, maxsplit=1)[0]
    document_names=r'\b(?:hall\s*ticket|admit\s*card|invoice|resume|curriculum vitae|proposal|letter|certificate|brochure|report)\b'
    doc_context=bool(previous and previous.get('kind')=='document') or any(re.search(document_names,m['content'],re.I) for m in messages[-12:] if m['role']=='user')
    # Questions about making files, quotations and negative instructions are not jobs.
    if re.match(r"(?is)^(?:how\b|what\b|why\b|explain\b|compare\b|research\b|(?:please\s+)?(?:do not|don't|don’t|never)\b|(?:can|could) you explain\b|[\"'`>])", p):
        return None
    if re.match(r'(?is)^(?:write|draft|give|create|make)\b.{0,50}\b(?:prompt|caption|script|ideas|instructions)\b.{0,20}\b(?:for|about|to)\b', p):
        return None
    action = re.search(r'(?i)\b(create|generate|make|design|draw|render|export|convert|turn|prepare|produce|build|animate|save|give|need|want|edit|change|resize|replace|remove|add|banado|banao|bana\s+do)\b|बनाओ|बनाइए', p)
    if not action or action.start() > 100:
        return None
    # An explicit draft of a workflow is not permission to execute its embedded steps.
    if re.search(r'(?i)\b(?:automation|workflow|schedule)\b', p[:180]):
        return None
    if re.search(r'(?i)\b(?:excel|xlsx|spreadsheet|workbook|powerpoint|pptx)\b',p[:180]):
        return None
    video = bool(re.search(r'(?i)\b(video|clip|reel|animation|animated\s+logo)\b', p) or re.match(r'(?i)^(?:please\s+)?animate\b', p))
    visual = bool(re.search(r'(?i)\b(image|photo|picture|portrait|poster|thumbnail|logo|icon|illustration|artwork|wallpaper|banner|flyer|infographic|instagram\s*post|insta\s*post|social\s+media\s+(?:post|design)|office\s+concept|launch\s+post|packaging)\b', p) or re.search(r'(?i)\bdraw\b', p))
    formats = [ext for ext, pattern in [('pdf', r'\bpdf\b'), ('docx', r'\b(?:docx|word\s+document)\b'), ('md', r'\bmarkdown\b'), ('txt', r'\b(?:txt|text\s+file)\b')] if re.search(pattern, p, re.I)]
    if re.search(document_names,p,re.I) or (doc_context and re.search(r'(?i)\b(?:png|pdf|docx|a4|this|it|create|design|give)\b',p)):
        if re.search(r'(?i)\bpng\b',p):formats.append('png')
        if not visual or re.search(document_names,p,re.I):
            return {'kind':'document','formats':formats or ['pdf'],'skill_id':'document-creation'}
    followup = bool(previous and re.search(r'(?i)\b(this|it|same|previous|headline|resize|background|colour|color|logo|text|image)\b', p))
    # Select the requested output, not an object mentioned inside its subject.
    target = re.split(r'(?i)\b(?:into|as)\s+(?:an?\s+)?', p)[-1] if re.search(r'(?i)\b(?:convert|turn|export|save)\b',p) else p[action.end():]
    output = re.search(r'(?i)\b(pdf|docx|word\s+document|markdown|text\s+file|txt|video|clip|reel|animation|animated\s+logo|image|photo|picture|portrait|poster|thumbnail|logo|icon|illustration|artwork|banner|flyer|infographic|instagram\s*post|insta\s*post|post)\b', target)
    if output:
        first = output[0].casefold()
        if first in {'pdf','docx','word document','markdown','text file','txt'}:
            return {'kind':'document','formats':formats or ['pdf'],'skill_id':'document-creation'}
        if first not in {'video','clip','reel','animation','animated logo'}:video=False
    if video:
        return {'kind': 'video', 'formats': ['mp4'], 'skill_id': 'storyboard'}
    if visual or (followup and previous.get('kind') == 'image' and not formats):
        design = bool(re.search(r'(?i)\b(poster|thumbnail|instagram\s*post|insta\s*post|post|flyer|banner|logo|icon|infographic)\b', p))
        return {'kind': 'image', 'formats': ['png', 'svg'] + (['pdf'] if 'pdf' in formats else []), 'skill_id': 'brand-layout' if design else 'photo-direction', 'followup': followup}
    if formats:
        return {'kind': 'document', 'formats': formats, 'skill_id': 'document-creation'}
    if re.search(r'(?i)\bpng\b',p):
        return {'kind':'document','formats':['png'],'skill_id':'document-creation'} if not visual else {'kind':'image','formats':['png','svg'],'skill_id':'photo-direction','followup':followup}
    return None


def informational(prompt):
    """Discussion of a deliverable is not a request to render that deliverable."""
    p = str(prompt or '').strip()
    if re.search(r"(?i)\b(?:(?:do\s+not|don't|don’t|never)\s+(?:want\s+(?:you\s+)?to\s+)?(?:create|generate|make|render|start|produce)|not\s+yet|before\s+(?:you\s+)?(?:create|generate|make))\b", p):
        return True
    lead = re.sub(r'(?i)^(?:please|okay|ok|hey|aerny)[,\s]+', '', p)
    if re.match(r'(?i)^(?:how|what|why|when|where|which|explain|compare|research|describe|discuss|tell\s+me|help\s+me\s+understand)\b', lead):
        return True
    if re.match(r'(?i)^(?:(?:can|could|would)\s+you\s+)?(?:please\s+)?(?:tell|explain|describe|discuss|advise)\b', lead):
        return True
    if re.search(r'(?i)\b(?:want|need|like)\s+to\s+(?:understand|learn|know)\b',lead[:100]):
        return True
    if re.search(r'(?i)\b(?:details|information|advice|instructions|steps|ideas|requirements|options|capabilities)\b', lead[:170]):
        # "Create a poster with these details" is an action; "give details of a video" is not.
        first_action = re.search(r'(?i)\b(?:create|generate|make|render|draw|export)\b', lead)
        info = re.search(r'(?i)\b(?:details|information|advice|instructions|steps|ideas|requirements|options|capabilities)\b', lead)
        supplied_details=bool(re.match(r'(?i)^here\s+(?:are|is)\b',lead) and first_action and first_action.start()>info.start())
        if not supplied_details and (not first_action or info.start() < first_action.start() or re.search(r'(?i)\b(?:how|about|before)\b', lead[:info.start()+1])):
            return True
    if re.search(r'(?i)\b(?:write|draft|give|create|make|need|want|provide|share)\b.{0,50}\b(?:prompt|caption|script|storyboard|brief|plan|ideas)\b.{0,30}\b(?:for|about|to|of)\b', lead):
        return True
    return False


def _has_visual_brief(prompt):
    p = re.split(r'(?i)\b(?:and\s+)?(?:i\s+(?:want|need)\s+to\s+)?save\b|\b(?:in|into|under)\s+(?:my\s+|the\s+)?[\w -]{1,55}\s+project\b', prompt)[0]
    p = re.sub(r'(?i)\bfor\s+(?:my\s+|the\s+|our\s+)?[\w -]{1,45}\s*$', '', p)
    p = re.sub(r'(?i)\b(?:\d+\s*(?:seconds?|secs?|s|minutes?|mins?|p|k)|\d+\s*[:x×]\s*\d+)\b', '', p)
    words = re.findall(r'[\w]+', p.casefold())
    generic = set('i we you me my our your want need would like love can could please now go ahead create generate make design draw render produce build animate edit change resize replace remove add turn into an a the this that it these those same previous above attached uploaded reference image photo picture video clip reel animation poster portrait thumbnail logo icon illustration artwork wallpaper banner flyer infographic instagram insta social media post concept to for of and with as in on up high quality resolution realistic photorealistic cinematic premium detailed professional beautiful good nice amazing hd uhd 4k 1080p 720p short long seconds duration second minute minutes aspect ratio landscape square vertical horizontal portrait latest banao banado bana do'.split())
    return any(w not in generic and not w.isdigit() for w in words)


def request_plan(prompt, previous=None, messages=(), has_reference=False):
    p = str(prompt or '').strip()
    if informational(p):
        return {'action':'answer','creation':None}
    candidate = _candidate(p, previous, messages)
    # Only a specific continuation of a pending clarification can resume its brief.
    pending = next((m.get('metadata',{}).get('clarification') for m in reversed(messages[-4:]) if m.get('metadata',{}).get('clarification')), None)
    if not candidate and pending and re.match(r'(?i)^(?:create|generate|make|render|draw|animate)\s+(?:it|this|that|now)\b', p):
        candidate = dict(pending['creation'])
    if not candidate:
        return {'action':'answer','creation':None}
    if candidate['kind'] not in {'image','video'}:
        return {'action':'create','creation':candidate}
    brief = p
    if not _has_visual_brief(p):
        # Use a user-written scene only for an explicit reference to conversation context.
        referred = bool(re.search(r'(?i)\b(?:create|generate|make|render|animate|edit|change)\s+(?:it|this|that)\b|\b(?:this|that|previous|same|above|attached|uploaded)\s+(?:image|photo|video|clip|scene|brief|script|reference|result)\b',p))
        if referred:
            for m in reversed(messages[-6:]):
                if m['role']=='user' and not informational(m['content']) and _has_visual_brief(m['content']):
                    brief = m['content']+'\n\nRequested follow-up: '+p
                    break
        if brief == p and not (has_reference or (previous and referred)):
            kind=candidate['kind']
            project=re.search(r'(?i)\b(?:in|into|under)\s+(?:the\s+|my\s+)?([\w -]{1,55}?)\s+project\b',p)
            question=('What should the video show? Send the scene or script, and tell me the duration and format if you have a preference.' if kind=='video' else 'What should the image show? Describe the subject or upload a reference, and include any exact text you want.')
            if project:question+=' For '+project[1].strip()+', select that project in the sidebar so this conversation and its output stay together.'
            return {'action':'clarify','creation':None,'clarification':{'creation':candidate,'question':question,'reason':'missing_visual_brief'}}
    return {'action':'create','creation':candidate,'brief':brief}


def intent(prompt, previous=None, messages=(), has_reference=False):
    return request_plan(prompt, previous, messages, has_reference)['creation']


def choose_skill(workspace, uid, prompt, plan=None, explicit=None):
    if explicit:
        skill = workspace.get_skill(uid, explicit)
        if not skill:
            raise ValueError('The selected skill is unavailable. Select another skill.')
        return skill, False
    words = set(re.findall(r'[a-z0-9]{3,}', prompt.casefold()))
    stop = {'create', 'make', 'please', 'with', 'that', 'this', 'from', 'your', 'about', 'and', 'the', 'for', 'use', 'skill'}
    matches = []
    for skill in workspace.skills(uid):
        if skill.get('builtin'):
            continue
        name = skill['name'].casefold()
        overlap = (set(re.findall(r'[a-z0-9]{3,}', name + ' ' + skill.get('description', '').casefold())) - stop) & words
        if name in prompt.casefold() or len(overlap) >= 3:
            matches.append((100 if name in prompt.casefold() else len(overlap), skill))
    if matches:
        return max(matches, key=lambda x: x[0])[1], True
    sid = plan.get('skill_id') if plan else None
    if not sid:
        for pattern, candidate in [(r'ui[ /-]?ux pro max', 'ui-ux-pro-max'), (r'framer[ -]?motion', 'framer-motion'), (r'desktop[\s_-]*commander|^/desktop\b', 'desktop-commander'), (r'\b(?:aws|ec2|session manager)\b|deploy.*(?:domain|synergy)', 'aws-deployment'), (r'\b(debug|review.*code|bug)\b', 'code-review'), (r'\b(ui|ux|interface)\b', 'ui-ux-design'), (r'\b(caption|brand.*copy|copywriting)\b', 'brand-writing')]:
            if re.search(pattern, prompt, re.I):
                sid = candidate
                break
    if not sid:
        from intelligence import select_skill
        sid=select_skill(prompt)
    return (workspace.get_skill(uid, sid), True) if sid else (None, False)


def last_creation(messages):
    for m in reversed(messages):
        if m['role'] == 'assistant' and m.get('metadata', {}).get('creation'):
            return m['metadata']['creation']
    return None


class Creator:
    def __init__(self, research, studio, video, legacy, gate):
        self.r, self.studio, self.video, self.legacy, self.gate = research, studio, video, legacy, gate
        # A restart leaves a retryable parent and stops its queued child, so a
        # stale task cannot silently generate an unlinked second result.
        with research.connect() as c:
            interrupted=c.execute("SELECT user_id,detail FROM research_tasks WHERE state='failed'").fetchall()
        for row in interrupted:
            detail=json.loads(row['detail']);child=detail.get('creation') or {}
            if detail.get('stage')!='Interrupted by restart' or not child.get('job_id'):continue
            try:
                if child.get('kind')=='image':studio.cancel(row['user_id'],child['job_id'])
                elif child.get('kind')=='video':
                    with research.connect() as c:owned=c.execute('SELECT 1 FROM jobs WHERE id=? AND user_id=?',(child['job_id'],row['user_id'])).fetchone()
                    if owned:video.cancel(child['job_id'])
            except KeyError:pass

    def artifact(self, uid, jid, filename, kind, label):
        path = self.r.folder(jid) / filename
        if not path.is_file() or path.stat().st_size == 0:
            raise RuntimeError('The requested file was not produced.')
        sha = hashlib.sha256()
        with path.open('rb') as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b''):
                sha.update(chunk)
        path.chmod(0o600)
        return {'name': filename, 'kind': kind, 'label': label, 'url': f'/api/research/tasks/{jid}/{filename}', 'bytes': path.stat().st_size, 'sha256': sha.hexdigest()}

    def image_context(self, uid, req, history):
        reference = None
        if req.get('file_id'):
            f = self.r.file(uid, req['file_id'])
            if f['parsed']['kind'] != 'image':
                raise ValueError('This creation needs a PNG or JPEG reference. Remove the document or upload an image.')
            reference = self.studio.add_asset(uid, (base64.b64decode(f['parsed']['preview_image']) if f['parsed'].get('preview_image') else (self.r.root / 'files' / f['id'] / 'original').read_bytes()), f['name'])['id']
        previous = None
        old = last_creation(history)
        if old and old.get('kind') == 'image' and req['creation'].get('followup') and not reference:
            p = self.studio.project(uid, old['project_id'])
            job = self.studio.job(uid, old['job_id'])
            previous = copy.deepcopy(job['spec'])
            previous['reference_id'] = job['result']['base_asset_id']
        if not reference and not previous and re.search(r'(?i)\b(this|attached|reference|uploaded|previous image|same image)\b', req['prompt']):
            fid = next((m.get('metadata', {}).get('file_id') for m in reversed(history) if m.get('metadata', {}).get('file_id')), None)
            if fid:
                f = self.r.file(uid, fid)
                if f['parsed']['kind'] == 'image':
                    reference = self.studio.add_asset(uid, (base64.b64decode(f['parsed']['preview_image']) if f['parsed'].get('preview_image') else (self.r.root / 'files' / fid / 'original').read_bytes()), f['name'])['id']
            if not reference and old and old.get('kind') == 'image':
                job = self.studio.job(uid, old['job_id'])
                reference = job['result']['base_asset_id']
        return reference, previous

    def visual(self, uid, jid, stop):
        r = self.r
        task = r.task(uid, jid); req = dict(task['request']); plan = req['creation']
        req['prompt'] = req.get('creation_prompt') or req['prompt']
        history = r.ws.chat(uid, task['conversation_id'])['messages'][:-1]
        kind = plan['kind']
        if not r.ws.tool_enabled(uid, kind):
            raise ValueError(f'The {kind} tool is disabled. Enable it in Plugins, then retry this saved request.')
        r.update(uid, jid, detail={'creation': {'kind': kind}, 'selected_skill': req.get('selected_skill')})
        if kind == 'video':
            return self.motion(uid, jid, req, history, stop)
        r.stage(uid, jid, 'Planning image and exact layout')
        reference, previous = self.image_context(uid, req, history)
        planned = image_plan(req['prompt'][:3000], previous, reference, self.studio.brands(uid))
        if planned['needs_mask']:
            raise ValueError('A selected-area edit needs a painted mask. Open Image Studio, paint the area, then generate. The request is saved; no whole-image edit was substituted.')
        if planned['missing_brand']:
            raise ValueError('No approved logo matches this request. Add the approved logo to a brand kit in Image Studio, or attach it and ask for a layout that keeps it unchanged.')
        spec = planned['spec']
        if not previous and not re.search(r'\b\d{3,4}\s*[x×]\s*\d{3,4}\b', req['prompt'], re.I):
            if re.search(r'(?i)\b(story|9:16)\b', req['prompt']):spec.update(width=1080, height=1920)
            elif re.search(r'(?i)\b(square|1:1)\b', req['prompt']):spec.update(width=1080, height=1080)
            elif re.search(r'(?i)\b(landscape|16:9|banner)\b', req['prompt']):spec.update(width=1920, height=1080)
        if not (Path(self.studio.adapter) / 'verified.json').exists() and spec['workflow'] != 'layout':
            spec['quality'] = 'balanced'
        p = self.studio.save(uid, {'title': req['prompt'][:90], 'spec': spec})
        job = self.studio.submit(uid, p['id'])
        creation = {'kind': 'image', 'project_id': p['id'], 'job_id': job['id'], 'workflow': spec['workflow']}
        r.update(uid, jid, detail={'creation': creation})
        last_stage = None
        try:
            while job['state'] in {'queued', 'running'}:
                r.check(stop)
                progress = job['progress']
                stage = progress.get('stage') or 'Waiting for image compute'
                if stage != last_stage:r.stage(uid, jid, stage);last_stage = stage
                r.update(uid, jid, detail={'progress': progress})
                stop.wait(.4); job = self.studio.job(uid, job['id'])
        except BaseException:
            self.studio.cancel(uid, job['id']);raise
        if job['state'] != 'succeeded':
            if job['state'] == 'cancelled':raise InterruptedError('Image generation stopped.')
            raise RuntimeError(job.get('error') or 'Image generation failed. Retry the saved request.')
        r.check(stop)
        folder = r.folder(jid)
        for name in ['output.png', 'output.svg']:
            shutil.copyfile(self.studio.folder(job['id']) / name, folder / name)
        artifacts = [self.artifact(uid, jid, 'output.png', 'image', 'Download PNG'), self.artifact(uid, jid, 'output.svg', 'source', 'Download editable SVG')]
        if 'pdf' in plan['formats']:
            from creation_documents import image_pdf
            image_pdf(folder / 'output.png', folder / 'output.pdf')
            artifacts.append(self.artifact(uid, jid, 'output.pdf', 'pdf', 'Download PDF'))
        r.update(uid, jid, detail={'artifacts': artifacts, 'creation': creation, 'generation': job['result']})
        w, h = job['result']['export_dimensions']
        return f'Your {"design" if spec["layers"] else "image"} is ready · {w} × {h}.', {'provider':'local-tool','model':job['result']['model'],'label':'SYnerGY text to image','reason':planned['summary']}

    def motion(self, uid, jid, req, history, stop):
        r = self.r
        status = self.video.status()
        if not status['ready']:raise RuntimeError(status['detail'])
        prompt = req['prompt']
        duration = re.search(r'(?i)\b(\d+)\s*(?:seconds?|secs?|s)\b', prompt)
        if duration and int(duration[1]) != 2:
            raise ValueError('The installed local motion model currently exports two-second clips. Ask for a two-second clip; this request has been saved without changing its duration.')
        ref_id, _ = self.image_context(uid, {**req, 'creation': {**req['creation'], 'followup': False}}, history)
        reference = self.studio.asset_path(uid, ref_id).read_bytes() if ref_id else None
        aspect = '9:16' if re.search(r'(?i)\b(reel|portrait|vertical|9:16)\b', prompt) else '1:1' if re.search(r'(?i)\b(square|1:1)\b', prompt) else '16:9'
        quality = 'fast' if req['effort'] == 'instant' or re.search(r'(?i)\b(fast|draft|quick)\b', prompt) else 'balanced'
        deadline = time.monotonic() + 7200
        r.stage(uid, jid, 'Waiting for local video compute')
        while True:
            r.check(stop)
            if time.monotonic() > deadline:raise TimeoutError('Local compute stayed busy for two hours. Retry this saved request.')
            with self.gate:
                if not (self.studio.active or self.legacy.active or self.video.active or any(lock.locked() for lock in list(r.locks.values()))):
                    job = self.video.submit(prompt[:1000], '4k' if re.search(r'(?i)\b4k\b', prompt) else '1080p', reference, quality, aspect)
                    with r.connect() as c:c.execute('INSERT INTO jobs VALUES(?,?)', (job['id'], uid))
                    break
            stop.wait(.4)
        creation = {'kind': 'video', 'job_id': job['id']}
        r.update(uid, jid, detail={'creation': creation})
        last_stage = None
        try:
            while job['state'] in {'queued','running'}:
                r.check(stop)
                if time.monotonic() > deadline:raise TimeoutError('Video generation exceeded two hours. Retry using Instant effort.')
                progress = job.get('progress', {})
                stage = progress.get('stage', 'Starting local video model')
                if stage != last_stage:r.stage(uid, jid, stage);last_stage = stage
                r.update(uid, jid, detail={'progress': progress})
                stop.wait(.5);job = self.video.get(job['id'])
        except BaseException:
            self.video.cancel(job['id']);raise
        if job['state'] != 'succeeded':
            if job['state'] == 'cancelled':raise InterruptedError('Video generation stopped.')
            raise RuntimeError(job.get('error') or 'Video generation failed.')
        r.check(stop)
        shutil.copyfile(self.video.folder(job['id']) / 'video.mp4', r.folder(jid) / 'video.mp4')
        artifact = self.artifact(uid, jid, 'video.mp4', 'video', 'Download MP4')
        r.update(uid, jid, detail={'artifacts':[artifact], 'generation':job.get('result',{}), 'creation':creation})
        return 'Your two-second video is ready. The export is upscaled; motion frames are generated by the local model.', {'provider':'local-tool','model':job.get('result',{}).get('engine','local motion model'),'label':'SYnerGY text to Video','reason':'Executed the installed local video worker and verified its MP4 output.'}

    def document_source(self, uid, jid, req, history):
        """Lossless exports bypass text inference; content drafting uses the assistant."""
        p = req['prompt']
        if not self.r.ws.tool_enabled(uid,'documents'):raise ValueError('The document tool is disabled. Enable it in Plugins, then retry.')
        exact = re.search(r'(?is)\b(?:exact(?:ly)?\s+(?:text|content)|content|text)\s*:\s*(.+)$', p)
        if exact:return exact[1].strip(), 'User-supplied content'
        if re.search(r'(?i)\b(?:give|export|convert|save)\b',p) and not re.search(r'(?i)\b(?:about|rewrite|revise|change|answer|reply|response)\b',p):
            previous=next((m for m in reversed(history) if m['role']=='assistant' and (m.get('metadata',{}).get('creation') or {}).get('kind')=='document'),None)
            if previous and previous['metadata'].get('task_id'):
                old=self.r.task(uid,previous['metadata']['task_id'])
                saved=self.r.folder(old['id'])/'document.md'
                if saved.is_file():return saved.read_text(), 'Previous saved document; wording retained'
        if re.search(r'(?i)\b(previous|last|above|this|that)\b.{0,25}\b(answer|response|reply|text|content)\b|\b(export|convert|save)\b.{0,20}\b(this|it|that)\b', p):
            previous = next((m for m in reversed(history) if m['role']=='assistant' and m.get('metadata',{}).get('state','succeeded')=='succeeded' and not m.get('metadata',{}).get('error')), None)
            if not previous:raise ValueError('There is no completed answer to export in this conversation. Provide the content or ask for a document about a topic.')
            return previous['content'], 'Previous completed answer'
        if req.get('file_id') and re.search(r'(?i)\b(convert|export)\b', p):
            f = self.r.file(uid, req['file_id'])
            if f['parsed']['kind'] == 'image':
                from creation_documents import image_pdf
                if req['creation']['formats'] != ['pdf']:raise ValueError('An image can be exported directly as a PDF. Ask for PDF only or describe the document to write.')
                image_pdf(self.r.root / 'files' / f['id'] / 'original', self.r.folder(jid) / 'output.pdf')
                self.r.update(uid,jid,detail={'artifacts':[self.artifact(uid,jid,'output.pdf','pdf','Download PDF')], 'creation':{'kind':'document'}})
                return None, 'Image exported to PDF'
            if f['parsed'].get('partial'):raise ValueError('The upload was only partially extracted. Export a specified excerpt or provide a smaller readable file; a complete conversion would omit content.')
            return '\n\n'.join(s['text'] for s in f['parsed']['sections']), 'Uploaded text; document layout is rebuilt'
        return None, None

    def export_document(self, uid, jid, content, sources=()):
        from creation_documents import export
        task = self.r.task(uid,jid)
        if not self.r.ws.tool_enabled(uid,'documents'):raise ValueError('The document tool is disabled. Enable it in Plugins, then retry.')
        self.r.stage(uid,jid,'Rendering and validating document files')
        files = export(self.r.folder(jid), content, task['request']['creation']['formats'], sources)
        artifacts = [self.artifact(uid,jid,name,kind,label) for name,kind,label in files]
        self.r.update(uid,jid,detail={'artifacts':artifacts,'creation':{'kind':'document'}})
        return artifacts
