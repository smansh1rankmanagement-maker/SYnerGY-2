"""Account-owned, source-attributed leads and real Excel exports."""
import datetime,hashlib,io,json,re,sqlite3,time,uuid
from html.parser import HTMLParser
from urllib.parse import urlsplit,urljoin,unquote
from research.net import fetch,validate_url
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.worksheet.table import Table,TableStyleInfo
from openpyxl.worksheet.datavalidation import DataValidation
class Page(HTMLParser):
 def __init__(self):super().__init__();self.text=[];self.links=[];self.title=[];self.in_title=False;self.skip=0;self.company=''
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag in {'script','style','noscript'}:self.skip+=1
  if tag=='title':self.in_title=True
  if tag=='a' and a.get('href'):self.links.append(a['href'])
  if tag=='meta' and a.get('property')=='og:site_name':self.company=a.get('content','')
 def handle_endtag(self,tag):
  if tag in {'script','style','noscript'}:self.skip=max(0,self.skip-1)
  if tag=='title':self.in_title=False
 def handle_data(self,data):
  if not self.skip:
   self.text.append(data)
   if self.in_title:self.title.append(data)
def clean_url(value):
 if not isinstance(value,str) or len(value)>2000:raise ValueError('Use a public website URL.')
 u=urlsplit(value)
 if u.scheme not in {'http','https'} or not u.hostname or u.username or u.password:raise ValueError('Use an HTTP(S) website without credentials.')
 if any(x in u.hostname.lower() for x in ['localhost','169.254.']):raise ValueError('Use a public website.')
 return value
def extract(url,title,text,links):
 emails=list(dict.fromkeys([unquote(x[7:].split('?')[0]) for x in links if x.lower().startswith('mailto:')]+re.findall(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',text)))[:20]
 phones=list(dict.fromkeys([unquote(x[4:].split('?')[0]) for x in links if x.lower().startswith('tel:')]+[x.strip() for x in re.findall(r'\+?\d[\d ()-]{8,22}\d',text) if 10<=len(re.sub(r'\D','',x))<=15]))[:20]
 return {'company':title[:160],'website':urlsplit(url).scheme+'://'+urlsplit(url).netloc,'email':emails[0] if emails else '', 'phone':phones[0] if phones else '', 'location':'','notes':'','source_url':url,'status':'New','captured_at':time.time(),'email_candidates':emails,'phone_candidates':phones,'review_required':True}
class Leads:
 def __init__(self,workspace):
  self.ws=workspace
  with self.ws.connect() as c:c.execute('CREATE TABLE IF NOT EXISTS lead_captures(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,project_id TEXT,company TEXT NOT NULL,website TEXT,email TEXT,phone TEXT,location TEXT,notes TEXT,source_url TEXT NOT NULL,status TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL,dedupe TEXT NOT NULL,UNIQUE(user_id,dedupe))')
 def list(self,uid):
  with self.ws.connect() as c:return [dict(r) for r in c.execute('SELECT * FROM lead_captures WHERE user_id=? ORDER BY updated DESC LIMIT 5000',(uid,))]
 def save(self,uid,d):
  fields={k:str(d.get(k,'')).strip() for k in ['company','website','email','phone','location','notes','source_url','status']}
  if not fields['company'] or len(fields['company'])>160:raise ValueError('Add a company name up to 160 characters.')
  if any(len(v)>2000 for v in fields.values()):raise ValueError('Keep each field under 2,000 characters.')
  clean_url(fields['source_url'])
  if fields['website']:clean_url(fields['website'])
  if fields['email'] and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',fields['email']):raise ValueError('Review the email address.')
  if fields['status'] not in {'New','Reviewed','Contacted','Qualified','Not a fit','Opted out'}:raise ValueError('Choose a supported lead status.')
  pid=d.get('project_id') or None
  if pid:self.ws.project(uid,pid)
  identity=(fields['email'].lower() or re.sub(r'\D','',fields['phone']) or (fields['website']+'|'+fields['company']).lower())
  digest=hashlib.sha256(identity.encode()).hexdigest();lid=d.get('id');now=time.time()
  with self.ws.connect() as c:
   if lid:
    if not c.execute('SELECT 1 FROM lead_captures WHERE id=? AND user_id=?',(lid,uid)).fetchone():raise KeyError()
   else:
    old=c.execute('SELECT id FROM lead_captures WHERE user_id=? AND dedupe=?',(uid,digest)).fetchone()
    if old:return {'id':old[0],'duplicate':True}
    if c.execute('SELECT COUNT(*) FROM lead_captures WHERE user_id=?',(uid,)).fetchone()[0]>=5000:raise ValueError('Lead limit reached: export or organise the existing 5,000 records.')
    lid=uuid.uuid4().hex;c.execute('INSERT INTO lead_captures(id,user_id,company,source_url,status,created,updated,dedupe) VALUES(?,?,?,?,?,?,?,?)',(lid,uid,fields['company'],fields['source_url'],fields['status'],now,now,digest))
   c.execute('UPDATE lead_captures SET project_id=?,company=?,website=?,email=?,phone=?,location=?,notes=?,source_url=?,status=?,updated=?,dedupe=? WHERE id=? AND user_id=?',(pid,*fields.values(),now,digest,lid,uid))
  return {'id':lid,'duplicate':False}
 def scan(self,url):
  validate_url(url);r=fetch(url,limit=1500000,timeout=15)
  if r['status']!=200:raise ValueError('The website did not return a readable page (HTTP '+str(r['status'])+'). Try its contact page or capture the open page with the extension.')
  if 'html' not in r['mime']:raise ValueError('Use a public HTML webpage.')
  page=Page();page.feed(r['body'].decode('utf-8',errors='replace'));return extract(r['url'],page.company or ''.join(page.title),' '.join(page.text),page.links)
 def export(self,uid):
  rows=self.list(uid);wb=Workbook();ws=wb.active;ws.title='Leads';headers=['Company','Website','Email','Phone','Location','Status','Notes','Source URL','Captured UTC','Updated UTC'];ws.append(headers)
  def safe(v):return "'"+v if isinstance(v,str) and v[:1] in {'=','+','-','@'} else v
  for r in rows:
   ws.append([safe(r[k] or '') for k in ['company','website','email','phone','location','status','notes','source_url']]+[datetime.datetime.fromtimestamp(r[k],datetime.timezone.utc).replace(tzinfo=None) for k in ['created','updated']])
  if not rows:ws.append(['']*10)
  end=ws.max_row;table=Table(displayName='LeadPipeline',ref=f'A1:J{end}');table.tableStyleInfo=TableStyleInfo(name='TableStyleMedium2',showRowStripes=True);ws.add_table(table);ws.freeze_panes='A2'
  for col,width in zip('ABCDEFGHIJ',[30,36,34,22,28,18,50,50,22,22]):ws.column_dimensions[col].width=width
  for row in ws.iter_rows(min_row=2):
   for cell in row:cell.alignment=Alignment(vertical='top',wrap_text=True)
   for idx in [8,9]:row[idx].number_format='dd mmm yyyy hh:mm'
  dv=DataValidation(type='list',formula1='"New,Reviewed,Contacted,Qualified,Not a fit,Opted out"');dv.errorTitle='Choose a status';dv.error='Select a value from the list.';dv.showErrorMessage=True;ws.add_data_validation(dv);dv.add('F2:F5001')
  summary=wb.create_sheet('Summary');summary.append(['Metric','Value']);summary.append(['Total leads','=COUNTA(Leads!A2:A5001)']);summary.append(['Reviewed','=COUNTIF(Leads!F2:F5001,"Reviewed")']);summary.append(['Qualified','=COUNTIF(Leads!F2:F5001,"Qualified")']);summary.append(['Opted out','=COUNTIF(Leads!F2:F5001,"Opted out")']);summary.column_dimensions['A'].width=28;summary.column_dimensions['B'].width=25
  notes=wb.create_sheet('Sources and method');notes.append(['Field','Details']);notes.append(['Updated UTC',datetime.datetime.now(datetime.timezone.utc).isoformat()]);notes.append(['Method','Visible website data captured or reviewed by the account owner; no inferred revenue, budgets or permission to contact.']);notes.append(['Review','Verify business details and communication permissions before outreach. Opted out records must not be contacted.']);notes.append(['Missing information','Empty cells mean not supplied or not found; they do not mean zero.']);notes.column_dimensions['A'].width=25;notes.column_dimensions['B'].width=100
  for sheet in wb:
   for cell in sheet[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='D66029')
  out=io.BytesIO();wb.save(out);return out.getvalue()
class LeadsHTTP:
 def leads_get(self,path,user):
  if path.endswith('/export.xlsx'):return self.response(200,self.leads.export(user['id']),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  return self.response(200,{'leads':self.leads.list(user['id'])})
 def leads_post(self,path,d,user):
  try:
   if path.endswith('/delete'):
    with self.workspace.connect() as c:
     if not c.execute('DELETE FROM lead_captures WHERE id=? AND user_id=?',(d.get('id'),user['id'])).rowcount:raise KeyError()
    return self.response(200,{'deleted':True})
   if path.endswith('/scan'):return self.response(200,self.leads.scan(d.get('url','')))
   return self.response(200,self.leads.save(user['id'],d))
  except sqlite3.IntegrityError:return self.fail(409,'Another saved lead already has this email, phone or company website.')
  except KeyError:return self.fail(404,'Lead or project not found in this account.')
  except (ValueError,TypeError,OSError) as e:return self.fail(400,str(e)[:300])
