"""Capability routing with explicit, server-owned external-provider opt-in."""
import json, os, re, time, urllib.request, urllib.error

OPENAI_MODELS = {'gpt-6-luna': 'GPT-6 Luna', 'gpt-6.1-sol': 'GPT-6.1 Sol'}

def account_models(user_id, mode='chat'):
    """Resolve access from persisted membership, never client role/plan claims."""
    from pathlib import Path
    from membership import Membership
    if type(user_id) is not int or user_id <= 0:
        raise ValueError('An authenticated account is required for OpenAI.')
    membership = Membership(Path(os.environ.get('SYNERGY_DATA_DIR', str(Path.home()/'.synergy-ai'))) / 'accounts.sqlite3')
    membership.require_provider(user_id, 'openai', mode)
    entitled = membership.entitlement(user_id)
    return ['gpt-6-luna', 'gpt-6.1-sol'] if entitled['usage_policy']['subscribed'] else ['gpt-6-luna']

def select_openai(user_id, mode='chat', requested='auto'):
    allowed = account_models(user_id, mode)
    if requested not in {'auto', *OPENAI_MODELS}:
        raise ValueError('Choose GPT-6 Luna or GPT-6.1 Sol.')
    model = allowed[-1] if requested == 'auto' else requested
    if model not in allowed:
        raise ValueError('GPT-6.1 Sol requires an active paid subscription or administrator access.')
    return model

def validate_openai(selection):
    key, _, enabled = external_config()
    if not enabled or selection.get('provider') != 'openai':
        raise ValueError('External inference is disabled.')
    model = select_openai(selection.get('user_id'), selection.get('mode', 'chat'), selection.get('model'))
    return key, model

LOCAL_MODELS = {
    'balanced': ('aerny:v2.0', 'Balanced', 'Writing, planning and code'),
    'fast': ('aerny-fast:v2.0', 'Fast', 'Short, straightforward requests'),
    'vision': ('qwen3-vl:2b-instruct', 'Vision', 'Read uploaded images'),
}

def external_config():
    key = os.environ.get('OPENAI_API_KEY', '')
    model = os.environ.get('SYNERGY_OPENAI_MODEL', '')
    enabled = os.environ.get('SYNERGY_ALLOW_OPENAI') == '1' and bool(key and model)
    return key, model, enabled

def catalog():
    _, model, enabled = external_config()
    import free_router
    free_enabled=free_router.enabled()
    import openai_budget
    health=openai_budget.status()['provider_status']
    hint={'quota_exhausted':'temporarily unavailable','authentication_failed':'connection needs attention','rate_limited':'temporarily rate limited','request_failed':'last request failed'}.get(health['state'],'connected' if health['state']=='available' else 'configured')
    try:
        with urllib.request.urlopen(os.environ.get('SYNERGY_OLLAMA_URL','http://127.0.0.1:11434').rstrip('/')+'/api/tags', timeout=3) as r:
            installed = {m['name'] for m in json.load(r).get('models', [])}
    except (OSError, ValueError, KeyError): installed = set()
    return {'version':'2.0','providers':[
        {'id':'synergy','name':'SYnerGY','available':bool(installed),'detail':'Inference on this server'},
        {'id':'openai','name':'OpenAI','available':enabled,'status_hint':hint if enabled else 'not connected','detail':model+' · '+hint if enabled else 'Not connected. External requests are disabled.'},
        {'id':'hybrid','name':'Hybrid','available':bool(installed) or enabled or free_enabled,'detail':'Eligible connected services first, with local fallback' if free_enabled else 'Connected services first, with local fallback.'}],
        'local_models':[{'id':k,'name':v[1],'model':v[0],'capability':v[2],'available':v[0] in installed} for k,v in LOCAL_MODELS.items()],
        'openai_model':model if enabled else None,'openai_models':[{'id':k,'name':v,'paid':k=='gpt-6.1-sol','available':enabled} for k,v in OPENAI_MODELS.items()], 'external_enabled':enabled or free_enabled,'hybrid_free_routing':free_enabled}

def route(provider='synergy', choice='auto', effort='medium', prompt='', vision=False, complex_context=False, mode='chat',family=None,user_id=None,openai_model='auto'):
    if family not in {None,'aerny','eternal'}:raise ValueError('Choose Aerny or ETERNAL.')
    if provider not in {'synergy','openai','hybrid'} or choice not in {'auto',*LOCAL_MODELS}:
        raise ValueError('Choose a supported provider and model.')
    _, external_model, enabled = external_config()
    import free_router
    free_enabled=free_router.enabled()
    difficult = effort in {'max','ultra'} or len(prompt)>2200 or bool(re.search(r'\b(audit|architecture|multi.step|proof|debug)\b',prompt,re.I))
    if provider=='openai' and not enabled:
        raise ValueError('OpenAI is not connected. Choose SYnerGY or Hybrid to use the local models.')
    if provider=='openai':
        external_model=select_openai(user_id,mode,openai_model)
        return {'provider':'openai','user_id':user_id,'mode':mode,'reasoning_effort':{'instant':'low','medium':'medium','high':'high','max':'xhigh','ultra':'max'}.get(effort,'medium'),'model':external_model,'label':'OpenAI · '+OPENAI_MODELS[external_model],'reason':'Selected OpenAI model; account entitlement verified on the server.'}
    selected='vision' if vision else choice
    if selected=='auto':
        # Short levels use the fast profile only for simple self-contained requests.
        advanced=bool(re.search(r'\b(code|coding|build|implement|python|javascript|research|sources|diagnos|medical|legal|contract|invest|security|compare|strategy|calculate|reason|proof|debug)\w*\b',prompt,re.I))
        selected='fast' if effort in {'instant','medium'} and len(prompt)<=420 and not (complex_context or difficult or advanced) else 'balanced'
    model,label,_=LOCAL_MODELS[selected];label='Aerny 2.0 · '+label
    if family=='eternal' or (family is None and mode in {'work','beast'}):
        model={'balanced':'eternal:v1.0','fast':'eternal-fast:v1.0'}.get(selected,model);label='ETERNAL · '+selected.title()
    if provider=='hybrid':
        planned=select_openai(user_id,mode) if enabled and user_id is not None else None
        return {'provider':'synergy','model':model,'user_id':user_id,'mode':mode,'planned_openai_model':planned,'routing_decisions':1,'label':('Aerny' if family=='aerny' else 'ETERNAL')+' · Hybrid','workflow':'hybrid_free','reason':'One account-aware plan: eligible OpenAI model, then local fallback. Tool permissions and provider budgets apply.'}
    return {'provider':'synergy','model':model,'label':label,'reason':('Hybrid selected a local model. OpenAI is unavailable.' if provider=='hybrid' and not enabled else 'Image understanding' if vision else 'Selected local model' if choice!='auto' else 'Matched to the response level and request')}

def openai_response(messages, selection, limit):
    key, model = validate_openai(selection)
    inputs=[]
    for m in messages[1:]:
        content=[{'type':'input_text','text':m['content']}] if m['role']=='user' else m['content']
        if m.get('images'):
            content += [{'type':'input_image','image_url':('data:image/jpeg;base64,' if i.startswith('/9j/') else 'data:image/png;base64,')+i} for i in m['images']]
        inputs.append({'role':m['role'],'content':content})
    body={'model':model,'instructions':messages[0]['content'],'input':inputs,'max_output_tokens':limit,'reasoning':{'effort':selection.get('reasoning_effort','low')},'store':False}
    import openai_budget
    reservation=openai_budget.reserve(body,user_id=selection['user_id'])
    req=urllib.request.Request('https://api.openai.com/v1/responses',data=json.dumps(body).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+key})
    try:
        with urllib.request.urlopen(req,timeout=max(.2,min(180,selection.get('deadline',time.monotonic()+180)-time.monotonic()))) as r:data=json.load(r)
    except urllib.error.HTTPError as exc:raise ValueError(openai_budget.reject(reservation,exc)) from None
    openai_budget.finish(reservation,data.get('usage'))
    text='\n'.join(c.get('text','') for item in data.get('output',[]) if item.get('type')=='message' for c in item.get('content',[]) if c.get('type')=='output_text')
    if not text.strip(): raise ValueError('OpenAI returned no text response.')
    return text
