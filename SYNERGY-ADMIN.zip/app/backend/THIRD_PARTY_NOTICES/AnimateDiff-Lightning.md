# AnimateDiff-Lightning

The deployed CPU video worker uses a separately downloaded, pretrained motion adapter published by ByteDance, combined with epiCRealism (a Stable Diffusion 1.5 derivative). The package does not contain either model's weights.

Official model card: https://huggingface.co/ByteDance/AnimateDiff-Lightning
Model card license declaration: CreativeML Open RAIL-M.
Pinned revision: 027c893eec01df7330f5d4b733bc9485ee02e8b2
Adapter: animatediff_lightning_4step_diffusers.safetensors
SHA-256: 8f3330914edd8fc2ee5659e6944323858feb0ec21cc913789202d043f69b5e17

Follow the upstream model and component license terms. SYnerGY and AeRny v1.4 name the application and assistant configuration, not ownership of third-party pretrained weights.

Base model: https://huggingface.co/emilianJR/epiCRealism
Pinned revision: 6522cf856b8c8e14638a0aaa7bd89b1b098aed17
Declared license: CreativeML Open RAIL-M.
File sizes and weight hashes: ../video_studio/models.lock.json
