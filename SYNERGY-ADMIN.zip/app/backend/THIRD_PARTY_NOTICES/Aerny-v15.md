# Aerny v1.5 components

Model weights are installed separately and are not redistributed in this source archive. Retain upstream terms and required notices with any subsequent distribution. These are source declarations, not a legal warranty for every downstream use.

| Component | Upstream licence / source | Use |
|---|---|---|
| epiCRealism / SD1.5 | CreativeML OpenRAIL-M; https://huggingface.co/emilianJR/epiCRealism/blob/main/README.md and https://huggingface.co/spaces/CompVis/stable-diffusion-license | Local CPU image inference |
| LCM-LoRA SDv1.5 | OpenRAIL++; https://huggingface.co/latent-consistency/lcm-lora-sdv1-5/blob/main/README.md | Optional local acceleration adapter |
| Diffusers, Transformers, PEFT | Apache-2.0; https://github.com/huggingface/peft/blob/v0.12.0/LICENSE | Local pipeline and adapter loading |
| Pillow | HPND-style Pillow/PIL licence; https://github.com/python-pillow/Pillow/blob/11.3.0/LICENSE | Raster validation and exact composition |
| DejaVu Sans fonts | Included DejaVu/Bitstream notices in image_studio/fonts/LICENSE.txt | Embedded fonts and exact text |
| Qwen3 and Qwen3-VL | Apache-2.0 as declared by upstream Qwen model repositories | Existing local chat and vision weights |

Inference uses safetensors and local_files_only. The installed safety checker remains enabled. No hosted image service is used. No training was performed; loading an existing LoRA for inference is not training a new LoRA.
