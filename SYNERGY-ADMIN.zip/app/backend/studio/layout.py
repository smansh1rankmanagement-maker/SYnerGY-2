"""Exact raster and editable SVG composition. No generated text or logo redraws."""
from pathlib import Path
from io import BytesIO
import base64, html, re
from PIL import Image, ImageOps, ImageDraw, ImageFont

FONTS = Path(__file__).resolve().parents[1] / 'image_studio' / 'fonts'
FONT_FILES = {'sans':'DejaVuSans.ttf','bold':'DejaVuSansCondensed-Bold.ttf'}

def colour(value):
    if not isinstance(value,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',value):
        raise ValueError('Use a six-digit hex colour.')
    return value

def fit(image, size, fill='#f4f0e9'):
    return ImageOps.pad(image.convert('RGB'),size,method=Image.Resampling.LANCZOS,color=fill)

def data_uri(image):
    b=BytesIO(); image.save(b,format='PNG')
    return 'data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()

def layout(base, spec, assets):
    width,height=spec['width'],spec['height']
    frame=spec.get('image_frame',{'x':0,'y':0,'width':100,'height':100})
    x,y,w,h=[round(frame[k]*(width if k in {'x','width'} else height)/100) for k in ['x','y','width','height']]
    out=Image.new('RGBA',(width,height),spec.get('background','#f4f0e9'))
    placed=(ImageOps.fit(base.convert('RGB'),(w,h),method=Image.Resampling.LANCZOS) if frame.get('fit')=='cover' else fit(base,(w,h),spec.get('background','#f4f0e9'))).convert('RGBA');out.alpha_composite(placed,(x,y))
    svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
         f'<rect width="{width}" height="{height}" fill="{spec.get("background","#f4f0e9")}"/>',
         f'<image id="background-image" x="{x}" y="{y}" width="{w}" height="{h}" href="{data_uri(placed)}"/>']
    checks=[]
    # Layers use percentages so the saved composition can be resized deliberately.
    for i,layer in enumerate(spec.get('layers',[])):
        x=round(layer['x']*width/100);y=round(layer['y']*height/100)
        w=round(layer['width']*width/100);h=round(layer['height']*height/100)
        if layer['type']=='logo':
            with Image.open(assets[layer['asset_id']]) as img:logo=img.convert('RGBA')
            bbox=logo.getchannel('A').getbbox()
            if bbox:logo=logo.crop(bbox)
            logo=ImageOps.contain(logo,(w,h),method=Image.Resampling.LANCZOS)
            out.alpha_composite(logo,(x,y))
            svg.append(f'<image id="layer-{i}" x="{x}" y="{y}" width="{logo.width}" height="{logo.height}" href="{data_uri(logo)}"/>')
            checks.append({'layer':i,'type':'logo','asset_id':layer['asset_id'],'redrawn':False})
        elif layer['type']=='text':
            text=layer['text'];size=max(8,round(layer.get('size',6)*width/100));filename=FONT_FILES[layer.get('font','bold')]
            draw=ImageDraw.Draw(out);lines=[]
            while size>=8:
                font=ImageFont.truetype(str(FONTS/filename),size)
                lines=[]
                for paragraph in text.split('\n'):
                    current=''
                    for word in paragraph.split(' '):
                        candidate=(current+' '+word).strip()
                        if current and draw.textlength(candidate,font=font)>w:lines.append(current);current=word
                        else:current=candidate
                    lines.append(current)
                line_h=round(size*1.3)
                if len(lines)*line_h<=h and all(draw.textlength(t,font=font)<=w for t in lines):break
                size-=1
            if size<8:raise ValueError('Text does not fit its layer. Increase the text box or shorten the headline.')
            if layer.get('panel'):
                panel=colour(layer.get('panel_colour','#171717'));draw.rectangle((x,y,x+w,y+h),fill=panel)
                svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{panel}"/>')
            font64=base64.b64encode((FONTS/filename).read_bytes()).decode()
            family='SynergyFont'+str(i)
            svg.append(f'<defs><style>@font-face{{font-family:{family};src:url(data:font/ttf;base64,{font64})}}</style></defs>')
            for n,line in enumerate(lines):
                ty=y+n*line_h
                draw.text((x,ty),line,font=font,fill=layer['colour'],anchor='lt')
                svg.append(f'<text id="text-{i}-{n}" x="{x}" y="{ty}" dominant-baseline="text-before-edge" font-family="{family}" font-size="{size}" fill="{layer["colour"]}">{html.escape(line)}</text>')
            checks.append({'layer':i,'type':'text','text':text,'font':filename,'font_size_px':size,'fits':True})
    svg.append('</svg>')
    return out.convert('RGB'),'\n'.join(svg),{'dimensions':[width,height],'layers':checks,'visual_review_required':True}
