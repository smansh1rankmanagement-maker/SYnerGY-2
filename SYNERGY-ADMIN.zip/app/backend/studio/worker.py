"""Isolated, user-owned CPU inference. Terminable between or during model calls."""
from pathlib import Path
import json, os, sys, time, math
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PIL import Image, ImageFilter, ImageChops, ImageOps
from layout import layout, fit

def atomic(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value));tmp.replace(path)

def main(folder):
    started=time.monotonic();job=json.loads((folder/'input.json').read_text());spec=job['spec'];assets=job['assets']
    def progress(stage,step=0,total=0):atomic(folder/'progress.json',dict(stage=stage,step=step,total=total,elapsed=round(time.monotonic()-started,1)))
    dims=(spec['width'],spec['height']);workflow=spec['workflow'];ref=spec.get('reference_id') if workflow!='generate' else None
    native=None;model='Pillow layout engine';scheduler=None;steps=0;clipped=False
    if workflow=='layout':
        progress('Composing exact layers')
        base=Image.open(assets[ref]).convert('RGB') if ref else Image.new('RGB',dims,spec.get('background','#f4f0e9'))
        # Layout places the original base into its frame once. Pre-padding it to
        # the canvas here would add nested borders on every conversational edit.
    else:
        progress('Loading local image model')
        import torch
        device=os.environ.get('SYNERGY_DEVICE','cpu')
        if device not in {'cpu','cuda'} or (device=='cuda' and not torch.cuda.is_available()):raise RuntimeError('The requested inference device is unavailable.')
        from diffusers import StableDiffusionPipeline, StableDiffusionImg2ImgPipeline, StableDiffusionInpaintPipeline, DPMSolverMultistepScheduler, LCMScheduler
        torch.set_num_threads(min(4,max(1,(os.cpu_count() or 2)//2)));torch.set_num_interop_threads(1)
        manifest=json.loads(Path(job['manifest']).read_text());model=manifest['model_id']
        klass={'generate':StableDiffusionPipeline,'transform':StableDiffusionImg2ImgPipeline,'inpaint':StableDiffusionImg2ImgPipeline}[workflow]
        pipe=klass.from_pretrained(manifest['path'],torch_dtype=torch.float16 if device=='cuda' else torch.float32,use_safetensors=True,local_files_only=True)
        if pipe.safety_checker is None:raise RuntimeError('The required safety checker is missing.')
        pipe.to(device);pipe.enable_attention_slicing();pipe.enable_vae_slicing();pipe.set_progress_bar_config(disable=True)
        fast=spec['quality']=='fast'
        if fast:
            adapter=Path(job['adapter'])
            if not (adapter/'verified.json').exists():raise RuntimeError('Fast image adapter is unavailable. Retry with Enhanced quality.')
            pipe.load_lora_weights(str(adapter),weight_name='pytorch_lora_weights.safetensors',local_files_only=True)
            pipe.fuse_lora();pipe.scheduler=LCMScheduler.from_config(pipe.scheduler.config);scheduler='LCM-LoRA SDv1.6';steps=8
        else:
            pipe.scheduler=DPMSolverMultistepScheduler.from_config(pipe.scheduler.config,algorithm_type='dpmsolver++',solver_order=2,use_karras_sigmas=True)
            scheduler='DPM++ 2M Karras';steps=28 if spec['quality']=='balanced' else 32
        # Native inference budget is separate from export dimensions.
        budget=512 if fast else 640 if spec['quality']=='balanced' else 768
        scale=min(budget/max(dims),math.sqrt((512*512 if fast else 640*640)/(dims[0]*dims[1])))
        nw=max(256,round(dims[0]*scale/8)*8);nh=max(256,round(dims[1]*scale/8)*8);native=[nw,nh]
        extra={};strength=spec['strength'];total=steps
        if ref:
            with Image.open(assets[ref]) as original:reference=fit(original,dims)
            extra['image']=fit(reference,(nw,nh));extra['strength']=strength;total=max(1,int(steps*strength))
            # At least four denoising steps for fast reference editing.
            if fast:steps=max(8,math.ceil(4/strength));total=int(steps*strength)
            if workflow=='inpaint':
                with Image.open(assets[spec['mask_id']]) as m:mask=m.convert('L').resize(dims,Image.Resampling.NEAREST)
                if mask.getextrema()[1]==0:raise ValueError('Paint the area to edit before submitting.')
                bounds=mask.getbbox();padding=max(64,round(max(bounds[2]-bounds[0],bounds[3]-bounds[1])*.35))
                crop_box=(max(0,bounds[0]-padding),max(0,bounds[1]-padding),min(dims[0],bounds[2]+padding),min(dims[1],bounds[3]+padding))
                crop_size=(crop_box[2]-crop_box[0],crop_box[3]-crop_box[1]);ratio=budget/max(crop_size)
                nw=max(256,round(crop_size[0]*ratio/8)*8);nh=max(256,round(crop_size[1]*ratio/8)*8);native=[nw,nh]
                extra['image']=fit(reference.crop(crop_box),(nw,nh))
        else:extra.update(width=nw,height=nh)
        prompt=spec['prompt'];clipped=len(pipe.tokenizer(prompt,truncation=False)['input_ids'])>pipe.tokenizer.model_max_length
        def callback(pipeline,step,timestep,kwargs):progress('Editing selected area' if workflow=='inpaint' else 'Generating image',step+1,total);return kwargs
        progress('Starting inference',0,total)
        with torch.inference_mode():
            result=pipe(prompt=prompt,negative_prompt=spec['negative'],num_inference_steps=steps,guidance_scale=1.5 if fast else 7.0,
                generator=torch.Generator('cpu').manual_seed(spec['seed']),callback_on_step_end=callback,**extra)
        if result.nsfw_content_detected and result.nsfw_content_detected[0]:raise ValueError('The image safety check blocked this result. Revise the brief and try again.')
        progress('Preparing export')
        base=fit(result.images[0],dims)
        if workflow=='inpaint':
            base=reference.copy()
            base.paste(ImageOps.fit(result.images[0],crop_size,method=Image.Resampling.LANCZOS),crop_box[:2])
            # White is editable; every zero-mask pixel is copied exactly from the reference.
            # Feather inward only: black/protected pixels remain exactly unchanged.
            feather=ImageChops.subtract(mask.filter(ImageFilter.GaussianBlur(8)),Image.new('L',dims,128)).point(lambda v:min(255,v*2))
            feather=ImageChops.multiply(feather,mask)
            if feather.getextrema()[1]==0:feather=mask
            base=Image.composite(base,reference,feather)
        del pipe
    base.save(folder/'base.png')
    progress('Placing exact text and logos')
    out,svg,checks=layout(base,spec,assets);out.save(folder/'output.png');(folder/'output.svg').write_text(svg)
    atomic(folder/'result.json',{'model':model,'model_revision':manifest.get('revision') if workflow!='layout' else None,
        'scheduler':scheduler,'steps':steps,'native_dimensions':native,'export_dimensions':list(dims),'checks':checks,
        'workflow':workflow,'provider':'local','device':device if workflow!='layout' else 'cpu','seconds':round(time.monotonic()-started,2),
        'edit_engine':'cropped image-to-image with protected-pixel compositing' if workflow=='inpaint' else None,'prompt_truncated':clipped,'seed':spec['seed'],'protected_pixels_exact':workflow=='inpaint',
        'note':'Protected pixels are retained before layout overlays. Regenerated subjects require visual review.' if workflow=='inpaint' else 'Exact layout; generated detail requires visual review. Enlarged exports are not native 4K inference.'})
    progress('Complete',1,1)

if __name__=='__main__':
    folder=Path(sys.argv[1])
    try:
        from media_compute import inference_slot
        with inference_slot(folder):main(folder)
    except Exception as exc:
        atomic(folder/'error.json',{'detail':str(exc)[:600]});raise
