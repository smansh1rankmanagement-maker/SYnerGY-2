"""Bounded brief-to-workflow planning. Text/logos remain deterministic layers."""
import copy, re

def plan(brief, previous=None, reference_id=None, brands=()):
    if not isinstance(brief,str) or not 1<=len(brief.strip())<=3000:raise ValueError('Enter a brief up to 3,000 characters.')
    s=copy.deepcopy(previous) if previous else {'width':1080,'height':1350,'quality':'fast','strength':.35,'seed':42,'layers':[],'category':'Photorealistic images','background':'#f4f0e9'}
    lower=brief.casefold();s['prompt']=brief
    dimensions=re.search(r'\b(\d{3,4})\s*[×xX]\s*(\d{3,4})\b',brief)
    if dimensions:s['width'],s['height']=map(int,dimensions.groups())
    elif not previous:
        if re.search(r'instagram\s*post|insta\s*post|social media post',lower):s.update(width=1080,height=1350)
        elif 'thumbnail' in lower:s.update(width=1280,height=720)
        elif re.search(r'\b(logo|icon)\b',lower):s.update(width=1024,height=1024)
    if reference_id:s['reference_id']=reference_id
    s['workflow']='transform' if s.get('reference_id') else 'generate'
    if re.search(r'\b(poster|thumbnail|launch post)\b',lower):s['category']='Posters and thumbnails'
    elif re.search(r'\b(office|interior|furniture)\b',lower):s['category']='Interior concepts'
    elif re.search(r'\b(logo|icon|wordmark)\b',lower):s['category']='Logos and icons'
    if re.search(r'instagram\s*post|insta\s*post|social media',lower):s['category']='Social media designs'
    exact_text=re.search(r'(?:headline|title|text|wordmark)\s*(?:to|is|:|=|says|reading)?\s*["“](.+?)["”]',brief,re.I|re.S)
    if exact_text:
        layer={'type':'text','text':exact_text[1],'x':6,'y':6,'width':88,'height':20,'size':5.8,'font':'bold','colour':'#2d241e','panel':False,'panel_colour':'#171717'}
        prior=next((x for x in s['layers'] if x['type']=='text'),None)
        if prior:prior['text']=exact_text[1]
        else:
            s['layers'].append(layer)
            # Reserve typography space, so a default headline never obscures the
            # reference. Follow-up edits preserve the existing frame and layers.
            if not s.get('image_frame'):s['image_frame']={'x':5,'y':28,'width':90,'height':66,'fit':'contain'}
    brand=next((b for b in brands if b['name'].casefold() in lower and b['approved']),None)
    if brand and not any(x['type']=='logo' and x['asset_id']==brand['logo_id'] for x in s['layers']):
        s['layers'].append({'type':'logo','asset_id':brand['logo_id'],'x':68,'y':4,'width':26,'height':20})
        for l in s['layers']:
            if l['type']=='text':l.update(colour=brand['colour'],font=brand['font'])
    layout_edit=bool(previous and (exact_text or dimensions or re.search(r'\b(remove (?:the )?(?:headline|text|logo)|layout only)\b',lower)))
    preserve=bool(re.search(r'\b(keep (?:the )?(?:image|photo|reference) (?:exact|unchanged)|layout only|wordmark|text logo)\b',lower))
    if layout_edit or preserve:s['workflow']='layout'
    if re.search(r'remove (?:the )?(headline|text)',lower):s['layers']=[l for l in s['layers'] if l['type']!='text']
    if re.search(r'remove (?:the )?logo',lower):s['layers']=[l for l in s['layers'] if l['type']!='logo']
    localized=bool(re.search(r'\b(selected area|selection|mask|only (?:the )?(?:chair|sofa|wall|table))\b',lower))
    needs_mask=localized and not s.get('mask_id')
    if localized and s.get('reference_id') and s.get('mask_id'):s['workflow']='inpaint'
    if s['workflow']=='generate':s.pop('mask_id',None)
    return {'spec':s,'needs_mask':needs_mask,'brand':brand['name'] if brand else None,
        'summary':{'generate':'Generate a new image with the local model.','transform':'Create a variation from the reference. Regenerated details may change.','inpaint':'Edit the painted area and keep unpainted pixels.','layout':'Keep the base image and compose exact text/logo layers.'}[s['workflow']],
        'missing_brand':bool(re.search(r'(?:approved|our|brand) logo',lower) and not brand and not any(l['type']=='logo' for l in s['layers']))}
