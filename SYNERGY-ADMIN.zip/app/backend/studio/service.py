"""Account-scoped projects, raster assets and a durable single-worker image queue."""
from pathlib import Path
from io import BytesIO
import base64, json, os, re, sqlite3, subprocess, threading, time, uuid, urllib.request
from PIL import Image, ImageOps
from .layout import colour

CATEGORIES=['Photorealistic images','Product photography','Advertising creatives','Social media designs','Posters and thumbnails','Founder portraits','Fashion editorials','Interior concepts','Architectural concepts','Illustrations','Character design','Storyboards','Cinematic frames','3D-style artwork','Logos and icons','Packaging mockups','Website assets','Patterns and textures','Educational graphics','Image variations']

def atomic(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value));tmp.replace(path)

class Studio:
    def __init__(self,db,root,manifest,python,adapter,busy=lambda:False,gate=None,start=True,recover=True):
        self.db=Path(db);self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.manifest=Path(manifest);self.python=str(python);self.adapter=str(adapter);self.busy=busy;self.gate=gate or threading.RLock()
        self.stop=threading.Event();self.wake=threading.Event();self.process=None;self.active=None
        with self.connection() as c:
            c.executescript('''CREATE TABLE IF NOT EXISTS studio_assets(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,name TEXT NOT NULL,width INTEGER,height INTEGER,created REAL);
            CREATE TABLE IF NOT EXISTS studio_projects(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,title TEXT NOT NULL,spec TEXT NOT NULL,created REAL,updated REAL,revision INTEGER NOT NULL DEFAULT 0,last_job TEXT);
            CREATE TABLE IF NOT EXISTS studio_jobs(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,project_id TEXT NOT NULL,state TEXT NOT NULL,spec TEXT NOT NULL,created REAL,started REAL,finished REAL,error TEXT,result TEXT);
            CREATE TABLE IF NOT EXISTS studio_brands(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,name TEXT NOT NULL,logo_id TEXT NOT NULL,colour TEXT NOT NULL,font TEXT NOT NULL,approved INTEGER NOT NULL DEFAULT 0);''')
            if recover:c.execute("UPDATE studio_jobs SET state='failed',error='The app restarted during this job. Your reference and settings are saved; use Retry.',finished=? WHERE state='running'",(time.time(),))
        if start:threading.Thread(target=self.run,daemon=True,name='aerny-image-queue').start()

    def connection(self):
        c=sqlite3.connect(self.db,timeout=20);c.row_factory=sqlite3.Row;return c
    def folder(self,jid):return self.root/'jobs'/jid
    def asset_path(self,uid,aid):
        with self.connection() as c:r=c.execute('SELECT * FROM studio_assets WHERE id=? AND user_id=?',(aid,uid)).fetchone()
        if not r:raise KeyError('Asset not found')
        return self.root/'assets'/(aid+'.png')
    def add_asset(self,uid,data,name='Reference',internal=False):
        if not isinstance(data,bytes) or not 1<=len(data)<=(64 if internal else 8)*1024*1024:raise ValueError('Use a PNG or JPEG under 8 MB.')
        Image.MAX_IMAGE_PIXELS=24000000
        try:
            with Image.open(BytesIO(data)) as im:
                if im.format not in {'PNG','JPEG'} or im.width*im.height>24000000:raise ValueError('Use a PNG or JPEG up to 24 megapixels.')
                im=ImageOps.exif_transpose(im).convert('RGBA');im.load()
        except (OSError,Image.DecompressionBombError,Image.DecompressionBombWarning):raise ValueError('This image cannot be read. Use PNG or JPEG.')
        aid=uuid.uuid4().hex;p=self.root/'assets';p.mkdir(exist_ok=True,mode=0o700);im.save(p/(aid+'.png'))
        with self.connection() as c:c.execute('INSERT INTO studio_assets VALUES(?,?,?,?,?,?)',(aid,uid,str(name)[:160],im.width,im.height,time.time()))
        return {'id':aid,'name':str(name)[:160],'width':im.width,'height':im.height,'url':'/api/studio/assets/'+aid}
    def spec(self,uid,s):
        if not isinstance(s,dict):raise ValueError('Provide project settings.')
        workflow=s.get('workflow','generate')
        if workflow not in {'generate','transform','inpaint','layout'}:raise ValueError('Choose Generate, Transform, Selective edit or Layout.')
        try:w=int(s.get('width',1080));h=int(s.get('height',1350));strength=float(s.get('strength',.4));seed=int(s.get('seed',42))
        except (TypeError,ValueError):raise ValueError('Invalid dimensions, strength or seed.')
        if not 256<=w<=4096 or not 256<=h<=4096 or w*h>16777216:raise ValueError('Dimensions must be between 256 and 4096 pixels.')
        if not .15<=strength<=.95 or not 0<=seed<2147483648:raise ValueError('Strength must be 0.15–0.95 and seed 0–2147483647.')
        prompt=s.get('prompt','');negative=s.get('negative','blurry, low resolution, distorted anatomy, duplicate objects, watermark, text, lettering')
        if not isinstance(prompt,str) or len(prompt)>3000 or (workflow!='layout' and not prompt.strip()):raise ValueError('Enter a visual brief of up to 3,000 characters.')
        if not isinstance(negative,str) or len(negative)>1000:raise ValueError('Negative prompt is too long.')
        quality=s.get('quality','fast')
        if quality not in {'fast','balanced','detail'}:raise ValueError('Choose a quality setting.')
        result={'workflow':workflow,'prompt':prompt,'negative':negative,'width':w,'height':h,'strength':strength,'seed':seed,'quality':quality,'category':str(s.get('category','Photorealistic images'))[:100],'background':colour(s.get('background','#f4f0e9')),'layers':[]}
        if s.get('image_frame'):
            f={k:float(s['image_frame'].get(k,v)) for k,v in [('x',0),('y',0),('width',100),('height',100)]}
            if any(not 0<=v<=100 for v in f.values()) or f['width']<1 or f['height']<1 or f['x']+f['width']>100 or f['y']+f['height']>100:raise ValueError('Keep the image frame inside the canvas.')
            f['fit']='cover' if s['image_frame'].get('fit')=='cover' else 'contain'
            result['image_frame']=f
        for k in ['reference_id','mask_id']:
            if s.get(k):self.asset_path(uid,s[k]);result[k]=s[k]
        if workflow in {'transform','inpaint'} and not result.get('reference_id'):raise ValueError('Add a reference image first.')
        if workflow=='inpaint' and not result.get('mask_id'):raise ValueError('Paint the area you want to change.')
        if workflow=='inpaint':
            with Image.open(self.asset_path(uid,result['mask_id'])) as m:
                if m.convert('L').getextrema()[1]==0:raise ValueError('Paint the area you want to change.')
        layers=s.get('layers',[])
        if not isinstance(layers,list) or len(layers)>12:raise ValueError('Use up to 12 layers.')
        for l in layers:
            if not isinstance(l,dict) or l.get('type') not in {'text','logo'}:raise ValueError('Unsupported layer.')
            t={'type':l['type']}
            for key,default in [('x',5),('y',5),('width',90),('height',20)]:
                try:t[key]=float(l.get(key,default))
                except (ValueError,TypeError):raise ValueError('Invalid layer position.')
                if not 0<=t[key]<=100 or (key in {'width','height'} and t[key]<1):raise ValueError('Layer positions and sizes use percentages from 0 to 100.')
            if t['x']+t['width']>100 or t['y']+t['height']>100:raise ValueError('Keep layers inside the canvas.')
            if t['type']=='logo':self.asset_path(uid,l.get('asset_id'));t['asset_id']=l['asset_id']
            else:
                text=l.get('text','')
                if not isinstance(text,str) or not 1<=len(text)<=1000:raise ValueError('Text layers need 1–1,000 characters.')
                font=l.get('font','bold')
                if font not in {'sans','bold'}:raise ValueError('Choose an installed font.')
                t.update(text=text,font=font,colour=colour(l.get('colour','#ffffff')),size=max(1,min(30,float(l.get('size',6)))),panel=bool(l.get('panel',False)),panel_colour=colour(l.get('panel_colour','#171717')))
            result['layers'].append(t)
        return result
    def projects(self,uid):
        with self.connection() as c:rows=c.execute('SELECT * FROM studio_projects WHERE user_id=? ORDER BY updated DESC LIMIT 100',(uid,)).fetchall()
        return [self.project_public(r) for r in rows]
    def project_public(self,r):
        d=dict(r);d.pop('user_id');d['spec']=json.loads(d['spec']);return d
    def project(self,uid,pid):
        with self.connection() as c:r=c.execute('SELECT * FROM studio_projects WHERE id=? AND user_id=?',(pid,uid)).fetchone()
        if not r:raise KeyError('Project not found')
        d=self.project_public(r);d['jobs']=self.jobs(uid,pid);return d
    def save(self,uid,d):
        spec=self.spec(uid,d.get('spec',{}));pid=d.get('id');now=time.time();title=str(d.get('title') or spec['prompt'][:70] or 'Untitled design')[:100]
        with self.connection() as c:
            c.execute('BEGIN IMMEDIATE')
            if pid:
                row=c.execute('SELECT revision FROM studio_projects WHERE id=? AND user_id=?',(pid,uid)).fetchone()
                if not row:raise KeyError('Project not found')
                if 'revision' in d and d['revision']!=row['revision']:raise ValueError('This project changed. Reopen it before saving.')
                c.execute('UPDATE studio_projects SET title=?,spec=?,updated=?,revision=revision+1 WHERE id=? AND user_id=?',(title,json.dumps(spec),now,pid,uid))
            else:
                pid=uuid.uuid4().hex;c.execute('INSERT INTO studio_projects(id,user_id,title,spec,created,updated) VALUES(?,?,?,?,?,?)',(pid,uid,title,json.dumps(spec),now,now))
        return self.project(uid,pid)
    def brands(self,uid):
        with self.connection() as c:return [dict(r) for r in c.execute('SELECT id,name,logo_id,colour,font,approved FROM studio_brands WHERE user_id=?',(uid,))]
    def save_brand(self,uid,d):
        self.asset_path(uid,d.get('logo_id'));name=str(d.get('name','')).strip()[:80]
        if not name:raise ValueError('Name the brand kit.')
        font=d.get('font','bold')
        if font not in {'sans','bold'}:raise ValueError('Choose an installed font.')
        bid=uuid.uuid4().hex
        with self.connection() as c:c.execute('INSERT INTO studio_brands VALUES(?,?,?,?,?,?,?)',(bid,uid,name,d['logo_id'],colour(d.get('colour','#ffffff')),font,int(d.get('approved') is True)))
        return next(b for b in self.brands(uid) if b['id']==bid)
    def jobs(self,uid,pid=None):
        with self.connection() as c:
            rows=c.execute('SELECT * FROM studio_jobs WHERE user_id=?'+(' AND project_id=?' if pid else '')+' ORDER BY created DESC LIMIT 100',(uid,pid) if pid else (uid,)).fetchall()
        return [self.public(r) for r in rows]
    def job(self,uid,jid):
        with self.connection() as c:r=c.execute('SELECT * FROM studio_jobs WHERE id=? AND user_id=?',(jid,uid)).fetchone()
        if not r:raise KeyError('Job not found')
        return self.public(r)
    def public(self,r):
        d=dict(r);d.pop('user_id');d['spec']=json.loads(d['spec']);d['result']=json.loads(d['result']) if d['result'] else None
        d['elapsed']=round((d['finished'] or time.time())-(d['started'] or d['created']),1);d['progress']={'stage':'Waiting for available compute','step':0,'total':0}
        p=self.folder(d['id'])/'progress.json'
        if p.exists():
            try:d['progress']=json.loads(p.read_text())
            except (ValueError,OSError):pass
        if d['state']=='queued':
            with self.connection() as c:d['queue_position']=c.execute("SELECT COUNT(*) FROM studio_jobs WHERE state='queued' AND created<=?",(d['created'],)).fetchone()[0]
        d['result_url']=f'/api/studio/jobs/{d["id"]}/output.png' if d['state']=='succeeded' else None
        return d
    def submit(self,uid,pid,spec=None):
        p=self.project(uid,pid);spec=self.spec(uid,spec or p['spec'])
        if spec['workflow']!='layout' and not self.manifest.exists():raise ValueError('The local image model is not installed.')
        jid=uuid.uuid4().hex;folder=self.folder(jid);folder.mkdir(parents=True,mode=0o700)
        ids=[spec[k] for k in ['reference_id','mask_id'] if k in spec]+[l['asset_id'] for l in spec['layers'] if l['type']=='logo']
        atomic(folder/'input.json',{'spec':spec,'assets':{a:str(self.asset_path(uid,a)) for a in ids},'manifest':str(self.manifest),'adapter':self.adapter})
        with self.connection() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute("SELECT COUNT(*) FROM studio_jobs WHERE user_id=? AND state IN ('queued','running')",(uid,)).fetchone()[0]>=5:raise ValueError('Five jobs are already waiting. Let one finish or cancel it first.')
            c.execute('INSERT INTO studio_jobs(id,user_id,project_id,state,spec,created) VALUES(?,?,?,?,?,?)',(jid,uid,pid,'queued',json.dumps(spec),time.time()))
            c.execute('UPDATE studio_projects SET last_job=?,updated=? WHERE id=? AND user_id=?',(jid,time.time(),pid,uid))
        self.wake.set();return self.job(uid,jid)
    def cancel(self,uid,jid):
        with self.gate:
            j=self.job(uid,jid)
            if j['state'] not in {'queued','running'}:return j
            with self.connection() as c:c.execute("UPDATE studio_jobs SET state='cancelled',finished=? WHERE id=? AND user_id=?",(time.time(),jid,uid))
            if self.active==jid and self.process and self.process.poll() is None:self.process.terminate()
        self.wake.set();return self.job(uid,jid)
    def retry(self,uid,jid):
        j=self.job(uid,jid)
        if j['state'] not in {'failed','cancelled'}:raise ValueError('Only failed or cancelled jobs can be retried.')
        return self.submit(uid,j['project_id'],j['spec'])
    def run(self):
        while not self.stop.is_set():
            row=None
            with self.gate:
                if not self.busy():
                    with self.connection() as c:
                        row=c.execute("SELECT * FROM studio_jobs WHERE state='queued' ORDER BY created LIMIT 1").fetchone()
                        if row:
                            self.active=row['id'];c.execute("UPDATE studio_jobs SET state='running',started=? WHERE id=?",(time.time(),self.active))
            if not row:self.wake.wait(1);self.wake.clear();continue
            jid=row['id'];folder=self.folder(jid)
            try:
                if json.loads(row['spec'])['workflow']!='layout':
                    # Free inactive Ollama weights before loading diffusion on a 16 GB Mac.
                    try:
                        with urllib.request.urlopen(os.environ.get('SYNERGY_OLLAMA_URL','http://127.0.0.1:11434').rstrip('/')+'/api/ps',timeout=2) as r:models=json.load(r).get('models',[])
                        for m in models:
                            req=urllib.request.Request(os.environ.get('SYNERGY_OLLAMA_URL','http://127.0.0.1:11434').rstrip('/')+'/api/generate',data=json.dumps({'model':m['name'],'keep_alive':0}).encode(),headers={'Content-Type':'application/json'})
                            urllib.request.urlopen(req,timeout=5).close()
                    except (OSError,ValueError,KeyError):pass
                with self.gate:
                    if self.job(row['user_id'],jid)['state']=='cancelled':continue
                    with open(folder/'worker.log','ab') as log:
                        self.process=subprocess.Popen([self.python,str(Path(__file__).with_name('worker.py')),str(folder)],stdout=log,stderr=log,env={**os.environ,'PYTHONPATH':os.environ.get('SYNERGY_STUDIO_WORKER_PATH',os.environ.get('PYTHONPATH','')),'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1'})
                try:code=self.process.wait(timeout=7200)
                except subprocess.TimeoutExpired:self.process.kill();self.process.wait();raise RuntimeError('The local model exceeded two hours. Retry Fast quality or a smaller image.')
                if self.job(row['user_id'],jid)['state']=='cancelled':continue
                if code or not (folder/'result.json').exists():
                    err=json.loads((folder/'error.json').read_text()).get('detail') if (folder/'error.json').exists() else 'The local image process stopped. Retry with Fast quality.'
                    raise RuntimeError(err)
                result=json.loads((folder/'result.json').read_text())
                base=self.add_asset(row['user_id'],(folder/'base.png').read_bytes(),'Generated base',internal=True)
                result['base_asset_id']=base['id']
                with self.connection() as c:c.execute("UPDATE studio_jobs SET state='succeeded',finished=?,result=? WHERE id=? AND state='running'",(time.time(),json.dumps(result),jid))
            except Exception as exc:
                with self.connection() as c:c.execute("UPDATE studio_jobs SET state='failed',finished=?,error=? WHERE id=? AND state='running'",(time.time(),str(exc)[:600],jid))
            finally:
                with self.gate:self.active=None;self.process=None
    def close(self):
        self.stop.set();self.wake.set()
        if self.process and self.process.poll() is None:self.process.terminate()
