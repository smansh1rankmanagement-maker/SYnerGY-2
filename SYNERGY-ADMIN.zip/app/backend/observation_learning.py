"""Private, review-gated retrieval. One deterministic screening agent; no weight training."""
import hashlib,json,re,sqlite3,time,uuid
from pathlib import Path
SECRET=re.compile(r'(?i)(?:[a-z0-9_=-]{40,}|AQ\.[a-z0-9_-]{25,}|sk-[a-z0-9_-]{12,}|AIza[a-z0-9_-]{20,}|-----BEGIN .*PRIVATE KEY|(?:password|api[_ -]?key|access[_ -]?token|secret)\s*[:=]\s*\S{4,}|\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|\b(?:\d[ -]?){10,16}\b)')
def provenance_provider(selection,detail):
 selection=selection or {};routing=detail.get('routing') or {};review=detail.get('review') or {}
 if routing.get('actual_provider'):return routing['actual_provider'],routing.get('actual_model',selection.get('model','unknown'))
 if review.get('status')=='reviewed':return 'openai',review.get('review_model','unknown')
 return selection.get('provider','unknown'),selection.get('model','unknown')
def may_retrieve(selection,prefs):
 return prefs.get('observation_learning',False) and (prefs.get('observation_external',False) or selection.get('provider')=='synergy' and (not selection.get('workflow') or not prefs.get('allow_external',False)))
class Observation:
 def __init__(self,db):
  self.db=Path(db)
  with self.connect() as c:
   c.execute('CREATE TABLE IF NOT EXISTS observation_examples(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,scope TEXT NOT NULL,prompt TEXT NOT NULL,response TEXT NOT NULL,provenance TEXT NOT NULL,state TEXT NOT NULL,created REAL NOT NULL,expires REAL NOT NULL,digest TEXT NOT NULL,UNIQUE(user_id,scope,digest))')
   c.execute('CREATE INDEX IF NOT EXISTS observation_owner ON observation_examples(user_id,state,expires)')
 def connect(self):
  c=sqlite3.connect(self.db,timeout=15);c.row_factory=sqlite3.Row;return c
 def prune(self,c):c.execute('DELETE FROM observation_examples WHERE expires<=?',(time.time(),))
 def capture(self,uid,prompt,response,scope='',provenance=None,*,enabled=False,external=False,external_consent=False,private=False):
  if not enabled:return {'status':'off'}
  if private:return {'status':'excluded_private_context'}
  if external and not external_consent:return {'status':'external_consent_required'}
  if not isinstance(prompt,str) or not isinstance(response,str) or len(prompt)>2000 or not 30<=len(response)<=12000:return {'status':'outside_capture_limits'}
  if SECRET.search(prompt+'\n'+response):return {'status':'excluded_sensitive_pattern'}
  scope=str(scope)[:64];now=time.time();digest=hashlib.sha256((prompt+'\n'+response).encode()).hexdigest();identifier=uuid.uuid4().hex
  p=provenance or {};prov={'provider':str(p.get('provider','unknown'))[:60],'model':str(p.get('model','unknown'))[:120],'task_id':str(p.get('task_id',''))[:64],'sources':[{'url':str(x.get('source','')).split('?')[0][:300],'retrieved':x.get('retrieved')} for x in p.get('sources',[])[:8]],'agent':'observation-reviewer-1.0','training_completed':False}
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE');self.prune(c)
   old=c.execute('SELECT id FROM observation_examples WHERE user_id=? AND scope=? AND digest=?',(uid,scope,digest)).fetchone()
   if old:return {'status':'already_saved','id':old[0]}
   if c.execute('SELECT count(*) FROM observation_examples WHERE user_id=?',(uid,)).fetchone()[0]>=200:return {'status':'review_queue_full'}
   c.execute('INSERT INTO observation_examples VALUES(?,?,?,?,?,?,?,?,?,?)',(identifier,uid,scope,prompt,response,json.dumps(prov),'pending',now,now+30*86400,digest))
  return {'status':'pending_review','id':identifier}
 def list(self,uid):
  with self.connect() as c:
   self.prune(c);rows=[dict(r) for r in c.execute('SELECT * FROM observation_examples WHERE user_id=? ORDER BY created DESC LIMIT 200',(uid,))]
  for r in rows:r.pop('user_id');r.pop('digest');r['provenance']=json.loads(r['provenance'])
  return {'examples':rows,'agent':'observation-reviewer-1.0','training_completed':False,'policy':'Off by default. Private to this account and project. Review before reuse; retained up to 30 days; reuse stops after 7 days. Secrets and private attachments are excluded. No model weights are trained.'}
 def review(self,uid,identifier,decision):
  if decision not in {'approve','delete'}:raise ValueError('Choose approve or delete.')
  with self.connect() as c:
   self.prune(c)
   if not c.execute('SELECT 1 FROM observation_examples WHERE id=? AND user_id=?',(identifier,uid)).fetchone():raise KeyError('Example not found.')
   if decision=='delete':c.execute('DELETE FROM observation_examples WHERE id=? AND user_id=?',(identifier,uid))
   else:c.execute("UPDATE observation_examples SET state='approved' WHERE id=? AND user_id=?",(identifier,uid))
  from research.cache import AnswerCache
  AnswerCache(self.db).clear(uid)
  return {'ok':True,'decision':decision}
 def clear(self,uid):
  with self.connect() as c:c.execute('DELETE FROM observation_examples WHERE user_id=?',(uid,))
  from research.cache import AnswerCache
  AnswerCache(self.db).clear(uid)
  return {'cleared':True}
 def retrieve(self,uid,prompt,scope='',enabled=False):
  if not enabled or re.search(r'(?i)\b(today|latest|current|now|news|price|weather|legal|medical)\b',prompt):return []
  words=set(re.findall(r'\w{4,}',prompt.lower()))
  if not words:return []
  with self.connect() as c:
   self.prune(c);rows=[dict(r) for r in c.execute("SELECT prompt,response,provenance,created,id FROM observation_examples WHERE user_id=? AND scope=? AND state='approved' AND created>?",(uid,scope,time.time()-7*86400))]
  scored=[]
  for r in rows:
   overlap=words&set(re.findall(r'\w{4,}',r['prompt'].lower()))
   if len(overlap)>=2 and len(overlap)/len(words)>=.5:
    r['response']=r['response'][:2200];r['provenance']=json.loads(r['provenance']);scored.append((len(overlap),r))
  return [r for _,r in sorted(scored,key=lambda x:x[0],reverse=True)[:2]]
