"""Keep unsupported Work mutations out of text-only model responses."""
import re

def work_action_message(prompt, mode):
    if mode != 'work' or not isinstance(prompt, str):
        return None
    action = re.search(r'\b(create|make|save|change|revise|update|export|download|schedule|activate|publish|send)\b', prompt, re.I)
    object_ = re.search(r'\b(brand|workspace|calendar|workbook|spreadsheet|excel|xlsx|pdf|automation|workflow|approval|day\s+(?:three|\d+))\b', prompt, re.I)
    if not action or not object_:
        return None
    if re.match(r'(?i)\s*(?:how|what|why|explain|suggest|can you explain)\b', prompt):
        return None
    return ('This request needs a saved Brand Operations action. Open Work → Brand Operations to create or edit the brand, '
            'run a reviewed workflow, export its files, or revise a calendar. No brand, file, approval or schedule was changed by this chat request. '
            'To draft an automation from chat, start with “Create a weekly automation for [exact brand name]”.')

def matching_brands(brands, prompt):
    """An exact longer brand name takes precedence over a contained shorter name."""
    text = prompt.casefold()
    hits = []
    for b in brands:
        for m in re.finditer(r'(?<!\w)' + re.escape(b['name'].casefold()) + r'(?!\w)', text):
            hits.append((m.start(), m.end(), b))
    hits = [h for h in hits if not any(x[0] <= h[0] and x[1] >= h[1] and x[1]-x[0] > h[1]-h[0] for x in hits)]
    return list({h[2]['id']:h[2] for h in hits}.values())
