"""Deterministic, private, versioned specialist services. No hosted AI or external sends."""
import datetime as dt
import hashlib
import json
import re
import secrets
import shutil
import sqlite3
import time
import uuid
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from fractions import Fraction
from pathlib import Path
from zoneinfo import ZoneInfo
from .catalog import SERVERS, canonical, get_tool, validate

def ident(): return uuid.uuid4().hex
def dump(value): return json.dumps(value,ensure_ascii=False,sort_keys=True)
def date(value):
    if value: dt.date.fromisoformat(value)
    return value

def metadata(data):
    out={k:data.get(k,'unspecified') for k in ('board','session','grade','subject','chapter','objective','source','edition','language','difficulty','prerequisites')}
    if str(out['board']).upper()=='ICSE' and str(out['grade']) in {'11','12'}:raise ValueError('Use ISC for Classes 11–12 under CISCE.')
    out['verification']='pending_review'
    out['administrator']='Senior Professor' if str(out['grade']) in {'11','12'} or any(x in str(out['board']).upper() for x in ('ICAI','ICSI','CSEET','CA FOUNDATION')) else 'Foundation Professor'
    return out

def explain(expression):
    match=re.fullmatch(r'\s*(-?\d{1,6}(?:/\d{1,6})?)\s*([+\-])\s*(-?\d{1,6}(?:/\d{1,6})?)\s*',expression)
    if not match:raise ValueError('Use two whole numbers or fractions separated by + or -, for example 1/2 + 1/4. Other questions can be explained in chat.')
    try:a,b=Fraction(match[1]),Fraction(match[3])
    except (ValueError,ZeroDivisionError):raise ValueError('A fraction denominator must be greater than zero.')
    import math
    den=math.lcm(a.denominator,b.denominator);left=a.numerator*(den//a.denominator);right=b.numerator*(den//b.denominator)
    answer=a+b if match[2]=='+' else a-b
    return dict(expression=expression,answer=str(answer),explanation=f'Use denominator {den}. {a} = {left}/{den} and {b} = {right}/{den}. {left} {match[2]} {right} gives {(a+b if match[2]=="+" else a-b)*den}/{den}; simplify to {answer}.',check='Exact rational arithmetic',understanding_question='Why must the denominators match before adding or subtracting?')

SCHEMA='''
CREATE TABLE IF NOT EXISTS sp_records(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,server TEXT NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,revision INTEGER NOT NULL,data TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL);
CREATE INDEX IF NOT EXISTS sp_records_owner ON sp_records(user_id,server,kind);
CREATE TABLE IF NOT EXISTS sp_versions(record_id TEXT NOT NULL,revision INTEGER NOT NULL,data TEXT NOT NULL,created REAL NOT NULL,PRIMARY KEY(record_id,revision));
CREATE TABLE IF NOT EXISTS sp_calls(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,server TEXT NOT NULL,tool TEXT NOT NULL,input_hash TEXT NOT NULL,result TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS sp_jobs(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,server TEXT NOT NULL,tool TEXT NOT NULL,args TEXT NOT NULL,mode TEXT NOT NULL,request_id TEXT NOT NULL,state TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,created REAL NOT NULL,updated REAL NOT NULL,result TEXT NOT NULL DEFAULT '{}',error TEXT NOT NULL DEFAULT '',UNIQUE(user_id,request_id));
CREATE TABLE IF NOT EXISTS sp_media(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,kind TEXT NOT NULL,prompt TEXT NOT NULL,mode TEXT NOT NULL,state TEXT NOT NULL,task_id TEXT,created REAL NOT NULL,error TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS sp_worker(id TEXT PRIMARY KEY,heartbeat REAL NOT NULL);
'''
class Session:
    def __init__(self,db,root,uid,server):
        if type(uid) is not int or uid<1:raise PermissionError('A signed-in account is required.')
        self.db=Path(db);self.root=Path(root);self.uid=uid;self.server=canonical(server)
        if self.server not in SERVERS:raise ValueError('Unknown specialist.')
        self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        with self.connect() as c:c.executescript(SCHEMA)
    def connect(self):
        c=sqlite3.connect(self.db,timeout=20);c.row_factory=sqlite3.Row;return c
    def get(self,c,rid,kind=None):
        row=c.execute('SELECT * FROM sp_records WHERE id=? AND user_id=? AND server=?',(rid,self.uid,self.server)).fetchone()
        if not row or (kind and row['kind']!=kind):raise KeyError('Record not found in this workspace.')
        r=dict(row);r['data']=json.loads(r['data']);return r
    def public(self,row):
        row=json.loads(dump(row));row.pop('user_id',None)
        if row['kind']=='exam':
            for q in row['data']['questions']:
                for key in ('answer','explanation','rubric'):q.pop(key,None)
        return row
    def save(self,c,kind,title,data,rid=None):
        now=time.time();revision=1
        if rid:
            old=self.get(c,rid,kind);revision=old['revision']+1
            if kind=='exam':raise ValueError('An exam is frozen. Create another exam for changes.')
            c.execute('UPDATE sp_records SET title=?,data=?,revision=?,updated=? WHERE id=?',(title,dump(data),revision,now,rid))
        else:
            rid=ident()
            if c.execute('SELECT COUNT(*) FROM sp_records WHERE user_id=?',(self.uid,)).fetchone()[0]>=2000:raise ValueError('Record limit reached. Remove old records first.')
            c.execute('INSERT INTO sp_records VALUES(?,?,?,?,?,?,?,?,?)',(rid,self.uid,self.server,kind,title,revision,dump(data),now,now))
        c.execute('INSERT INTO sp_versions VALUES(?,?,?,?)',(rid,revision,dump(data),now))
        return self.public(self.get(c,rid))
    def learner(self,c,rid):
        if rid:
            record=self.get(c,rid,'learner')['data']
            if not record.get('save_progress'):raise PermissionError('Saving learner progress is disabled.')
            if record.get('minor') and not record.get('guardian_confirmed'):raise PermissionError('Guardian confirmation is required.')
    def call(self,name,args,call_id,mode='chat',access=None):
        spec=get_tool(self.server,name);validate(args,spec['inputSchema'])
        for key in ('title','name','alias','topic','expression'):
            if key in args and not args[key].strip():raise ValueError(key.replace('_',' ').capitalize()+' cannot be blank.')
        if not re.fullmatch(r'[A-Za-z0-9-]{8,80}',call_id):raise ValueError('Use a valid request ID.')
        if mode not in {'chat','work','beast'}:raise ValueError('Unknown mode.')
        if access:
            access(self.uid,mode)
            access(self.uid,spec['mode'])
        elif self.db.name=='accounts.sqlite3':
            from membership import Membership
            member=Membership(self.db);member.require(self.uid,mode);member.require(self.uid,spec['mode'])
        digest=hashlib.sha256(dump(dict(server=self.server,tool=name,args=args)).encode()).hexdigest()
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            old=c.execute('SELECT * FROM sp_calls WHERE id=?',(call_id,)).fetchone()
            if old:
                if old['user_id']!=self.uid or old['input_hash']!=digest:raise ValueError('Request ID already belongs to a different call.')
                return json.loads(old['result'])
            result=self.execute(c,name,args,mode)
            result=dict(result,tool=name,server=self.server,call_id=call_id)
            c.execute('INSERT INTO sp_calls VALUES(?,?,?,?,?,?,?)',(call_id,self.uid,self.server,name,digest,dump(result),time.time()))
            return result
    def exports(self,c,rid,content,formats=('pdf','docx')):
        row=self.get(c,rid);folder=self.root/'files'/str(self.uid)/rid/str(row['revision']);folder.mkdir(parents=True,exist_ok=True,mode=0o700)
        from creation_documents import export
        files=export(folder,content,list(formats))
        artifacts=[]
        for name,kind,label in files:
            artifacts.append(dict(name=name,kind=kind,label=label,url=f'/api/specialists/{self.server}/files/{rid}/{row["revision"]}/{name}'))
        return artifacts
    def execute(self,c,name,a,mode):
        if name=='records_list':
            rows=c.execute('SELECT * FROM sp_records WHERE user_id=? AND server=? ORDER BY updated DESC LIMIT 150',(self.uid,self.server)).fetchall()
            return {'records':[dict(id=r['id'],kind=r['kind'],title=r['title'],revision=r['revision'],updated=r['updated']) for r in rows if not a.get('kind') or r['kind']==a['kind']]}
        if name=='record_get':return {'record':self.public(self.get(c,a['record_id']))}
        if name=='record_delete':
            if not a['confirm']:raise ValueError('Confirm deletion first.')
            record=self.get(c,a['record_id']);ids=[record['id']]
            if record['kind']=='learner':
                ids += [r['id'] for r in c.execute('SELECT id,data FROM sp_records WHERE user_id=? AND server=?',(self.uid,self.server)) if json.loads(r['data']).get('learner_id')==record['id']]
            if record['data'].get('brand_id'):
                self.brand_permission(c,record['data']['brand_id'])
                if record['kind']=='task':c.execute('DELETE FROM ops_tasks WHERE id=? AND brand_id=?',(record['id'],record['data']['brand_id']))
                if record['kind']=='contact':c.execute('DELETE FROM ops_leads WHERE id=? AND brand_id=?',(record['id'],record['data']['brand_id']))
            for rid in ids:
                c.execute('DELETE FROM sp_versions WHERE record_id=?',(rid,));c.execute('DELETE FROM sp_records WHERE id=?',(rid,))
            # Clear owned execution payloads which might retain deleted private content.
            c.execute('DELETE FROM sp_calls WHERE user_id=? AND server=?',(self.uid,self.server))
            c.execute("UPDATE sp_jobs SET args='{}',result='{}' WHERE user_id=? AND server=? AND state IN ('complete','failed','cancelled')",(self.uid,self.server))
            for rid in ids:shutil.rmtree(self.root/'files'/str(self.uid)/rid,ignore_errors=True)
            return {'deleted':ids}
        if name=='knowledge_review':
            r=self.get(c,a['record_id'],'curriculum')
            if r['revision']!=a['revision']:raise ValueError('The record changed. Review the current revision.')
            data=r['data'];data.update(review=dict(reviewer=self.uid,reviewed_revision=r['revision'],decision=a['decision'],note=a['note'],at=time.time()))
            data['metadata']['verification']=a['decision']
            return {'record':self.save(c,'curriculum',r['title'],data,r['id'])}
        if name=='curriculum_save':
            if not a['permission_confirmed']:raise ValueError('Confirm permission to store this material.')
            return {'record':self.save(c,'curriculum',a['title'],dict(metadata=metadata(a['metadata']),content=a['content'],permission_confirmed=True))}
        if name=='curriculum_search':
            query=a.get('query','').casefold();grade=a.get('grade','');matches=[]
            for row in c.execute("SELECT * FROM sp_records WHERE user_id=? AND server='vedics' AND kind='curriculum'",(self.uid,)):
                r=dict(row);r['data']=json.loads(r['data'])
                if query in (r['title']+' '+dump(r['data'])).casefold() and (not grade or r['data']['metadata']['grade']==grade):matches.append(self.public(r))
            return dict(records=matches[:30],pilot={'grade':'5','subject':'Mathematics','topics':['fractions','arithmetic'],'source':'Original SYnerGY examples; not a board-aligned textbook'},limitations='Board, session and syllabus mappings need supplied permissioned sources and review. No full NCERT/ICSE/ISC/ICAI/ICSI corpus is installed.')
        if name=='learning_plan_update':
            if a['minor'] and not a.get('guardian_confirmed'):raise ValueError('A guardian must confirm before saving a child learning record.')
            if not a['save_progress']:raise ValueError('Enable saving explicitly, or continue a lesson in chat without a learner record.')
            return {'record':self.save(c,'learner',a['alias'],a,a.get('learner_id'))}
        if name=='question_explain':return explain(a['expression'])
        if name=='lesson_create':
            self.learner(c,a.get('learner_id'));meta=metadata(a['metadata']);content=a.get('content','').strip();topic=a['topic'].lower()
            if not content:
                if topic not in {'fractions','arithmetic'}:raise ValueError('For this topic, ask VEDICS in chat to draft the lesson, or supply content here. Only fractions and arithmetic have checked built-in lessons.')
                if meta['language'].lower() not in {'english','unspecified','en'}:raise ValueError('Use chat to draft this lesson in your preferred language.')
                content=('# Fractions\nPrerequisite: equal parts and multiplication.\nA fraction represents a number of equal parts. In 3/4, 4 is the number of equal parts and 3 is the number selected.\nExample: 1/2 + 1/4 = 2/4 + 1/4 = 3/4. Use a common denominator before adding.\nCheck: why is 1/3 greater than 1/4 when both refer to the same whole?\nPractice: solve 1/3 + 1/6. Answer: 1/2.\nNext: explain your steps; use smaller numbers if the common denominator is unclear.' if topic=='fractions' else '# Whole-number arithmetic\nPrerequisite: place value.\nAdd values in matching columns. Example: 127 + 36 = 163. Ones: 7+6=13; carry 1. Tens: 2+3+1=6. Hundreds: 1.\nCheck: explain why carrying changes the next column.\nPractice: 245 + 18 = 263. Verify by subtracting 18 from 263.\nNext: describe a place-value error and correct it.')
                meta['source']='Original SYnerGY teaching material';meta['verification']='deterministic_examples_checked'
            return {'record':self.save(c,'lesson',a.get('title') or a['topic'],dict(topic=a['topic'],metadata=meta,content=content,learner_id=a.get('learner_id')))}
        if name=='practice_generate':
            self.learner(c,a.get('learner_id'));questions=[]
            for i in range(a.get('count',5)):
                den=secrets.choice([2,3,4,6,8,10]);left=secrets.randbelow(den)+1;right=secrets.randbelow(den)+1
                expression=f'{left}/{den} + {right}/{den}' if a['topic']=='fractions' else f'{secrets.randbelow(900)+10} + {secrets.randbelow(90)+10}'
                result=explain(expression);questions.append(dict(id='q'+str(i+1),prompt=expression,kind='objective',answer=result['answer'],explanation=result['explanation'],marks=1))
            return {'record':self.save(c,'practice',a['topic'].title()+' practice',dict(questions=questions,learner_id=a.get('learner_id'),metadata=metadata(dict(grade=a.get('grade','5'),subject='Mathematics',source='Original generated examples; exact Fraction checks',board='Independent'))))}
        if name=='exam_create':
            self.learner(c,a.get('learner_id'))
            questions=a.get('questions') or (self.get(c,a['practice_id'],'practice')['data']['questions'] if a.get('practice_id') else [])
            if not questions or len({q['id'] for q in questions})!=len(questions):raise ValueError('Use a non-empty set of questions with unique IDs.')
            for q in questions:
                if q['kind']=='objective' and not q.get('answer','').strip():raise ValueError('Objective questions require an answer key.')
                if q['kind']=='descriptive' and not q.get('rubric','').strip():raise ValueError('Descriptive questions require a rubric.')
            data=dict(questions=questions,metadata=metadata(a.get('metadata',{})),learner_id=a.get('learner_id'),frozen=True,hash=hashlib.sha256(dump(questions).encode()).hexdigest(),assessment='VEDICS assessment, not an official qualification')
            return {'record':self.save(c,'exam',a['title'],data)}
        if name=='exam_submit':
            exam=self.get(c,a['exam_id'],'exam');learner=a.get('learner_id') or exam['data'].get('learner_id');self.learner(c,learner)
            answers={x['question_id']:x['answer'].strip() for x in a['answers']}
            if len(answers)!=len(a['answers']) or set(answers)-{q['id'] for q in exam['data']['questions']}:raise ValueError('Answer IDs must be unique and belong to this exam.')
            rows=[]
            for q in exam['data']['questions']:
                given=answers.get(q['id'],'');mark=None
                if q['kind']=='objective':
                    correct=given.casefold()==q['answer'].strip().casefold()
                    if given and re.fullmatch(r'-?\d+(?:/\d+|\.\d+)?',given) and re.fullmatch(r'-?\d+(?:/\d+|\.\d+)?',q['answer']):
                        try:correct=Fraction(given)==Fraction(q['answer'])
                        except (ValueError,ZeroDivisionError):correct=False
                    mark=q['marks'] if correct else 0
                rows.append(dict(question_id=q['id'],prompt=q['prompt'],answer=given,expected=q.get('answer',''),explanation=q.get('explanation',''),rubric=q.get('rubric',''),maximum=q['marks'],marks=mark,kind=q['kind']))
            data=dict(exam_id=exam['id'],exam_revision=exam['revision'],exam_hash=exam['data']['hash'],learner_id=learner,rows=rows)
            self.score(data)
            return {'record':self.save(c,'attempt',exam['title']+' scorecard',data)}
        if name=='assessment_grade':
            r=self.get(c,a['attempt_id'],'attempt');data=r['data'];reviews=a.get('reviews',[])
            if reviews:
                if not a.get('human_review_confirmed'):raise ValueError('Confirm human review of the answers against the frozen rubric.')
                if len({v['question_id'] for v in reviews})!=len(reviews):raise ValueError('Duplicate rubric review.')
                for v in reviews:
                    q=next((x for x in data['rows'] if x['question_id']==v['question_id'] and x['kind']=='descriptive'),None)
                    if q is None or v['marks']>q['maximum'] or not v['note'].strip():raise ValueError('Review must match a descriptive answer, its mark limit and include a reason.')
                    q.update(marks=v['marks'],review_note=v['note'],reviewer=self.uid,reviewed=time.time())
                self.score(data);return {'record':self.save(c,'attempt',r['title'],data,r['id'])}
            return {'record':self.public(r)}
        if name=='scorecard_export':
            r=self.get(c,a['attempt_id'],'attempt');d=r['data'];lines=['# '+r['title'],'VEDICS private assessment. Not an official board result.',f'Status: {d["status"]}; graded marks: {d["score"]}/{d["maximum"]}.',f'Frozen exam: {d["exam_id"]} · revision {d["exam_revision"]}']
            for q in d['rows']:lines += [f'## {q["question_id"]}: {q["prompt"]}',f'Answer: {q["answer"]}',f'Marks: {q["marks"] if q["marks"] is not None else "Pending rubric review"}/{q["maximum"]}',q['explanation'],q.get('review_note','')]
            lines+=['## Next steps',d['next_steps']]
            return {'record_id':r['id'],'artifacts':self.exports(c,r['id'],'\n\n'.join(lines),('pdf',))}
        if name=='creative_job_create':
            if len(a['prompt'].strip())<10:raise ValueError('Describe the educational subject to create.')
            mid=ident();c.execute('INSERT INTO sp_media VALUES(?,?,?,?,?,?,?,?,?)',(mid,self.uid,a['kind'],a['prompt'],mode,'queued',None,time.time(),''))
            return {'request_id':mid,'state':'queued','message':'Queued for the existing local media engine. Check video_job_status for actual progress.'}
        if name=='video_job_status':
            r=c.execute('SELECT * FROM sp_media WHERE id=? AND user_id=?',(a['request_id'],self.uid)).fetchone()
            if not r:raise KeyError('Generation request not found.')
            result=dict(r);result.pop('user_id');result.pop('prompt')
            if r['task_id']:
                task=c.execute('SELECT state,detail FROM research_tasks WHERE id=? AND user_id=?',(r['task_id'],self.uid)).fetchone()
                if task:result.update(state=task['state'],progress=json.loads(task['detail']))
            return result
        return self.founder(c,name,a)
    @staticmethod
    def score(data):
        data.update(score=sum(q['marks'] or 0 for q in data['rows']),maximum=sum(q['maximum'] for q in data['rows']),status='pending_review' if any(q['marks'] is None for q in data['rows']) else 'graded')
        gaps=[q['question_id'] for q in data['rows'] if q['marks'] is not None and q['marks']<q['maximum']]
        data['next_steps']='Revisit '+', '.join(gaps)+' and explain the correction.' if gaps else 'Review pending descriptive answers.' if data['status']=='pending_review' else 'Try a new variation and explain your reasoning.'
    def brand_permission(self,c,bid):
        if not bid:return
        r=c.execute('SELECT role FROM ops_members WHERE brand_id=? AND user_id=?',(bid,self.uid)).fetchone()
        if not r or r['role'] not in {'admin','manager','member'}:raise PermissionError('Brand write permission is required.')
    def founder(self,c,name,a):
        if name=='friend_preferences':
            r=c.execute("SELECT id FROM sp_records WHERE user_id=? AND server='foundr' AND kind='friend'",(self.uid,)).fetchone()
            return {'record':self.save(c,'friend','Companion preferences',dict(a,identity='AI assistant; not a human friend'),r['id'] if r else None)}
        if name=='task_assign':
            old=self.get(c,a['task_id'],'task') if a.get('task_id') else None
            data={**(old['data'] if old else {}),**a};data.setdefault('status','open');date(data.get('due',''));bid=data.get('brand_id');self.brand_permission(c,bid)
            if old and old['data'].get('brand_id')!=bid:raise ValueError('Create a separate task to change its brand.')
            record=self.save(c,'task',a['title'],data,a.get('task_id'))
            if bid:
                c.execute('INSERT INTO ops_tasks VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,state=excluded.state,owner=excluded.owner,due=excluded.due,detail=excluded.detail',(record['id'],bid,None,'foundr:'+record['id'],a['title'],'complete' if data['status']=='done' else data['status'],'medium',data.get('assignee','Unassigned'),data.get('due',''),dump(data)))
            return {'record':record,'notification_sent':False}
        if name=='crm_contact_update':
            old=self.get(c,a['contact_id'],'contact') if a.get('contact_id') else None
            data={**(old['data'] if old else {}),**a};email=data.get('email','').strip().casefold();phone=re.sub(r'[^0-9+]','',data.get('phone',''))
            if email and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email):raise ValueError('Use a valid email address.')
            if not email and not phone:raise ValueError('Provide an email or phone to prevent duplicate contacts.')
            bid=data.get('brand_id');self.brand_permission(c,bid);rid=old['id'] if old else None
            if old and old['data'].get('brand_id')!=bid:raise ValueError('Create a separate contact to change its brand.')
            for row in c.execute("SELECT id,data FROM sp_records WHERE user_id=? AND server='foundr' AND kind='contact'",(self.uid,)):
                existing=json.loads(row['data'])
                if existing.get('brand_id')==bid and ((email and existing.get('email')==email) or (phone and existing.get('phone')==phone)):
                    if rid and rid!=row['id']:raise ValueError('This contact already exists. Update the matching record.')
                    rid=row['id'];data={**existing,**data};break
            data.update(email=email,phone=phone);data.setdefault('opt_out',False);data.setdefault('stage','new')
            record=self.save(c,'contact',a['name'],data,rid)
            if bid:
                key=hashlib.sha256((email or phone).encode()).hexdigest()
                c.execute('INSERT INTO ops_leads VALUES(?,?,?,?,?) ON CONFLICT(brand_id,contact_key) DO UPDATE SET data=excluded.data,updated=excluded.updated',(record['id'],bid,key,dump(data),time.time()))
            return {'record':record,'message_sent':False}
        if name=='email_send':
            self.get(c,a['draft_id'],'email')
            return {'status':'blocked','sent':False,'blocker':'No authorised outbound email connection exists for this deployment. The draft remains saved.'}
        if name=='email_draft':
            if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',a['to']):raise ValueError('Use a valid recipient email.')
            return {'record':self.save(c,'email',a['subject'],dict(a,status='draft',sent=False))}
        if name in {'meeting_find_slots','meeting_create'}:
            ZoneInfo(a['timezone'])
            def stamp(x):
                value=dt.datetime.fromisoformat(x)
                if value.tzinfo is None:raise ValueError('Include the timezone offset in each date-time.')
                return value
            if name=='meeting_find_slots':
                slots=[]
                for w in a['windows']:
                    start,end=stamp(w['start']),stamp(w['end'])
                    if end<=start:raise ValueError('The end must be after the start.')
                    if (end-start).total_seconds()>=a['duration_minutes']*60:slots.append({'start':start.astimezone(ZoneInfo(a['timezone'])).isoformat(),'end':(start+dt.timedelta(minutes=a['duration_minutes'])).astimezone(ZoneInfo(a['timezone'])).isoformat()})
                return {'slots':slots,'basis':'Only the availability windows supplied by you; live calendars were not checked.'}
            start,end=stamp(a['start']),stamp(a['end'])
            if not 0<(end-start).total_seconds()<=86400:raise ValueError('Use a meeting duration between one second and one day.')
            r=self.save(c,'meeting',a['title'],dict(a,status='draft',invitations_sent=False));folder=self.root/'files'/str(self.uid)/r['id']/'1';folder.mkdir(parents=True,exist_ok=True,mode=0o700)
            def escape(v):return v.replace('\\','\\\\').replace('\r','').replace('\n','\\n').replace(',','\\,').replace(';','\\;')
            values=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//SYnerGY//FOUNDR//EN','BEGIN:VEVENT','UID:'+r['id']+'@synergyai.1rank.in','DTSTAMP:'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ'),'DTSTART:'+start.astimezone(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ'),'DTEND:'+end.astimezone(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ'),'SUMMARY:'+escape(a['title']),'DESCRIPTION:'+escape(a.get('notes','')),'END:VEVENT','END:VCALENDAR']
            # Fold by UTF-8 byte length, never split a code point.
            lines=[]
            for line in values:
                chunk=''
                for char in line:
                    if len((chunk+char).encode())>73:lines.append(chunk);chunk=' '
                    chunk+=char
                lines.append(chunk)
            (folder/'meeting.ics').write_bytes(('\r\n'.join(lines)+'\r\n').encode())
            return {'record':r,'artifacts':[{'name':'meeting.ics','kind':'ics','label':'Calendar draft','url':f'/api/specialists/foundr/files/{r["id"]}/1/meeting.ics'}],'invitations_sent':False}
        if name=='compliance_calendar_create':
            date(a['effective_date'])
            if not a['items']:raise ValueError('Add at least one sourced deadline.')
            for item in a['items']:
                date(item['due'])
                if not item['source'].strip() or not item['due']:raise ValueError('Every deadline needs its source and date.')
            r=self.save(c,'compliance',a['title'],dict(a,review='Professional review required',filings_submitted=False))
            body='# '+a['title']+'\n\nJurisdiction: '+a['jurisdiction']+'\nEffective date: '+a['effective_date']+'\nUser-supplied dates. Professional review required.\n\n'+'\n\n'.join(x['due']+' — '+x['task']+'\nSource: '+x['source'] for x in a['items'])
            return {'record':r,'artifacts':self.exports(c,r['id'],body)}
        if name=='document_draft':
            if not a['content'].strip():raise ValueError('Supply document content, or ask FOUNDR in chat to draft it.')
            if a.get('category') in {'legal','accounting'} and not a.get('jurisdiction'):raise ValueError('A legal/accounting draft needs a jurisdiction.')
            r=self.save(c,'document',a['title'],dict(a,status='draft',review='Professional review required' if a.get('category') in {'legal','accounting'} else 'User review required'))
            return {'record':r,'artifacts':self.exports(c,r['id'],'# '+a['title']+'\n\n'+a['content']+'\n\nSource: '+a.get('source','User supplied / assistant draft; verify factual claims.'))}
        if name=='strategy_brief_create':
            r=self.save(c,'strategy',a['title'],dict(a,status='draft',approval='Not approved'))
            body='# '+a['title']+'\n\n'+'\n\n'.join('## '+k.replace('_',' ').title()+'\n'+a[k] for k in ('goal','evidence','assumptions','growth','finance','operations','customer','risks','next_action'))
            return {'record':r,'artifacts':self.exports(c,r['id'],body)}
        if name=='payroll_calculate':
            date(a['effective_date'])
            if not a['employees'] or not a['rules'].strip() or not a['effective_date']:raise ValueError('Provide employees, the effective date and calculation rules.')
            rows=[]
            def money(v):
                if not re.fullmatch(r'\d{1,10}(?:\.\d{1,2})?',v):raise ValueError('Amounts must be non-negative decimals with at most two decimal places.')
                return Decimal(v).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP)
            for item in a['employees']:
                gross,additions,deductions=[money(item[k]) for k in ('gross','additions','deductions')];net=gross+additions-deductions
                if net<0:raise ValueError('Deductions exceed gross plus additions.')
                rows.append(dict(item,net=str(net)))
            data=dict(a,employees=rows,total_net=str(sum((Decimal(x['net']) for x in rows),Decimal(0))),status='review_required',paid=False)
            r=self.save(c,'payroll',a['period']+' payroll',data);folder=self.root/'files'/str(self.uid)/r['id']/'1';folder.mkdir(parents=True,exist_ok=True,mode=0o700)
            from openpyxl import Workbook,load_workbook
            from openpyxl.styles import Font,PatternFill
            from openpyxl.worksheet.table import Table,TableStyleInfo
            from openpyxl.worksheet.datavalidation import DataValidation
            wb=Workbook();ws=wb.active;ws.title='Payroll';ws.append(['Employee','Gross','Additions','Deductions','Net'])
            def literal(v):return "'"+v if v.startswith(('=','+','-','@','\t','\r')) else v
            for i,row in enumerate(rows,2):
                ws.append([literal(row['name']),float(Decimal(row['gross'])),float(Decimal(row['additions'])),float(Decimal(row['deductions'])),f'=ROUND(B{i}+C{i}-D{i},2)'])
                for cell in ws[i][1:]:cell.number_format='#,##0.00'
            end=len(rows)+1;ws.append(['Total',f'=SUM(B2:B{end})',f'=SUM(C2:C{end})',f'=SUM(D2:D{end})',f'=SUM(E2:E{end})']);ws.freeze_panes='A2'
            table=Table(displayName='Payroll',ref=f'A1:E{end}');table.tableStyleInfo=TableStyleInfo(name='TableStyleMedium2',showRowStripes=True);ws.add_table(table)
            valid=DataValidation(type='decimal',operator='greaterThanOrEqual',formula1='0');valid.error='Enter a non-negative amount.';valid.showErrorMessage=True;ws.add_data_validation(valid);valid.add(f'B2:D{end}')
            for col in 'ABCDE':ws.column_dimensions[col].width=24
            notes=wb.create_sheet('Rules and sources');notes.append(['Field','Value'])
            for key in ('period','effective_date','currency','rules','total_net','status'):notes.append([key,literal(str(data[key]))])
            notes.append(['Calculation','Net = gross + additions - deductions; verify before payment. No tax rates were inferred.']);notes.column_dimensions['A'].width=24;notes.column_dimensions['B'].width=85
            wb.calculation.fullCalcOnLoad=True;wb.calculation.forceFullCalc=True
            file=folder/'payroll.xlsx';wb.save(file);checked=load_workbook(file)
            if checked['Payroll']['E2'].value!='=ROUND(B2+C2-D2,2)':raise RuntimeError('Spreadsheet formula validation failed.')
            return {'record':r,'artifacts':[{'name':'payroll.xlsx','kind':'xlsx','label':'Payroll workbook','url':f'/api/specialists/foundr/files/{r["id"]}/1/payroll.xlsx'}],'calculation_check':'Decimal arithmetic validated; Excel formulas recalculate when opened. No payment was made.'}
        raise ValueError('Unsupported tool.')
