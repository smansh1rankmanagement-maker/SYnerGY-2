"""Pinned MCP 2025-11-25 tool schemas; no account identity is accepted from arguments."""
VERSION = '1.0.0'
PROTOCOL = '2025-11-25'

def s(label='', limit=2000, **extra):
    return dict(type='string', description=label, maxLength=limit, **extra)
def obj(properties, required=()):
    return dict(type='object', properties=properties, required=list(required), additionalProperties=False)
def arr(item, limit=40):
    return dict(type='array', items=item, maxItems=limit)
def enum(values, label=''):
    return s(label, enum=values)
def tool(name, description, properties, required=(), *, mode='chat', read=False, example=None, status='ready'):
    return dict(name=name, description=description, inputSchema=obj(properties, required),
                annotations=dict(readOnlyHint=read, destructiveHint=name=='record_delete', openWorldHint=False),
                mode=mode, status=status, example=example or {})
META = dict(board=s('Board or programme; use Independent for unverified mapping',100), session=s('Academic year or exam session',40),
            grade=s('KG or grade/programme',40), subject=s('Subject',100), chapter=s('Chapter',150), objective=s('Learning objective',500),
            source=s('Source URL or original/user-supplied material',1500), edition=s('Source edition',100), language=s('Teaching language',40),
            difficulty=enum(['foundation','standard','advanced']), prerequisites=s('Prerequisite concepts',500))
QUESTION = obj(dict(id=s(limit=40), prompt=s(limit=1500), kind=enum(['objective','descriptive']), answer=s(limit=500),
                    explanation=s(limit=1500), marks=dict(type='integer',minimum=1,maximum=20), rubric=s(limit=1500)), ['id','prompt','kind','marks'])
VEDICS = [
 tool('curriculum_search','Search your saved, versioned curriculum entries and original pilot lessons. No claim of complete board coverage.', {'query':s(limit=200),'grade':s(limit=40)},read=True,example={'query':'fractions','grade':'5'}),
 tool('curriculum_save','Save a permissioned curriculum entry as pending review.', {'title':s(limit=150),'metadata':obj(META), 'content':s(limit=12000),'permission_confirmed':dict(type='boolean')}, ['title','metadata','content','permission_confirmed']),
 tool('lesson_create','Create and save a lesson. Fractions and whole-number arithmetic have original deterministic lessons; other topics require supplied lesson content or chat drafting.',{'title':s(limit=150),'topic':s(limit=150),'metadata':obj(META),'content':s(limit=24000),'learner_id':s(limit=40)},['topic','metadata'],example={'topic':'fractions','metadata':{'grade':'5','subject':'Mathematics','board':'Independent','language':'English'}}),
 tool('question_explain','Explain a fraction or whole-number addition/subtraction using exact rational arithmetic.',{'expression':s('Example: 1/2 + 1/4',80)},['expression'],read=True,example={'expression':'1/2 + 1/4'}),
 tool('practice_generate','Generate original, checked arithmetic or fractions questions and save a practice set.',{'topic':enum(['fractions','arithmetic']),'count':dict(type='integer',minimum=1,maximum=20),'grade':s(limit=40),'learner_id':s(limit=40)},['topic'],example={'topic':'fractions','count':5,'grade':'5'}),
 tool('exam_create','Freeze a VEDICS assessment version from a practice set or supplied questions. Answers stay private until submission.',{'title':s(limit=150),'practice_id':s(limit=40),'questions':arr(QUESTION,30),'metadata':obj(META),'learner_id':s(limit=40)},['title'],example={'title':'Fractions check','practice_id':'PASTE_PRACTICE_ID'}),
 tool('exam_submit','Submit answers against a frozen exam. Objective questions are graded deterministically; descriptive answers need rubric review.',{'exam_id':s(limit=40),'learner_id':s(limit=40),'answers':arr(obj({'question_id':s(limit=40),'answer':s(limit=3000)},['question_id','answer']),30)},['exam_id','answers']),
 tool('assessment_grade','Read a scorecard or record explicit human-reviewed rubric marks. The reviewed attempt and rubric remain versioned.',{'attempt_id':s(limit=40),'reviews':arr(obj({'question_id':s(limit=40),'marks':dict(type='integer',minimum=0,maximum=20),'note':s(limit=1500)},['question_id','marks','note']),30),'human_review_confirmed':dict(type='boolean')},['attempt_id']),
 tool('scorecard_export','Export your private assessment as PDF and editable Markdown.',{'attempt_id':s(limit=40)},['attempt_id']),
 tool('learning_plan_update','Save an opt-in learning record. Child records require guardian confirmation; use an alias instead of a full name.',{'learner_id':s(limit=40),'alias':s(limit=60),'grade':s(limit=40),'language':s(limit=40),'goals':s(limit=2000),'accessibility':s(limit=500),'minor':dict(type='boolean'),'guardian_confirmed':dict(type='boolean'),'save_progress':dict(type='boolean')},['alias','grade','minor','save_progress'],example={'alias':'Learner A','grade':'5','language':'English','goals':'Understand fractions','minor':True,'guardian_confirmed':True,'save_progress':True}),
 tool('creative_job_create','Queue an educational image or short video in the existing SYnerGY engine; returns an actual request ID. Rendering depends on installed model availability.',{'kind':enum(['image','video']),'prompt':s(limit=2000)},['kind','prompt'],example={'kind':'image','prompt':'A classroom demonstration of a circle divided into four equal parts, no text'}),
 tool('video_job_status','Read actual generation request and research job progress.',{'request_id':s(limit=40)},['request_id'],read=True),
]
FOUNDR = [
 tool('task_assign','Save or update a private founder task. An assignee is a label, not a sent message. An optional brand requires write permission.',{'task_id':s(limit=40),'title':s(limit=180),'assignee':s(limit=80),'due':s('ISO date YYYY-MM-DD',10),'status':enum(['open','in_progress','done','cancelled']),'brand_id':s(limit=40),'notes':s(limit=3000)},['title'],example={'title':'Review the launch brief','assignee':'Me','due':'','status':'open'},mode='work'),
 tool('crm_contact_update','Save a contact with source evidence and opt-out state. Existing email/phone matches are updated, not duplicated.',{'contact_id':s(limit=40),'name':s(limit=120),'email':s(limit=254),'phone':s(limit=40),'company':s(limit=150),'source':s(limit=1000),'notes':s(limit=3000),'opt_out':dict(type='boolean'),'stage':enum(['new','qualified','proposal','won','lost']),'brand_id':s(limit=40)},['name','source'],mode='work'),
 tool('email_draft','Save an email draft. Nothing is sent.',{'to':s(limit=254),'subject':s(limit=200),'body':s(limit=12000)},['to','subject','body'],example={'to':'client@example.com','subject':'Draft for review','body':'Please review the attached brief.'}),
 tool('email_send','Sending is not connected on this deployment. Returns the exact blocker without sending.',{'draft_id':s(limit=40)},['draft_id'],status='connection_required',mode='work'),
 tool('meeting_find_slots','Compare user-supplied availability windows in an explicit timezone. This does not read live calendars.',{'timezone':s(limit=80),'windows':arr(obj({'start':s(limit=40),'end':s(limit=40)},['start','end']),20),'duration_minutes':dict(type='integer',minimum=15,maximum=240)},['timezone','windows','duration_minutes'],read=True),
 tool('meeting_create','Save a meeting draft and export an ICS calendar file. External invitations are not sent.',{'title':s(limit=180),'start':s('Timezone-aware ISO date-time',40),'end':s(limit=40),'timezone':s(limit=80),'notes':s(limit=2000)},['title','start','end','timezone'],mode='work'),
 tool('compliance_calendar_create','Save supplied compliance dates with jurisdiction, source and effective date. Does not infer legal deadlines or file returns.',{'title':s(limit=180),'jurisdiction':s(limit=150),'effective_date':s(limit=10),'items':arr(obj({'task':s(limit=180),'due':s(limit=10),'source':s(limit=1000)},['task','due','source']),60)},['title','jurisdiction','effective_date','items'],mode='work'),
 tool('document_draft','Save supplied document content and export PDF and editable Word/Markdown. Legal/accounting drafts remain pending professional review.',{'title':s(limit=180),'content':s(limit=24000),'category':enum(['business','legal','accounting','general']),'jurisdiction':s(limit=150),'source':s(limit=1500)},['title','content'],example={'title':'Founder brief','content':'# Launch brief\nGoal: validate demand.\nUnknown: conversion rate.','category':'business'}),
 tool('payroll_calculate','Calculate from explicit gross pay, additions and deductions using decimal arithmetic. Exports Excel with formulas; no tax inference or payment.',{'period':s(limit=40),'effective_date':s(limit=10),'currency':enum(['INR','USD','EUR','GBP']),'rules':s(limit=2000),'employees':arr(obj({'name':s(limit=100),'gross':s(limit=20),'additions':s(limit=20),'deductions':s(limit=20)},['name','gross','additions','deductions']),100)},['period','effective_date','currency','rules','employees'],mode='work',example={'period':'2026-11','effective_date':'2026-11-01','currency':'INR','rules':'User-supplied amounts; no statutory deductions calculated.','employees':[{'name':'Employee A','gross':'30000','additions':'1000','deductions':'500'}]}),
 tool('strategy_brief_create','Save a decision brief with growth, finance, operations, customer and risk perspectives. Distinguish evidence and assumptions.',{'title':s(limit=180),'goal':s(limit=1000),'evidence':s(limit=4000),'assumptions':s(limit=4000),'growth':s(limit=3000),'finance':s(limit=3000),'operations':s(limit=3000),'customer':s(limit=3000),'risks':s(limit=3000),'next_action':s(limit=1000)},['title','goal','evidence','assumptions','growth','finance','operations','customer','risks','next_action']),
 tool('friend_preferences','Set the AI companion name and speaking style. No psychological profile or emotional inference is stored.',{'name':s(limit=40),'style':enum(['concise','friendly','formal','teaching'])},['name','style'],example={'name':'Synergy','style':'friendly'}),
]
COMMON = [
 tool('records_list','List only your records and their latest versions.',{'kind':s(limit=40)},read=True),
 tool('record_get','Open one of your records. Frozen exam answer keys are not returned.',{'record_id':s(limit=40)},['record_id'],read=True),
 tool('record_delete','Permanently remove one private record and its exports. Learner deletion removes linked learning records.',{'record_id':s(limit=40),'confirm':dict(type='boolean')},['record_id','confirm']),
 tool('knowledge_review','Approve or reject the exact revision of your curriculum entry after review. Changes need a new review.',{'record_id':s(limit=40),'revision':dict(type='integer',minimum=1),'decision':enum(['approved','rejected']),'note':s(limit=2000)},['record_id','revision','decision','note']),
]
SERVERS = {
 'vedics':dict(name='VEDICS',description='Education, original practice, private assessments and teaching records.',roles=['Foundation Professor · KG–10','Senior Professor · 11–12 and foundation preparation'],tools=VEDICS+COMMON),
 'foundr':dict(name='FOUNDR',aliases=['FOUNDERFIT','Founder'],description='Founder documents, tasks, CRM, calculations and decision support.',roles=['CA–CS Assistant','Friend','Legal Assistant','Personal Assistant','Boards'],tools=FOUNDR+COMMON),
}
def canonical(server):
    key=str(server).lower()
    return 'foundr' if key in {'founder','founderfit'} else key

def validate(value, schema, path='arguments'):
    t=schema.get('type')
    types={'object':dict,'array':list,'string':str,'integer':int,'boolean':bool}
    if t in types and type(value) is not types[t]:raise ValueError(path+' must be '+t+'.')
    if 'enum' in schema and value not in schema['enum']:raise ValueError(path+' has an unsupported value.')
    if t=='object':
        if set(value)-set(schema['properties']):raise ValueError(path+' contains unsupported fields.')
        if set(schema['required'])-set(value):raise ValueError(path+' requires '+', '.join(sorted(set(schema['required'])-set(value)))+'.')
        for k,v in value.items():validate(v,schema['properties'][k],path+'.'+k)
    if t=='array':
        if len(value)>schema['maxItems']:raise ValueError(path+' has too many entries.')
        for v in value:validate(v,schema['items'],path+'[]')
    if t=='string' and (len(value)>schema.get('maxLength',24000) or '\x00' in value):raise ValueError(path+' exceeds its text limit.')
    if t=='integer' and not schema.get('minimum',0)<=value<=schema.get('maximum',100000):raise ValueError(path+' is outside its supported range.')

def get_tool(server,name):
    server=canonical(server)
    if server not in SERVERS:raise ValueError('Unknown specialist.')
    found=next((t for t in SERVERS[server]['tools'] if t['name']==name),None)
    if not found:raise ValueError('Unknown tool.')
    return found
