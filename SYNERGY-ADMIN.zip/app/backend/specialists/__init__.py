"""Account-scoped VEDICS and FOUNDR MCP tools."""
