"""Durable queue, authenticated downloads and backend workers for bundled MCP servers."""
import fcntl,json,re,threading,time
from pathlib import Path
from .catalog import SERVERS,VERSION,PROTOCOL,canonical,get_tool,validate
from .store import Session,ident,dump
from .client import call

class Specialists:
    def __init__(self,workspace,data,access,research=None):
        self.ws=workspace;self.data=Path(data);self.root=self.data/'specialists';self.access=access;self.research=research
        self.seed=Session(workspace.db,self.root,1,'vedics');self.stopped=threading.Event();self.last_heartbeat=0
    def connect(self):return self.seed.connect()
    def catalog(self):
        with self.connect() as c:r=c.execute("SELECT heartbeat FROM sp_worker WHERE id='local'").fetchone()
        return {'version':VERSION,'protocol':PROTOCOL,'transport':'stdio','worker_ready':bool(r and time.time()-r[0]<90),'servers':[dict(id=k,**v) for k,v in SERVERS.items()]}
    def submit(self,uid,server,tool,args,request_id=None,mode='chat'):
        server=canonical(server);spec=get_tool(server,tool);validate(args,spec['inputSchema']);self.access(uid,mode);self.access(uid,spec['mode'])
        rid=request_id or ident()
        if not isinstance(rid,str) or not re.fullmatch(r'[A-Za-z0-9-]{8,80}',rid):raise ValueError('Invalid request ID.')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');old=c.execute('SELECT * FROM sp_jobs WHERE user_id=? AND request_id=?',(uid,rid)).fetchone()
            if old:
                if old['server']!=server or old['tool']!=tool or old['args']!=dump(args):raise ValueError('Request ID already used for different inputs.')
                jid=old['id']
            else:
                if c.execute("SELECT count(*) FROM sp_jobs WHERE user_id=? AND state IN ('queued','running')",(uid,)).fetchone()[0]>=8:raise ValueError('Your tool queue is full. Wait or cancel a queued job.')
                jid=ident();now=time.time();c.execute('INSERT INTO sp_jobs(id,user_id,server,tool,args,mode,request_id,state,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?)',(jid,uid,server,tool,dump(args),mode,rid,'queued',now,now))
        return self.job(uid,jid)
    def job(self,uid,jid):
        with self.connect() as c:row=c.execute('SELECT * FROM sp_jobs WHERE id=? AND user_id=?',(jid,uid)).fetchone()
        if not row:raise KeyError('Tool job not found.')
        r=dict(row);r.pop('user_id');r.pop('args');r['result']=json.loads(r['result']);return r
    def cancel(self,uid,jid):
        self.job(uid,jid)
        with self.connect() as c:
            r=c.execute("UPDATE sp_jobs SET state='cancelled',updated=? WHERE id=? AND user_id=? AND state='queued'",(time.time(),jid,uid))
            if not r.rowcount:raise ValueError('This short tool step has already started or finished. Its actual result will remain in History.')
        return self.job(uid,jid)
    def once(self):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');c.execute('INSERT OR REPLACE INTO sp_worker VALUES(?,?)',('local',time.time()))
            row=c.execute("SELECT * FROM sp_jobs WHERE state='queued' ORDER BY created LIMIT 1").fetchone()
            if not row:return False
            c.execute("UPDATE sp_jobs SET state='running',attempts=attempts+1,updated=? WHERE id=?",(time.time(),row['id']))
        try:
            self.access(row['user_id'],row['mode']);self.access(row['user_id'],get_tool(row['server'],row['tool'])['mode'])
            result=call(self.data,row['user_id'],row['server'],row['tool'],json.loads(row['args']),row['id'],row['mode'])
            state='complete';error=''
        except Exception as e:
            from research.net import redact
            result={};state='failed';error=redact(str(e))[:700]
        with self.connect() as c:c.execute('UPDATE sp_jobs SET state=?,result=?,error=?,updated=? WHERE id=?',(state,dump(result),error,time.time(),row['id']))
        return True
    def recover(self):
        with self.connect() as c:
            c.execute("UPDATE sp_jobs SET state='queued',updated=? WHERE state='running' AND attempts<2",(time.time(),))
            c.execute("UPDATE sp_jobs SET state='failed',error='Restart recovery limit reached. Retry with a new request.',updated=? WHERE state='running'",(time.time(),))
    def media_once(self):
        if not self.research:return
        with self.connect() as c:rows=c.execute("SELECT * FROM sp_media WHERE state='queued' ORDER BY created LIMIT 8").fetchall()
        for row in rows:
            try:
                self.access(row['user_id'],row['mode'])
                job=self.research.submit(row['user_id'],dict(prompt='Create '+('an image' if row['kind']=='image' else 'a short video')+' of '+row['prompt'],mode=row['mode'],search_mode='off',request_id='specialist-'+row['id']))
                with self.connect() as c:c.execute("UPDATE sp_media SET state='submitted',task_id=? WHERE id=?",(job['id'],row['id']))
            except ValueError as e:
                if 'already running' in str(e):continue
                with self.connect() as c:c.execute("UPDATE sp_media SET state='failed',error=? WHERE id=?",(str(e)[:500],row['id']))
            except Exception as e:
                from research.net import redact
                with self.connect() as c:c.execute("UPDATE sp_media SET state='failed',error=? WHERE id=?",(redact(str(e))[:500],row['id']))
    def context(self,uid,prompt):
        words=set(re.findall(r'[a-z0-9]{4,}',prompt.casefold()))-{'please','create','draft','using','about','these','those','vedics','foundr','founder','with','that','this'}
        if not words:return []
        candidates=[]
        with self.connect() as c:
            rows=c.execute("SELECT * FROM sp_records WHERE user_id=? AND kind IN ('curriculum','lesson','strategy','document','task','friend') ORDER BY updated DESC LIMIT 100",(uid,)).fetchall()
        for row in rows:
            data=json.loads(row['data'])
            if row['kind']=='curriculum' and data.get('metadata',{}).get('verification')!='approved':continue
            hay=(row['title']+' '+data.get('topic','')+' '+data.get('goal','')).casefold()
            score=sum(w in hay for w in words)+(100 if row['id'] in prompt else 0)
            if score:candidates.append((score,dict(title=row['server'].upper()+' · '+row['title'],content=dump(data)[:3500],source='/api/specialists/'+row['server']+'/records/'+row['id'],created=row['updated'])))
        return [r for _,r in sorted(candidates,key=lambda v:v[0],reverse=True)[:3]]
    def start(self):
        def loop():
            lock=(self.root/'worker.lock').open('a')
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:lock.close();return
            self.recover()
            try:
                while not self.stopped.is_set():
                    try:self.once();self.media_once()
                    except Exception:pass  # Failed jobs carry their error; a transient database error is retried on next tick.
                    self.stopped.wait(.7)
            finally:lock.close()
        self.thread=threading.Thread(target=loop,name='synergy-specialist-worker',daemon=True);self.thread.start()
    def wait(self,uid,job,stop,stage):
        while True:
            if stop.is_set():
                try:self.cancel(uid,job['id'])
                except ValueError:pass
                raise InterruptedError('Stopped; inspect specialist History for any step already committed.')
            r=self.job(uid,job['id']);stage(r['state'])
            if r['state']=='complete':return r['result']
            if r['state'] in {'failed','cancelled'}:raise ValueError(r['error'] or 'Tool job cancelled.')
            stop.wait(.35)
    def file(self,uid,server,rid,revision,name):
        if not re.fullmatch(r'[0-9a-f]{32}',rid) or not re.fullmatch(r'[1-9][0-9]{0,5}',revision) or not re.fullmatch(r'[a-zA-Z0-9_.-]+\.(pdf|docx|md|txt|xlsx|ics)',name):raise KeyError('File not found.')
        session=Session(self.ws.db,self.root,uid,server)
        with session.connect() as c:
            session.get(c,rid)
            if not c.execute('SELECT 1 FROM sp_versions WHERE record_id=? AND revision=?',(rid,int(revision))).fetchone():raise KeyError('Version not found.')
        file=self.root/'files'/str(uid)/rid/revision/name
        if not file.is_file():raise KeyError('File not found.')
        return file

class SpecialistHTTP:
    def specialists_get(self,path,user):
        uid=user['id'];service=self.specialists
        try:
            self.membership.require(uid,'chat')
            if path=='/api/specialists':return self.response(200,service.catalog())
            if path=='/api/specialists/jobs':
                with service.connect() as c:ids=[r[0] for r in c.execute('SELECT id FROM sp_jobs WHERE user_id=? ORDER BY created DESC LIMIT 50',(uid,))]
                return self.response(200,{'jobs':[service.job(uid,jid) for jid in ids]})
            record_match=re.fullmatch(r'/api/specialists/(vedics|foundr)/records/([0-9a-f]{32})',path)
            if record_match:
                session=Session(self.workspace.db,service.root,uid,record_match[1])
                with session.connect() as c:record=session.public(session.get(c,record_match[2]))
                return self.response(200,{'record':record})
            match=re.fullmatch(r'/api/specialists/jobs/([0-9a-f]{32})',path)
            if match:return self.response(200,service.job(uid,match[1]))
            match=re.fullmatch(r'/api/specialists/(vedics|foundr)/files/([^/]+)/([^/]+)/([^/]+)',path)
            if match:
                file=service.file(uid,*match.groups());return self.research_download(file.read_bytes(),file.name)
            return self.fail(404,'Not found.')
        except PermissionError as e:return self.fail(403,str(e))
        except KeyError:return self.fail(404,'Item not found.')
    def specialists_post(self,path,d,user):
        try:
            match=re.fullmatch(r'/api/specialists/(vedics|foundr|founder|founderfit)/call',path)
            if match:
                if set(d)-{'tool','arguments','request_id','mode'}:raise ValueError('Unsupported request fields.')
                return self.response(202,self.specialists.submit(user['id'],match[1],d.get('tool'),d.get('arguments',{}),d.get('request_id'),d.get('mode','chat')))
            match=re.fullmatch(r'/api/specialists/jobs/([0-9a-f]{32})/cancel',path)
            if match:return self.response(200,self.specialists.cancel(user['id'],match[1]))
            return self.fail(404,'Not found.')
        except PermissionError as e:return self.fail(403,str(e))
        except KeyError:return self.fail(404,'Item not found.')
        except (ValueError,TypeError) as e:return self.fail(400,str(e))
