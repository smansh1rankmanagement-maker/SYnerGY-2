"""Conservative explicit actions. Unknown requests use normal evidence-based chat."""
import json,re
from .catalog import canonical,SERVERS

def route(prompt):
    if not isinstance(prompt,str):return None
    # Machine-readable form is also shown by the tool form; never interpret quoted JSON as authority.
    hit=re.fullmatch(r'\s*/(vedics|foundr|founder|founderfit)\s+([a-z_]+)\s+(\{[\s\S]*\})\s*',prompt,re.I)
    if hit:return {'server':canonical(hit[1]),'tool':hit[2].lower(),'arguments':json.loads(hit[3])}
    tagged=re.match(r'^\s*(?:use\s+)?(vedics|foundr|founderfit|founder)\b[\s:,-]*(.*)$',prompt,re.I|re.S)
    if not tagged:return None
    server=canonical(tagged[1]);text=tagged[2].strip()
    if re.match(r'^(?:what|how|can|why|do you|tell me)\b',text,re.I):return None
    if re.fullmatch(r'(?:list|show)(?: my)? (?:records|tasks|contacts|lessons|assessments|scorecards)',text,re.I):
        word=text.lower().split()[-1];kind={'tasks':'task','contacts':'contact','lessons':'lesson','assessments':'exam','scorecards':'attempt'}.get(word,'')
        return dict(server=server,tool='records_list',arguments={'kind':kind})
    if server=='vedics':
        hit=re.fullmatch(r'(?:explain|solve|calculate)\s+([\d\s/+\-]+)[.?]?',text,re.I)
        if hit:return dict(server=server,tool='question_explain',arguments={'expression':hit[1].strip()})
        if re.match(r'^(?:create|make|generate)\b',text,re.I) and re.search(r'\b(practice|quiz)\b',text,re.I) and re.search(r'\b(fractions|arithmetic)\b',text,re.I):
            number=re.search(r'\b(\d+)\s*(?:-\s*)?(?:question|problem)',text,re.I);grade=re.search(r'\b(?:grade|class)\s*(\d+)\b',text,re.I)
            return dict(server=server,tool='practice_generate',arguments={'topic':'fractions' if 'fraction' in text.lower() else 'arithmetic','count':min(20,max(1,int(number[1]))) if number else 5,'grade':grade[1] if grade else '5'})
        if re.match(r'^(?:teach|create (?:a )?lesson|explain)\b',text,re.I):
            grade=re.search(r'\b(?:grade|class)\s*(\d+)\b',text,re.I)
            return dict(server=server,draft='lesson',title=text[:120],metadata={'grade':grade[1] if grade else 'unspecified','source':'Assistant draft; verify against permissioned sources','board':'Independent','language':'As requested'},prompt=text)
    if server=='foundr':
        hit=re.fullmatch(r'(?:create|add|save) (?:a )?task\s*:\s*(.+)',text,re.I|re.S)
        if hit:return dict(server=server,tool='task_assign',arguments={'title':hit[1][:180],'notes':hit[1][180:],'assignee':'Me','status':'open'})
        if re.match(r'^(?:draft|write|create)\b',text,re.I) and re.search(r'\b(proposal|brief|document|strategy|plan|sop|email)\b',text,re.I):
            return dict(server=server,draft='document',title=text[:120],prompt=text)
    return None

def instructions(plan):
    if not plan:return ''
    if plan.get('draft')=='lesson':return 'VEDICS lesson workflow: write a compact complete lesson; avoid decorative emojis and separate source appendices. Use inline citations only. Identify grade and prerequisites; explain with a worked example; ask an understanding question; provide checked practice and next steps. Do not claim board/session alignment without a verified source. Use the requested language and age-appropriate examples. The local MCP service will save this answer as a pending-review lesson. Do not say it is already saved.'
    if plan.get('draft')=='document':return 'FOUNDR document workflow: draft a complete practical document from supplied inputs. Distinguish evidence from assumptions. For strategy include growth, finance, operations, customer impact, risks and next action. For legal or accounting support ask for missing jurisdiction and label professional review. Do not invent recipient addresses, send messages, certifications or filings. The MCP document tool will save and export the draft after generation. Do not invent links.'
    return ''

def present(result):
    server=result.get('server','').upper();tool=result.get('tool','');r=result.get('record')
    if result.get('status')=='blocked':return result['blocker']
    if tool=='question_explain':return '**'+result['expression']+' = '+result['answer']+'**\n\n'+result['explanation']+'\n\n'+result['understanding_question']
    if r:
        text=f'**{r["title"]}**\n\nSaved in {server} · version {r["revision"]}. Record ID: `{r["id"]}`.\n\n'
        d=r['data']
        if r['kind']=='practice':
            text+='\n'.join(f'{i+1}. {q["prompt"]}' for i,q in enumerate(d['questions']))+'\n\nOpen VEDICS to review answers or create a frozen assessment from this practice set.'
        elif r['kind']=='attempt':text+=f'Status: {d["status"]}. Graded marks: {d["score"]}/{d["maximum"]}.\n\n'+d['next_steps']
        elif r['kind']=='payroll':text+=f'Total net: {d["currency"]} {d["total_net"]}. Review required; no payment was made.'
        elif r['kind']=='lesson':text+=d['content']
        elif r['kind']=='task':text+=d['title']+'\nStatus: '+d.get('status','open')+'. No message was sent.'
        elif r['kind']=='document':text+='Draft ready for review.'
        else:text+='Open the specialist workspace to review this record.'
    elif 'records' in result:
        text='\n'.join(f'- **{r["title"]}** · {r["kind"]} · v{r["revision"]} · `{r["id"]}`' for r in result['records']) or 'No saved records yet.'
    else:text=json.dumps(result,ensure_ascii=False,indent=2)
    for a in result.get('artifacts',[]):text+='\n\n['+a['label']+']('+a['url']+')'
    return text
