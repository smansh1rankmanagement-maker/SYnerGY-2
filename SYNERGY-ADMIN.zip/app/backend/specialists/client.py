"""The application invokes its bundled MCP servers over stdio, not by pretending a prompt is a tool."""
import json,os,subprocess,sys
from pathlib import Path
from .catalog import PROTOCOL,canonical

def call(data,uid,server,name,arguments,request_id,mode='chat',timeout=40):
    messages=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':PROTOCOL,'capabilities':{},'clientInfo':{'name':'synergy','version':'2.1.0'}}},
              {'jsonrpc':'2.0','method':'notifications/initialized'},
              {'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':name,'arguments':arguments,'_meta':{'synergy/request_id':request_id}}}]
    env={k:v for k,v in os.environ.items() if k in {'PATH','PYTHONPATH','LANG','LC_ALL'}}
    result=subprocess.run([sys.executable,str(Path(__file__).with_name('server.py')),'--data',str(data),'--user',str(uid),'--server',canonical(server),'--mode',mode],input=''.join(json.dumps(x)+'\n' for x in messages),text=True,capture_output=True,timeout=max(.1,min(40,float(timeout))),env=env)
    if len(result.stdout)>2*1024*1024:raise ValueError('Tool output exceeded its limit.')
    responses=[json.loads(line) for line in result.stdout.splitlines() if line.strip()]
    response=next((r for r in responses if r.get('id')==2),None)
    if not response:raise RuntimeError('The MCP server stopped before returning a tool result.')
    if response.get('error'):raise ValueError(response['error']['message'])
    out=response['result']
    if out.get('isError'):raise ValueError(out['content'][0]['text'])
    return out['structuredContent']
