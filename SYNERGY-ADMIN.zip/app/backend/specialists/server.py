"""Real newline-delimited stdio MCP server. Account binding is host-only startup configuration."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from specialists.catalog import SERVERS,PROTOCOL,VERSION,canonical
from specialists.store import Session,ident

def main():
    p=argparse.ArgumentParser();p.add_argument('--data',required=True,type=Path);p.add_argument('--user',required=True,type=int);p.add_argument('--server',required=True);p.add_argument('--mode',default='chat');args=p.parse_args()
    server=canonical(args.server);session=Session(args.data/'accounts.sqlite3',args.data/'specialists',args.user,server)
    initialized=False;ready=False
    while True:
        line=sys.stdin.buffer.readline(130001)
        if not line:break
        request={};out=None
        try:
            if len(line)>130000:raise ValueError('Request exceeds the input limit.')
            request=json.loads(line)
            if not isinstance(request,dict) or request.get('jsonrpc')!='2.0' or not isinstance(request.get('method'),str):raise ValueError('Invalid JSON-RPC request.')
            method=request['method'];params=request.get('params',{})
            if not isinstance(params,dict):raise ValueError('Invalid params.')
            if method=='initialize':
                initialized=True
                requested=params.get('protocolVersion');version=requested if requested in {'2025-03-26','2025-06-18',PROTOCOL} else PROTOCOL
                out={'protocolVersion':version,'capabilities':{'tools':{'listChanged':False}},'serverInfo':{'name':'synergy-'+server,'version':VERSION},'instructions':'Private account-scoped tools. Review tool results and blockers. Documents remain drafts; no external messages or payments.'}
            elif method=='notifications/initialized':ready=initialized;continue
            elif method=='ping':out={}
            elif not ready:out={'error':'Initialize the MCP session first.'}
            elif method=='tools/list':out={'tools':[{k:t[k] for k in ('name','description','inputSchema','annotations')} for t in SERVERS[server]['tools']]}
            elif method=='tools/call':
                try:
                    result=session.call(params.get('name'),params.get('arguments',{}),params.get('_meta',{}).get('synergy/request_id') or ident(),args.mode)
                    out={'content':[{'type':'text','text':json.dumps(result,ensure_ascii=False)}],'structuredContent':result,'isError':False}
                except (ValueError,KeyError,PermissionError) as exc:out={'content':[{'type':'text','text':str(exc)}],'isError':True}
            elif method.startswith('notifications/'):continue
            else:
                if 'id' in request:print(json.dumps({'jsonrpc':'2.0','id':request['id'],'error':{'code':-32601,'message':'Method not found'}}),flush=True)
                continue
            if 'id' in request:print(json.dumps({'jsonrpc':'2.0','id':request['id'],'result':out},ensure_ascii=False),flush=True)
        except Exception as exc:
            from research.net import redact
            message=redact(str(exc))[:300]
            print(json.dumps({'jsonrpc':'2.0','id':request.get('id') if isinstance(request,dict) else None,'error':{'code':-32602,'message':message}}),flush=True)
if __name__=='__main__':main()
