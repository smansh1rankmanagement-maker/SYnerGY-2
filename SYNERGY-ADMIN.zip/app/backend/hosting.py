"""Single-server hosting policy. Proxy headers never override the configured origin."""
import os
import re
import threading
from collections import OrderedDict
from http.server import ThreadingHTTPServer
from urllib.parse import urlsplit
import time

VERSION = '3.1.0' # Internal release sequence; customer-facing product is SYNERGY 2.0.

class Hosting:
    def __init__(self, env=None):
        env = os.environ if env is None else env
        self.port = int(env.get('SYNERGY_PORT', '8090'))
        self.origin = env.get('SYNERGY_PUBLIC_ORIGIN', '').rstrip('/')
        self.public = bool(self.origin)
        self.bind = env.get('SYNERGY_BIND_HOST', '127.0.0.1')
        self.registration = env.get('SYNERGY_REGISTRATION_ENABLED', '1') == '1'
        if self.public:
            u = urlsplit(self.origin)
            if (u.scheme != 'https' or not u.hostname or u.username or u.password
                    or u.path or u.query or u.fragment or u.port not in (None, 443)
                    or not re.fullmatch(r'[a-z0-9.-]+', u.hostname)):
                raise ValueError('SYNERGY_PUBLIC_ORIGIN must be one HTTPS origin, without a path.')
            self.hosts = {u.netloc}
        else:
            if self.bind not in {'127.0.0.1', 'localhost', '::1'}:
                raise ValueError('A public bind requires SYNERGY_PUBLIC_ORIGIN.')
            self.hosts = {f'127.0.0.1:{self.port}', f'localhost:{self.port}'}

    def accepts(self, host, origin, method='GET', webhook=False):
        if host not in self.hosts:
            return False
        expected = self.origin if self.public else 'http://' + host
        if origin is not None:
            return origin == expected
        return not (self.public and method == 'POST' and not webhook)

    @property
    def cookie_suffix(self):
        return '; Secure' if self.public else ''

class RateLimiter:
    """Bounded memory and a shared cap behind the private reverse proxy."""
    def __init__(self, limit=12, window=60, capacity=2048):
        self.limit, self.window, self.capacity = limit, window, capacity
        self.items = OrderedDict()
        self.lock = threading.Lock()

    def allow(self, key):
        now = time.monotonic()
        with self.lock:
            recent = [t for t in self.items.pop(key, []) if now - t < self.window]
            allowed = len(recent) < self.limit
            if allowed:
                recent.append(now)
            self.items[key] = recent
            while len(self.items) > self.capacity:
                self.items.popitem(last=False)
            return allowed

class BoundedServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 64
    def __init__(self, *args, **kwargs):
        self.slots = threading.BoundedSemaphore(64)
        super().__init__(*args, **kwargs)

    def get_request(self):
        request, address = super().get_request()
        request.settimeout(20)
        return request, address

    def process_request(self, request, address):
        if not self.slots.acquire(False):
            try:
                request.sendall(b'HTTP/1.1 503 Service Unavailable\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')
            finally:
                self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except BaseException:
            self.slots.release()
            raise

    def process_request_thread(self, request, address):
        try:
            super().process_request_thread(request, address)
        finally:
            self.slots.release()
