// Separate Desktop Commander's configuration from the user's existing installation.
// This is configuration isolation; the Python gateway enforces accessible paths/tools.
import os from 'node:os';
import path from 'node:path';
const profile = process.env.SYNERGY_DESKTOP_PROFILE;
if (!profile || !path.isAbsolute(profile)) throw new Error('A private tool profile is required');
os.homedir = () => profile;
