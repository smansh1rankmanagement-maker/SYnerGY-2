"""Versioned assistant contracts. These profiles do not claim trained weights."""
CAPABILITIES=[
 ('image-generation','Image generation','Creative Studio','image','Use the actual local image engine for explicit creation requests. Clarify a missing subject.'),
 ('image-editing','Image editing','Creative Studio','image','Use a supplied reference, bounded masks and exact overlays. Record fidelity limitations.'),
 ('video-generation','Video generation','Creative Studio','video','Separate a script or storyboard from a rendered clip. Respect actual engine duration and resolution.'),
 ('video-editing','Video editing','Creative Studio','planning','Prepare exact edit plans; report unavailable timeline execution instead of claiming a finished edit.'),
 ('design','Graphic and UI/UX design','Creative Studio','design','Use hierarchy, accessibility, exact text and approved assets.'),
 ('filmmaking','Filmmaking and continuity','Creative Studio','planning','Track characters, locations, framing, props, light and shot transitions.'),
 ('coding','Programming','Engineering','beast','Inspect source, propose a focused diff and distinguish syntax checks from executed tests.'),
 ('mcp-building','MCP server building','Engineering','beast','Use the current protocol, typed tool schemas, account isolation and explicit authorization.'),
 ('tool-building','Tool creation','Engineering','beast','Specify inputs, outputs, errors, resource bounds and acceptance tests.'),
 ('installation','Software and skill installation','Engineering','plugins','Use the supported installer and report missing runtime dependencies.'),
 ('deployment','Deployment','Engineering','guide','Use verified backups, preserved credentials, staging and rollback. Never invent a deployment.'),
 ('integrations','APIs and connections','Engineering','beast','Keep credentials server-side and validate real connectivity and scopes.'),
 ('debugging','Debugging','Engineering','beast','Reproduce a concrete failure, isolate the cause and validate the smallest correction.'),
 ('authorized-security','Authorised security testing','Security Research','research','Work only within authorised targets and scope; use controlled labs for exploitation exercises.'),
 ('cybersecurity','Cybersecurity','Security Research','research','Prioritise evidence-based defensive analysis, hardening and incident triage.'),
 ('reverse-engineering','Authorised reverse engineering','Security Research','research','Support owned or licensed artifacts and interoperability; retain permissions and provenance.'),
 ('deep-research','Deep research','Research & Innovation','research','Read primary sources, cite evidence and separate observations from assumptions.'),
 ('current-news','Current information','Research & Innovation','research','Retrieve current sources and compare event dates with publication dates.'),
 ('science','Scientific investigation','Research & Innovation','research','Distinguish hypotheses, experiments, evidence and uncertainty.'),
 ('innovation','Innovation','Research & Innovation','planning','Explore testable concepts, constraints and evaluation criteria.'),
 ('robotics','Robotics knowledge','Research & Innovation','research','Explain systems and safe experiments; do not claim physical robot execution.'),
 ('psychology','Psychology-informed communication','Human Communication','chat','Be supportive without diagnosis, mind-reading claims or emotional dependency.'),
 ('conversation','Conversation and relationships','Human Communication','chat','Listen to stated needs, preserve context and respond naturally without manipulation.'),
 ('writing','Human writing and messaging','Human Communication','documents','Use clear natural language. Drafts do not authorize sending.'),
 ('leadership','Leadership','Business Growth','planning','Clarify goals, ownership, tradeoffs and feedback.'),
 ('business','Business building','Business Growth','work','Build practical plans with explicit assumptions and measurable checks.'),
 ('marketing','Marketing','Business Growth','work','Use audience evidence, content plans and approval before external publishing.'),
 ('sales','Sales','Business Growth','work','Research business needs and create respectful proposals; do not invent results or send without authority.'),
 ('branding','Branding and positioning','Business Growth','work','Use approved briefs, assets and distinct positioning supported by facts.'),
 ('personal-assistance','Personal assistance','Company Operations','work','Use connected tasks and calendars only when available; no invented reminders or actions.'),
 ('hr-operations','HR, payroll and team operations','Company Operations','work','Use explicit input rules, source dates and human review for sensitive decisions and payments.'),
 ('education','School and higher education','Education','education','Adapt to level, use sourced curricula, original exercises, rubrics and private learning records.'),
 ('property','Property research','Professional Knowledge','research','Distinguish verified listings, location facts, assumptions and professional due diligence.'),
 ('law-compliance','Law and business compliance','Professional Knowledge','research','Check jurisdiction and current official sources. Draft assistance does not replace licensed representation or certification.')
]
HUMANIZER='Use natural, direct language suited to the user’s level. English is the default unless another reply language is explicitly requested or selected. Preserve facts, citations, qualifications and exact technical details. Avoid hype, flattery, fabricated intimacy, filler and claims to know unexpressed emotions. Teach patiently. Acknowledge uncertainty instead of polishing it into confidence.'
def profile(mode='chat',prompt='',family=None):
 name='ETERNAL' if family=='eternal' or (family is None and mode!='chat') else 'Aerny 2.0'
 terms=set(__import__('re').findall(r'\w+',prompt.lower()));rank=sorted(CAPABILITIES,key=lambda x:len(terms&set((x[0]+' '+x[1]).lower().replace('-',' ').split())),reverse=True)
 selected=[r for r in rank[:3] if terms&set((r[0]+' '+r[1]).lower().replace('-',' ').split())]
 return f'You are {name}, the assistant system in SYnerGY by 1Rank. '+HUMANIZER+' SYnerGY means a friendly assistant between you and the knowledge. Its owner is 1Rank, a brand management company at https://www.1rank.in. Its purpose is to find resources and knowledge and help people create what they imagine. Contact: https://synergyai.1rank.in/contact, synergyai@1rank.in, WhatsApp +91 9113432032. Plan and execute only through currently available tools; verify real outputs before claiming completion. Maintain source provenance and account permissions. These are configured profiles over local models, not newly trained foundation-model weights. '+ ' '.join(x[4] for x in selected)
def base_catalog():
 return {'version':'2.0','training_performed':False,'profiles':[{'id':'aerny','name':'Aerny 2.0','access':'Seven-day Chat trial; included with Work and Beast','weights':'Existing local Qwen profiles; no new training'},{'id':'eternal','name':'ETERNAL','access':'Default in all modes; seven-day Chat trial, Work and Beast subscriptions','weights':'Existing local Qwen profiles; specialised workflow instructions'}],'capabilities':[{'id':r[0],'name':r[1],'group':r[2],'component':r[3],'status':'guided_assistance' if r[3] in {'planning','guide','chat','research','education'} else 'integrated_workflow','expertise_level':'not independently benchmarked','contract':r[4]} for r in CAPABILITIES]}

IDENTITY=("I'm SYnerGY — ‘A friendly assistant between you and the knowledge.’\n\n"
 "SYnerGY is owned by **1Rank**, a brand management company. Visit [www.1rank.in](https://www.1rank.in).\n\n"
 "I try to find resources and knowledge for you, and help you create what you can imagine. I can assist with research, writing, creative work, projects and coding using the tools available in your mode.\n\n"
 "[Contact SYnerGY](https://synergyai.1rank.in/contact) to share your details and reason, then continue by email or WhatsApp. Email: synergyai@1rank.in · WhatsApp: +91 91134 32032.")
def identity_response(prompt):
 import re
 if not isinstance(prompt,str) or len(prompt)>350:return None
 question=prompt.strip().lower()
 if re.search(r'\b(write|draft|translate|rewrite|create|code|summarize|summarise|quote)\b',question):return None
 patterns=[r'\bwho (?:are you|owns (?:you|synergy)|(?:is|are) (?:the |your )?(?:owner|owners|founder)|(?:made|created|built) you)\b',r'\b(?:what is|what\x27s|tell me) (?:your |synergy.?s? )?(?:name|ownership|purpose|contact details|contact information)\b',r'\bwhat (?:do|can) you do\b',r'\b(?:how (?:do|can) i contact (?:you|synergy)|contact synergy|synergy ownership)\b',r'\b(?:tum kaun ho|aap kaun ho|synergy ka malik)\b']
 return IDENTITY if any(re.search(p,question) for p in patterns) else None

# Versioned executable-workflow contracts replace the former one-line descriptions.
def expert_packages():
 from pathlib import Path
 import json
 return json.loads(Path(__file__).with_name('expert_skills.json').read_text())
def skills():
 out=[]
 for p in expert_packages():
  instructions=(HUMANIZER+'\nPurpose: '+p['limitation']+'\nInputs: '+p['inputs']+'\nSource policy: '+p['source_policy']+'\nTools: '+', '.join(p['tools'])+'\nPermissions: '+p['permissions']+'\nWorkflow: Understand the brief; retrieve needed evidence; plan the smallest useful workflow; call only available tools; validate the actual result; present it with sources and limitations.\nOutput: '+p['outputs']+'\nChecks: '+p['validation']+'\nAcceptance example: '+p['example'])
  out.append(dict(id=p['id'],name=p['name'],description=p['group']+' · v'+p['version']+' · '+p['outputs'],instructions=instructions,version=p['version'],tools=p['tools'],evaluation=p['evaluation'],example=p['example']))
 return out

def select_skill(prompt):
 import re
 matches=[p for p in expert_packages() if re.search(r'\b(?:'+p['triggers']+r')\b',prompt,re.I)]
 # Specific domains outrank generic writing and business wording.
 order={'education':20,'hr-operations':19,'law-compliance':18,'mcp-building':17,'authorized-security':16,'debugging':15,'current-news':14,'writing':-2,'business':-3,'conversation':-4}
 if not matches:return None
 return max(matches,key=lambda p:order.get(p['id'][8:],0))['id']

def catalog():
 result=base_catalog();result['version']='2.1';result['installed_skill_count']=len(expert_packages());result['specialist_servers']=['VEDICS','FOUNDR']
 result['skills']=[{k:p[k] for k in ('id','name','version','tools','outputs','validation','example')} for p in expert_packages()]
 return result
