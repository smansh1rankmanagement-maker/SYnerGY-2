"""Durable single-concurrency Lab worker, independent of an open browser."""
import argparse,datetime,fcntl,json,os,signal,sqlite3,subprocess,sys,time
from pathlib import Path
from zoneinfo import ZoneInfo
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from membership import Membership
from eternal_lab.store import Lab

def heartbeat(lab):
    with lab.connect() as c:c.execute('INSERT OR REPLACE INTO lab_heartbeat VALUES(1,?)',(time.time(),))
def schedule(lab,now=None):
    local=(now or datetime.datetime.now(datetime.timezone.utc)).astimezone(ZoneInfo('Asia/Kolkata'));day=local.date().isoformat()
    with lab.connect() as c:rows=c.execute("SELECT id,owner,active FROM lab_objects WHERE kind='workflow' AND enabled=1 AND active IS NOT NULL AND owner>0").fetchall()
    for row in rows:
        try:
            obj=lab.get(row['owner'],row['id'],row['active']);s=obj['spec']
            if s.get('trigger')!='daily' or not s.get('enabled_schedule') or local.strftime('%H:%M')<s['schedule']:continue
            with lab.connect() as c:done=c.execute('SELECT 1 FROM lab_schedule_receipts WHERE object_id=? AND version=? AND day=?',(row['id'],row['active'],day)).fetchone()
            if done:continue
            run=lab.submit(row['owner'],'workflow',row['id'],row['active'],{},'schedule:'+row['id']+':'+str(row['active'])+':'+day)
            with lab.connect() as c:c.execute('INSERT OR IGNORE INTO lab_schedule_receipts VALUES(?,?,?,?)',(row['id'],row['active'],day,run['id']))
        except (PermissionError,ValueError,KeyError):continue

def work(lab,once=False):
    heartbeat(lab)
    with lab.connect() as c:
        c.execute("UPDATE lab_runs SET state='failed',error='Worker restarted during execution. Inspect effects before explicitly retrying; writes were not replayed.',updated=?,finished=? WHERE state='running'",(time.time(),time.time()))
    last_heartbeat=0;last_schedule=0
    while True:
        now=time.monotonic()
        if now-last_heartbeat>2:heartbeat(lab);last_heartbeat=now
        if now-last_schedule>30:
            try:schedule(lab)
            except Exception:pass
            last_schedule=now
        with lab.connect() as c:
            c.execute('BEGIN IMMEDIATE');row=c.execute("SELECT * FROM lab_runs WHERE state='queued' ORDER BY created LIMIT 1").fetchone()
            if row:c.execute("UPDATE lab_runs SET state='running',started=?,updated=? WHERE id=? AND state='queued'",(time.time(),time.time(),row['id']))
        if not row:
            if once:return
            time.sleep(.15);continue
        lab.event(row['id'],'Isolated worker started; configuration versions are pinned.')
        pin=json.loads(row['pinned']);root=pin[row['object_id']+':'+str(row['version'])];deadline=time.monotonic()+min(600,root['spec'].get('limits',{}).get('seconds',180))+5
        env={k:v for k,v in os.environ.items() if k in {'PATH','LANG','LC_ALL','PYTHONPATH','SYNERGY_OLLAMA_URL'} or k.startswith('SYNERGY_LAB_')}
        process=subprocess.Popen([sys.executable,str(Path(__file__).with_name('runner.py')),str(lab.data),row['id']],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=env,start_new_session=True)
        reason=None
        while process.poll() is None:
            if time.monotonic()-last_heartbeat>2:heartbeat(lab);last_heartbeat=time.monotonic()
            with lab.connect() as c:state=c.execute('SELECT state FROM lab_runs WHERE id=?',(row['id'],)).fetchone()[0]
            if state=='cancelled':reason='Cancelled';break
            if time.monotonic()>deadline:reason='The isolated job exceeded its timeout.';break
            time.sleep(.05)
        if reason:
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            process.wait(timeout=5)
        with lab.connect() as c:c.execute("UPDATE lab_runs SET state='failed',error=?,finished=?,updated=? WHERE id=? AND state='running'",(reason or 'The isolated runner exited before saving a result.',time.time(),time.time(),row['id']))
        if once:return

def main():
    p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--once',action='store_true');a=p.parse_args();data=Path(a.data);db=data/'accounts.sqlite3';m=Membership(db);lab=Lab(db,data,m.admin)
    with (lab.root/'worker.lock').open('w') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('Another Lab worker already holds the lock.')
        work(lab,a.once)
if __name__=='__main__':main()
