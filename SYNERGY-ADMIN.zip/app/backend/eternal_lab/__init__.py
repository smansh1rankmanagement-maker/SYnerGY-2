"""ETERNAL Lab: versioned configuration, evidence, and bounded execution."""
