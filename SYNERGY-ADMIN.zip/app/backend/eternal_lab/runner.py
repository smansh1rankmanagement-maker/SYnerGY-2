"""One job in one trusted subprocess; never import the web server."""
import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from membership import Membership
from workspace import Workspace
from eternal_lab.store import Lab,ident
from eternal_lab.validation import dump,safe
from eternal_lab.runtime import Runtime,Blocked

def run_one(data,rid):
    data=Path(data);db=data/'accounts.sqlite3';members=Membership(db);lab=Lab(db,data,members.admin)
    with lab.connect() as c:row=c.execute('SELECT actor FROM lab_runs WHERE id=?',(rid,)).fetchone()
    if not row:raise ValueError('Run unavailable.')
    run=lab.run(row[0],rid)
    if run['state']!='running':return
    try:
        result=Runtime(lab,run).execute();safe(result);state='succeeded' if result.get('passed',True) else 'failed';error=''
    except InterruptedError:result={};state='cancelled';error='Cancelled.'
    except Blocked as e:result={'blocked':True,'weights_trained':False};state='blocked';error=str(e)[:1000]
    except Exception as e:
        result={};state='failed';error='The isolated job failed ('+type(e).__name__+'). Review the configuration and connection.'
        if isinstance(e,(ValueError,KeyError,TimeoutError)):
            try:safe(str(e));error=str(e)[:1000]
            except ValueError:pass
    with lab.connect() as c:
        c.execute("UPDATE lab_runs SET state=?,result=?,error=?,finished=?,updated=? WHERE id=? AND state='running'",(state,dump(result),error,time.time(),time.time(),rid))
        current=c.execute('SELECT state FROM lab_runs WHERE id=?',(rid,)).fetchone()[0]
        if run['kind'] in {'test','evaluation'} and current!='cancelled':
            obj=run['pinned'][run['object_id']+':'+str(run['version'])]
            c.execute('INSERT INTO lab_checks VALUES(?,?,?,?,?,?,?,?)',(ident(),obj['id'],obj['version'],obj['hash'],run['kind'],int(state=='succeeded'),dump({'run_id':rid,**result,'error':error}),time.time()))
        lab.audit(c,run['actor'],'job_'+current,run['object_id'],run['version'],{'run_id':rid,'error':error,'weights_trained':False})
    lab.event(rid,'Job '+current+((': '+error) if error else ''))
if __name__=='__main__':run_one(sys.argv[1],sys.argv[2])
