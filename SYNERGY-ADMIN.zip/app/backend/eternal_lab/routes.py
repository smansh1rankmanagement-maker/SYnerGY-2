"""Same authenticated operations for manual forms and Beast proposals."""
import io,json,re,zipfile
from urllib.parse import urlsplit,parse_qs
from .templates import example
from .validation import KINDS
from .proposals import propose,apply
class LabHTTP:
 def lab_get(self,path,user):
  uid=user['id'];lab=self.lab
  try:
   lab.admin(uid);q=parse_qs(urlsplit(self.path).query)
   if path=='/api/admin/lab':return self.response(200,lab.overview(uid))
   if path=='/api/admin/lab/templates':return self.response(200,{k:example(k) for k in sorted(KINDS)})
   if path=='/api/admin/lab/object':return self.response(200,lab.compare(uid,q.get('id',[''])[0],int(q['version'][0]) if q.get('version') else None))
   if path=='/api/admin/lab/run':return self.response(200,lab.run(uid,q.get('id',[''])[0]))
   if path=='/api/admin/lab/export':
    obj=lab.get(uid,q.get('id',[''])[0]);raw=json.dumps({'object':obj,'review':lab.compare(uid,obj['id'])},indent=2,ensure_ascii=False).encode();return self.research_download(raw,'capability-'+obj['id']+'.json')
   return self.fail(404,'Lab item not found.')
  except PermissionError as e:return self.fail(403,str(e))
  except KeyError:return self.fail(404,'Lab item not found in this account.')
  except (ValueError,TypeError) as e:return self.fail(400,str(e))
 def lab_post(self,path,d,user):
  uid=user['id'];lab=self.lab
  try:
   lab.admin(uid)
   if path=='/api/admin/lab/save':out=lab.save(uid,d.get('kind'),d.get('spec'),d.get('id'),d.get('expected_version'))
   elif path=='/api/admin/lab/server-project':out=lab.create_server_project(uid,d.get('name'))
   elif path=='/api/admin/lab/validate':out=lab.check(uid,d.get('id'),d.get('version'))
   elif path=='/api/admin/lab/action':out=lab.action(uid,d)
   elif path=='/api/admin/lab/submit':out=lab.submit(uid,d.get('kind'),d.get('id'),d.get('version'),d.get('inputs'),d.get('request_id'))
   elif path=='/api/admin/lab/cancel':out=lab.cancel(uid,d.get('id'))
   elif path=='/api/admin/lab/propose':out=propose(lab,uid,d.get('prompt'),d.get('family','eternal'),d.get('configuration'),d.get('kind'),d.get('id'),d.get('expected_version'))
   elif path=='/api/admin/lab/apply':out=apply(lab,uid,d.get('id'),d.get('reviewed_hash'))
   else:return self.fail(404,'Lab operation not found.')
   return self.response(200,out)
  except PermissionError as e:return self.fail(403,str(e))
  except KeyError:return self.fail(404,'Lab item not found in this account.')
  except (ValueError,TypeError) as e:return self.fail(400,str(e))
