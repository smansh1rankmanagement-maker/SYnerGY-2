"""Beast requests become reviewable typed proposals, never privileged free-form code."""
import copy,json,re,time
from .templates import agent,example,tool,ref
from .validation import digest,dump,normalise,safe,text
from .store import ident

def propose(lab,uid,prompt,family='eternal',configuration=None,kind=None,oid=None,expected_version=None):
    lab.admin(uid);prompt=text(prompt,'Beast request',8000);safe(prompt)
    if family not in {'eternal','aerny'}:raise ValueError('Choose a connected SYnerGY model family.')
    ops=[];questions=[];p=prompt.casefold();items=lab.list(uid)
    if configuration is not None:
        s=normalise(kind,configuration);lab.verify_references(uid,kind,s,oid);ops=[{'action':'save','kind':kind,'spec':s,'id':oid,'expected_version':expected_version}]
    elif 'server' in p and ('create' in p or 'build' in p):
        ops=[{'action':'server_project','name':'SYnerGY MCP draft server'}]
    elif 'roll back' in p or 'rollback' in p:
        match=next((o for o in items if o['spec']['name'].casefold() in p),None)
        if match and match['latest']>1:
            v=lab.get(uid,match['id'],match['latest']-1);ops=[{'action':'rollback','id':v['id'],'version':v['version'],'reviewed_hash':v['hash'],'expected_version':v['latest'],'note':prompt}]
        else:questions.append('Select the capability and previously tested version to roll back.')
    elif 'evaluate' in p or 'test the' in p:
        match=next((o for o in items if o['kind'] in {'agent','subagent'} and o['spec']['name'].casefold() in p),None)
        if match:ops=[{'action':'evaluation','id':match['id'],'version':match['version']}]
        else:questions.append('Select the agent and assign its evaluation suite.')
    elif ('agent' in p or 'subagent' in p) and ('create' in p or 'add' in p):
        name='VEDICS Class 10 mathematics '+('subagent' if 'subagent' in p else 'agent') if 'vedic' in p or 'math' in p else 'Filmmaking agent' if 'film' in p else 'Research agent'
        s=agent(name);s['model']['family']=family;kind='subagent' if 'subagent' in p else 'agent'
        if 'film' in p:s.update(purpose='Plan films with reviewed storyboard and editing skills; call only assigned tools.',instructions='Build a shot list, continuity notes and editing plan. Actual video generation/editing requires configured media tools. Never claim unexecuted renders.')
        for item in items:
            if item['kind']=='skill' and ((('math' in p or 'vedic' in p) and item['spec'].get('package_id')=='26-subject-teaching') or ('film' in p and item['spec'].get('package_id')=='34-filmmaking')):s['skills'].append(ref(item['id'],item['version']))
        if kind=='subagent':
            parents=[o for o in items if o['kind']=='agent' and o['spec']['delegation']['depth']>0]
            named=[o for o in parents if o['spec']['name'].casefold() in p]
            parent=(named or parents)[0] if len(named or parents)==1 else None
            if not parent:questions.append('Choose the parent agent; the subagent cannot inherit unassigned permissions.')
            else:
                s['parent']=ref(parent['id'],parent['version']);s['delegation']['depth']=parent['spec']['delegation']['depth']-1
                for key in ['tools','knowledge','skills','scope','limits','evaluation']:s[key]=copy.deepcopy(parent['spec'].get(key))
        else:
            candidates=[o for o in items if o['kind']=='mcp_tool' and o['spec'].get('upstream_tool')=='question_explain' and o['active']]
            if len(candidates)==1:s['tools']=[ref(candidates[0]['id'],candidates[0]['active'])]
        if not questions:ops=[{'action':'save','kind':kind,'spec':s}]
    elif 'tool' in p and ('pdf' in p or 'scorecard' in p):
        s=tool('Export VEDICS scorecard PDF','scorecard_export');s['test_assert']={'contains':'pdf'};ops=[{'action':'save','kind':'mcp_tool','spec':s}]
    elif ('crm' in p or 'api' in p) and 'connect' in p:
        urls=re.findall(r'https://[^\s<>]+',prompt);s=example('connection');s['name']='Documented CRM connection'
        if urls:s['documentation']=urls[0]
        questions=['Provide the documented read-only endpoint, confirm the authorised account, and select a stored credential reference. No secret value belongs in chat.'];ops=[{'action':'draft_template','kind':'connection','spec':s}]
    elif 'sales' in p and ('update' in p or 'examples' in p):questions=['Select the sales skill version and attach the approved examples with their source, usage rights and reviewer.']
    else:questions=['Describe the capability to create, or select a type and attach its JSON configuration for a validated Beast proposal.']
    errors=[]
    for op in ops:
        if op['action']=='save':
            try:op['spec']=normalise(op['kind'],op['spec']);lab.verify_references(uid,op['kind'],op['spec'],op.get('id'))
            except (ValueError,KeyError) as e:errors.append(str(e))
    payload={'request':prompt,'assistant_family':family,'mode':'beast','operations':ops,'questions':questions,'validation_errors':errors,'affected':[],'permissions':[op.get('spec',{}).get('scope') for op in ops if op.get('spec')],'dependencies':[r for op in ops for r in op.get('spec',{}).get('tools',[])],'credentials_required':[op['spec'].get('secret_ref') for op in ops if op.get('kind')=='connection'],'resource_impact':'Configuration changes use no external API credits. Tests are queued with one worker and bounded time/tokens. No training or installation happens on save.','deployment_status':'proposed','interpretation':'Deterministic intent parser and validated templates; model weights are unchanged.'}
    pid=ident();h=digest(payload)
    with lab.connect() as c:c.execute('INSERT INTO lab_proposals VALUES(?,?,?,?,?,?,?)',(pid,uid,dump(payload),h,'proposed',time.time(),None));lab.audit(c,uid,'beast_proposed',detail={'proposal_id':pid,'hash':h,'family':family})
    return {'id':pid,'hash':h,**payload}

def apply(lab,uid,pid,reviewed_hash):
    lab.admin(uid)
    with lab.connect() as c:
        c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT * FROM lab_proposals WHERE id=? AND actor=?',(pid,uid)).fetchone()
        if not r:raise KeyError('Proposal not found in this account.')
        if r['hash']!=reviewed_hash:raise ValueError('Review this exact proposal before applying it.')
        if r['state']=='applied':return json.loads(r['result'])
        if r['state']!='proposed':raise ValueError('This proposal is already being applied or failed. Review its audit record.')
        p=json.loads(r['payload'])
        if p['questions'] or p['validation_errors']:raise ValueError('Resolve the proposal’s questions and validation failures first.')
        c.execute("UPDATE lab_proposals SET state='applying' WHERE id=?",(pid,))
    try:
        results=[]
        for op in p['operations']:
            if op['action']=='save':results.append(lab.save(uid,op['kind'],op['spec'],op.get('id'),op.get('expected_version'),route='beast'))
            elif op['action']=='server_project':results.append(lab.create_server_project(uid,op['name'])['capability'])
            elif op['action']=='rollback':results.append(lab.action(uid,op))
            elif op['action']=='evaluation':results.append(lab.submit(uid,'evaluation',op['id'],op['version'],request_id='proposal:'+pid))
            else:raise ValueError('This template still needs configuration.')
        with lab.connect() as c:c.execute("UPDATE lab_proposals SET state='applied',result=? WHERE id=?",(dump(results),pid));lab.audit(c,uid,'beast_applied',detail={'proposal_id':pid,'records':[r['id'] for r in results]})
        return results
    except Exception:
        with lab.connect() as c:c.execute("UPDATE lab_proposals SET state='failed' WHERE id=?",(pid,))
        raise
