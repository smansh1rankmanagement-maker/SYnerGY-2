"""Administrator-only immutable versions, audit records and durable job queue."""
import copy,difflib,json,sqlite3,time,uuid
from pathlib import Path
from .validation import KINDS,digest,dump,normalise,refs,reference,safe,text,validate_data

DDL='''
CREATE TABLE IF NOT EXISTS lab_objects(id TEXT PRIMARY KEY,kind TEXT NOT NULL,owner INTEGER NOT NULL,latest INTEGER NOT NULL,active INTEGER,enabled INTEGER NOT NULL DEFAULT 1,created REAL NOT NULL,updated REAL NOT NULL);
CREATE TABLE IF NOT EXISTS lab_versions(object_id TEXT NOT NULL,version INTEGER NOT NULL,spec TEXT NOT NULL,hash TEXT NOT NULL,actor INTEGER NOT NULL,created REAL NOT NULL,PRIMARY KEY(object_id,version));
CREATE TABLE IF NOT EXISTS lab_audit(id TEXT PRIMARY KEY,actor INTEGER NOT NULL,action TEXT NOT NULL,object_id TEXT,version INTEGER,detail TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS lab_checks(id TEXT PRIMARY KEY,object_id TEXT NOT NULL,version INTEGER NOT NULL,hash TEXT NOT NULL,kind TEXT NOT NULL,passed INTEGER NOT NULL,result TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS lab_runs(id TEXT PRIMARY KEY,actor INTEGER NOT NULL,kind TEXT NOT NULL,object_id TEXT,version INTEGER,state TEXT NOT NULL,pinned TEXT NOT NULL,input TEXT NOT NULL,result TEXT NOT NULL DEFAULT '{}',error TEXT NOT NULL DEFAULT '',created REAL NOT NULL,updated REAL NOT NULL,started REAL,finished REAL,request_id TEXT NOT NULL,UNIQUE(actor,request_id));
CREATE TABLE IF NOT EXISTS lab_events(id INTEGER PRIMARY KEY AUTOINCREMENT,run_id TEXT NOT NULL,event TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS lab_proposals(id TEXT PRIMARY KEY,actor INTEGER NOT NULL,payload TEXT NOT NULL,hash TEXT NOT NULL,state TEXT NOT NULL,created REAL NOT NULL,result TEXT);
CREATE TABLE IF NOT EXISTS lab_heartbeat(id INTEGER PRIMARY KEY CHECK(id=1),updated REAL NOT NULL);
CREATE TABLE IF NOT EXISTS lab_schedule_receipts(object_id TEXT NOT NULL,version INTEGER NOT NULL,day TEXT NOT NULL,run_id TEXT NOT NULL,PRIMARY KEY(object_id,version,day));
'''
def ident():return uuid.uuid4().hex
class Lab:
    def __init__(self,db,data,admin,workspace=None,beast=None):
        self.db=Path(db);self.data=Path(data);self.root=self.data/'eternal-lab';self.root.mkdir(exist_ok=True,parents=True,mode=0o700);self.admin=admin;self.workspace=workspace;self.beast=beast
        with self.connect() as c:c.executescript(DDL)
        self.seed()
    def connect(self):
        c=sqlite3.connect(self.db,timeout=20);c.row_factory=sqlite3.Row;return c
    def audit(self,c,uid,action,oid=None,version=None,detail=None):
        c.execute('INSERT INTO lab_audit VALUES(?,?,?,?,?,?,?)',(ident(),uid,action,oid,version,dump(detail or {}),time.time()))
    def seed(self):
        from .templates import seeds
        with self.connect() as c:
            for oid,kind,spec,active in seeds():
                if c.execute('SELECT 1 FROM lab_objects WHERE id=?',(oid,)).fetchone():continue
                now=time.time();c.execute('INSERT INTO lab_objects VALUES(?,?,?,?,?,?,?,?)',(oid,kind,0,1,1 if active else None,1,now,now));c.execute('INSERT INTO lab_versions VALUES(?,?,?,?,?,?)',(oid,1,dump(spec),digest(spec),0,now));self.audit(c,0,'bundled_definition',oid,1,{'training_performed':False})
    def get(self,uid,oid,version=None,c=None):
        self.admin(uid)
        if c is None:
            with self.connect() as conn:return self.get(uid,oid,version,conn)
        row=c.execute('SELECT * FROM lab_objects WHERE id=?',(oid,)).fetchone()
        if not row:raise KeyError('Capability not found.')
        item=dict(row);v=c.execute('SELECT * FROM lab_versions WHERE object_id=? AND version=?',(oid,version or row['latest'])).fetchone()
        if not v:raise KeyError('Capability version not found.')
        item.update(version=v['version'],hash=v['hash'],spec=json.loads(v['spec']))
        if item['owner'] not in {0,uid} and item['spec'].get('scope',{}).get('kind')!='shared':raise KeyError('Private capability not found in this account.')
        return item
    def list(self,uid,kind=None):
        self.admin(uid)
        with self.connect() as c:
            rows=c.execute('SELECT id FROM lab_objects WHERE (? IS NULL OR kind=?) ORDER BY updated DESC',(kind,kind)).fetchall();out=[]
            for row in rows:
                try:item=self.get(uid,row['id'],c=c)
                except KeyError:continue
                out.append(item)
        return out
    def verify_references(self,uid,kind,spec,oid=None):
        dependencies=[self.get(uid,r['id'],r['version']) for r in refs(spec)]
        typed={'skills':'skill','knowledge':'knowledge','tools':'mcp_tool','agents':'agent','connections':'connection'}
        for field,wanted in typed.items():
            for r in spec.get(field,[]):
                actual=self.get(uid,r['id'],r['version'])['kind']
                if actual!=wanted and not (wanted=='agent' and actual=='subagent'):raise ValueError(field+' references the wrong capability type.')
        for field,wanted in {'evaluation':'evaluation','dataset':'dataset','base_model':'model','server':'mcp_server','connection':'connection','heldout_evaluation':'evaluation'}.items():
            if spec.get(field) and self.get(uid,spec[field]['id'],spec[field]['version'])['kind']!=wanted:raise ValueError(field+' references the wrong capability type.')
        if oid and any(x['id']==oid for x in dependencies):raise ValueError('A capability cannot reference itself.')
        for project in spec['scope']['projects']:
            if not self.workspace:raise ValueError('Project permission checks unavailable.')
            self.workspace.project(uid,project)
        if spec.get('code_project'):
            if not self.beast:raise ValueError('Private code-project access is unavailable.')
            self.beast.project(uid,spec['code_project'])
        if spec['scope']['kind']=='shared' and any(x['spec']['scope']['kind']=='private' for x in dependencies):raise ValueError('Shared definitions cannot expose private dependencies.')
        if kind in {'agent','subagent'} and spec.get('parent'):
            p=self.get(uid,**{'oid':spec['parent']['id'],'version':spec['parent']['version']})
            if p['kind'] not in {'agent','subagent'}:raise ValueError('Parent must be an agent.')
            parent=p['spec'];seen={oid} if oid else set();depth=0
            while p:
                if p['id'] in seen:raise ValueError('Circular delegation is not allowed.')
                seen.add(p['id']);depth+=1
                if depth>3:raise ValueError('Delegation exceeds three levels.')
                r=p['spec'].get('parent');p=self.get(uid,r['id'],r['version']) if r else None
            for field in ['tools','knowledge','skills']:
                if not {dump(x) for x in spec.get(field,[])}<={dump(x) for x in parent.get(field,[])}:raise ValueError('Subagent '+field+' exceed its parent permissions.')
            if spec['scope']!=parent['scope']:raise ValueError('Subagent data scope must equal the parent scope in this release.')
            if spec['delegation']['depth']>=parent['delegation']['depth']:raise ValueError('Child delegation depth must be lower than the parent.')
            if spec['delegation']['concurrent_children']>parent['delegation']['concurrent_children']:raise ValueError('Child concurrency exceeds parent.')
            if parent['model']['provider']=='synergy' and spec['model']['provider']!='synergy':raise ValueError('Subagent cannot add external-provider access.')
            if any(spec['limits'][k]>parent['limits'][k] for k in spec['limits']):raise ValueError('Subagent resource limits exceed parent.')
        return dependencies
    def save(self,uid,kind,spec,oid=None,expected_version=None,route='manual'):
        self.admin(uid);spec=normalise(kind,spec);self.verify_references(uid,kind,spec,oid);now=time.time()
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if kind=='mcp_tool':
                for row in c.execute("SELECT o.id,v.spec FROM lab_objects o JOIN lab_versions v ON v.object_id=o.id AND v.version=o.latest WHERE o.kind='mcp_tool' AND o.owner IN (0,?)",(uid,)):
                    if row['id']!=oid and json.loads(row['spec']).get('tool_name')==spec['tool_name']:raise ValueError('This tool name already exists in the workspace. Update its version or choose a unique tool_name.')
            if oid:
                old=self.get(uid,oid,c=c)
                if old['kind']!=kind or type(expected_version) is not int or expected_version!=old['latest']:raise ValueError('The definition changed. Reload and review the latest version.')
                version=old['latest']+1;c.execute('UPDATE lab_objects SET latest=?,updated=? WHERE id=?',(version,now,oid))
            else:
                if c.execute('SELECT count(*) FROM lab_objects WHERE owner=?',(uid,)).fetchone()[0]>=1000:raise ValueError('Capability workspace limit reached.')
                oid=ident();version=1;c.execute('INSERT INTO lab_objects VALUES(?,?,?,?,?,?,?,?)',(oid,kind,uid,1,None,1,now,now))
            c.execute('INSERT INTO lab_versions VALUES(?,?,?,?,?,?)',(oid,version,dump(spec),digest(spec),uid,now));self.audit(c,uid,'draft_saved',oid,version,{'route':route,'hash':digest(spec)})
        return self.get(uid,oid)
    def compare(self,uid,oid,version=None):
        item=self.get(uid,oid,version);old=self.get(uid,oid,item['active']) if item['active'] else None
        diff=''.join(difflib.unified_diff(json.dumps(old['spec'] if old else {},indent=2).splitlines(True),json.dumps(item['spec'],indent=2).splitlines(True),fromfile='production',tofile='candidate'))
        affected=[]
        for obj in self.list(uid):
            if any(r['id']==oid for r in refs(obj['spec'])):affected.append({'id':obj['id'],'name':obj['spec']['name'],'version':obj['version'],'pinned_versions_unchanged':True})
        dependencies=self.verify_references(uid,item['kind'],item['spec'],oid)
        return {'object':item,'diff':diff,'affected':affected,'dependencies':[{'id':d['id'],'version':d['version'],'name':d['spec']['name']} for d in dependencies],'permissions':item['spec'].get('scope'),'resources':item['spec'].get('limits',{}),'credentials':[d['spec'].get('secret_ref') for d in dependencies if d['kind']=='connection' and d['spec'].get('secret_ref')],'deployment':'draft' if item['active']!=item['version'] else 'active','validation':self.check(uid,oid,item['version'],persist=False)}
    def check(self,uid,oid,version=None,persist=True):
        item=self.get(uid,oid,version);errors=[];gaps=[]
        try:normalise(item['kind'],item['spec']);deps=self.verify_references(uid,item['kind'],item['spec'],oid)
        except (ValueError,KeyError) as e:errors.append(str(e));deps=[]
        s=item['spec'];kind=item['kind']
        if kind=='mcp_tool' and s.get('handler')=='draft':gaps.append('Executable handler is missing; this tool cannot run or be released.')
        if kind=='mcp_tool' and s.get('effect')=='external_write':gaps.append('External-write handlers are not enabled in this release.')
        if kind=='mcp_tool':
            for d in deps:
                if not d['enabled'] or d['active']!=d['version']:gaps.append(d['spec']['name']+' requires connection testing and release.')
            if not s.get('test_assert',{}).get('contains'):gaps.append('Add an expected result for the executable tool test.')
        if kind=='mcp_server' and s.get('transport')=='project':gaps.append('Server project requires code review, packaging and an isolated supported runner.')
        if kind=='connection' and s.get('secret_ref'):
            import os
            if not os.environ.get(s['secret_ref'].removeprefix('env:')):gaps.append('Missing configured secret reference '+s['secret_ref'])
        if kind in {'agent','subagent'}:
            if not s.get('evaluation'):gaps.append('Assign an evaluation suite before release.')
            for d in deps:
                if not d['enabled'] or d['active']!=d['version']:gaps.append(d['spec']['name']+' is not active at the pinned version.')
            if s['scope']['projects'] and s.get('tools'):gaps.append('These connectors enforce account scope but do not support project-specific records. Use a project-scoped adapter before release.')
            if s['delegation']['strategy']=='parallel':gaps.append('The first Lab runner supports sequential delegation only; parallel configuration remains draft.')
            if s['model']['provider']!='synergy':gaps.append('External Lab assistance is unavailable under the current $0 Lab policy.')
        if kind=='skill' and s.get('review',{}).get('status')!='approved':gaps.append('Domain instruction review is pending; installation is not domain expertise.')
        if kind in {'dataset','knowledge'}:
            entries=s.get('records',s.get('documents',[]))
            if not entries:gaps.append('No reviewed records have been added.')
            if any(x.get('review',{}).get('status')!='approved' or not x.get('review',{}).get('reviewer') for x in entries):gaps.append('Named human review is pending for one or more records.')
        if kind=='workflow' and any(step['action']=='evaluate' for step in s.get('steps',[])):
            if not s.get('agents'):gaps.append('An evaluation workflow needs a released agent.')
            for d in deps:
                if d['active']!=d['version'] or not d['enabled']:gaps.append('Workflow dependency '+d['spec']['name']+' is not released.')
        if kind=='experiment':gaps.extend(['Training checkpoint unavailable: installed models are inference GGUFs.','No isolated fine-tuning runtime with approved compute is configured.','No weight-training job has run.'])
        result={'schema_valid':not errors,'errors':errors,'gaps':gaps,'passed':not errors,'release_ready':not errors and not gaps,'training_performed':False}
        if persist:
            with self.connect() as c:
                c.execute('INSERT INTO lab_checks VALUES(?,?,?,?,?,?,?,?)',(ident(),oid,item['version'],item['hash'],'validation',int(not errors),dump(result),time.time()));self.audit(c,uid,'validated',oid,item['version'],result)
        return result
    def action(self,uid,data):
        self.admin(uid);oid=data.get('id');action=data.get('action');item=self.get(uid,oid,data.get('version'))
        if action=='duplicate':
            spec=copy.deepcopy(item['spec']);spec['name']=text(data.get('name'),'New name',140);return self.save(uid,item['kind'],spec,route='duplicate')
        if action not in {'activate','rollback','disable','enable'}:raise ValueError('Choose activate, rollback, disable, enable or duplicate.')
        if action in {'activate','rollback','enable'}:
            if data.get('reviewed_hash')!=item['hash']:raise ValueError('Review the exact candidate hash before activation.')
            report=self.check(uid,oid,item['version'])
            if not report['release_ready']:raise ValueError('Release blocked: '+'; '.join(report['errors']+report['gaps']))
            required='evaluation' if item['kind'] in {'agent','subagent'} else 'test' if item['kind'] in {'mcp_tool','mcp_server','connection','workflow'} else 'validation'
            with self.connect() as c:
                check=c.execute('SELECT passed FROM lab_checks WHERE object_id=? AND version=? AND hash=? AND kind=? ORDER BY created DESC LIMIT 1',(oid,item['version'],item['hash'],required)).fetchone()
            if not check or not check[0]:raise ValueError('A passing '+required+' of this exact version is required.')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');current=self.get(uid,oid,c=c)
            if data.get('expected_version')!=current['latest']:raise ValueError('Definition changed. Review it again.')
            if action=='disable':c.execute('UPDATE lab_objects SET enabled=0,updated=? WHERE id=?',(time.time(),oid))
            else:c.execute('UPDATE lab_objects SET active=?,enabled=1,updated=? WHERE id=?',(item['version'],time.time(),oid))
            self.audit(c,uid,action,oid,item['version'],{'hash':item['hash'],'note':text(data.get('note'),'Release reason',1000)})
        return self.get(uid,oid)
    def pin(self,uid,item):
        pinned={};visiting=set()
        def add(v):
            key=v['id']+':'+str(v['version'])
            if v['id'] in visiting:raise ValueError('Circular references are not allowed.')
            if key in pinned:return
            if len(pinned)>100:raise ValueError('Too many dependencies.')
            visiting.add(v['id'])
            pinned[key]={k:v[k] for k in ['id','kind','owner','version','hash','spec','enabled','active']}
            for r in refs(v['spec']):add(self.get(uid,r['id'],r['version']))
            visiting.remove(v['id'])
        add(item);return pinned
    def submit(self,uid,kind,oid,version=None,inputs=None,request_id=None):
        self.admin(uid)
        if kind not in {'test','evaluation','agent','training','workflow','proposal'}:raise ValueError('Choose a supported job type.')
        inputs=safe(inputs or {});request_id=request_id or ident()
        if not isinstance(request_id,str) or not 8<=len(request_id)<=100:raise ValueError('Invalid request ID.')
        item=self.get(uid,oid,version);pin=self.pin(uid,item)
        allowed={'test':{'mcp_tool','mcp_server','connection','workflow'},'evaluation':{'agent','subagent'},'agent':{'agent','subagent'},'training':{'experiment'},'workflow':{'workflow'}}
        if kind not in allowed or item['kind'] not in allowed[kind]:raise ValueError('Job type does not match this capability.')
        if kind=='agent':
            validate_data(inputs,item['spec']['input_schema'])
            if inputs.get('delegate_id'):
                allowed_children=item['spec'].get('allowed_delegates',[])
                if allowed_children and inputs['delegate_id'] not in allowed_children:raise ValueError('Child is not on this parent’s delegation allowlist.')
                child=self.get(uid,inputs['delegate_id']);parent=child['spec'].get('parent',{})
                if child['kind']!='subagent' or parent!={'id':item['id'],'version':item['version']}:raise ValueError('Child must pin this exact parent version.')
                if child['active']!=child['version'] or not child['enabled']:raise ValueError('Release this subagent before delegation.')
                self.verify_references(uid,'subagent',child['spec'],child['id']);pin.update(self.pin(uid,child))
        if kind in {'agent','workflow'} and (not item['enabled'] or item['active']!=item['version']):raise ValueError('Activate the reviewed version before running it.')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');old=c.execute('SELECT * FROM lab_runs WHERE actor=? AND request_id=?',(uid,request_id)).fetchone()
            if old:
                if (old['object_id'],old['version'],old['kind'],old['input'])!=(oid,item['version'],kind,dump(inputs)):raise ValueError('Request ID already used for different inputs.')
                return self.run(uid,old['id'],c)
            if c.execute("SELECT count(*) FROM lab_runs WHERE actor=? AND state IN ('queued','running')",(uid,)).fetchone()[0]>=8:raise ValueError('Lab queue is full.')
            rid=ident();now=time.time();c.execute('INSERT INTO lab_runs(id,actor,kind,object_id,version,state,pinned,input,created,updated,request_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(rid,uid,kind,oid,item['version'],'queued',dump(pin),dump(inputs),now,now,request_id));self.audit(c,uid,'job_queued',oid,item['version'],{'run_id':rid,'kind':kind,'pinned_hash':digest(pin)})
        return self.run(uid,rid)
    def run(self,uid,rid,c=None):
        self.admin(uid)
        if c is None:
            with self.connect() as conn:return self.run(uid,rid,conn)
        row=c.execute('SELECT * FROM lab_runs WHERE id=? AND actor=?',(rid,uid)).fetchone()
        if not row:raise KeyError('Run not found in this account.')
        d=dict(row);d['pinned']=json.loads(d['pinned']);d['input']=json.loads(d['input']);d['result']=json.loads(d['result']);d['events']=[dict(x) for x in c.execute('SELECT event,created FROM lab_events WHERE run_id=? ORDER BY id',(rid,))];return d
    def cancel(self,uid,rid):
        self.run(uid,rid)
        with self.connect() as c:
            c.execute("UPDATE lab_runs SET state='cancelled',updated=?,finished=? WHERE id=? AND state IN ('queued','running')",(time.time(),time.time(),rid));self.audit(c,uid,'job_cancelled',detail={'run_id':rid})
        return self.run(uid,rid)
    def event(self,rid,message):
        with self.connect() as c:c.execute('INSERT INTO lab_events(run_id,event,created) VALUES(?,?,?)',(rid,str(message)[:1200],time.time()))
    def overview(self,uid):
        self.admin(uid);objects=self.list(uid)
        with self.connect() as c:
            runs=[dict(r) for r in c.execute('SELECT id,kind,object_id,version,state,error,created,updated FROM lab_runs WHERE actor=? ORDER BY created DESC LIMIT 100',(uid,))]
            audit=[dict(r) for r in c.execute('SELECT * FROM lab_audit WHERE actor IN (0,?) ORDER BY created DESC LIMIT 150',(uid,))]
            heartbeat=c.execute('SELECT updated FROM lab_heartbeat WHERE id=1').fetchone()
        return {'objects':objects,'runs':runs,'audit':audit,'worker_ready':bool(heartbeat and time.time()-heartbeat[0]<30),'training_performed':False,'weights_changed':False,'default_provider':'synergy','default_family':'eternal','default_delegation':'sequential','coverage':self.coverage(uid,objects),'limits':{'concurrent_jobs':1,'delegation_depth':3,'generated_code_execution':False}}
    def coverage(self,uid,objects=None):
        objects=objects or self.list(uid);out=[]
        with self.connect() as c:checks=[dict(x) for x in c.execute('SELECT * FROM lab_checks ORDER BY created DESC')]
        for s in [x for x in objects if x['kind']=='skill']:
            agents=[a for a in objects if a['kind'] in {'agent','subagent'} and any(r['id']==s['id'] for r in a['spec'].get('skills',[]))]
            knowledge_ids={r['id'] for a in [s]+agents for r in a['spec'].get('knowledge',[])}
            tool_ids={r['id'] for a in [s]+agents for r in a['spec'].get('tools',[])}
            knowledge=[o for o in objects if o['id'] in knowledge_ids];tools=[o for o in objects if o['id'] in tool_ids]
            datasets=[o for o in objects if o['kind']=='dataset' and s['spec'].get('package_id') in o['spec'].get('capabilities',[])]
            tool_checks=[x for x in checks if x['object_id'] in tool_ids and x['kind']=='test']
            ev=[x for x in checks if any(a['id']==x['object_id'] and a['version']==x['version'] for a in agents) and x['kind']=='evaluation']
            for e in ev:e['result']=json.loads(e['result']) if isinstance(e['result'],str) else e['result']
            ready_knowledge=bool(knowledge) and all(o['active']==o['version'] and o['enabled'] for o in knowledge)
            ready_tools=bool(tools) and all(any(x['object_id']==o['id'] and x['version']==o['version'] and x['passed'] for x in tool_checks) for o in tools)
            reviewed=bool(datasets) and all(o['active']==o['version'] for o in datasets)
            out.append({'id':s['id'],'name':s['spec']['name'],'package_version':s['spec'].get('package_version'),'assigned_agents':[{'id':a['id'],'name':a['spec']['name']} for a in agents],'instructions_installed':True,'knowledge_connected':ready_knowledge,'knowledge_coverage':[{'name':o['spec']['name'],'version':o['version'],'documents':len(o['spec'].get('documents',[])),'active':o['active']} for o in knowledge],'tools_configured':bool(tools),'available_tools':[{'id':o['id'],'name':o['spec']['name'],'version':o['version'],'active':o['active']} for o in tools],'tools_connection_tested':ready_tools,'dataset_reviewed':reviewed,'dataset_version':[{'id':o['id'],'version':o['version'],'label':o['spec'].get('version_label')} for o in datasets] or None,'training_run_completed':False,'candidate_evaluated':bool(ev),'production_version':s['active'],'production_ready':bool(s['active'] and s['spec'].get('review',{}).get('status')=='approved' and ev and all(e['passed'] for e in ev)),'evaluation_results':ev,'known_gaps':s['spec'].get('notes',[]),'gap_categories':{'knowledge':not ready_knowledge,'integrations':not ready_tools,'training':'not_run','failed_evaluations':sum(not e['passed'] for e in ev),'runtime':'No fine-tuning worker or GPU configured.'},'subject_coverage':s['spec'].get('subject_coverage',[])})
        return sorted(out,key=lambda x:x['id'])
    def create_server_project(self,uid,name):
        self.admin(uid)
        if not self.beast:raise ValueError('Private code workspace is unavailable.')
        from .scaffold import files
        from .templates import example
        project=self.beast.create(uid,{'name':text(name,'Server project name',80),'brief':'Draft MCP server. No code executes until explicitly reviewed and run in an isolated environment.','files':files()})
        spec=example('mcp_server');spec.update(name=name,purpose='Editable MCP server source; pending review and isolated connector packaging.',code_project=project['id'])
        obj=self.save(uid,'mcp_server',spec,route='server_project')
        return {'capability':obj,'project_id':project['id'],'revision':project['revision'],'execution':'not_started'}
