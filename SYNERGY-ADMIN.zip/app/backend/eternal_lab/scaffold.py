"""A harmless, editable stdio MCP example. Creation never starts this server."""
SERVER='''"""Bounded stdio example. The host must provide authentication and permissions."""
import json,sys
TOOL={"name":"echo_text","description":"Return supplied text; no network or file access.","inputSchema":{"type":"object","properties":{"text":{"type":"string","maxLength":2000}},"required":["text"],"additionalProperties":False},"annotations":{"readOnlyHint":True,"destructiveHint":False,"openWorldHint":False}}
def handle(m):
 method=m.get("method");params=m.get("params",{})
 if method=="initialize":return {"protocolVersion":"2025-11-25","capabilities":{"tools":{}},"serverInfo":{"name":"synergy-draft","version":"0.1.0"}}
 if method=="tools/list":return {"tools":[TOOL]}
 if method=="tools/call":
  a=params.get("arguments",{})
  if params.get("name")!="echo_text" or set(a)!={"text"} or not isinstance(a["text"],str) or len(a["text"])>2000:raise ValueError("Invalid bounded tool input")
  return {"content":[{"type":"text","text":a["text"]}],"structuredContent":{"text":a["text"]},"isError":False}
 if method=="ping":return {}
 raise ValueError("Unsupported method")
for line in sys.stdin:
 if len(line)>16000:raise SystemExit("Input limit exceeded")
 try:
  m=json.loads(line)
  if "id" not in m:continue
  try:reply={"jsonrpc":"2.0","id":m["id"],"result":handle(m)}
  except (ValueError,TypeError):reply={"jsonrpc":"2.0","id":m["id"],"error":{"code":-32602,"message":"Invalid method or input"}}
  print(json.dumps(reply),flush=True)
 except json.JSONDecodeError:print(json.dumps({"jsonrpc":"2.0","id":None,"error":{"code":-32700,"message":"Invalid JSON"}}),flush=True)
'''
TEST='''import json,subprocess,sys,unittest
class ToolTests(unittest.TestCase):
 def test_echo(self):
  req={"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"echo_text","arguments":{"text":"fixture"}}}
  r=subprocess.run([sys.executable,"server.py"],input=json.dumps(req)+"\\n",text=True,capture_output=True,timeout=3)
  self.assertEqual(json.loads(r.stdout)["result"]["structuredContent"],{"text":"fixture"})
if __name__=="__main__":unittest.main()
'''
def files():return {'server.py':SERVER,'test_server.py':TEST,'README.md':'# Draft SYnerGY MCP server\n\nPython 3.10+. Run `python test_server.py` in an authorised isolated environment, then `python server.py` for stdio. The host is responsible for authentication, owner scope, timeouts and output limits. This example has only a harmless echo handler. Creation does not install it into production. Review code, test the intended tools, package an isolated connector and release through Eternal Lab. Never put credentials in source.\n'}
