"""Bounded, fail-closed configuration validation. No generated code execution."""
import copy,hashlib,json,math,os,re
from urllib.parse import urlsplit

KINDS={'skill','agent','subagent','mcp_server','mcp_tool','connection','workflow','knowledge','dataset','evaluation','experiment','model','policy'}
SECRET=re.compile(r'(?:sk-[A-Za-z0-9_-]{16,}|AKIA[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|Bearer\s+[A-Za-z0-9_.-]{12,}|(?:password|api_key|access_token|client_secret)\s*[=:]\s*["\']?[^\s,;"\']{8,})',re.I)
def dump(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(x):return hashlib.sha256(dump(x).encode()).hexdigest()
def safe(value):
    raw=dump(value)
    if len(raw.encode())>600000:raise ValueError('Configuration exceeds 600 KB. Split the collection.')
    if any(len(v)>=8 and v in raw for k,v in os.environ.items() if k.startswith('SYNERGY_LAB_') or k=='OPENAI_API_KEY'):raise ValueError('A configured secret was detected. Use its reference instead.')
    if SECRET.search(raw):raise ValueError('Potential secret detected. Use a configured secret reference; do not paste credentials.')
    def walk(v,depth=0):
        if depth>16:raise ValueError('Configuration nesting is too deep.')
        if isinstance(v,dict):
            for k,x in v.items():
                if str(k).lower() in {'password','api_key','access_token','secret_value','authorization','cookie'} and x:raise ValueError('Literal credentials are not accepted.')
                walk(x,depth+1)
        elif isinstance(v,list):
            if len(v)>500:raise ValueError('Use at most 500 items per collection.')
            for x in v:walk(x,depth+1)
    walk(value);return value
def text(value,label,maximum=6000,empty=False):
    if not isinstance(value,str) or not (0 if empty else 1)<=len(value.strip())<=maximum:raise ValueError(label+' is missing or too long.')
    return value.strip()
def integer(v,label,low,high):
    if type(v) is not int or not low<=v<=high:raise ValueError(label+' is outside its allowed range.')
    return v
def schema(spec,depth=0):
    if depth>8 or not isinstance(spec,dict):raise ValueError('Use a bounded JSON Schema object.')
    if set(spec)-{'type','description','title','properties','required','additionalProperties','items','enum','minimum','maximum','minLength','maxLength','minItems','maxItems'}:raise ValueError('Unsupported schema keyword; this runtime supports the documented bounded schema subset.')
    kind=spec.get('type')
    if kind not in {'object','array','string','integer','number','boolean','null'}:raise ValueError('Specify a supported schema type.')
    if kind=='object':
        if spec.get('additionalProperties') is not False:raise ValueError('Object schemas must set additionalProperties:false.')
        props=spec.get('properties',{});required=spec.get('required',[])
        if not isinstance(props,dict) or len(props)>40 or not isinstance(required,list) or not all(isinstance(k,str) and k in props for k in required):raise ValueError('Invalid schema properties or required fields.')
        for s in props.values():schema(s,depth+1)
    if kind=='array':schema(spec.get('items'),depth+1);integer(spec.get('maxItems',50),'Array limit',0,100)
    if kind=='string':integer(spec.get('maxLength',12000),'Text limit',0,64000)
    return spec
def validate_data(v,s,path='input'):
    kind=s['type'];types={'object':dict,'array':list,'string':str,'integer':int,'number':(int,float),'boolean':bool,'null':type(None)}
    if not isinstance(v,types[kind]) or kind in {'integer','number'} and isinstance(v,bool):raise ValueError(path+' has the wrong type.')
    if 'enum' in s and v not in s['enum']:raise ValueError(path+' is outside the allowed choices.')
    if kind=='object':
        props=s.get('properties',{})
        if set(v)-set(props) or set(s.get('required',[]))-set(v):raise ValueError(path+' has missing or unknown fields.')
        for k,x in v.items():validate_data(x,props[k],path+'.'+k)
    elif kind=='array':
        if not s.get('minItems',0)<=len(v)<=s.get('maxItems',50):raise ValueError(path+' has too many/few items.')
        for x in v:validate_data(x,s['items'],path+'[]')
    elif kind=='string':
        if not s.get('minLength',0)<=len(v)<=s.get('maxLength',12000):raise ValueError(path+' length is outside the limit.')
    elif kind in {'integer','number'}:
        if not math.isfinite(v) or not s.get('minimum',-1e12)<=v<=s.get('maximum',1e12):raise ValueError(path+' is outside its numeric limit.')
def reference(v):
    if not isinstance(v,dict) or set(v)!={'id','version'} or not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}',str(v.get('id',''))):raise ValueError('References must pin an object ID and version.')
    integer(v['version'],'Version',1,100000);return v
def refs(spec):
    out=[]
    for key in ['skills','knowledge','tools','connections','agents']:
        for v in spec.get(key,[]):out.append(reference(v))
    for key in ['parent','evaluation','dataset','base_model','server','connection','heldout_evaluation']:
        if spec.get(key):out.append(reference(spec[key]))
    return out
def normalise(kind,spec):
    if kind not in KINDS or not isinstance(spec,dict):raise ValueError('Choose a supported capability type and JSON configuration.')
    s=copy.deepcopy(safe(spec));text(s.get('name'),'Name',140);text(s.get('purpose'),'Purpose',4000);refs(s)
    common={'name','purpose','notes','scope','review','subject_coverage'}
    fields={
      'agent':{'model','instructions','skills','knowledge','tools','scope','parent','delegation','input_schema','output_schema','limits','evaluation','failure','escalation','allowed_delegates','allow_model_fallback'},
      'subagent':{'model','instructions','skills','knowledge','tools','scope','parent','delegation','input_schema','output_schema','limits','evaluation','failure','escalation','allowed_delegates','allow_model_fallback'},
      'mcp_tool':{'tool_name','input_schema','output_schema','handler','server','upstream_tool','connection','effect','timeout_s','output_bytes','retries','idempotency','test_input','test_assert','code_project'},
      'mcp_server':{'transport','upstream','endpoint','connection','protocol','code_project','instructions'},
      'connection':{'kind','endpoint','documentation','secret_ref','authorised','allowed_operations','timeout_s'},
      'knowledge':{'documents','freshness_days','jurisdiction','source_version'},
      'dataset':{'records','capabilities','version_label'},
      'evaluation':{'tasks','capabilities','human_rubric','pass_threshold','comparison_kind'},
      'experiment':{'dataset','base_model','method','seed','epochs','learning_rate','approved_budget_usd','runtime','heldout_evaluation','reviewed_config_hash'},
      'workflow':{'steps','agents','trigger','timezone','schedule','enabled_schedule','knowledge','tools','limits'},
      'skill':{'package_id','package_version','scope_notes','objectives','prerequisites','sources','retrieval','procedures','examples','mistakes','evaluations','formats','criteria','permissions','history','reviewer','tools','knowledge'},
      'model':{'provider','actual_model','checkpoint','license','modalities','context_limit','hardware','training_compatibility','provenance','deployment','evaluation_results'},
      'policy':{'external_enabled','allowed_models','assistance_budget_usd','request_tokens','max_retries','release_policy','training_schedule','stopped'}
    }
    if set(s)-common-fields[kind]:raise ValueError('Unknown configuration field: '+', '.join(sorted(set(s)-common-fields[kind])))
    s.setdefault('scope',{'kind':'private','projects':[]})
    if not isinstance(s['scope'],dict) or set(s['scope'])!={'kind','projects'} or s['scope']['kind'] not in {'private','shared'} or not isinstance(s['scope']['projects'],list) or len(s['scope']['projects'])>20:raise ValueError('Use an explicit private/shared scope and owned project identifiers.')
    if kind in {'agent','subagent'}:
        text(s.get('instructions'),'Instructions',16000);m=s.get('model',{})
        if set(m)!={'family','provider','choice'} or m['family'] not in {'eternal','aerny'} or m['provider'] not in {'synergy','openai','hybrid'} or m['choice'] not in {'auto','fast','balanced','vision'}:raise ValueError('Choose a connected SYnerGY family and provider.')
        schema(s.get('input_schema'));schema(s.get('output_schema'));limits=s.get('limits',{})
        if set(limits)!={'seconds','tokens','usd','steps'}:raise ValueError('Set seconds, tokens, USD and step limits.')
        integer(limits['seconds'],'Seconds',1,600);integer(limits['tokens'],'Tokens',16,8192);integer(limits['steps'],'Steps',1,16)
        if type(limits['usd']) not in {float,int} or not 0<=limits['usd']<=2:raise ValueError('Agent spending limit must be $0..$2.')
        d=s.get('delegation',{})
        if set(d)!={'depth','concurrent_children','strategy'} or d['strategy'] not in {'sequential','parallel'}:raise ValueError('Set bounded delegation controls.')
        integer(d['depth'],'Delegation depth',0,3);integer(d['concurrent_children'],'Child limit',1,3)
        if d['strategy']=='sequential' and d['concurrent_children']!=1:raise ValueError('Sequential delegation uses one child at a time.')
        if kind=='subagent' and not s.get('parent'):raise ValueError('A subagent requires a pinned parent.')
        if type(s.get('allow_model_fallback',True)) is not bool:raise ValueError('Set allow_model_fallback to true or false.')
        children=s.get('allowed_delegates',[])
        if not isinstance(children,list) or len(children)>20 or any(not isinstance(x,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}',x) for x in children):raise ValueError('Use a bounded child-agent allowlist.')
        text(s.get('failure'),'Failure behaviour',1500);text(s.get('escalation'),'Escalation',1500)
    elif kind=='mcp_tool':
        if not re.fullmatch(r'[a-z][a-z0-9_]{2,63}',str(s.get('tool_name',''))):raise ValueError('Use a unique lowercase tool_name.')
        schema(s.get('input_schema'));schema(s.get('output_schema'))
        if s.get('handler') not in {'draft','specialist','knowledge_search','rest_json_get'}:raise ValueError('Use a supported handler or keep the tool draft.')
        if s.get('effect') not in {'read','internal_write','external_write'}:raise ValueError('Classify the side effect.')
        integer(s.get('timeout_s'),'Tool timeout',1,40);integer(s.get('output_bytes'),'Output bytes',1024,1048576);integer(s.get('retries',0),'Retries',0,2)
        if s.get('effect')!='read' and (s.get('retries',0) or s.get('idempotency')!='request_id'):raise ValueError('Writes require request-id idempotency and no automatic retries.')
        if s['handler']=='specialist':
            if not s.get('server') or not s.get('upstream_tool'):raise ValueError('Pin the real upstream server and tool.')
        if s['handler']=='rest_json_get' and (not s.get('connection') or s['effect']!='read'):raise ValueError('Pin an authorised read-only connection.')
    elif kind=='mcp_server':
        if s.get('transport') not in {'stdio','project'}:raise ValueError('Use a bundled stdio connector or a draft server project.')
        if s['transport']=='stdio' and s.get('upstream') not in {'vedics','foundr'}:raise ValueError('Only the installed VEDICS/FOUNDR stdio adapters can execute in this release.')
    elif kind=='connection':
        if s.get('kind') not in {'public_json','authenticated_json','mcp'}:raise ValueError('Choose a supported connection kind.')
        u=urlsplit(text(s.get('endpoint'),'Endpoint',1500))
        if u.scheme!='https' or not u.hostname or u.username or u.password or u.query or u.fragment:raise ValueError('Use a public HTTPS endpoint without credentials/query parameters.')
        if s.get('secret_ref') and not re.fullmatch(r'env:SYNERGY_LAB_[A-Z0-9_]{1,80}',s['secret_ref']):raise ValueError('Use an env:SYNERGY_LAB_… secret reference provisioned in server settings.')
        if s.get('allowed_operations')!=['GET']:raise ValueError('This release supports documented read-only GET connections. Writes remain draft.')
        if s.get('authorised') is not True:raise ValueError('Confirm authority to connect this API.')
    elif kind=='knowledge':
        integer(s.get('freshness_days',30),'Freshness days',0,3650)
        for doc in s.get('documents',[]):
            for k in ['id','title','text','source','publisher','retrieved','rights','owner']:text(doc.get(k),'Knowledge '+k,64000 if k=='text' else 1500)
            if doc['rights'] not in {'owned','public_domain','licensed','permissioned'}:raise ValueError('Record suitable source usage rights.')
            if doc.get('client_private') and s['scope']['kind']=='shared':raise ValueError('Client-private knowledge cannot enter a shared collection.')
    elif kind=='dataset':
        records=s.get('records',[])
        if not isinstance(records,list) or len(records)>500:raise ValueError('Use up to 500 reviewed candidate records.')
        hashes=set();families={};texts=[]
        for r in records:
            for k in ['id','capability','input','expected','source','rights','family','split','verification']:text(r.get(k),'Dataset '+k,16000)
            if r['rights'] not in {'owned','public_domain','licensed','permissioned'} or r['split'] not in {'train','validation','test'}:raise ValueError('Dataset rights or split is invalid.')
            if r.get('origin')=='openai' or r.get('private_client'):raise ValueError('External model outputs and private client material are excluded from weight-training datasets.')
            h=hashlib.sha256(re.sub(r'\W','',r['input'].casefold()).encode()).hexdigest()
            if h in hashes:raise ValueError('Duplicate dataset input. Remove duplicates before saving.')
            hashes.add(h)
            from difflib import SequenceMatcher
            words=re.sub(r'\s+',' ',r['input'].strip().casefold())
            if any(SequenceMatcher(None,words,t).ratio()>.90 for t in texts):raise ValueError('Near-duplicate dataset input. Review deduplication and held-out contamination.')
            texts.append(words)
            if r['family'] in families and families[r['family']]!=r['split']:raise ValueError('Task/source family leaks across dataset splits.')
            families[r['family']]=r['split']
    elif kind=='evaluation':
        if not isinstance(s.get('tasks'),list) or not 1<=len(s['tasks'])<=30:raise ValueError('An evaluation needs 1–30 representative tasks.')
        for task in s['tasks']:
            text(task.get('prompt'),'Evaluation prompt',3000)
            if task.get('check') not in {'exact','contains','tool_answer','json','human','blocked'}:raise ValueError('Choose a supported evaluation check.')
        if not 0<float(s.get('pass_threshold',1))<=1:raise ValueError('Pass threshold must be above zero and at most one.')
    elif kind=='experiment':
        if s.get('method') not in {'lora','qlora','sft'}:raise ValueError('Choose an explicitly planned training method.')
        integer(s.get('seed',42),'Seed',0,2147483647);integer(s.get('epochs',1),'Epochs',1,10)
        if not 0<=float(s.get('approved_budget_usd',0))<=2:raise ValueError('A separately approved training budget is required above $2.')
    elif kind=='workflow':
        if s.get('trigger','manual') not in {'manual','daily'} or s.get('timezone','Asia/Kolkata')!='Asia/Kolkata':raise ValueError('Use a manual/daily trigger in Asia/Kolkata in this release.')
        if s.get('enabled_schedule') and s.get('trigger')!='daily':raise ValueError('Only daily workflows have a schedule.')
        if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',s.get('schedule','09:00')):raise ValueError('Use a valid 24-hour HH:MM schedule.')
        if not isinstance(s.get('steps'),list) or not 1<=len(s['steps'])<=12:raise ValueError('Use 1–12 bounded workflow steps.')
        for step in s['steps']:
            if step.get('action') not in {'evaluate','refresh_review','dataset_review'}:raise ValueError('Only evaluations and review reminders may be scheduled; training remains manual.')
    elif kind=='policy':
        if s.get('external_enabled') or float(s.get('assistance_budget_usd',0))!=0:raise ValueError('External Lab spending is unavailable in this release. Keep the separate Lab budget at $0.')
        if s.get('training_schedule'):raise ValueError('Automatic weight training is disabled.')
        if s.get('release_policy')!='explicit_admin_review':raise ValueError('Exact-version administrator release review is required.')
    elif kind=='skill':
        for field in ['scope_notes','reviewer','package_id','package_version']:text(s.get(field),field,4000)
        if not re.fullmatch(r'\d+\.\d+\.\d+',s['package_version']):raise ValueError('Use a semantic package version such as 1.0.0.')
        for level in ['beginner','intermediate','advanced']:
            if not s.get('objectives',{}).get(level):raise ValueError('Add learning objectives for '+level+'.')
        for field in ['prerequisites','sources','procedures','examples','mistakes','evaluations','formats','criteria','permissions','history']:
            if not isinstance(s.get(field),list) or not s[field]:raise ValueError('Skill package requires meaningful '+field+'.')
    return s
