"""One offline diffusion process per host data directory, including legacy studios."""
import contextlib,fcntl,json,os,time
from pathlib import Path
@contextlib.contextmanager
def inference_slot(folder):
    data=os.environ.get('SYNERGY_DATA_DIR')
    if not data:
        yield;return
    path=Path(data)/'inference.lock';path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a') as lock:
        while True:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
            except BlockingIOError:
                target=Path(folder)/'progress.json';tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps({'stage':'Waiting for local inference compute','step':0,'total':0,'progress':0}));tmp.replace(target);time.sleep(.5)
        try:yield
        finally:fcntl.flock(lock,fcntl.LOCK_UN)
