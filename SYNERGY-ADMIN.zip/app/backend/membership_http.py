import csv,io,re,os
from membership import AccessRequired
class MembershipHTTP:
 def openai_status(self):
  import openai_budget,model_router
  _,model,enabled=model_router.external_config()
  return {'enabled':enabled,'model':model if enabled else None,'allowance':openai_budget.status() if enabled else None}
 def member_get(self,path,user):
  if path.startswith('/api/admin/lab'):return self.lab_get(path,user)
  if path=='/api/admin/source' or path.startswith('/api/admin/source/'):return self.source_get(path,user)
  m=self.membership;uid=user['id']
  try:
   if path=='/api/account':return self.response(200,{**m.entitlement(uid),'payments':m.orders(uid)})
   if path=='/api/admin/dashboard':
    m.admin(uid)
    from deployment_policy import status
    import free_router
    return self.response(200,{**m.dashboard(uid),'transfers':self.project_transfers.list(uid),'openai_usage':self.openai_status(),'hybrid_routing':free_router.status(),'deployment':status()})
   if path=='/api/admin/transfers':return self.response(200,{'transfers':self.project_transfers.list(uid)})
   hit=re.fullmatch(r'/api/admin/tickets/(SYN-[A-Z0-9-]+)',path)
   if hit:
    m.admin(uid)
    with m.connect() as c:r=c.execute('SELECT user_id FROM support_tickets WHERE id=?',(hit[1],)).fetchone()
    if not r:raise KeyError('Ticket not found.')
    return self.response(200,self.support.get(r[0],hit[1]))
   if path=='/api/admin/payments.csv':
    d=m.dashboard(uid);out=io.StringIO();w=csv.writer(out);keys=['id','email','plan_id','amount_paise','currency','state','utr','transaction_id','submitted','paid_at','verified','review_note'];w.writerow(keys)
    for p in d['payments']:w.writerow([("'"+str(p.get(k,''))) if str(p.get(k,'')).startswith(('=','+','-','@','\t','\r')) else p.get(k,'') for k in keys])
    return self.research_download(out.getvalue().encode('utf-8-sig'),'synergy-payments.csv')
   return self.fail(404,'Not found.')
  except PermissionError as e:return self.fail(403,str(e))
  except KeyError:return self.fail(404,'Item not found.')
 def member_post(self,path,d,user):
  if path.startswith('/api/admin/lab'):return self.lab_post(path,d,user)
  if path.startswith('/api/admin/source/'):return self.source_post(path,d,user)
  m=self.membership;uid=user['id']
  try:
   if path=='/api/account/profile':result=m.update_profile(uid,d)
   elif path=='/api/account/recovery-key':result=m.recovery_key(uid,d.get('password'))
   elif path=='/api/billing/checkout':result=m.checkout(uid,d)
   elif path=='/api/billing/submit':result=m.submit_payment(uid,d)
   elif path=='/api/admin/transfers/review':result=self.project_transfers.review(uid,d)
   elif path=='/api/admin/openai-limit':
    m.admin(uid)
    import openai_budget
    result=openai_budget.configure(d.get('total_budget_usd'),d.get('usage_percent'),uid,d.get('note',''),d.get('revision'))
   elif path=='/api/admin/payment':result=m.review_payment(uid,d)
   elif path=='/api/admin/account':result=m.account_action(uid,d)
   elif path=='/api/admin/subscription':result=m.subscription_action(uid,d)
   elif path=='/api/admin/subscription-exception':result=m.exception_action(uid,d)
   elif path=='/api/admin/reconcile/preview':result=m.reconcile_preview(uid,d.get('csv'))
   elif path=='/api/admin/reconcile/apply':result=m.reconcile_apply(uid,d.get('id'))
   elif path=='/api/admin/ticket':
    m.admin(uid);status=d.get('status');note=d.get('note','')
    if status not in {'needs_information','blocked','needs_validation','closed','cancelled'} or not isinstance(note,str) or not note.strip() or len(note)>4000:raise ValueError('Choose a ticket status and write a clear update.')
    if status=='closed' and d.get('verified') is not True:raise ValueError('Confirm that the fix was verified before closing this ticket.')
    with m.connect() as c:r=c.execute('SELECT user_id FROM support_tickets WHERE id=?',(d.get('id'),)).fetchone()
    if not r:raise KeyError()
    t=self.support.get(r[0],d['id'])
    if t['revision']!=d.get('revision'):raise ValueError('The ticket changed; reopen it before updating.')
    if t.get('job_id') and t.get('job',{}).get('state') in {'queued','running','awaiting_review'}:raise ValueError('Wait for or cancel the investigation before changing its status.')
    self.support.transition(t,status,'Administrator update: '+note)
    with m.connect() as c:m.audit(c,uid,'ticket_review',t['id'],{'status':status,'note':note})
    result=self.support.get(r[0],d['id'])
   else:return self.fail(404,'Not found.')
   return self.response(200,result)
  except AccessRequired as e:return self.fail(402,str(e))
  except PermissionError as e:return self.fail(403,str(e))
  except KeyError:return self.fail(404,'Item not found.')
  except (ValueError,TypeError) as e:return self.fail(400,str(e))
 def enforce_mode(self,path,d,user):
  mode='chat'
  if path.startswith('/api/beast/') and not (path.endswith('/action') and d.get('action')=='cancel'):mode='beast'
  elif path.startswith('/api/operations/') and d.get('action') not in {'cancel','pause'}:mode='work'
  elif path in {'/api/leads/scan','/api/extension/leads/scan'}:mode='work'
  elif path in {'/api/research/tasks','/api/chat','/api/extension/ask','/api/conversations'}:mode=d.get('mode','work' if path=='/api/extension/ask' else 'chat')
  self.membership.require(user['id'],mode)
  if d.get('provider') in {'openai','hybrid'}:self.membership.require_provider(user['id'],d['provider'],mode)
