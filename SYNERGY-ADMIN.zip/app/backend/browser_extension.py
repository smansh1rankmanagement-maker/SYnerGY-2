"""Narrow bearer-authenticated API for the owner's packaged Chrome extension."""
import hashlib,io,json,re,secrets,time,zipfile
from pathlib import Path
from research.routes import public_task
import model_router
from urllib.parse import urlsplit,parse_qs
from extension_work import ExtensionWork
from hosting import VERSION
from browser_bridge import BrowserBridge
EXTENSION_ID='fcaldehcmldbepekmdafhglcibnniacb'
EXTENSION_ORIGIN='chrome-extension://'+EXTENSION_ID
ALLOWED={'/api/extension/work','/api/extension/work/save','/api/extension/work/delete','/api/extension/work/calendar','/api/extension/work/publish','/api/extension/me','/api/extension/models','/api/extension/projects','/api/extension/history','/api/extension/ask','/api/extension/cancel','/api/extension/files','/api/extension/leads','/api/extension/leads/scan','/api/extension/leads/export.xlsx'}
def extension_path(path):
 return path in {'/api/extension/browser/connect','/api/extension/browser/claim','/api/extension/browser/control','/api/extension/browser/heartbeat','/api/extension/browser/complete'} or path in ALLOWED or bool(re.fullmatch(r'/api/extension/(?:conversations/[0-9a-f]{32}|task/[0-9a-f]{32}(?:/(?:report\.md|evidence\.json|output\.(?:pdf|png|svg|docx|txt)|video\.mp4|document\.md|pages\.zip))?)',path))
def extension_request(path,origin):return origin==EXTENSION_ORIGIN and extension_path(path)
def extension_bearer_request(path,origin,authorization):
 # Chrome's privileged extension GET requests can omit Origin. The scoped bearer
 # authenticates these requests; an explicitly foreign Origin is still rejected.
 return origin in {None,EXTENSION_ORIGIN} and extension_path(path) and bool(re.fullmatch(r'Bearer sgx_[A-Za-z0-9_-]{40,80}',authorization or ''))
class BrowserExtension:
 def __init__(self,ws):
  self.ws=ws;self.work=ExtensionWork(ws);self.bridge=BrowserBridge(ws)
  with ws.connect() as c:c.execute('CREATE TABLE IF NOT EXISTS extension_tokens(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL,created REAL NOT NULL,expires REAL NOT NULL,last_used REAL)')
 def pair(self,uid):
  token='sgx_'+secrets.token_urlsafe(32);now=time.time()
  with self.ws.connect() as c:
   c.execute('DELETE FROM extension_tokens WHERE user_id=?',(uid,))
   c.execute('INSERT INTO extension_tokens VALUES(?,?,?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),uid,now,now+30*86400,None))
  return {'token':token,'extension_id':EXTENSION_ID,'expires_in_days':30,'scope':'Chat, project selection, lead capture and lead exports. No AWS or runtime-plugin administration.'}
 def user(self,header):
  if not isinstance(header,str) or not re.fullmatch(r'Bearer sgx_[A-Za-z0-9_-]{40,80}',header):return None
  key=hashlib.sha256(header[7:].encode()).hexdigest()
  with self.ws.connect() as c:
   row=c.execute('SELECT u.id,u.username FROM users u JOIN extension_tokens t ON u.id=t.user_id WHERE t.token_hash=? AND t.expires>?',(key,time.time())).fetchone()
   if row:c.execute('UPDATE extension_tokens SET last_used=? WHERE token_hash=?',(time.time(),key))
   return row
 def revoke(self,uid):
  with self.ws.connect() as c:c.execute('DELETE FROM extension_tokens WHERE user_id=?',(uid,))
class BrowserExtensionHTTP:
 def extension_get(self,path,user):
  uid=user['id']
  if path=='/api/extension/work':
   try:self.membership.require_extension_work(uid)
   except PermissionError as e:return self.fail(402,str(e))
   return self.response(200,{'items':self.browser_extension.work.rows(uid),'calendar':self.connections.status(uid,'google-calendar')})
  if path=='/api/extension/me':
   ent=self.membership.entitlement(uid)
   return self.response(200,{'username':user['username'],'account_id':uid,'email':ent['profile']['email'],'plan':ent['plan'],'version':VERSION,'aerny':'2.0','eternal':'1.0','extension_version':json.loads((Path(__file__).resolve().parents[1]/'extension'/'manifest.json').read_text())['version'],'membership':ent['access'],'chat_model':ent['chat_model'],'extension_work':ent['extension_work']})
  if path=='/api/extension/models':return self.response(200,{**self.membership.provider_catalog(uid,model_router.catalog(),parse_qs(urlsplit(self.path).query).get('mode',['chat'])[0]),'families':[{'id':'eternal','name':'ETERNAL'},{'id':'aerny','name':'Aerny 2.0'}],'response_levels':['low','medium','high','max','ultra'],'external_allowed':self.research.settings(uid)['allow_external']})
  if path=='/api/extension/status':
   root=Path(__file__).resolve().parents[1]/'extension';manifest=json.loads((root/'manifest.json').read_text())
   with self.workspace.connect() as c:paired=c.execute('SELECT created,expires,last_used FROM extension_tokens WHERE user_id=? ORDER BY created DESC LIMIT 1',(uid,)).fetchone()
   return self.response(200,{'version':manifest['version'],'extension_id':EXTENSION_ID,'download_url':'/api/extension/download','default_mode':'work','default_family':'eternal','pairing':dict(paired) if paired else None,'application_version':VERSION,'repair_policy':'Check connection, reconnect, or submit a repair ticket. Code fixes require review, testing and a versioned release. Reload unpacked extensions in Chrome.'})
  if path=='/api/extension/projects':return self.response(200,{'projects':self.workspace.projects(uid)})
  if path=='/api/extension/history':return self.response(200,{'conversations':self.workspace.chats(uid)})
  m=re.fullmatch(r'/api/extension/conversations/([0-9a-f]{32})',path)
  if m:
   try:return self.response(200,self.workspace.chat(uid,m[1]))
   except KeyError:return self.fail(404,'Conversation not found in this account.')
  if path in {'/api/extension/leads','/api/extension/leads/export.xlsx'}:
   try:self.membership.require_extension_work(uid)
   except PermissionError as e:return self.fail(403,str(e))
   return self.leads_get(path,user)
  if path=='/api/extension/download':
   if self.headers.get('Authorization'):return self.fail(403,'Open SYnerGY to download the extension.')
   root=Path(__file__).resolve().parents[1]/'extension';out=io.BytesIO()
   with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for name in ['manifest.json','background.js','panel.html','panel.js','access-policy.js','work.js','panel.css','icon.png','README.md','browser-control.js','browser-page.js','browser.html','browser-ui.js']:
     p=root/name
     if p.is_file():z.write(p,name)
   return self.research_download(out.getvalue(),'SYnerGY-Chrome-Extension.zip')
  m=re.fullmatch(r'/api/extension/task/([0-9a-f]{32})(/[^/]+)?',path)
  if m:
   if m[2]:return self.research_get('/api/research/tasks/'+m[1]+m[2],user)
   try:return self.response(200,public_task(self.research.task(uid,m[1])))
   except KeyError:return self.fail(404,'Task not found.')
  return self.fail(404,'Not found.')
 def extension_post(self,path,d,user):
  uid=user['id']
  if path.startswith('/api/extension/browser/'):
   try:
    op=path.rsplit('/',1)[-1]
    if op not in {'connect','prepare','claim','control','heartbeat','complete','plan','identify','record'}:raise ValueError('Unknown browser operation')
    if op in {'prepare','plan','identify','record'} and self.headers.get('Authorization'):raise PermissionError('Prepare actions from signed-in SYnerGY chat')
    if op in {'connect','claim','heartbeat','complete'} and not self.headers.get('Authorization'):raise PermissionError('Use the paired extension for device operations')
    if op=='record':
     cid=d.get('conversation_id');self.workspace.chat(uid,cid)
     self.workspace.add(uid,cid,'user',str(d.get('prompt',''))[:6000],{'private_tool_data':True})
     self.workspace.add(uid,cid,'assistant',str(d.get('summary',''))[:4000],{'private_tool_data':True,'browser_actions':True})
     return self.response(200,{'saved':True})
    d={**d,'_credential':hashlib.sha256(self.headers.get('Authorization','').encode()).hexdigest()}
    return self.response(200,getattr(self.browser_extension.bridge,op)(uid,d))
   except PermissionError as e:return self.fail(403,str(e))
   except (ValueError,TypeError,KeyError) as e:return self.fail(400,str(e))
  if path.startswith('/api/extension/work/'):
   try:
    self.membership.require_extension_work(uid);w=self.browser_extension.work
    if path.endswith('/save'):return self.response(200,w.save(uid,d))
    if path.endswith('/delete'):return self.response(200,w.delete(uid,d))
    if path.endswith('/calendar'):return self.response(200,w.calendar_link(uid,d.get('id')))
    if path.endswith('/publish'):return self.response(200,w.publish(uid,d.get('id'),d.get('revision'),self.connections))
   except KeyError:return self.fail(404,'Work item not found in this account.')
   except PermissionError as e:return self.fail(403,str(e))
   except (ValueError,TypeError) as e:return self.fail(400,str(e))
  if path in {'/api/extension/pair','/api/extension/revoke'}:
   if self.headers.get('Authorization'):return self.fail(403,'Manage pairing from the signed-in website.')
   if path.endswith('/pair'):return self.response(200,self.browser_extension.pair(uid))
   self.browser_extension.revoke(uid);return self.response(200,{'ok':True})
  if path in {'/api/extension/leads','/api/extension/leads/scan'}:
   try:self.membership.require_extension_work(uid)
   except PermissionError as e:return self.fail(403,str(e))
   return self.leads_post(path,d,user)
  if path in {'/api/extension/cancel','/api/extension/files'}:
   try:
    if path.endswith('/cancel'):return self.response(200,public_task(self.research.cancel(uid,d.get('id'))))
    return self.response(201,self.research.upload(uid,d.get('file'),d.get('name','')))
   except KeyError:return self.fail(404,'Item not found in this account.')
   except (ValueError,TypeError):return self.fail(400,'Choose a supported file or an active task.')
  if path=='/api/extension/ask':
   try:
    mode=d.get('mode','work');self.membership.require(uid,mode)
    prompt=d.get('prompt','');page=d.get('page','')
    if not isinstance(prompt,str) or not prompt.strip() or len(prompt)>6000 or not isinstance(page,str) or len(page)>3800:raise ValueError('Use a message under 6,000 characters and page context under 3,800.')
    if re.match(r'\s*(?:please\s+)?(?:install|/desktop|desktop commander)',prompt,re.I):raise ValueError('Install and manage runtime plugins from the signed-in SYnerGY website.')
    cid=d.get('conversation_id')
    if cid:self.workspace.chat(uid,cid)
    else:cid=self.workspace.create_chat(uid,project_id=d.get('project_id'),mode=mode)['id']
    r=self.research.submit(uid,{'conversation_id':cid,'prompt':prompt,'page_context':page,'file_id':d.get('file_id'),'mode':mode,'model_family':d.get('model_family','eternal'),'effort':'instant' if d.get('effort')=='low' else d.get('effort','medium'),'provider':d.get('provider','synergy'),'local_model':d.get('local_model','auto'),'openai_model':d.get('openai_model','auto'),'search_mode':d.get('search_mode','off' if page else 'auto'),'request_id':d.get('request_id'),'_extension_readonly':True})
    return self.response(202,{'conversation_id':cid,'task':public_task(r)})
   except KeyError:return self.fail(404,'Conversation or project not found.')
   except (ValueError,TypeError) as e:return self.fail(400,str(e))
  return self.fail(404,'Not found.')
