"""Additive project storage; never touches password or session records."""
import json,re,time,uuid
class Projects:
 def initialize_projects(self):
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE')
   c.execute('CREATE TABLE IF NOT EXISTS work_projects(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,name TEXT NOT NULL,instructions TEXT NOT NULL DEFAULT "",created REAL NOT NULL,updated REAL NOT NULL,archived INTEGER NOT NULL DEFAULT 0)')
   c.execute('CREATE TABLE IF NOT EXISTS work_project_files(project_id TEXT NOT NULL,file_id TEXT NOT NULL,PRIMARY KEY(project_id,file_id))')
   project_cols={r[1] for r in c.execute('PRAGMA table_info(work_projects)')}
   if 'beast_project_id' not in project_cols:c.execute('ALTER TABLE work_projects ADD COLUMN beast_project_id TEXT')
   if 'kind' not in project_cols:c.execute("ALTER TABLE work_projects ADD COLUMN kind TEXT NOT NULL DEFAULT 'general'")
   cols={r[1] for r in c.execute('PRAGMA table_info(conversations)')}
   if 'project_id' not in cols:c.execute('ALTER TABLE conversations ADD COLUMN project_id TEXT')
   if 'mode' not in cols:c.execute("ALTER TABLE conversations ADD COLUMN mode TEXT NOT NULL DEFAULT 'chat'")
   c.execute('CREATE INDEX IF NOT EXISTS conversations_project ON conversations(user_id,project_id,updated)')
 def projects(self,uid):
  with self.connect() as c:return [dict(r) for r in c.execute('SELECT p.*, (SELECT COUNT(*) FROM conversations c WHERE c.project_id=p.id AND c.user_id=p.user_id AND c.archived=0) AS chat_count FROM work_projects p WHERE p.user_id=? AND p.archived=0 ORDER BY p.updated DESC',(uid,))]
 def project(self,uid,pid):
  with self.connect() as c:
   p=c.execute('SELECT * FROM work_projects WHERE id=? AND user_id=? AND archived=0',(pid,uid)).fetchone()
   if not p:raise KeyError('Project not found.')
   chats=[dict(r) for r in c.execute('SELECT id,title,mode,updated,project_id FROM conversations WHERE user_id=? AND project_id=? AND archived=0 ORDER BY updated DESC',(uid,pid))]
   files=[dict(r) for r in c.execute('SELECT f.id,f.name,f.created FROM research_files f JOIN work_project_files pf ON f.id=pf.file_id WHERE pf.project_id=? AND f.user_id=? ORDER BY f.created DESC',(pid,uid))]
  return {**dict(p),'conversations':chats,'files':files}
 def save_project(self,uid,d):
  name=d.get('name','');instructions=d.get('instructions','')
  if not isinstance(name,str) or not 1<=len(name.strip())<=80:raise ValueError('Use a project name up to 80 characters.')
  if not isinstance(instructions,str) or len(instructions)>4000:raise ValueError('Keep project instructions under 4,000 characters.')
  kind=d.get('kind','general');source=d.get('beast_project_id')
  if kind not in {'general','website','app','research','creative'}:raise ValueError('Choose a project type.')
  now=time.time();pid=d.get('id')
  with self.connect() as c:
   if source and not c.execute('SELECT 1 FROM beast_projects WHERE id=? AND user_id=?',(source,uid)).fetchone():raise KeyError('Code workspace not found in this account.')
   if pid:
    from project_transfers import protected
    if protected(c,pid) and ('beast_project_id' in d and c.execute('SELECT beast_project_id FROM work_projects WHERE id=?',(pid,)).fetchone()[0]!=source):raise ValueError('The code link of an approved transfer is managed by the administrator.')
    if not c.execute('UPDATE work_projects SET name=?,instructions=?,updated=? WHERE id=? AND user_id=? AND archived=0',(name.strip(),instructions,now,pid,uid)).rowcount:raise KeyError('Project not found.')
   else:
    if c.execute('SELECT COUNT(*) FROM work_projects WHERE user_id=? AND archived=0',(uid,)).fetchone()[0]>=100:raise ValueError('Archive an unused project first (100 active projects per account).')
    pid=uuid.uuid4().hex;c.execute('INSERT INTO work_projects(id,user_id,name,instructions,created,updated) VALUES(?,?,?,?,?,?)',(pid,uid,name.strip(),instructions,now,now))
   c.execute('UPDATE work_projects SET kind=? WHERE id=? AND user_id=?',(kind,pid,uid))
   if 'beast_project_id' in d:c.execute('UPDATE work_projects SET beast_project_id=? WHERE id=? AND user_id=?',(source or None,pid,uid))
  return self.project(uid,pid)
 def move_chat(self,uid,cid,pid):
  current=self.chat(uid,cid)
  from project_transfers import protected
  with self.connect() as c:
   if protected(c,current.get('project_id')) and current.get('project_id')!=pid:raise ValueError('Keep transferred conversations in their approved project.')
  if pid:self.project(uid,pid)
  with self.connect() as c:
   if not c.execute('UPDATE conversations SET project_id=? WHERE id=? AND user_id=? AND archived=0',(pid,cid,uid)).rowcount:raise KeyError('Conversation not found.')
  return self.chat(uid,cid)
 def link_project_file(self,uid,pid,fid,remove=False):
  self.project(uid,pid)
  with self.connect() as c:
   if not c.execute('SELECT 1 FROM research_files WHERE id=? AND user_id=?',(fid,uid)).fetchone():raise KeyError('File not found.')
   if remove:c.execute('DELETE FROM work_project_files WHERE project_id=? AND file_id=?',(pid,fid))
   else:
    if c.execute('SELECT COUNT(*) FROM work_project_files WHERE project_id=?',(pid,)).fetchone()[0]>=20:raise ValueError('Use up to 20 project files.')
    c.execute('INSERT OR IGNORE INTO work_project_files VALUES(?,?)',(pid,fid))
  return self.project(uid,pid)
 def project_context(self,uid,cid):
  if not cid:return {'instructions':'','sources':[]}
  chat=self.chat(uid,cid);pid=chat.get('project_id')
  if not pid:return {'instructions':'','sources':[]}
  p=self.project(uid,pid);sources=[];remaining=6000
  with self.connect() as c:
   for f in p['files']:
    row=c.execute('SELECT parsed FROM research_files WHERE id=? AND user_id=?',(f['id'],uid)).fetchone()
    if not row:continue
    parsed=json.loads(row['parsed'])
    for s in parsed.get('sections',[])[:3]:
     text=s.get('text','')[:min(1600,remaining)]
     if not text:continue
     remaining-=len(text);url='/api/research/files/'+f['id']+'/original'
     sources.append({'id':'D'+str(100+len(sources)),'title':f['name']+' · '+s.get('label','Reference'),'source':url,'url':url,'access':'read','kind':'private_document','excerpt':text,'section':s.get('label','Reference'),'context_excerpt_only':True})
  return {'name':p['name'],'instructions':p['instructions'],'sources':sources}

class ProjectHTTP:
 def projects_get(self,path,user):
  try:
   m=re.fullmatch(r'/api/projects/([0-9a-f]{32})/source.zip',path)
   if m:
    filename,data=self.source_bundles.export(user['id'],m[1]);return self.research_download(data,filename)
   if path=='/api/projects':return self.response(200,{'projects':self.workspace.projects(user['id'])})
   m=re.fullmatch(r'/api/projects/([0-9a-f]{32})',path)
   if m:return self.response(200,self.workspace.project(user['id'],m[1]))
  except KeyError:return self.fail(404,'Project not found in this account.')
  return self.fail(404,'Not found.')
 def projects_post(self,path,d,user):
  uid=user['id'];w=self.workspace
  try:
   if path=='/api/projects':return self.response(200,w.save_project(uid,d))
   if path=='/api/projects/move-chat':return self.response(200,w.move_chat(uid,d.get('conversation_id'),d.get('project_id')))
   if path=='/api/projects/files':
    p=w.project(uid,d.get('project_id'))
    if len(p['files'])>=20:raise ValueError('Use up to 20 reference files per project.')
    f=self.research.upload(uid,d.get('file'),d.get('name',''))
    return self.response(201,w.link_project_file(uid,p['id'],f['id']))
   if path=='/api/projects/remove-file':return self.response(200,w.link_project_file(uid,d.get('project_id'),d.get('file_id'),True))
   if path=='/api/projects/archive':
    w.project(uid,d.get('id'))
    with w.connect() as c:
     from project_transfers import protected
     if protected(c,d['id']):raise ValueError('Use Admin > Project transfers to revoke access; imported source history is preserved.')
     c.execute('UPDATE conversations SET project_id=NULL WHERE user_id=? AND project_id=?',(uid,d['id']))
     c.execute('UPDATE work_projects SET archived=1 WHERE user_id=? AND id=?',(uid,d['id']))
    return self.response(200,{'ok':True})
  except KeyError:return self.fail(404,'Project, conversation or file not found in this account.')
  except (ValueError,TypeError) as exc:return self.fail(400,str(exc))
  return self.fail(404,'Not found.')
