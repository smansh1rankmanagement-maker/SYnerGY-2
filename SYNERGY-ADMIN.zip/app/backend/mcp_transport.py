"""Small MCP client for the two reviewed connectors. Server instructions are data."""
import json,os,queue,subprocess,threading,time,urllib.request,urllib.error

MAX_MESSAGE=4*1024*1024
PROTOCOL='2024-11-05'

def result(message):
    if 'error' in message:raise RuntimeError(str(message['error'].get('message','MCP request failed'))[:500])
    return message.get('result',{})

def decode_http(raw,content_type,request_id):
    if len(raw)>MAX_MESSAGE:raise ValueError('Connector response exceeds 4 MB.')
    text=raw.decode('utf-8')
    if 'text/event-stream' in content_type:
        # SSE frames may contain several data lines and unrelated notifications.
        for frame in text.replace('\r\n','\n').split('\n\n'):
            payload='\n'.join(line[5:].lstrip() for line in frame.splitlines() if line.startswith('data:'))
            if not payload:continue
            data=json.loads(payload)
            if data.get('id')==request_id:return result(data)
        raise ValueError('The connector did not return this request result.')
    data=json.loads(text)
    if data.get('id')!=request_id:raise ValueError('Unexpected MCP response identifier.')
    return result(data)

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*a,**kw):raise ValueError('Unexpected connector redirect.')

class HTTPClient:
    def __init__(self,endpoint):
        if endpoint!='https://mcp.firecrawl.dev/v2/mcp':raise ValueError('Connector endpoint is not in the catalog.')
        self.endpoint=endpoint;self.seq=0;self.session=None;self.opener=urllib.request.build_opener(NoRedirect())
    def request(self,method,params=None,notify=False):
        self.seq+=1;payload={'jsonrpc':'2.0','method':method,'params':params or {}}
        if not notify:payload['id']=self.seq
        headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream','MCP-Protocol-Version':PROTOCOL,'X-Firecrawl-Origin':'synergy-ai'}
        if self.session:headers['Mcp-Session-Id']=self.session
        req=urllib.request.Request(self.endpoint,data=json.dumps(payload).encode(),headers=headers)
        try:
            with self.opener.open(req,timeout=55) as response:
                self.session=response.headers.get('Mcp-Session-Id') or self.session
                raw=response.read(MAX_MESSAGE+1)
                if notify:return {}
                return decode_http(raw,response.headers.get('Content-Type',''),self.seq)
        except urllib.error.HTTPError as e:
            if e.code in {402,429}:raise RuntimeError('Firecrawl free access is currently rate-limited. No paid upgrade was enabled.') from e
            raise RuntimeError('Firecrawl returned HTTP '+str(e.code)+'. No paid fallback was used.') from e
    def close(self):
        if self.session:
            try:self.opener.open(urllib.request.Request(self.endpoint,method='DELETE',headers={'Mcp-Session-Id':self.session,'MCP-Protocol-Version':PROTOCOL}),timeout=3).close()
            except Exception:pass

class StdioClient:
    def __init__(self,command,env,cwd):
        self.seq=0;self.lines=queue.Queue();self.process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,env=env,cwd=cwd)
        def reader():
            try:
                while True:
                    line=self.process.stdout.readline(MAX_MESSAGE+1)
                    if not line:break
                    if len(line)>MAX_MESSAGE:self.lines.put(ValueError('Connector message exceeds 4 MB.'));break
                    self.lines.put(line)
            finally:self.lines.put(None)
        self.reader=threading.Thread(target=reader,daemon=True);self.reader.start()
    def request(self,method,params=None,notify=False):
        self.seq+=1;payload={'jsonrpc':'2.0','method':method,'params':params or {}}
        if not notify:payload['id']=self.seq
        self.process.stdin.write(json.dumps(payload).encode()+b'\n');self.process.stdin.flush()
        if notify:return {}
        deadline=time.monotonic()+45
        while time.monotonic()<deadline:
            try:line=self.lines.get(timeout=.2)
            except queue.Empty:continue
            if line is None:raise RuntimeError('The connector stopped before returning a result.')
            if isinstance(line,Exception):raise line
            try:message=json.loads(line)
            except (ValueError,UnicodeError):continue
            if message.get('id')==self.seq and ('result' in message or 'error' in message):return result(message)
            # Never service sampling, elicitation or tool-execution requests from a server.
            if 'method' in message and 'id' in message:
                self.process.stdin.write(json.dumps({'jsonrpc':'2.0','id':message['id'],'error':{'code':-32601,'message':'Client-initiated operations only'}}).encode()+b'\n');self.process.stdin.flush()
        raise TimeoutError('Desktop Commander timed out.')
    def close(self):
        if self.process.poll() is None:
            self.process.terminate()
            try:self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:self.process.kill();self.process.wait(timeout=3)
        self.reader.join(timeout=1)
        streams=[self.process.stdin]
        # Do not block closing a pipe while a descendant still holds its writer.
        if not self.reader.is_alive():streams.append(self.process.stdout)
        for stream in streams:
            if stream and not stream.closed:stream.close()

def initialize(client):
    info=client.request('initialize',{'protocolVersion':PROTOCOL,'capabilities':{},'clientInfo':{'name':'synergy-ai','version':'1.5.2'}})
    client.request('notifications/initialized',notify=True)
    return info.get('serverInfo',{})

def unpack(payload):
    blocks=[c.get('text','') for c in payload.get('content',[]) if c.get('type')=='text']
    if payload.get('isError'):raise RuntimeError(('\n'.join(blocks) or 'Connector tool failed.')[:700])
    if isinstance(payload.get('structuredContent'),dict):return payload['structuredContent']
    for block in blocks:
        try:return json.loads(block)
        except ValueError:pass
    return {'text':'\n'.join(blocks)}
