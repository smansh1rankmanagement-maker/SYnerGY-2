"""SYnerGY Observation MCP: explicit conversational cues, not emotion diagnosis.

Run: python observation_mcp.py (MCP JSON-RPC over stdio). No network, private
profiles or background recording. The only input is the current user's text.
"""
import argparse,json,re,sys
from pathlib import Path
RULES=[('correction_requested',r"\b(not what i (?:asked|wanted)|you (?:misunderstood|ignored)|incorrect|wrong answer|stop (?:doing|creating|generating)|without context)\b",'Acknowledge the specific mismatch briefly and answer the current request. Do not repeat the unwanted action.'),('more_detail',r'\b(more details?|in detail|step by step|explain fully|bullet points)\b','Use the requested detail and structure; keep facts distinct from assumptions.'),('concise_reply',r'\b(keep it short|briefly|short answer|no jargon|quick summary)\b','Give the direct answer concisely in plain language.'),('time_sensitive',r'\b(urgent|as soon as possible|deadline|asap)\b','Prioritize useful next steps and state real progress. Do not invent speed or completion promises.'),('positive_feedback',r'\b(thank you|thanks|that works|looks good|satisfied|perfect)\b','Respond naturally. Positive wording is not approval to publish, spend, or close a ticket.')]
def observe(text):
 if not isinstance(text,str) or len(text)>6000:raise ValueError('Provide the current user message, up to 6,000 characters.')
 signals=[]
 for name,pattern,action in RULES:
  found=re.search(pattern,text,re.I)
  if found and not (name=='positive_feedback' and re.search(r'\b(?:not|never|hardly)\s+(?:really\s+)?$',text[max(0,found.start()-20):found.start()],re.I)):signals.append({'signal':name,'evidence':found.group(0),'suggestion':action})
 return {'tool':'synergy_observe_feedback','signals':signals,'inference':'Observable wording only; emotional state is unknown. No sensitive traits inferred.','authority':'Does not grant tool permissions, approve changes, or override the latest request.'}
def instruction(result):return ' User-feedback cues (style guidance only): '+' '.join(s['suggestion'] for s in result['signals']) if result['signals'] else ''
def learning_tools():
 return [{'name':'observation_examples','description':'List this account’s private review queue and provenance. No model-weight training.','inputSchema':{'type':'object','properties':{},'additionalProperties':False}}, {'name':'observation_review','description':'Approve an owned example for private retrieval, or delete it. Approval does not establish factual correctness.','inputSchema':{'type':'object','properties':{'id':{'type':'string','pattern':'^[a-f0-9]{32}$'},'decision':{'enum':['approve','delete']}},'required':['id','decision'],'additionalProperties':False}}, {'name':'observation_clear','description':'Delete all examples for the host-bound account.','inputSchema':{'type':'object','properties':{},'additionalProperties':False}}]
def learning_call(engine,uid,name,args):
 if not isinstance(args,dict):raise ValueError('Arguments must be an object.')
 if name=='observation_examples' and not args:return engine.list(uid)
 if name=='observation_clear' and not args:return engine.clear(uid)
 if name=='observation_review' and set(args)=={'id','decision'}:return engine.review(uid,args['id'],args['decision'])
 raise ValueError('Unknown tool or invalid arguments.')
def serve(engine=None,uid=None,access=None):
 for raw in sys.stdin:
  if len(raw)>40000:continue
  try:
   req=json.loads(raw);rid=req.get('id');method=req.get('method');params=req.get('params',{})
   if rid is None:continue
   if method=='initialize':result={'protocolVersion':'2024-11-05','capabilities':{'tools':{}},'serverInfo':{'name':'synergy-observation','version':'2.0.0'}}
   elif method=='tools/list':result={'tools':[{'name':'synergy_observe_feedback','description':'Identify explicit feedback and response-format cues in the current user message. No emotion diagnosis or persistent profile.','inputSchema':{'type':'object','properties':{'text':{'type':'string','maxLength':6000}},'required':['text'],'additionalProperties':False},'annotations':{'readOnlyHint':True,'destructiveHint':False,'openWorldHint':False}}]+(learning_tools() if engine else [])}
   elif method=='tools/call' and params.get('name')=='synergy_observe_feedback':
    data=observe(params.get('arguments',{}).get('text'));result={'content':[{'type':'text','text':json.dumps(data)}],'structuredContent':data,'isError':False}
   elif method=='tools/call' and engine:
    if access:access(uid,'chat')
    data=learning_call(engine,uid,params.get('name'),params.get('arguments',{}));result={'content':[{'type':'text','text':json.dumps(data)}],'structuredContent':data,'isError':False}
   elif method=='ping':result={}
   else:raise ValueError('Unsupported method or tool.')
   print(json.dumps({'jsonrpc':'2.0','id':rid,'result':result}),flush=True)
  except (ValueError,TypeError,KeyError,PermissionError) as e:print(json.dumps({'jsonrpc':'2.0','id':locals().get('rid'),'error':{'code':-32602,'message':str(e)}}),flush=True)
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path);parser.add_argument('--user',type=int);args=parser.parse_args()
 if args.data and args.user:
  from observation_learning import Observation
  from membership import Membership
  membership=Membership(args.data/'accounts.sqlite3');membership.require(args.user,'chat');serve(Observation(args.data/'accounts.sqlite3'),args.user,membership.require)
 elif args.data or args.user:parser.error('--data and --user must be configured together by the trusted host')
 else:serve()
