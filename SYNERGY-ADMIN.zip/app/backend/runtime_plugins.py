"""Reviewed runtime connectors installed by explicit chat commands, scoped per account."""
from pathlib import Path
import datetime,hashlib,json,os,re,shutil,signal,subprocess,sys,threading,time,urllib.request,uuid
from research.net import redact,validate_url
from research.web import Web,relevance,search_match
from research.latency import PhaseStop

CATALOG=json.loads(Path(__file__).with_name('runtime_catalog.json').read_text())

def command(prompt):
    """Only the current user's imperative can install; retrieved text never enters here."""
    if not re.match(r'^\s*(?:(?:please|can you|could you)\s+)?install\b',prompt,re.I):return None
    urls=re.findall(r'https?://[^\s<>`]+',prompt)
    allowed={'https://github.com/wonderwhy-er/desktopcommandermcp','https://github.com/firecrawl/firecrawl-mcp-server'}
    if any(u.rstrip('/.,)').removesuffix('.git').lower() not in allowed for u in urls):return None
    keys=[]
    if re.search(r'desktop[\s_-]*commander|github\.com/wonderwhy-er/desktopcommandermcp',prompt,re.I):keys.append('desktop-commander')
    if re.search(r'fire[\s_-]*crawl',prompt,re.I):keys.append('firecrawl')
    return keys or None

def desktop_command(prompt):
    if not re.search(r'desktop[\s_-]*commander|^/desktop\b',prompt,re.I):return None
    text=re.sub(r'desktop[\s_-]*commander|^/desktop\b','',prompt,flags=re.I).strip(' :')
    read=re.search(r'\b(?:read|open|show)\s+(?:the\s+)?(?:file\s+)?["`\']?([^"`\'\n]+\.[a-zA-Z0-9]+)["`\']?',text,re.I)
    if read:return {'action':'read','path':read[1].strip()}
    find=re.search(r'\b(?:search|find)\s+(?:for\s+)?["`\']([^"`\']{1,120})["`\']',text,re.I)
    if find:return {'action':'search','term':find[1]}
    if re.search(r'\b(list|files|folder|workspace)\b',text,re.I):return {'action':'list'}
    return {'action':'help'}

def stop_process(p):
    if p.poll() is None:
        try:os.killpg(p.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:p.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            p.wait(timeout=2)

class RuntimePlugins:
    def __init__(self,workspace,root):
        self.ws=workspace;self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.guard=threading.RLock();self.install_lock=threading.Lock();self.processes={}
        with self.ws.connect() as c:
            c.execute('CREATE TABLE IF NOT EXISTS runtime_connectors(user_id INTEGER NOT NULL,key TEXT NOT NULL,state TEXT NOT NULL,enabled INTEGER NOT NULL,metadata TEXT NOT NULL,updated REAL NOT NULL,PRIMARY KEY(user_id,key))')
            c.execute("UPDATE runtime_connectors SET state='interrupted' WHERE state='installing'")
    def admin(self,uid):
        expected=os.environ.get('SYNERGY_PLUGIN_ADMIN','')
        if not expected:return False
        with self.ws.connect() as c:
            try:row=c.execute('SELECT username FROM users WHERE id=?',(uid,)).fetchone()
            except Exception:return False
        return bool(row and row['username'].casefold()==expected.casefold())
    def get(self,uid,key):
        if key not in CATALOG:raise ValueError('Choose a verified plugin from the catalog.')
        with self.ws.connect() as c:r=c.execute('SELECT state,enabled,metadata,updated FROM runtime_connectors WHERE user_id=? AND key=?',(uid,key)).fetchone()
        if r:return {**dict(r),'metadata':json.loads(r['metadata'])}
        if key=='desktop-commander' and (self.package_path()/'node_modules/@wonderwhy-er/desktop-commander/dist/index.js').is_file():return {'state':'ready','enabled':True,'metadata':{'tools':CATALOG[key]['tools'],'version':CATALOG[key]['version'],'default':True}}
        if key=='firecrawl':return {'state':'ready','enabled':True,'metadata':{'availability':'not_checked','tools':CATALOG[key]['tools'],'version':'keyless MCP','default':True}}
        return {'state':'not_installed','enabled':False,'metadata':{}}
    def set(self,uid,key,state,metadata,enabled=True):
        with self.ws.connect() as c:c.execute('INSERT OR REPLACE INTO runtime_connectors VALUES(?,?,?,?,?,?)',(uid,key,state,int(enabled),json.dumps(metadata),time.time()))
    def enabled(self,uid,key):
        p=self.get(uid,key);return p['state']=='ready' and bool(p['enabled'])
    def catalog(self,uid):
        out=[]
        for key,spec in CATALOG.items():
            s=self.get(uid,key);m=s['metadata'];out.append({'id':'mcp:'+key,'key':key,'name':spec['name'],'description':spec['description'],'source':spec['source'],'builtin':False,'runtime':True,'status':s['state'],'availability':m.get('availability'),'enabled':bool(s['enabled']),'version':m.get('version',spec.get('version','')),'tools':m.get('tools',[]),'scope':spec['scope'],'can_install':self.admin(uid),'error':m.get('error')})
        return out
    def toggle(self,uid,key,enabled):
        if type(enabled) is not bool:raise ValueError('Invalid plugin state.')
        s=self.get(uid,key)
        if s['state']!='ready':raise ValueError('Install this plugin in Chat first.')
        self.set(uid,key,s['state'],s['metadata'],enabled)
    def workspace(self,uid):
        p=self.root/'accounts'/str(uid)/'workspace';p.mkdir(parents=True,exist_ok=True,mode=0o700);return p.resolve()
    def private_profile(self,uid):
        p=self.root/'accounts'/str(uid)/'profile';p.mkdir(parents=True,exist_ok=True,mode=0o700)
        config=p/'.claude-server-commander';config.mkdir(exist_ok=True,mode=0o700)
        (config/'config.json').write_text(json.dumps({'allowedDirectories':[str(self.workspace(uid))],'telemetryEnabled':False,'fileReadLineLimit':300,'fileWriteLineLimit':100,'blockedCommands':['*']}));(config/'config.json').chmod(0o600)
        return p
    def scoped_path(self,uid,path):
        root=self.workspace(uid);p=(root/str(path)).resolve()
        if not p.is_relative_to(root) or any(x.startswith('.') for x in p.relative_to(root).parts):raise ValueError('Use a file inside your private SYnerGY tool workspace.')
        if p.is_file() and p.stat().st_size>8*1024*1024:raise ValueError('File exceeds the 8 MB tool limit.')
        return p
    def node(self):
        p=os.environ.get('SYNERGY_NODE') or shutil.which('node')
        if not p:raise ValueError('Node.js 22.12 or newer is required on the inference machine.')
        return str(Path(p).resolve())
    def package_path(self):return self.root/'packages'/'desktop-commander-0.3.1'
    def execute(self,jid,argv,cwd,env,stop,timeout,log):
        with open(log,'wb') as output:
            p=subprocess.Popen(argv,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
            with self.guard:self.processes.setdefault(jid,set()).add(p)
            try:
                deadline=time.monotonic()+timeout
                while p.poll() is None:
                    if stop.is_set():raise InterruptedError('Stopped by you.')
                    if time.monotonic()>deadline:raise TimeoutError('The plugin operation timed out. Retry when the service is available.')
                    stop.wait(.1)
                if stop.is_set():raise InterruptedError('Stopped by you.')
                return p.returncode
            finally:
                stop_process(p)
                with self.guard:self.processes.get(jid,set()).discard(p)
    def cancel(self,jid):
        with self.guard:processes=list(self.processes.get(jid,set()))
        for p in processes:stop_process(p)
    def close(self):
        for jid in list(self.processes):self.cancel(jid)
    def worker(self,uid,jid,folder,key,stop,tool=None,arguments=None):
        d={'key':key,'tool':tool,'arguments':arguments or {}}
        if key=='desktop-commander':
            d.update(node=self.node(),entry=str(self.package_path()/'node_modules/@wonderwhy-er/desktop-commander/dist/index.js'),workspace=str(self.workspace(uid)),profile=str(self.private_profile(uid)))
        name='connector-'+uuid.uuid4().hex;request=Path(folder)/(name+'.json');output=Path(folder)/(name+'.result')
        request.write_text(json.dumps(d));request.chmod(0o600)
        try:
            code=self.execute(jid,[sys.executable,str(Path(__file__).with_name('plugin_worker.py')),str(request)],str(folder),{k:v for k,v in os.environ.items() if k in {'PATH','LANG','LC_ALL','TMPDIR','SSL_CERT_FILE','SSL_CERT_DIR','PYTHONPATH','SYNERGY_NODE'}},stop,75,output)
            lines=output.read_text(errors='replace').splitlines();value=None
            for line in reversed(lines):
                try:value=json.loads(line);break
                except ValueError:continue
            if not value or 'error' in value or code:raise RuntimeError((value or {}).get('error','The plugin did not return a result.'))
            return value['result']
        finally:request.unlink(missing_ok=True);output.unlink(missing_ok=True)
    def install(self,uid,jid,folder,key,stop,stage):
        if not self.admin(uid):raise ValueError('Runtime plugin installation is available to this server\'s configured owner account.')
        spec=CATALOG[key]
        while not self.install_lock.acquire(timeout=.2):
            if stop.is_set():raise InterruptedError('Stopped by you.')
        old=self.get(uid,key)
        try:
            if stop.is_set():raise InterruptedError('Stopped by you.')
            self.set(uid,key,'installing',old['metadata'],False);stage('Preparing '+spec['name'])
            if key=='desktop-commander':
                node=self.node();dest=self.package_path();entry=dest/'node_modules/@wonderwhy-er/desktop-commander/dist/index.js'
                if not entry.exists():
                    stage('Downloading verified Desktop Commander 0.3.1')
                    npm=os.environ.get('SYNERGY_NPM') or shutil.which('npm')
                    if not npm:raise ValueError('npm is required to install Desktop Commander.')
                    # npm checks the registry tarball integrity; verify its locked identity too.
                    temp=self.root/'packages'/('install-'+uuid.uuid4().hex);temp.mkdir(parents=True,mode=0o700)
                    config=temp/'empty.npmrc';config.write_text('');global_config=temp/'empty-global.npmrc';global_config.write_text('')
                    env={k:os.environ[k] for k in ['LANG','TMPDIR','SYSTEMROOT'] if k in os.environ};env.update(PATH=str(Path(node).parent)+os.pathsep+os.defpath,DO_NOT_TRACK='1',DISABLE_TELEMETRY='1',npm_config_cache=str(self.root/'npm-cache'),npm_config_userconfig=str(config),npm_config_globalconfig=str(global_config))
                    pinned=Path(__file__).with_name('runtime-locks')/'desktop-commander'
                    for name in ['package.json','package-lock.json']:shutil.copy2(pinned/name,temp/name)
                    argv=[node,str(Path(npm).resolve()),'ci','--prefix',str(temp),'--ignore-scripts','--omit=dev','--no-audit','--no-fund','--registry=https://registry.npmjs.org']
                    try:
                        code=self.execute(jid,argv,str(temp),env,stop,480,Path(folder)/'package-install.log')
                        if code:raise RuntimeError('Package installation failed. Retry after checking npm/network availability.')
                        lock=json.loads((temp/'package-lock.json').read_text());locked=lock['packages']['node_modules/'+spec['package']]
                        if locked.get('version')!=spec['version'] or locked.get('integrity')!=spec['integrity']:raise ValueError('Package integrity does not match the verified catalog.')
                        package=json.loads((temp/'node_modules'/spec['package']/'package.json').read_text())
                        if package.get('name')!=spec['package'] or package.get('version')!=spec['version']:raise ValueError('Unexpected installed package.')
                        if dest.exists():shutil.rmtree(dest)
                        temp.rename(dest)
                    finally:
                        if temp.exists():shutil.rmtree(temp)
                work=self.workspace(uid);guide=work/'README.md'
                if not guide.exists():guide.write_text('# Your SYnerGY tool workspace\n\nDesktop Commander can list, read and search files placed in this account\'s workspace.\n\nIn any mode, try:\n- Desktop Commander list files\n- Desktop Commander read README.md\n- Desktop Commander search "research"\n\nFirecrawl searches public websites. Private documents stay local. Website inspection uses a separate isolated browser.\n')
            stage('Checking '+spec['name']+' connection')
            probe=self.worker(uid,jid,folder,key,stop)
            if not set(spec['tools']).issubset(set(probe['tools'])):raise ValueError('The plugin did not expose its required tools.')
            metadata={'version':spec.get('version') or probe['server'].get('version'),'server':probe['server'],'tools':probe['tools'],'transport':spec['transport'],'source':spec['source'],'scope':spec['scope'],'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
            if key=='firecrawl':
                stage('Testing Firecrawl public-page access')
                try:
                    check=self.worker(uid,jid,folder,key,stop,'firecrawl_scrape',{'url':'https://example.com','formats':['markdown'],'onlyMainContent':True,'objective':'Verify this public web connector using the example.com demonstration page.'})
                    data=check.get('data',{});data=data.get('data',data)
                    if not isinstance(data,dict) or len(str(data.get('markdown','')).strip())<80:raise RuntimeError('The service did not return readable page content.')
                    metadata.update(availability='available',access_test='https://example.com')
                except InterruptedError:raise
                except Exception as e:
                    metadata.update(availability='unavailable',error=firecrawl_error(e),availability_checked=time.time())
                    stage('Firecrawl access unavailable; built-in public research remains available')
            self.set(uid,key,'ready',metadata,True);stage(spec['name']+(' connector saved; free access unavailable' if metadata.get('availability')=='unavailable' else ' is connected'));return metadata
        except BaseException as e:
            self.set(uid,key,old['state'] if old['state']=='ready' and not old['metadata'].get('default') else 'failed',{**old['metadata'],'error':redact(str(e))[:500]},old['enabled'] if not old['metadata'].get('default') else False);raise
        finally:self.install_lock.release()
    def call(self,uid,jid,folder,key,tool,args,stop):
        if not self.enabled(uid,key):raise ValueError('Install or enable '+CATALOG[key]['name']+' in Chat first.')
        if tool not in CATALOG[key]['tools']:raise ValueError('This plugin tool is not enabled.')
        if key=='desktop-commander':args={**args,'path':str(self.scoped_path(uid,args.get('path','')))}
        started=time.monotonic();data=self.worker(uid,jid,folder,key,stop,tool,args)
        return {**data,'seconds':round(time.monotonic()-started,3)}
    def desktop(self,uid,jid,folder,request,stop,stage):
        if request['action']=='help':return 'Try `Desktop Commander list files`, `Desktop Commander read README.md`, or `Desktop Commander search "research"`.',[]
        stage('Reading your workspace with Desktop Commander');evidence=[]
        if request['action'] in {'list','read'}:
            tool='list_directory' if request['action']=='list' else 'read_file';args={'path':request.get('path','')}
            args.update({'depth':2} if tool=='list_directory' else {'offset':0,'length':250})
            r=self.call(uid,jid,folder,'desktop-commander',tool,args,stop);text=r['data'].get('text',json.dumps(r['data'],ensure_ascii=False));evidence.append({'tool':tool,'seconds':r['seconds'],'path':str(args['path']),'result':text[:20000]})
            return 'Desktop Commander · '+('workspace files' if tool=='list_directory' else request['path'])+'\n\n```text\n'+text[:16000].replace('```','~~~')+'\n```',evidence
        # Bounded search reads actual files through Desktop Commander, never shell code.
        hits=[];root=self.workspace(uid);files=[p for p in root.rglob('*') if p.is_file() and not any(x.startswith('.') for x in p.relative_to(root).parts) and p.suffix.lower() in {'.txt','.md','.py','.js','.json','.csv','.html','.css'}][:12]
        for p in files:
            if stop.is_set():raise InterruptedError('Stopped by you.')
            try:r=self.call(uid,jid,folder,'desktop-commander','read_file',{'path':str(p),'offset':0,'length':250},stop)
            except ValueError:continue
            text=r['data'].get('text','');lines=[line for line in text.splitlines() if request['term'].casefold() in line.casefold()][:10]
            evidence.append({'tool':'read_file','path':str(p.relative_to(root)),'seconds':r['seconds'],'matches':lines})
            if lines:hits.append('**'+str(p.relative_to(root))+'**\n\n```text\n'+'\n'.join(lines).replace('```','~~~')+'\n```')
        return ('\n\n'.join(hits) or 'No match in the files read.')+'\n\nChecked up to 12 text files, 250 lines per file, in your private tool workspace.',evidence

def firecrawl_error(error):
    text=redact(str(error))
    if re.search(r'anonymous|keyless|api.key|unauthori|rate.limit|429|402',text,re.I):return 'Firecrawl refused free access. No API key or paid service was connected.'
    return 'Firecrawl was unavailable: '+text.split('\n')[0][:220]

class FirecrawlWeb(Web):
    def __init__(self,runtime,uid,jid,folder,stage,stop,fallback=None,warnings=None):
        super().__init__();self.runtime=runtime;self.uid=uid;self.jid=jid;self.folder=folder;self.stage=stage;self.stop=stop;self.conversation=None;self.serial=threading.Lock();self.fallback=fallback;self.warnings=warnings if warnings is not None else [];self.unavailable=None;self.used_fallback=False
        state=runtime.get(uid,'firecrawl')['metadata']
        if fallback and state.get('availability')=='unavailable' and time.time()-state.get('availability_checked',0)<300:self.unavailable=state.get('error','Firecrawl is unavailable.')
    def fallback_notice(self,error):
        with self.serial:
            if not self.used_fallback:
                self.unavailable=firecrawl_error(error);self.used_fallback=True
                notice=self.unavailable+' SYnerGY used its built-in public web tools.'
                self.warnings.append(notice);self.stage(notice)
                state=self.runtime.get(self.uid,'firecrawl')
                if state.get('state')=='ready':self.runtime.set(self.uid,'firecrawl','ready',{**state['metadata'],'availability':'unavailable','availability_checked':time.time(),'error':self.unavailable},state['enabled'])
    def tool(self,name,args):
        with self.serial:
            if self.stop.is_set():raise InterruptedError('Stopped by you.')
            if self.unavailable:raise RuntimeError(self.unavailable)
            args={**args,'objective':'Find reliable public sources for the current research question.'}
            if self.conversation:args['conversationId']=self.conversation
            # A slow/limited connector must leave time for direct public search.
            probe=PhaseStop(self.stop,min(getattr(self.stop,"deadline",float("inf")),time.monotonic()+8))
            try:r=self.runtime.call(self.uid,self.jid,self.folder,'firecrawl',name,args,probe)
            except InterruptedError:
                if self.stop.is_set():raise
                raise TimeoutError('Firecrawl did not respond in time; trying direct public search.') from None
            data=r['data']
            if isinstance(data,dict) and data.get('conversationId'):self.conversation=data['conversationId']
            if isinstance(data,dict) and data.get('success') is False:raise RuntimeError(str(data.get('error') or 'Firecrawl did not complete this request.')[:400])
            state=self.runtime.get(self.uid,'firecrawl')
            if state.get('state')=='ready':self.runtime.set(self.uid,'firecrawl','ready',{**state['metadata'],'availability':'available','availability_checked':time.time(),'error':None},state['enabled'])
            return data
    def search(self,query,limit=5,timelimit=None,domains=(),cancel=None):
        self.stage('Searching public sources with Firecrawl');args={'query':query[:400],'limit':min(limit,5),'sources':['web'],'domainTools':False}
        if domains:args['includeDomains']=[d.lower() for d in domains]
        if timelimit:args['tbs']='qdr:'+timelimit
        try:
            data=self.tool('firecrawl_search',args);rows=data.get('data',data) if isinstance(data,dict) else data
            if isinstance(rows,dict):rows=rows.get('web',rows.get('results',[]))
            if not isinstance(rows,list):raise ValueError('Unexpected Firecrawl search response.')
            results=[]
            for row in rows:
                url=row.get('url') or row.get('link')
                try:u,host,*_=validate_url(url)
                except (OSError,ValueError,TypeError):continue
                if domains and not any(host==d.lower() or host.endswith('.'+d.lower()) for d in domains):continue
                if not search_match(query,row.get('title',''),url,str(row.get('description') or row.get('snippet') or '')):continue
                results.append({'url':url,'title':row.get('title') or host,'snippet':str(row.get('description') or row.get('snippet') or '')[:1000],'access':'snippet_only','engine':'Firecrawl keyless','published':row.get('publishedDate')})
            if not results and self.fallback:raise ValueError('No relevant public results were returned.')
            return {'results':results[:limit],'engine':'Firecrawl keyless','cached':False,**({} if results else {'error':'Firecrawl returned no matching public sources.'})}
        except InterruptedError:raise
        except Exception as e:
            if self.fallback:
                self.fallback_notice(e)
                return {**self.fallback.search(query,limit,timelimit,domains,cancel),'fallback_from':'Firecrawl','connector_notice':self.unavailable}
            return {'results':[],'engine':'Firecrawl keyless','error':firecrawl_error(e)}
    def read(self,url,question='',cancel=None,allowed_origins=()):
        start=time.monotonic();public=False;item={'url':url,'source':url,'title':url,'access':'unread','reader':'Firecrawl keyless','retrieved':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        try:
            validate_url(url)  # Test/private origins are never forwarded to a hosted connector.
            public=True
            self.stage('Reading a public page with Firecrawl')
            data=self.tool('firecrawl_scrape',{'url':url,'formats':['markdown','links'],'onlyMainContent':True,'timeout':45000,'domainTools':False})
            d=data.get('data',data)
            if not isinstance(d,dict):raise ValueError('Unexpected Firecrawl page response.')
            text=d.get('markdown','');metadata=d.get('metadata',{});status=metadata.get('statusCode',200)
            if status>=400 or not isinstance(text,str) or len(text.strip())<80:raise ValueError('The page did not provide readable content (HTTP '+str(status)+').')
            final=metadata.get('sourceURL') or metadata.get('url') or url;validate_url(final)
            item.update(url=final,source=final,title=metadata.get('title') or url,http_status=status,access='read',text=text[:120000],excerpt=relevance(text,question),links=[x for x in d.get('links',[]) if isinstance(x,str) and x.startswith('http')][:150],published=metadata.get('publishedTime') or metadata.get('article:published_time'),modified=metadata.get('modifiedTime'),content_sha256=hashlib.sha256(text.encode()).hexdigest(),hash_basis='Firecrawl returned Markdown',partial=len(text)>120000,bytes=len(text.encode()),seconds=round(time.monotonic()-start,3))
        except InterruptedError:raise
        except Exception as e:
            if public and self.fallback:
                self.fallback_notice(e)
                return {**self.fallback.read(url,question,cancel),'fallback_from':'Firecrawl','connector_notice':self.unavailable}
            item.update(access='blocked',error=firecrawl_error(e) if public else redact(str(e))[:500])
        return item
