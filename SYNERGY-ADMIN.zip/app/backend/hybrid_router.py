"""Hybrid connected-first orchestration; preserves account privacy and provider budgets."""
import json,time
import free_router,model_router
from membership import Membership

def respond(messages,maximum,permission=False,structured=False,stage=lambda s:None,
            deadline=None,free_data_permission=False,notice=lambda s:None,user_id=None,mode='chat',planned_model=None):
    if not permission:
        return None,{'status':'local','reason':'External AI is off for this account.','attempts':[]}
    attempts=[]
    def progress(text):
        if text!='Trying the local SYNERGY model':stage(text)
    def available():return not deadline or time.monotonic()<deadline
    def free(kind):
        answer,meta=free_router.respond(messages,maximum,permission,structured,progress,deadline,
            free_data_permission,notice,user_id,preferred=kind)
        attempts.extend(meta.get('attempts',[]))
        if answer:
            meta['attempts']=list(attempts)
            return answer,meta
        return None,None
    _,name,enabled=model_router.external_config()
    if enabled and available():
        permitted=False
        try:
            if type(user_id) is not int or user_id<=0:raise ValueError('Missing authenticated owner.')
            name=model_router.select_openai(user_id,mode,planned_model or 'auto')
            permitted=True
        except (ValueError,KeyError,PermissionError):
            pass
        if permitted:
            started=time.monotonic();stage('SYNERGY is answering with Hybrid')
            try:
                selection={'provider':'openai','model':name,'user_id':user_id,'mode':mode,'reasoning_effort':'low','deadline':deadline or time.monotonic()+90}
                answer=model_router.openai_response(messages,selection,maximum)
                if structured:json.loads(answer.strip().removeprefix(chr(96)*3+'json').removesuffix(chr(96)*3))
                free_router.audit('openai/'+name,'completed',200,started)
                if attempts:
                    notice({'id':str(time.time_ns()),'message':'Switched to another available service.','created':time.time(),'expires':time.time()+8})
                attempts.append({'provider':'openai','model':name,'status':'completed'})
                return answer,{'status':'completed','actual_provider':'openai','actual_model':name,'attempts':attempts,'free_only':False}
            except Exception:
                free_router.audit('openai/'+name,'request_unavailable',None,started)
                attempts.append({'provider':'openai','model':name,'status':'request_unavailable'})
    # Keep a single eligible OpenAI plan and a local fallback. Legacy provider
    # credentials never influence this mode's model choice.
    stage('Trying the local SYNERGY model')
    return None,{'status':'local_fallback','reason':'Eligible connected services could not complete this request.','attempts':attempts}
