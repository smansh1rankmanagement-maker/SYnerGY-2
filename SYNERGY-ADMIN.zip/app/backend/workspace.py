"""Account-owned conversations, prompt skills, and local-tool preferences."""
import json,re,sqlite3,time,uuid
from pathlib import Path
from projects import Projects

BUILTIN_SKILLS=[
 {'id':'document-creation','name':'Document creation','description':'Create downloadable PDFs, A4 PNG pages, Word documents and editable text from supplied content or a brief.','instructions':'Write finished document content, not instructions for creating a document. Preserve exact supplied wording when exporting. Do not invent facts, approvals or download links. Use clear headings, compact tables and source references. The local renderer produces the actual files.'},
 {'id':'brand-layout','name':'Poster and social design','description':'Create posters, Instagram posts and thumbnails with exact typography and approved logos.','instructions':'Use a clear subject, natural textures and deliberate composition. Preserve approved assets; do not redraw logos. Place exact user-supplied text with the layout engine. Do not invent contact details, offers or performance claims.'},
 {'id':'ui-ux-design','name':'UI and UX design','description':'Design accessible, responsive interfaces and implement them in source.','instructions':'Start with the user goal, content hierarchy and key task. Reuse supplied brand assets and existing design patterns. Use semantic landmarks, keyboard access, visible focus, labelled inputs, useful errors and loading/empty/success states. Design mobile, tablet and desktop layouts with coherent spacing and type. Respect reduced motion. Choose components that support the task. State which interactions and accessibility checks were actually tested. Never claim a screenshot reveals backend behaviour or that an untested layout is production ready.'},
 {'id':'brand-writing','name':'Brand writing','description':'Clear, direct copy in the brand’s voice.','instructions':'Write plain, specific copy. Avoid inflated claims, clichés, invented facts and unsolicited prices. Match the user’s language and requested length.'},
 {'id':'photo-direction','name':'Photo direction','description':'Turn an idea into a precise image brief.','instructions':'Help write a concrete photographic prompt with subject, materials, setting, light, composition and things to preserve. Keep it under 75 words. Do not claim the image has been generated unless a real image job completed.'},
 {'id':'storyboard','name':'Storyboard','description':'Plan shots and maintain continuity.','instructions':'Create concise shot plans. Keep character, wardrobe, setting and lighting consistent. Describe visible action and camera movement. Separate a plan from completed video generation.'},
 {'id':'code-review','name':'Code review','description':'Find defects and explain practical fixes.','instructions':'Review the supplied code for correctness, security and maintainability. Lead with concrete defects and minimal fixes. Never invent test execution or repository access.'}
]
from intelligence import skills as intelligence_skills
BUILTIN_SKILLS += intelligence_skills()
AWS_SKILL=Path(__file__).resolve().parents[1]/'skills/aws-deployment/SKILL.md'
if AWS_SKILL.is_file():
 BUILTIN_SKILLS.append({'id':'aws-deployment','name':'AWS deployment','description':'Set up AWS, deploy SYnerGY on a domain, preserve accounts, verify and roll back upgrades.','instructions':AWS_SKILL.read_text()})
DC_SKILL=Path(__file__).resolve().parents[1]/'skills/desktop-commander/SKILL.md'
if DC_SKILL.is_file():
 BUILTIN_SKILLS.append({'id':'desktop-commander','name':'Desktop Commander','description':'List, read and search your private server tool workspace using real MCP calls.','instructions':DC_SKILL.read_text()})
for key,name,desc in [('ui-ux-pro-max','UI/UX Pro Max','Search installed design guidance for layouts, accessibility and responsive interfaces.'),('framer-motion','Framer Motion','Build React animations with the installed Motion runtime; respect reduced motion.')]:
 skill_file=Path(__file__).resolve().parents[1]/'skills'/key/'SKILL.md'
 if skill_file.is_file():BUILTIN_SKILLS.append({'id':key,'name':name,'description':desc,'instructions':skill_file.read_text()[:20000]})
TOOLS=[{'id':'synergy-media','name':'SYNERGY MEDIA MCP','description':'Edit uploaded images and videos, add text/logos, trim, join, caption, mix audio, compress and use local Diffusers. Private versioned outputs.','builtin':True},{'id':'documents','name':'SYnerGY documents','description':'Create PDF, Word and editable text files directly from chat.','builtin':True},{'id':'research','name':'Web research','description':'Search public sources, read pages and keep verifiable source links.','builtin':True},{'id':'browser','name':'Website inspection','description':'Inspect an isolated browser with screenshots, console and network evidence.','builtin':True},{'id':'image','name':'SYnerGY text to image','description':'Create images from a prompt or a reference.','builtin':True}, {'id':'video','name':'SYnerGY text to video','description':'Generate short clips with local motion models.','builtin':True}, {'id':'voice','name':'SYnerGY Jarvis voice','description':'Talk with SYnerGY using local Faster-Whisper and Kokoro. Start from the microphone beside Send.','builtin':True}, {'id':'knowledge','name':'Knowledge','description':'Use your private reference notes in chat.','builtin':True}]

def ident():return uuid.uuid4().hex

class Workspace(Projects):
 def __init__(self,db):
  self.db=db
  with self.connect() as c:c.executescript('''
   CREATE TABLE IF NOT EXISTS conversations(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,title TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL,archived INTEGER NOT NULL DEFAULT 0);
   CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,conversation_id TEXT NOT NULL,role TEXT NOT NULL,content TEXT NOT NULL,created REAL NOT NULL,metadata TEXT NOT NULL DEFAULT '{}');
   CREATE INDEX IF NOT EXISTS messages_conversation ON messages(conversation_id,created);
   CREATE TABLE IF NOT EXISTS skills(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,name TEXT NOT NULL,description TEXT NOT NULL,instructions TEXT NOT NULL,source TEXT NOT NULL,plugin_id TEXT,created REAL NOT NULL);
   CREATE TABLE IF NOT EXISTS plugins(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,name TEXT NOT NULL,description TEXT NOT NULL,source TEXT NOT NULL,status TEXT NOT NULL,enabled INTEGER NOT NULL,metadata TEXT NOT NULL,created REAL NOT NULL);
   CREATE TABLE IF NOT EXISTS preferences(user_id INTEGER NOT NULL,name TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(user_id,name));
  ''')
  self.initialize_projects()
 def connect(self):
  c=sqlite3.connect(self.db,timeout=15);c.row_factory=sqlite3.Row;return c
 def chats(self,uid):
  with self.connect() as c:return [dict(x) for x in c.execute('SELECT id,title,created,updated,project_id,mode FROM conversations WHERE user_id=? AND archived=0 ORDER BY updated DESC LIMIT 80',(uid,))]
 def create_chat(self,uid,title='New conversation',project_id=None,mode='chat'):
  if project_id:self.project(uid,project_id)
  if mode not in {'chat','work','beast'}:raise ValueError('Choose Chat, Work or Beast.')
  now=time.time();row=dict(id=ident(),title=title[:100] or 'New conversation',created=now,updated=now,project_id=project_id,mode=mode)
  with self.connect() as c:c.execute('INSERT INTO conversations(id,user_id,title,created,updated,project_id,mode) VALUES(?,?,?,?,?,?,?)',(row['id'],uid,row['title'],now,now,project_id,mode))
  return row
 def chat(self,uid,cid):
  with self.connect() as c:
   row=c.execute('SELECT id,title,created,updated,project_id,mode FROM conversations WHERE id=? AND user_id=? AND archived=0',(cid,uid)).fetchone()
   if not row:raise KeyError('Conversation not found.')
   messages=[{**dict(m),'metadata':json.loads(m['metadata'])} for m in c.execute('SELECT id,role,content,created,metadata FROM messages WHERE conversation_id=? ORDER BY created',(cid,))]
  return {**dict(row),'messages':messages}
 def add(self,uid,cid,role,content,metadata=None):
  with self.connect() as c:
   if not c.execute('SELECT 1 FROM conversations WHERE id=? AND user_id=? AND archived=0',(cid,uid)).fetchone():raise KeyError('Conversation not found.')
   now=time.time();mid=ident();c.execute('INSERT INTO messages VALUES(?,?,?,?,?,?)',(mid,cid,role,content,now,json.dumps(metadata or {})))
   c.execute('UPDATE conversations SET updated=? WHERE id=?',(now,cid))
   if role=='user':c.execute("UPDATE conversations SET title=? WHERE id=? AND title='New conversation'",(' '.join(content.split())[:64],cid))
  return {'id':mid,'role':role,'content':content,'metadata':metadata or {}}
 def edit_chat(self,uid,cid,title=None,archive=False):
  with self.connect() as c:
   if archive:r=c.execute('UPDATE conversations SET archived=1 WHERE id=? AND user_id=?',(cid,uid))
   else:
    if not isinstance(title,str) or not title.strip() or len(title)>100:raise ValueError('Use a title up to 100 characters.')
    r=c.execute('UPDATE conversations SET title=? WHERE id=? AND user_id=?',(title.strip(),cid,uid))
   if not r.rowcount:raise KeyError('Conversation not found.')
 def skills(self,uid):
  with self.connect() as c:rows=[dict(r) for r in c.execute('SELECT s.* FROM skills s LEFT JOIN plugins p ON s.plugin_id=p.id WHERE s.user_id=? AND (s.plugin_id IS NULL OR p.enabled=1) ORDER BY s.created DESC',(uid,))]
  return [{**s,'builtin':True,'source':'SYnerGY'} for s in BUILTIN_SKILLS]+[{**s,'builtin':False} for s in rows]
 def get_skill(self,uid,sid):
  return next((s for s in self.skills(uid) if s['id']==sid),None)
 def save_skill(self,uid,data):
  name=data.get('name');instructions=data.get('instructions');description=data.get('description','')
  if not isinstance(name,str) or not 1<=len(name.strip())<=80 or not isinstance(instructions,str) or not 1<=len(instructions.strip())<=16000:raise ValueError('Add a name (80 characters) and instructions (16,000 characters maximum).')
  item={'id':ident(),'name':name.strip(),'description':str(description)[:240],'instructions':instructions.strip(),'source':str(data.get('source','Personal skill'))[:600],'plugin_id':data.get('plugin_id'),'created':time.time()}
  with self.connect() as c:
   if item['plugin_id'] and not c.execute('SELECT 1 FROM plugins WHERE id=? AND user_id=?',(item['plugin_id'],uid)).fetchone():raise ValueError('Plugin not found in this account.')
   if c.execute('SELECT COUNT(*) FROM skills WHERE user_id=?',(uid,)).fetchone()[0]>=200:raise ValueError('Skill limit reached.')
   c.execute('INSERT INTO skills VALUES(?,?,?,?,?,?,?,?)',(item['id'],uid,item['name'],item['description'],item['instructions'],item['source'],item['plugin_id'],item['created']))
  return item
 def delete_skill(self,uid,sid):
  with self.connect() as c:
   if not c.execute('DELETE FROM skills WHERE id=? AND user_id=?',(sid,uid)).rowcount:raise KeyError('Skill not found.')
 def tool_enabled(self,uid,tool):
  with self.connect() as c:r=c.execute('SELECT value FROM preferences WHERE user_id=? AND name=?',(uid,'tool:'+tool)).fetchone()
  return r is None or r['value']=='true'
 def plugins(self,uid):
  with self.connect() as c:rows=[{**dict(r),'metadata':json.loads(r['metadata'])} for r in c.execute('SELECT * FROM plugins WHERE user_id=? ORDER BY created DESC',(uid,))]
  return [{**p,'enabled':self.tool_enabled(uid,p['id']),'status':'ready','source':'On this server'} for p in TOOLS]+[{**r,'builtin':False,'enabled':bool(r['enabled'])} for r in rows]
 def toggle(self,uid,pid,enabled):
  if type(enabled) is not bool:raise ValueError('Invalid plugin state.')
  with self.connect() as c:
   if pid in {p['id'] for p in TOOLS}:c.execute('INSERT OR REPLACE INTO preferences VALUES(?,?,?)',(uid,'tool:'+pid,json.dumps(enabled)))
   elif not c.execute('UPDATE plugins SET enabled=? WHERE id=? AND user_id=?',(int(enabled),pid,uid)).rowcount:raise KeyError('Plugin not found.')
 def save_plugin(self,uid,data):
  with self.connect() as c:
   old=c.execute('SELECT id FROM plugins WHERE user_id=? AND source=?',(uid,data['source'])).fetchone()
   if old:raise ValueError('This repository is already installed. Open it in Plugins.')
   if c.execute('SELECT COUNT(*) FROM plugins WHERE user_id=?',(uid,)).fetchone()[0]>=50:raise ValueError('Plugin limit reached.')
   pid=ident();c.execute('INSERT INTO plugins VALUES(?,?,?,?,?,?,?,?,?)',(pid,uid,data['name'][:80],data['description'][:400],data['source'],data['status'],1,json.dumps(data.get('metadata',{})),time.time()))
  return pid
