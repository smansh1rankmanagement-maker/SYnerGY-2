# SYnerGY Work mode 1.6.0 — verification

Tested 4 November 2026. This document records observed behaviour, not a claim of perfect quality or completion of every roadmap item.

## Deployment and preservation

The existing Mac app was upgraded from 1.5.2 to 1.6.0 at 11:23:53 UTC. The original source, SQLite database and app LaunchAgent were backed up to `work-v160-20261104-165352`. The same data directory is retained. Before the switch there were 2 users, 13 conversations and 38 messages. The deployment added Operations tables rather than replacing user data. A later health check confirmed version 1.6.0 and a current worker heartbeat. No paid infrastructure was activated.

Actual source is `v1.6.0`; app/model versions are distinct. Aerny v1.5 uses existing local Qwen weights. No model training occurred.

## Automated checks

`python3 -m unittest discover -s tests`: **88 tests passed** in 21.232 seconds. This includes the existing 70 regression checks plus Operations store/worker/API checks. JavaScript syntax checks passed for `static/app.js` and `static/operations.js`.

Coverage includes:

- Backend role checks and cross-brand/account denial, including file downloads.
- Brand revision approval invalidation and exact workflow-definition review hashes.
- Immutable definition versions, Asia/Kolkata weekly scheduling and a New York DST gap.
- Concurrent duplicate-trigger handling, scheduled catch-up, pause and event receipts.
- HMAC webhook validation, replay deduplication and expired/tampered requests.
- Worker state recovery, task/lead controls, opt-out retention and source-backed SEO extraction.
- Failed connections and robots exclusions without invented performance values.
- Actual child-process XLSX/PDF generation, readable PDF text, workbook tables/validation/formulas/caches and saved artifacts.
- Approval rejection on a mismatched hash; revised drafts generate a new run requiring review.
- HTTP auth/CSRF, two-account isolation, chat-created workflow drafts, activation, run execution, authenticated downloads and refused external-action execution.
- Retention cleanup preserving trigger receipts; obvious credential-pattern rejection.
- Brand deletion removes its temporary draft outputs as well as stored records and artifacts.

Tests simulate or isolate the cases above; the separate Mac acceptance results below are real processes and network requests. Timeout and retry limits are enforced by code, but the acceptance suite does not claim an exhaustive stress test of every failure mode or native Excel application.

## Real process-level acceptance on the Mac

The isolated script `scripts/verify-operations-macos.py` started only a scheduler/worker; the staging HTTP server was stopped, and no app browser tab was open. It used a separate QA database and no client account data.

| Check | Observed result |
| --- | --- |
| Scheduler without browser/HTTP | One-time schedule 4 Nov 16:49:52.169 IST / 11:19:52.169 UTC; worker started it at 11:19:52.335 UTC |
| Real run | `03efa3b20cb94988b6221b91aa4fa6ee`, completed with four saved files |
| Forced restart | Worker received SIGKILL during calendar work; orphan child exited; inputs, SEO and tasks kept their one committed attempt |
| Recovery | Replacement worker finished the remaining steps; four artifacts and one approval, without repeating committed work |
| Duplicate scheduler ticks | Two extra ticks left one execution for the scheduled trigger |
| Real crawl | Public example.com returned 200; robots.txt/sitemap returned 404; title, missing meta/H1/canonical observations recorded with URLs, timestamp and content hash |
| Pause/resume/cancel | Second QA run `62b54cc8e22949148ed85943c9532b8f` paused during a local-model step, resumed, then cancelled; no export artifacts were created |

The recovery phase deliberately disabled optional model drafting so the recovery assertion did not depend on response quality. The production run below used actual local inference. A single public HTML page test does not prove all-site crawl quality.

## Production InteriFY acceptance

The InteriFY workspace was created from the uploaded workflow document, pages 2 and 9, with its brief and assets explicitly pending approval and no inferred website permission. In the live Work chat, the request `Create a weekly automation for InteriFY Monday at 09:00` produced a draft definition. Its trigger, inputs, steps, approvals and outputs were reviewed in the UI before activation.

- Workspace `fa75618428b946aa9cbf8966d724fe54`.
- Workflow `14c487ef11f74f708f5fa0e310051cf1`, version 1, active.
- Weekly schedule: Monday 09:00 Asia/Kolkata; next after deployment 9 November 2026.
- Production run `ee27737879944d22960d434a8cdda594` completed in **38.83 seconds**.
- Actual local `aerny:v1.5` inference: **35.64 seconds**. It retained the supplied editorial draft wording in this example.
- Inputs and SEO: blocked for missing website authority and unapproved brief. Independent tasks/calendar/export/review/notification steps completed.
- Seven draft posts: 5–11 November 2026. Two input tasks and one pending artifact review.
- Four immutable files: XLSX, PDF, editable Markdown and JSON evidence. Their transferred bytes matched the original database SHA-256 hashes.

The right-side preview showed each step and authenticated file links. Reloading the app reopened the saved Work conversation and run. No InteriFY crawl, logo approval, publishing, email, advertisements, traffic or revenue results were claimed or performed.

## Export checks

All three PDF pages were rendered and visually inspected for clipping, fonts, layout and missing content. The report is readable and carries InteriFY's name with a SYnerGY footer. It does not apply an unapproved logo.

The actual production XLSX was imported into Artifact Tool and recalculated. Planned posts = 7, approved = 0, drafts = 7. Changing one status to Approved recalculated approved to 1 and drafts to 6; restoring it returned the baseline. The formula-error scan found no errors. Tables, typed dates, status validation and three sheets are present. Calendar, sources, SEO blocker and brand-input views were visually checked. The production file itself was not modified by the verification copy.

Browser-native download verification was interrupted by the browser connector timing out. Backend authenticated download responses and cross-account denial passed real HTTP tests. The original production artifact bytes were independently retrieved and checksum-verified. Any later browser-download check is recorded separately in the evidence archive.

## Evidence and source changes

The evidence archive contains the production run, process acceptance JSON, deployment receipt, test logs, spreadsheet recalculation evidence and the four actual production outputs. It excludes account databases, sessions, secrets and unrelated client data.

New code: `backend/operations/{catalog,store,seo,content,artifacts,execute,worker,routes}.py`; `static/operations.{js,css}`; XLSX template and builder; Mac deployment and acceptance scripts; Operations unit and HTTP tests. Integration changes are in `backend/server.py`, `backend/research/{net,service}.py`, `static/{app.js,index.html}` and the version assertion in existing backend tests. SHA-256 source inventory is regenerated in `SOURCE_SHA256.json`.

See `WORK_MODE_GUIDE.md` for feature status, dependency setup, backups, recovery and remaining work. The original requested prompt remains in `specifications/BRAND_OPERATIONS_USER_PROMPT.md`.
