# SYnerGY research upgrade · application 1.5.1

This release adds research to the existing Aerny v1.5 workspace. It is an application/tool upgrade, not model training. Inference stays on the configured Mac. No paid service, credit balance or subscription was added.

## Run and recover

On the installed Mac, open `http://127.0.0.1:8090/`. This address works on that Mac; it is not a public deployment.

The web app requires Python 3.12 and Pillow from the existing v1.5 web environment. Install `requirements-research.txt` into a separate target directory with `scripts/install-research-deps.sh`. Add that directory to the **web server's** `PYTHONPATH`. Keep `SYNERGY_STUDIO_WORKER_PATH`, `SYNERGY_IMAGE_PYTHON` and `SYNERGY_VIDEO_PYTHON` unchanged; image/video dependencies use a separate Python runtime.

Installed paths:

- Source: `/Users/a1989/Library/Application Support/SYnerGY/v1.5.1`
- Account and project data: `/Users/a1989/Library/Application Support/SYnerGY/v1.4-data`
- Web Python: `/Users/a1989/Library/Application Support/SYnerGY/runtime/managed-python/cpython-3.12.15-macos-x86_64-none/bin/python3.12`
- Research dependencies: `/Users/a1989/Library/Application Support/SYnerGY/runtime/research-deps`
- LaunchAgent: `/Users/a1989/Library/LaunchAgents/in.1rank.synergy-v14.plist`
- Logs: `v1.4-data/server.log` and `v1.4-data/server-error.log`

The historical LaunchAgent label is retained intentionally. To restart after an authorized configuration change:

```sh
launchctl kickstart -k "gui/$(id -u)/in.1rank.synergy-v14"
```

Normal termination cancels child workers. After an unexpected server restart, unfinished tasks are marked failed and can be retried in a new conversation branch. Reports, references and prior messages remain saved. A power failure or forced process kill is not a completed request.

A pre-upgrade backup contains the v1.5 source, an SQLite online backup and the previous LaunchAgent. Prefer restoring the previous LaunchAgent to roll back code while retaining the additive data tables. Restore the database only if you explicitly intend to discard work made after the backup. Never overwrite an active database. See `DEPLOYMENT_RESEARCH.json` for the actual backup path and deployment checks.

## Models and routing

| Selection | Actual configured Ollama identifier | Purpose |
|---|---|---|
| Balanced | `aerny:v1.5` | Existing profile based on Qwen3 4B Instruct 2507 Q4_K_M; default for retrieved evidence and document research |
| Fast | `aerny-fast:v1.5` | Existing Qwen3 0.6B profile; manual short prompts and automatic greetings only; weaker factual and language reliability |
| Vision | `qwen3-vl:2b-instruct` | Uploaded image understanding, including approximate text recognition |
| OpenAI | None configured | Disabled; no API call was made |
| Hybrid | Configured local models | External routing requires both administrator configuration and per-account permission |

The app displays the chosen identifier and routing reason in Activity, task evidence and Settings. Auto uses Balanced for substantive requests, including retrieved evidence and detected Hindi/Hinglish requests. Only short greetings use Fast automatically. Explicit arithmetic uses a bounded AST/Decimal calculator (28-digit precision), with no eval or arbitrary code execution. Explicit model choices are respected. No automatic model download or cloud fallback occurs.

External inference is disabled unless `OPENAI_API_KEY`, `SYNERGY_OPENAI_MODEL` and `SYNERGY_ALLOW_OPENAI=1` are intentionally configured and the account separately enables external AI. This release does not enable them. OpenAI streaming is implemented but untested against a live paid endpoint. Do not describe it as an active service.

| Effort | Context tokens | Maximum output tokens | Queries | Page budget | Evidence excerpt per source |
|---|---:|---:|---:|---:|---:|
| Instant | 4,096 | 512 | 1 | 3 | 2,200 characters |
| Medium | 8,192 | 1,200 | 2 | 4 | 3,200 characters |
| High | 8,192 | 1,800 | 3 | 6 | 4,200 characters |
| Max | 12,288 | 2,400 | 4 | 8 | 5,200 characters |
| Ultra | 16,384 | 3,200 | 5 | 10 | 6,500 characters |

Evidence excerpts are further bounded to fit context. Deep research/Beast uses at least three query slots and six page slots. Query count is a maximum, not a promise to make redundant queries. Chat answers the question; Work asks for a usable deliverable and completion criteria; Beast uses broader evidence budgets and comparison instructions. All modes save reports and keep the same privacy boundaries. Higher effort does not guarantee better accuracy.

## Components and licenses

| Component | Version | License | Use |
|---|---|---|---|
| DDGS | 9.6.1 | MIT | Public web search; Bing first, DuckDuckGo/Brave fallbacks |
| primp | 0.15.0 | MIT | Compatible DDGS transport; newer 2.x broke this pinned DDGS integration |
| Playwright | 1.56.0 | Apache-2.0 | A fresh headless Chrome context per inspection |
| Installed Google Chrome | Existing Mac installation | Google's installed-browser terms | Browser executable; not redistributed |
| pypdf | 6.21.4 | BSD-3-Clause | PDF text and page extraction |
| python-docx | 1.2.0 | MIT | DOCX paragraphs and tables |
| openpyxl | 3.1.5 | MIT | XLSX values and sheet/row locations |
| Python standard library | Python 3.12 | Python license | HTTP server, SQLite, page text reader, text/code/CSV handling |
| Pillow | Existing web environment | HPND | Validate uploaded PNG/JPEG files |

Package notices are under `backend/THIRD_PARTY_NOTICES/research`. Search availability depends on third-party public endpoints and may change. No search API key is required. Google Search and the user's existing Chrome session are not connected to the application.

## Research and privacy

Use Web Auto, Search the web, or Search off. Search off disables search-engine queries; explicitly supplied URLs and attached inspections can still be read. Disable public web access in Settings to block both search and page reads. Search options accept domains and day/week/month/year filters. Auto is a heuristic, not a guarantee of perfect question classification; choose Search the web when verification is required. The search client uses its standard English region after the previous region returned unrelated results in live testing. Domain matching is enforced on returned results. Date filters are search-engine hints, not proof of a page's publication date. Publication metadata and retrieval time remain separate.

Search results remain snippets until a real page read succeeds. The reader follows validated redirects, reads text/HTML and supported PDF content, records a content hash, and follows topical links within the page budget. Unsupported, blocked and sign-in pages are labelled. It does not bypass access controls. Evidence excerpts and find-in-source controls are in Sources. Reports and tool evidence can be downloaded from Output or each completed reply.

Private uploads and relevant saved notes disable automatic search. Searching with private context requires the explicit account setting; this can send the user's query to search providers. File bodies are not submitted to search. External AI remains independently disabled by default. Preferences, notes, files, conversation context and research evidence have separate database records. Notes can be edited/deleted; original uploads can be downloaded/deleted. Deleting an upload does not erase copies already quoted in conversation answers/reports. Conversations are archived, not irreversibly purged.

Citation IDs and explicit PDF page references are checked and linked. These are structural checks, **not semantic proof** that each claim is true. Models can still misread text or infer unsupported limitations. Review source excerpts and original documents. Initial Fast-model acceptance runs showed factual mistakes; these failures are recorded, and Balanced is the research default. Hindi/Hinglish quality remains limited by the installed model.

## Browser inspection boundaries

The browser is isolated and has no access to the user's everyday Chrome tabs, passwords, cookies or extensions. A disposable context is closed after each task. Public URLs only; DNS is resolved and pinned by a local proxy, each request is checked, and private/metadata addresses are blocked. Test-only origins are enabled solely in staging through `SYNERGY_RESEARCH_TEST_ORIGINS`; the production LaunchAgent does not include this exception.

The service supports page reads, screenshots, DOM/accessibility snapshots, explicit click/type/scroll/wait actions, small downloads, console errors, network failures/statuses, redirects, cookie metadata and timing. The UI supports attaching a URL and an explicitly authorized button test. The API supports up to eight explicit actions. It does not execute model-invented browser actions.

Only GET/HEAD requests are allowed; sign-in, credential entry, purchases, publishing and other consequential actions are blocked. These restrictions can alter site behaviour and are recorded. It cannot debug an authenticated production account without a separately designed and approved integration. Cookie values and recognized credential assignments/emails are redacted. Input/textarea/private elements are masked in screenshots. Redaction is best-effort; review diagnostics before sharing.

Browser summaries are constructed from captured evidence rather than model guesses. They distinguish JavaScript errors, HTTP failures, CORS, visible text changes and completed downloads. They do not claim a backend cause from page evidence alone. Screenshots and logs are available in Preview. Repository checkout, source modification, server-log access and arbitrary command execution are **not** application capabilities in this release. The supplied broken-button acceptance fixture was fixed by the developer and then re-inspected by the app.

## File limits

- One attachment per request; originals retained per account. Maximum 8 MB.
- PDF: first 50 pages; text extraction only. Scanned PDFs need an OCR pipeline that is not installed.
- DOCX: paragraphs/tables; page layout, drawings, tracked changes, headers and text boxes are partial.
- XLSX: first eight sheets, 1,000 rows and 30 columns per sheet; cached formula values only. No macros/formula execution.
- UTF-8 TXT/MD/CSV/source code: line ranges, up to 120,000 extracted characters; 12,000 per section.
- PNG/JPEG: up to 24 megapixels; local Vision transcription is approximate, without OCR bounding boxes or confidence calibration.
- Relevant extracted sections are selected for context. The interface warns when only part of a document is used.
- Parser subprocess: 30-second timeout and a best-effort memory limit. Search, reads, browser jobs and model jobs have bounded deadlines. Cancellation terminates app child workers; cached Ollama model runners may remain loaded briefly.

## Verification

Run local regression tests with `python -m unittest discover -s tests -v`. Test-only dependencies include ReportLab, Pillow, python-docx and openpyxl. `tests/acceptance_research_mac.py` uses staging port 8091 and synthetic fixtures. `tests/acceptance_research_extra.py` adds language, cookie, CORS, download and cancellation checks. Never point these fixtures at a production account/database.

`RESEARCH_VERIFICATION.md` records observed timings, errors, human review and feature status. The evidence archive includes task JSON/reports and synthetic fixture results. It contains no production passwords, API keys or user documents.

Automated Chrome file-picker testing was blocked by the ChatGPT browser extension's file-URL permission. Uploads and original downloads were tested through the app API; the UI was tested by reopening and editing a conversation with a saved upload. The blocked automation does not establish that normal manual file selection is broken.

To enable file upload, open chrome://extensions, click Details under the ChatGPT browser extension, and enable "Allow access to file URLs." See [here](https://developers.openai.com/codex/app/chrome-extension#upload-files) for details.
