# Workspace upgrade verification · 4 November 2026

## Current build

- Seventeen automated tests passed after the final runtime change. Coverage includes accounts, sessions, isolation, conversation persistence, all five response budgets, selected skill injection, commit-pinned GitHub bundle imports with linked Markdown references, unsupported repositories, reference handoff to workers, result ownership and interrupted jobs. Worker fixtures are distinguished from the real runs below.
- Browser checks on the connected Mac verified Home/recents, Plugins, Skills, Chat/Work/Beast selectors, the response-level selector beside Send, the + menu, conversation rename, reload persistence of messages/mode/level/skill, and image reuse as a video reference.
- A pasted SKILL.md was installed through chat. Aerny used it to return the requested three concise launch actions.
- A real public GitHub bundle import of `anthropics/skills/tree/main/skills/internal-comms` succeeded, pinned to commit `ca45fc496a3436251f191354091d557da31c15b5`. Its instructions and Markdown examples were stored locally, appeared in Plugins/Skills, and influenced a live reply. Executable plugin connectors were not installed.
- Browser playback of the enhanced video reached 2.0 seconds with no media error. Its downloaded file matched the worker output by SHA-256.
- The mobile sidebar and composer worked without horizontal overflow at the tested narrow browser width (487 CSS pixels after the browser's zoom scaling). The viewport override was restored afterwards.

## Fresh quality runs

| Output | Native synthesis | Export | Worker time |
| --- | --- | --- | --- |
| Enhanced image | epiCRealism, 768×432, 28 steps, DPM++ 2M Karras; verified Real-ESRGAN refinement | PNG, 1920×1080 | 649.56 s |
| Enhanced video | epiCRealism + AnimateDiff-Lightning; 640×360; 16 model frames at 8 fps | H.264 MP4, 1920×1080, 2 s, 24 fps after optical-flow interpolation | 1083.27 s |

The real jobs ran through the upgraded inference workers in an isolated validation folder, then their verified outputs were registered in the existing account's recent creations. They were not fabricated placeholder media. The browser preview uses those real files. All 48 exported video frames decoded; mean adjacent pixel difference was 1.064 on an 8-bit RGB scale. MP4 SHA-256: `a57fed5bda8ab8d068196423f61b3ca9ac51411abd104ba82a481e6b7b5bbb37`.

The new image has clearer texture and a lighter room, but imperfect prompt adherence: the armchairs are cream rather than the requested orange. The new video fills the landscape frame and shows plausible orange furniture; motion remains subtle. These checks do not establish general character preservation or cinematic motion. No human-character identity test was performed. 1080p/4K are enlarged exports, not native synthesis. The upgraded 4K and portrait paths were not rerun with a real model in this check.

## Remaining limits

CPU generation is slow. Video duration is two seconds. The workspace has no streaming/Stop, arbitrary MCP runtime, automatic tool execution by the chat model, autonomous browsing or model-weight training. The + file picker and image-reuse control are implemented; file parsing/reference plumbing has automated coverage, while fresh vision-chat inference was not evaluated. Imported instructions can affect output quality; the first internal-comms reply added unsupported template details, so the base response instructions were tightened to require plain prose and no invented fields. A subsequent live reply returned exactly the three supplied facts in plain sentences. Conversations and their sources remain available for review.

The original user browser tab was preserved. The updated preview is open in a separate tab. Backups of the prior source, image manifest and SQLite data were taken before deployment. Account data, model weights and private runtime configuration remain outside the source ZIP.

---

# Previous-build evidence (before this upgrade)

The entries below describe earlier builds; the current-build findings above supersede their missing-feature notes.

# Verification · 4 November 2026

## Connected Intel Mac

- Ollama profile `aerny:v1.4` was created from the installed Qwen3 4B Instruct model. Live website chat returned “AeRny v1.4 is connected.”
- Username/password registration, login, logout, session persistence after refresh, and all three mode controls passed real Chrome browser checks.
- Knowledge notes passed save/delete and per-account isolation checks.
- The original orange wordmark checksum matched the packaged artwork. Sign-in, desktop workspace, video studio and result screenshots were visually reviewed.

## Real generation

| Path | Output | Native render | Worker time | Verification |
| --- | --- | --- | --- | --- |
| Text to image | PNG, 1920×1080 | 680×384, 12 steps | 238.95 s | Red mug output visually reviewed |
| Text to video | MP4, 3840×2160 | 384×384, 8 frames, 4 fps, 4 steps | 393.41 s | Mountains visible in first/middle/last frames; output decoded; frames differ |
| Reference image to video | MP4, 1920×1080 | 384×384, 8 frames, 4 fps, 2 effective denoising steps | 309.87 s | Red mug reference submitted in browser; output visually reviewed; playback and authenticated download passed |

Both videos are two seconds long. The successful video engine uses the pinned, checksum-verified epiCRealism base and AnimateDiff-Lightning 4-step motion adapter. Content checking remains enabled. Earlier experimental SD1.5/256-pixel video results were rejected during quality review; that configuration was replaced.

## Application checks

- Reference image upload and removal.
- Generation resumes polling after page refresh.
- Starting a new conversation keeps the active generation.
- Mobile results can be opened, closed and reopened; progress updates do not reopen a closed panel.
- Completed video is available after logout and login, with an authenticated MP4 download.
- Browser JavaScript exception collection passed.
- Ten automated tests passed in 13.563 seconds. They cover authentication, session invalidation, origin checks, account isolation, references, job ownership and interrupted jobs. Media plumbing tests use fake workers; the live inference checks above are separate.
- Test HTTP waits were raised to 30 seconds after scheduling-related timeouts in the shared test runner. Assertions and production timeouts were unchanged.

## Practical limits

- This is a local Mac website at http://127.0.0.1:8090. It requires the Mac and local services to be running. The earlier hosted preview does not connect to this backend.
- 1080p and 4K are enlarged exports, not native inference resolutions. Exact character preservation is not guaranteed.
- CPU generation takes minutes. The current video configuration produces short, low-frame-rate clips.
- AeRny v1.4 is a configured pretrained assistant profile. Knowledge notes provide retrieval; they do not train foundation weights or enable autonomous web learning.
- The package contains source and model references, not model weights, account data, credentials or generated media.

## Fresh browser retest and preview-label repair

- Re-ran all 10 automated checks: passed in 2.295 seconds.
- Live Work-mode chat returned the requested three-point checklist.
- New interior PNG: 1920×1080 enlarged from 680×384; 211.72 seconds worker time. Prompt fidelity was partial (extra chair and darker walls).
- New interior text-to-video: 1920×1080, eight 384×384 native frames, four fps, two seconds; 311.84 seconds worker time. All eight frames decoded and differed; motion was very subtle. Browser playback reached the end without error.
- Both browser downloads matched their generated files byte-for-byte by SHA-256.
- Refresh retained the signed-in session and resumed a running video. Chat messages did not survive refresh; conversation persistence is still missing.
- Fixed a saved-image preview label showing “Your undefined is ready.” Legacy image jobs omit `kind`; the frontend now defaults such jobs to image when rendering them. JavaScript syntax check passed.
- Current Browser extension reference-upload retest was blocked by its file-transfer permission/setup; earlier release reference results are separate evidence.
