#!/usr/bin/env python3
"""Real local worker/LLM lifecycle validation in a separate disposable database."""
import argparse,json,os,signal,sqlite3,subprocess,sys,time
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from beast.store import Beast
from beast.worker import Worker

def until(fn,seconds=30):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  value=fn()
  if value:return value
  time.sleep(.3)
 raise AssertionError('Timed out waiting for the validation condition.')
def child_pids(pid):
 r=subprocess.run(['pgrep','-P',str(pid)],capture_output=True,text=True)
 return [int(x) for x in r.stdout.split() if x.isdigit()]
def dead(pid):
 r=subprocess.run(['ps','-p',str(pid),'-o','stat='],capture_output=True,text=True)
 return r.returncode!=0 or not r.stdout.strip() or r.stdout.strip().startswith('Z')
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path,required=True);args=parser.parse_args();data=args.data
 assert not data.exists(),'Use a new validation directory; never point this at application data.'
 data.mkdir(parents=True,mode=0o700);b=Beast(data/'accounts.sqlite3',data/'beast');p=b.create(1,{'name':'Worker acceptance','template':'python'});evidence={'database':'isolated validation database','started':time.time(),'model':'aerny:v1.5','browser_required':False};workers=[]
 def launch():
  with (data/'worker.log').open('ab') as out:w=subprocess.Popen([sys.executable,str(Path(__file__).resolve().parents[1]/'backend/beast/worker.py'),'--data',str(data)],stdout=out,stderr=out,start_new_session=True)
  workers.append(w);return w
 try:
  request={'project_id':p['id'],'revision':1,'prompt':'Add a one-line docstring to greet explaining that it returns a greeting. Preserve every other line. Keep summary and notes short.','paths':['main.py'],'effort':'medium','idempotency_key':'restart-acceptance'}
  j=b.submit(1,request);w=launch();until(lambda:b.job(1,j['id'])['state']=='running');children=until(lambda:child_pids(w.pid));os.kill(w.pid,signal.SIGKILL);w.wait();until(lambda:all(dead(x) for x in children),10)
  w=launch();done=until(lambda:b.job(1,j['id']) if b.job(1,j['id'])['state'] in {'awaiting_review','completed','failed'} else None,420)
  assert done['state']=='awaiting_review',done.get('error');assert done['attempt']==2;assert b.project(1,p['id'])['revision']==1
  duplicate=b.submit(1,request);assert duplicate['id']==j['id']
  applied=b.job_action(1,{'id':j['id'],'action':'apply','revision':1,'reviewed_hash':done['result']['hash']});assert applied['result']['applied_revision']==2
  evidence['restart']={'job_id':j['id'],'state':done['state'],'attempts':done['attempt'],'orphan_client_terminated':all(dead(x) for x in children),'duplicate_request_same_job':True,'revision_before_review':1,'revision_after_apply':2,'model':done['result']['selection'],'checks':done['result']['checks'],'elapsed':done['result']['elapsed']}
  c=b.submit(1,{**request,'revision':2,'prompt':'Write a long but focused explanation of all code paths. Do not modify files.','task_mode':'explain','idempotency_key':'cancel-acceptance'});until(lambda:b.job(1,c['id'])['state']=='running');cancel_children=until(lambda:child_pids(w.pid));b.job_action(1,{'id':c['id'],'action':'cancel'});until(lambda:all(dead(x) for x in cancel_children),10)
  assert b.job(1,c['id'])['state']=='cancelled';assert b.project(1,p['id'])['revision']==2
  evidence['cancel']={'job_id':c['id'],'state':'cancelled','client_terminated':True,'revision_unchanged':2}
  os.kill(w.pid,signal.SIGTERM);w.wait(timeout=8)
  bad=b.submit(1,{**request,'revision':2,'idempotency_key':'failure-acceptance'});worker=Worker(b);claimed=worker.claim()
  with patch('beast.worker.model_router.route',return_value={'provider':'synergy','model':'synergy-nonexistent-validation-model','label':'Unavailable validation model','reason':'Real failure test'}):worker.process(claimed)
  failed=b.job(1,bad['id']);assert failed['state']=='failed';assert b.project(1,p['id'])['revision']==2;evidence['failure']={'job_id':bad['id'],'state':failed['state'],'error':failed['error'],'revision_unchanged':2}
  evidence['finished']=time.time();evidence['passed']=True;(data/'evidence.json').write_text(json.dumps(evidence,indent=2));print(json.dumps(evidence))
 finally:
  for w in workers:
   if w.poll() is None:w.terminate();w.wait(timeout=8)
if __name__=='__main__':main()
