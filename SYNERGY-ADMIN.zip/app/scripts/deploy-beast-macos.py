#!/usr/bin/env python3
"""Back up the current app and add a loopback-only Beast proposal worker."""
import argparse,datetime,json,os,plistlib,shutil,sqlite3,subprocess,time,urllib.request
from pathlib import Path

def start(domain,plist):
 deadline=time.monotonic()+20;error=''
 while time.monotonic()<deadline:
  r=subprocess.run(['launchctl','bootstrap',domain,str(plist)],capture_output=True,text=True)
  if r.returncode==0:return
  error=r.stderr.strip();time.sleep(.5)
 raise RuntimeError('LaunchAgent could not start: '+error)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--source',required=True,type=Path);args=parser.parse_args();source=args.source.resolve()
 base=Path.home()/'Library/Application Support/SYnerGY';agents=Path.home()/'Library/LaunchAgents';app_path=agents/'in.1rank.synergy-v14.plist';ops_path=agents/'in.1rank.synergy-operations.plist';beast_path=agents/'in.1rank.synergy-beast.plist'
 original={p:p.read_bytes() if p.exists() else None for p in [app_path,ops_path,beast_path]};assert original[app_path] and original[ops_path],'The working SYnerGY app and Work scheduler must exist.'
 cfg=plistlib.loads(original[app_path]);ops=plistlib.loads(original[ops_path]);data=Path(cfg['EnvironmentVariables']['SYNERGY_DATA_DIR']);python=cfg['ProgramArguments'][0];db=data/'accounts.sqlite3';previous=Path(cfg['ProgramArguments'][1]).parent.parent
 assert (source/'backend/beast/worker.py').is_file() and (source/'static/beast.js').is_file(),'The new source is incomplete.'
 assert source!=previous,'Use a versioned source directory; preserve the prior version.'
 check_env=os.environ.copy();check_env.update(cfg['EnvironmentVariables']);check_env['PYTHONPATH']=str(source/'backend')+os.pathsep+check_env.get('PYTHONPATH','')
 subprocess.run([python,'-c','from beast.safety import validate_files; from beast.checks import run_checks; from beast.preview import render; import PIL, reportlab'],cwd=source,env=check_env,check=True)
 with sqlite3.connect(db) as c:
  names={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
  for t in ['research_tasks','studio_jobs','ops_runs','beast_jobs']:
   if t in names:assert c.execute('SELECT count(*) FROM '+t+" WHERE state IN ('queued','running')").fetchone()[0]==0,'Wait for active '+t+' tasks.'
  for kind in ['image','video']:
   for f in (data/kind).rglob('job.json'):assert json.loads(f.read_text()).get('state') not in {'queued','running','cancelling'},'Wait for active media jobs.'
  backup=base/'backups'/('beast-v170-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));backup.mkdir(parents=True,mode=0o700)
  with sqlite3.connect(backup/'accounts.sqlite3') as dest:c.backup(dest)
  os.chmod(backup/'accounts.sqlite3',0o600)
  counts={t:c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in ['users','conversations','messages','ops_workflows','ops_runs','ops_artifacts']}
 for p,raw in original.items():
  if raw:(backup/p.name).write_bytes(raw);os.chmod(backup/p.name,0o600)
 shutil.copytree(previous,backup/'source',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 cfg['ProgramArguments'][1]=str(source/'backend/server.py');cfg['WorkingDirectory']=str(source)
 ops['ProgramArguments'][1]=str(source/'backend/operations/worker.py');ops['WorkingDirectory']=str(source)
 beast={'Label':'in.1rank.synergy-beast','ProgramArguments':[python,str(source/'backend/beast/worker.py'),'--data',str(data)],'WorkingDirectory':str(source),'EnvironmentVariables':cfg['EnvironmentVariables'],'RunAtLoad':True,'KeepAlive':True,'ThrottleInterval':10,'StandardOutPath':str(base/'beast-worker.log'),'StandardErrorPath':str(base/'beast-worker-error.log')}
 configs={app_path:cfg,ops_path:ops,beast_path:beast};domain='gui/'+str(os.getuid())
 for p in configs:
  if original[p]:subprocess.run(['launchctl','bootout',domain+'/'+plistlib.loads(original[p])['Label']],capture_output=True,check=True)
 try:
  for p,value in configs.items():p.write_bytes(plistlib.dumps(value));os.chmod(p,0o600);start(domain,p)
  deadline=time.monotonic()+35;ready=False
  while time.monotonic()<deadline:
   try:
    health=json.load(urllib.request.urlopen('http://127.0.0.1:8090/api/auth/config',timeout=2))
    with sqlite3.connect(db) as c:
     heartbeats=[c.execute('SELECT heartbeat FROM '+t+" WHERE id='local'").fetchone() for t in ['beast_worker','ops_worker']]
     after={t:c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in counts}
    if health.get('version')=='1.7.0' and all(h and time.time()-h[0]<12 for h in heartbeats):ready=True;break
   except Exception:pass
   time.sleep(.4)
  assert ready,'The app and independent workers did not become healthy.'
  assert after==counts,'Existing record counts changed during deployment.'
 except BaseException:
  for value in configs.values():subprocess.run(['launchctl','bootout',domain+'/'+value['Label']],capture_output=True)
  for p,raw in original.items():
   if raw:p.write_bytes(raw);start(domain,p)
   else:p.unlink(missing_ok=True)
  raise
 result={'version':'1.7.0','model':'Aerny v1.5; existing weights unchanged','source':str(source),'previous_source':str(previous),'data':str(data),'backup':str(backup),'url':'http://127.0.0.1:8090/','workers':['in.1rank.synergy-operations','in.1rank.synergy-beast'],'counts_before':counts,'counts_after':after,'deployed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (source/'DEPLOYMENT_BEAST.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
if __name__=='__main__':main()
