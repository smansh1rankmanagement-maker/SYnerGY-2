#!/usr/bin/env python3
"""Isolated process-level verification. Never uses a customer database."""
import datetime as dt,json,os,signal,sqlite3,subprocess,sys,time
from pathlib import Path
from zoneinfo import ZoneInfo
source=Path(__file__).resolve().parents[1];sys.path.insert(0,str(source/'backend'))
from operations.store import Operations
base=Path.home()/'Library/Application Support/SYnerGY';data=base/('operations-validation-'+str(int(time.time())));data.mkdir(mode=0o700)
with sqlite3.connect(data/'accounts.sqlite3') as c:c.execute('CREATE TABLE users(id INTEGER PRIMARY KEY,username TEXT)');c.execute("INSERT INTO users VALUES(1,'isolated-qa')")
o=Operations(data/'accounts.sqlite3',data/'operations');evidence={'data':str(data),'started_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'tests':[]};worker=None

def save(): (base/'operations-process-evidence.json').write_text(json.dumps(evidence,indent=2))
def start(ai='0'):
 env=os.environ.copy();env['SYNERGY_OPERATIONS_AERNY']=ai
 log=(data/'worker.log').open('ab');return subprocess.Popen([sys.executable,str(source/'backend/operations/worker.py'),'--data',str(data)],env=env,stdout=log,stderr=log,start_new_session=True)
def wait_for(fn,seconds=120):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  v=fn()
  if v:return v
  time.sleep(.2)
 raise TimeoutError('Expected process state was not reached.')
def running_calendar(rid):return any(x['key']=='calendar' and x['state']=='running' for x in o.run(1,rid)['steps'])
def stop(p,sig=signal.SIGTERM):
 if p and p.poll() is None:p.send_signal(sig);p.wait(timeout=5)
def record(name,**kw):evidence['tests'].append({'test':name,'passed':True,**kw});save()
try:
 # No HTTP server or browser is needed. This service does not start either.
 b=o.save_brand(1,{'name':'Public example QA','config':{'brief':'Isolated testing of a public example website. No client data.','source':'Test fixture created by verification script','website':'https://example.com','website_authorized':True}})
 o.approve_brand(1,b['id'],b['revision'])
 when=dt.datetime.now(ZoneInfo('Asia/Kolkata'))+dt.timedelta(seconds=4)
 w=o.save_workflow(1,{'brand_id':b['id'],'name':'Isolated scheduled QA','schedule':{'kind':'once','timezone':'Asia/Kolkata','at':when.isoformat()}})
 w=o.workflow_action(1,w['id'],{'action':'activate','reviewed_hash':w['hash']});worker=start('1')
 def scheduled():
  with o.connect() as c:
   r=c.execute('SELECT id FROM ops_runs WHERE workflow_id=?',(w['id'],)).fetchone();return r[0] if r else None
 rid=wait_for(scheduled);wait_for(lambda:running_calendar(rid))
 before=o.run(1,rid);attempts={s['key']:s['attempts'] for s in before['steps'] if s['state'] in {'complete','blocked'}}
 child=subprocess.run(['pgrep','-P',str(worker.pid)],capture_output=True,text=True).stdout.split()
 stop(worker,signal.SIGKILL);time.sleep(1.2)
 alive=[]
 for pid in child:
  r=subprocess.run(['ps','-p',pid,'-o','stat='],capture_output=True,text=True)
  if r.stdout.strip() and not r.stdout.strip().startswith('Z'):alive.append(pid)
 assert not alive,'Orphan step survived parent termination'
 worker=start('0');finished=wait_for(lambda:(r if (r:=o.run(1,rid))['state'] in {'completed','completed_with_blockers','failed'} else None))
 assert finished['state']!='failed',finished['steps']
 assert all(next(s for s in finished['steps'] if s['key']==k)['attempts']==v for k,v in attempts.items())
 assert len(finished['artifacts'])==4 and len(finished['approvals'])==1
 record('scheduler_without_browser_or_http',run_id=rid,scheduled_local=when.isoformat(),scheduled_utc=when.astimezone(dt.timezone.utc).isoformat(),started_utc=dt.datetime.fromtimestamp(finished['started'],dt.timezone.utc).isoformat(),state=finished['state'])
 record('SIGKILL_restart_recovery',run_id=rid,committed_steps=attempts,orphan_steps_alive=alive,artifacts=4,approval_count=1)
 o.tick();o.tick()
 with o.connect() as c:count=c.execute('SELECT count(*) FROM ops_runs WHERE workflow_id=?',(w['id'],)).fetchone()[0]
 assert count==1;record('duplicate_scheduler_tick',run_count=count)
 seo=next(s['result'] for s in finished['steps'] if s['key']=='seo');record('real_public_website_audit',result=seo)
 stop(worker);worker=start('1');r=o.enqueue(1,w['id'],'pause-cancel');rid2=r['id'];wait_for(lambda:running_calendar(rid2))
 o.run_action(1,rid2,'pause');wait_for(lambda:not running_calendar(rid2));assert o.run(1,rid2)['state']=='paused';record('pause_during_local_model_step',run_id=rid2)
 o.run_action(1,rid2,'resume');wait_for(lambda:running_calendar(rid2));o.run_action(1,rid2,'cancel');wait_for(lambda:not running_calendar(rid2));r=o.run(1,rid2);assert r['state']=='cancelled' and len(r['artifacts'])==0;record('resume_and_cancel_during_step',run_id=rid2,artifacts=0)
 evidence['passed']=True
except Exception as exc:evidence['passed']=False;evidence['error']=str(exc);raise
finally:
 stop(worker);evidence['finished_utc']=dt.datetime.now(dt.timezone.utc).isoformat();save()
print(json.dumps({'passed':evidence['passed'],'tests':[x['test'] for x in evidence['tests']],'evidence':str(base/'operations-process-evidence.json')}))
