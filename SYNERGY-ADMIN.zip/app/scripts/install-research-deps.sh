#!/bin/sh
# Use the web server Python, never the image/video environment.
set -eu
: "${SYNERGY_WEB_PYTHON:?Set SYNERGY_WEB_PYTHON to the Python 3.12 executable}"
: "${SYNERGY_RESEARCH_DEPS:?Set SYNERGY_RESEARCH_DEPS to a dedicated directory}"
"$SYNERGY_WEB_PYTHON" -m pip install --target "$SYNERGY_RESEARCH_DEPS" --upgrade -r "$(dirname "$0")/../requirements-research.txt"
printf '%s\n' 'Research dependencies installed. Add this directory to the web server PYTHONPATH.'
