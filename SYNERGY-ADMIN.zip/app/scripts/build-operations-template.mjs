import fs from "node:fs/promises";
import {Workbook,SpreadsheetFile} from "@oai/artifact-tool";
const outputDir="/workspace/scratch/1971dd3650c1/outputs/synergy-work-mode";
await fs.mkdir(outputDir,{recursive:true});
const wb=Workbook.create();
const cal=wb.worksheets.add("Calendar"),tasks=wb.worksheets.add("SEO tasks"),brief=wb.worksheets.add("Brand inputs");
for(const sh of [cal,tasks,brief]){sh.showGridLines=false;sh.getRange("A1:L60").format.font={name:"Arial",size:10,color:"#252B29"};sh.getRange("A1:L60").format.verticalAlignment="center";}
function title(sh,txt,last){sh.getRange("A2").values=[[txt]];sh.getRange("A2").format.font={name:"Arial",size:16,bold:true};sh.getRange("A3:"+last+"3").format.borders={bottom:{style:"thin",color:"#DA6331"}};}
function head(sh,range){sh.getRange(range).format={fill:"#29332D",font:{name:"Arial",size:10,bold:true,color:"#FFFFFF"},horizontalAlignment:"center",verticalAlignment:"center",wrapText:true,rowHeight:30};}
title(cal,"Seven-day content calendar","L");cal.getRange("A4").values=[["Planned posts"]];cal.getRange("B4").formulas=[['=COUNTA(D8:D14)']];cal.getRange("C4").values=[["Approved"]];cal.getRange("D4").formulas=[['=COUNTIF(I8:I14,"Approved")']];cal.getRange("E4").values=[["Drafts"]];cal.getRange("F4").formulas=[['=COUNTIF(I8:I14,"Draft")']];cal.getRange("A5").values=[["Publishing remains pending until the exact version is approved and a connection is authorised."]];
cal.getRange("A7:L7").values=[["Date","Channel","Format","Topic","Caption draft","Creative brief","Call to action","Owner","Status","Source","UTM URL","Notes"]];head(cal,"A7:L7");
cal.getRange("A8:L14").values=Array.from({length:7},()=>[null,"","","","","","","Unassigned","Draft","","",""]);
cal.tables.add("A7:L14",true,"ContentCalendar").style="TableStyleLight8";cal.freezePanes.freezeRows(7);cal.freezePanes.freezeColumns(1);
for(const [column,width] of Object.entries({A:15,B:22,C:22,D:25,E:55,F:50,G:30,H:18,I:18,J:45,K:35,L:35}))cal.getRange(column+"1:"+column+"14").format.columnWidth=width;
cal.getRange("A8:A14").setNumberFormat("dd mmm yyyy");cal.getRange("A8:L14").format.wrapText=true;cal.getRange("A8:L14").format.rowHeight=104;
cal.getRange("H8:I14").format.fill="#FFF2CC";cal.getRange("I8:I14").dataValidation={rule:{type:"list",values:["Draft","In review","Approved","Rejected"]}};
cal.getRange("I8:I14").conditionalFormats.add("containsText",{text:"Approved",format:{fill:"#E2F0D9"}});
title(tasks,"Prioritised SEO tasks","G");tasks.getRange("A4").values=[["Audit status"]];tasks.getRange("B4").values=[["Pending authorised website"]];tasks.getRange("A5").values=[["Observed issues"]];tasks.getRange("B5").formulas=[['=IF(B4="Complete",COUNTA(A8:A57),"n.a.")']];
tasks.getRange("A7:G7").values=[["Task","Impact","Effort","Evidence","URL","Observed date","Status"]];head(tasks,"A7:G7");tasks.getRange("A8:G57").values=Array.from({length:50},()=>["","","","","","",""]);
tasks.tables.add("A7:G57",true,"SEOTasks").style="TableStyleLight8";tasks.freezePanes.freezeRows(7);
for(const [column,width] of Object.entries({A:42,B:14,C:14,D:60,E:45,F:18,G:18}))tasks.getRange(column+"1:"+column+"57").format.columnWidth=width;
tasks.getRange("A8:G57").format.wrapText=true;tasks.getRange("A8:G57").format.rowHeight=60;tasks.getRange("F8:F57").setNumberFormat("dd mmm yyyy");tasks.getRange("G8:G57").dataValidation={rule:{type:"list",values:["Open","In progress","Done","Blocked"]}};
title(brief,"Brand inputs and sources","B");brief.getRange("A5:B5").values=[["Field","Value"]];head(brief,"A5:B5");brief.getRange("A6:B18").values=[["Brand",""],["Input revision",""],["Approval status","Pending"],["Brief",""],["Audience",""],["Services",""],["Authorised website","Not provided"],["Source",""],["Generated at",""],["Timezone","Asia/Kolkata"],["Drafting method",""],["Limitations",""],["Run ID",""]];brief.getRange("A1:A18").format.columnWidth=25;brief.getRange("B1:B18").format.columnWidth=95;brief.getRange("B6:B18").format.wrapText=true;brief.getRange("A6:B18").format.rowHeight=40;brief.getRange("A9:B9").format.rowHeight=100;
wb.recalculate();
console.log((await wb.inspect({kind:"region",sheetId:"Calendar",range:"A4:F4",maxChars:1500,include:"values,formulas"})).ndjson);
const out=await SpreadsheetFile.exportXlsx(wb);await out.save(outputDir+"/brand-review-template.xlsx");
for(const [sheetName,range] of [["Calendar","A2:I10"],["SEO tasks","A2:G10"],["Brand inputs","A2:B18"]]){const img=await wb.render({sheetName,range,scale:1,format:"png"});await fs.writeFile(outputDir+"/template-"+sheetName.replaceAll(" ","-")+".png",new Uint8Array(await img.arrayBuffer()));}
