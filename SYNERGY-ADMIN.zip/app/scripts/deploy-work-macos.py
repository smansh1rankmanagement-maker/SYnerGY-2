#!/usr/bin/env python3
"""Add the independent Work scheduler and switch the existing app after backup."""
import argparse,datetime,json,os,plistlib,shutil,sqlite3,subprocess,time,urllib.request
from pathlib import Path

def bootstrap(domain,plist):
 deadline=time.monotonic()+20;error=''
 while time.monotonic()<deadline:
  r=subprocess.run(['launchctl','bootstrap',domain,str(plist)],capture_output=True,text=True)
  if r.returncode==0:return
  error=r.stderr.strip();time.sleep(1)
 raise RuntimeError('LaunchAgent start failed: '+error)
def main():
 p=argparse.ArgumentParser();p.add_argument('--source',required=True,type=Path);args=p.parse_args();source=args.source.resolve()
 base=Path.home()/'Library/Application Support/SYnerGY';folder=Path.home()/'Library/LaunchAgents';plist=folder/'in.1rank.synergy-v14.plist';worker_plist=folder/'in.1rank.synergy-operations.plist'
 original=plist.read_bytes();cfg=plistlib.loads(original);prior_worker=worker_plist.read_bytes() if worker_plist.exists() else None
 assert (source/'backend/operations/worker.py').is_file() and (source/'templates/brand-review-template.xlsx').is_file(),'Unpack the full source first.'
 data=Path(cfg['EnvironmentVariables']['SYNERGY_DATA_DIR']);db=data/'accounts.sqlite3';python=cfg['ProgramArguments'][0]
 deps=base/'runtime/work-deps-v160';env=cfg['EnvironmentVariables'].copy();env['PYTHONPATH']=os.pathsep.join([str(deps)]+[x for x in env.get('PYTHONPATH','').split(os.pathsep) if x and x!=str(deps)])
 env['SYNERGY_OPERATIONS_MODEL']='aerny:v1.5';check_env=os.environ.copy();check_env.update(env)
 subprocess.run([python,'-c','import reportlab,charset_normalizer; assert reportlab.Version=="5.1.0"; from reportlab.pdfbase.ttfonts import TTFont'],env=check_env,check=True)
 with sqlite3.connect(db) as c:
  for table in ['research_tasks','studio_jobs']:
   assert c.execute(f"SELECT count(*) FROM {table} WHERE state IN ('queued','running')").fetchone()[0]==0,'Wait for active '+table
  for media in ['image','video']:
   for j in (data/media).rglob('job.json'):assert json.loads(j.read_text()).get('state') not in {'queued','running','cancelling'},'Wait for active media jobs.'
  backup=base/'backups'/('work-v160-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));backup.mkdir(parents=True,mode=0o700)
  with sqlite3.connect(backup/'accounts.sqlite3') as dest:c.backup(dest)
  counts={t:c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in ['users','conversations','messages']}
 (backup/plist.name).write_bytes(original)
 if prior_worker:(backup/worker_plist.name).write_bytes(prior_worker)
 previous=Path(cfg['ProgramArguments'][1]).parent.parent;shutil.copytree(previous,backup/'source',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 cfg.update(WorkingDirectory=str(source));cfg['ProgramArguments'][1]=str(source/'backend/server.py');cfg['EnvironmentVariables']=env
 worker={'Label':'in.1rank.synergy-operations','ProgramArguments':[python,str(source/'backend/operations/worker.py'),'--data',str(data)],'WorkingDirectory':str(source),'EnvironmentVariables':env,'RunAtLoad':True,'KeepAlive':True,'ThrottleInterval':10,'StandardOutPath':str(base/'operations-worker.log'),'StandardErrorPath':str(base/'operations-worker-error.log')}
 domain='gui/'+str(os.getuid());subprocess.run(['launchctl','bootout',domain+'/'+cfg['Label']],check=True)
 if prior_worker:subprocess.run(['launchctl','bootout',domain+'/'+worker['Label']],capture_output=True)
 try:
  plist.write_bytes(plistlib.dumps(cfg));worker_plist.write_bytes(plistlib.dumps(worker));os.chmod(worker_plist,0o600)
  bootstrap(domain,plist);bootstrap(domain,worker_plist)
  deadline=time.monotonic()+30;ready=False
  while time.monotonic()<deadline:
   try:
    with urllib.request.urlopen('http://127.0.0.1:8090/api/auth/config',timeout=2) as r:health=json.load(r)
    with sqlite3.connect(db) as c:hb=c.execute('SELECT heartbeat FROM ops_worker WHERE id=?',('local',)).fetchone()
    if health.get('version')=='1.6.0' and hb and time.time()-hb[0]<10:ready=True;break
   except Exception:pass
   time.sleep(.3)
  assert ready,'App or independent worker did not become healthy.'
 except BaseException:
  for label in [worker['Label'],cfg['Label']]:subprocess.run(['launchctl','bootout',domain+'/'+label],capture_output=True)
  plist.write_bytes(original);bootstrap(domain,plist)
  if prior_worker:worker_plist.write_bytes(prior_worker);bootstrap(domain,worker_plist)
  else:worker_plist.unlink(missing_ok=True)
  raise
 result={'version':'1.6.0','model':'Aerny v1.5 (unchanged weights)','source':str(source),'previous_source':str(previous),'backup':str(backup),'data':str(data),'url':'http://127.0.0.1:8090/','worker_label':worker['Label'],'preserved_counts_before':counts,'deployed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (source/'DEPLOYMENT_WORK.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
if __name__=='__main__':main()
