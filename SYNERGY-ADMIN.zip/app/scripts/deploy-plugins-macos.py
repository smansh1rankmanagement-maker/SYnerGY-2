#!/usr/bin/env python3
"""Upgrade the existing local LaunchAgent; connector installation stays in Chat."""
import argparse,datetime,json,os,plistlib,shutil,sqlite3,subprocess,time,urllib.request
from pathlib import Path

def bootstrap(domain,plist):
    # launchctl bootout can return before macOS has released the old job.
    deadline=time.monotonic()+18;error=''
    while time.monotonic()<deadline:
        r=subprocess.run(['launchctl','bootstrap',domain,str(plist)],capture_output=True,text=True)
        if r.returncode==0:return
        error=r.stderr.strip();time.sleep(1)
    raise RuntimeError('LaunchAgent could not start: '+error)

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',required=True,type=Path);p.add_argument('--owner',required=True);p.add_argument('--search-deps',type=Path);args=p.parse_args()
    source=args.source.resolve();base=Path.home()/'Library/Application Support/SYnerGY';plist=Path.home()/'Library/LaunchAgents/in.1rank.synergy-v14.plist'
    original=plist.read_bytes();config=plistlib.loads(original);data=Path(config['EnvironmentVariables']['SYNERGY_DATA_DIR']);db=data/'accounts.sqlite3'
    assert (source/'backend/runtime_plugins.py').is_file() and (source/'backend/runtime-locks/desktop-commander/package-lock.json').is_file(),'Unpack the complete 1.5.2 source first.'
    search_deps=(args.search_deps or base/'runtime/research-search-v152').resolve()
    assert (search_deps/'ddgs').is_dir(),'Install requirements-search-v152.txt into the separate search-deps directory first.'
    old_paths=config['EnvironmentVariables'].get('PYTHONPATH','').split(os.pathsep)
    search_path=os.pathsep.join([str(search_deps)]+[x for x in old_paths if x and x!=str(search_deps)])
    check_env=os.environ.copy();check_env.update(config['EnvironmentVariables']);check_env['PYTHONPATH']=search_path
    subprocess.run([config['ProgramArguments'][0],'-c','import importlib.metadata; assert importlib.metadata.version("ddgs")=="9.16.1"; from ddgs.engines import ENGINES; assert "yahoo" in ENGINES["text"]'],env=check_env,check=True)
    with sqlite3.connect(db) as c:
        assert c.execute('SELECT 1 FROM users WHERE lower(username)=lower(?)',(args.owner,)).fetchone(),'Owner account does not exist.'
        assert c.execute("SELECT count(*) FROM research_tasks WHERE state IN ('queued','running')").fetchone()[0]==0,'Wait for active research to finish.'
        assert c.execute("SELECT count(*) FROM studio_jobs WHERE state IN ('queued','running')").fetchone()[0]==0,'Wait for active studio jobs to finish.'
        for media in ['image','video']:
            for job in (data/media).rglob('job.json'):
                assert json.loads(job.read_text()).get('state') not in {'queued','running','cancelling'},'Wait for active '+media+' jobs to finish.'
        backup=base/'backups'/('chat-tools-v152-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));backup.mkdir(parents=True)
        with sqlite3.connect(backup/'accounts.sqlite3') as dest:c.backup(dest)
    (backup/plist.name).write_bytes(original)
    previous=Path(config['ProgramArguments'][1]).parent.parent;shutil.copytree(previous,backup/'source',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    config['ProgramArguments'][1]=str(source/'backend/server.py');config['WorkingDirectory']=str(source)
    config['EnvironmentVariables'].update(SYNERGY_PLUGIN_ADMIN=args.owner,SYNERGY_NODE='/usr/local/bin/node',SYNERGY_NPM='/usr/local/bin/npm')
    config['EnvironmentVariables']['PYTHONPATH']=search_path
    for executable in [config['ProgramArguments'][0],'/usr/local/bin/node','/usr/local/bin/npm']:assert Path(executable).exists(),executable
    domain='gui/'+str(os.getuid());label=config['Label']
    subprocess.run(['launchctl','bootout',domain+'/'+label],check=True)
    try:
        with plist.open('wb') as f:plistlib.dump(config,f)
        bootstrap(domain,plist)
        deadline=time.monotonic()+25;health=None
        while time.monotonic()<deadline:
            try:
                with urllib.request.urlopen('http://127.0.0.1:8090/api/auth/config',timeout=2) as r:health=json.load(r)
                if health.get('version')=='1.5.2':break
            except Exception:pass
            time.sleep(.3)
        assert health and health.get('version')=='1.5.2','New app did not become healthy.'
    except BaseException:
        subprocess.run(['launchctl','bootout',domain+'/'+label],capture_output=True)
        plist.write_bytes(original);bootstrap(domain,plist)
        raise
    print(json.dumps({'version':health['version'],'backup':str(backup),'source':str(source),'owner':args.owner,'chat_install_required':True}))

if __name__=='__main__':main()
