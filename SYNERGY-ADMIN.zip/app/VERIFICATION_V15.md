# Aerny v1.5 — release verification

Verified on 4 November 2026. The configured Mac is running v1.5 at **http://127.0.0.1:8090/**. Existing accounts, conversations, skills and media remain available. This is a local application, not a public hosted deployment.

## What is working

The release adds local text-to-image, reference-to-image and brush-mask selective editing, plus deterministic text/logo composition. Saved projects retain settings, assets, completed revisions and downloadable PNG, editable SVG and project JSON. Queued jobs have actual inference progress, cancellation, retry and interrupted-job recovery. Saved unfinished briefs and painted selections survive reopening the editor.

The interface retains Home/recents, Plugins, Skills, Chat/Work/Beast, the + menu and right-side preview. It adds SYnerGY/OpenAI/Hybrid provider controls, capability selection and elapsed response time. No prices, subscriptions, credit balances or hosted image-generation services were added.

## Observed machine and components

| Component | Actual implementation and status |
|---|---|
| Machine | Intel MacBook Pro, i7-1068NG7, 16 GB RAM, integrated Intel Iris Plus, macOS 26.6.2; approximately 335 GB free during inspection |
| Acceleration | CPU inference; Torch reports CUDA false and MPS false |
| Chat | Ollama on loopback; `aerny:v1.5` uses existing Qwen3 4B Instruct Q4_K_M weights; `aerny-fast:v1.5` reuses the installed Qwen3 0.6B profile; vision uses installed Qwen3-VL 2B Instruct |
| Assistant planning | Bounded brief parser selects image, reference, selected-area or exact-layout workflows; saved approved brand kits are retrieved by name. This is not an unrestricted autonomous planner |
| Image base | `emilianJR/epiCRealism`, revision `6522cf856b8c8e14638a0aaa7bd89b1b098aed17`, CreativeML OpenRAIL-M |
| Fast adapter | `latent-consistency/lcm-lora-sdv1-5`, revision `cf2fced511dbe7e26c8d1d397e728fbab875db4b`, OpenRAIL++; downloaded safetensors SHA-256 verified |
| Selective edit | Cropped local image-to-image inference with inward-feathered mask compositing. Zero-mask pixels are copied from the fitted reference before layout overlays |
| Exact layout | Pillow, original uploaded logo pixels, DejaVu Sans / Condensed Bold fonts, percentage-positioned text/image layers, PNG and embedded-asset SVG |
| Web runtime | Managed Python 3.12.15 with scrypt and Pillow 11.3.0; private SQLite accounts/sessions/projects |
| Media runtime | Python 3.9.6, Pillow 10.4.0, Torch 2.2.2, Diffusers 0.30.3, Transformers 4.44.2, PEFT 0.12.0; separate binary dependency path |
| Video | Existing local AnimateDiff-Lightning / epiCRealism pipeline retained; saved 1920 × 1080, 2-second, interpolated 24-fps video loads in v1.5 |
| OpenAI | Disabled: no approved key/model configuration. Hybrid currently routes locally. Optional Responses adapter is fixture-tested only |
| Network | Website and inference run on the same Mac over loopback. No public inference tunnel or cloud GPU was connected |

Pinned model details and source URLs are in `backend/studio/models.lock.json`; software/licence notes are in `backend/THIRD_PARTY_NOTICES/Aerny-v15.md`. Aerny v1.5 is an application/profile version: no ChatGPT weights, new foundation training, autonomous self-training or new subject LoRA training is claimed.

## Test evidence

| Check | Observed result |
|---|---|
| Automated suite | **31 tests passed**, 3.768 seconds. Authentication/origin checks, account isolation, persistent conversations, job lifecycle, exact layouts, HTTP exports/reopening, brand approval, routing and existing plugin/video regressions |
| JavaScript | `node --check` passed for `static/app.js` and `static/studio.js` |
| Local text-to-image | Real CPU inference: **134.42 s**, eight LCM steps, **408 × 512 native**, 1080 × 1350 export |
| Reference-to-image | Real HTTP upload and inference: **97.93 s**, four effective denoising steps from 16 requested at strength 0.25, 408 × 512 native, 1080 × 1350 export |
| Final selective-edit engine | Real inference: **101.54 s**, 496 × 512 native crop; changed pixels inside the mask, **no changed zero-mask pixels** before overlays |
| Exact layout | Original logo + exact headline produced a 1080 × 1350 PNG/SVG in **2.35 s** in acceptance testing; final live header composition took **3.93 s** |
| Full HTTP sequence | Upload reference → reference generation → selective edit → logo/headline composition → download → reopen completed, with three stored jobs |
| Browser | Login/register exercised in staging; live existing session retained. Provider/mode controls, cancel/retry, conversational headline edit, saved projects and revision controls exercised |
| Browser brush | Pointer-painted mask uploaded as a 640 × 800 PNG with both black and white pixels; saved brief/workflow/mask survived closing and reopening after a final UI fix |
| Download | Live browser PNG download matched the saved output SHA-256 `b721f86291e563b71a9c61a984323046b5d79115ff2f221ba1519e60125606ee` |
| Local chat | Hybrid + Instant produced an actual Fast reply in approximately **2 s**; route showed the local model used |
| Media compatibility | Separate deployed media runtime successfully imported all required libraries; saved video decoded with readyState 4, 1920 × 1080 dimensions, duration 2 s and no media error |
| Browser console | No error/warning entries returned during the final preview check |

The full HTTP sequence initially used an earlier selective-edit implementation. Visual inspection found a conspicuous edit boundary. That method was replaced; the final cropped image-to-image worker was rerun against the same saved inputs and passed its pixel check and boundary inspection. The complete three-stage HTTP sequence was not rerun after that worker change; the final worker test and HTTP/job regression tests are recorded separately. The final saved-draft UI fix was then verified in the live browser. These distinctions prevent the original `acceptance-report.json` boolean from being mistaken for final visual approval.

Evidence files include actual result metadata, the original acceptance report, final selective-edit pixel checks, runtime/deployment records, browser checks and two actual output images. The prior v1.4 image run took 649.56 seconds with a different prompt, resolution and preset; it is not a controlled speed/quality comparison with the new Fast example.

## Visual review and remaining limits

- The clean office-lounge generation is a usable draft: furniture, daylight and the final exact headline/logo composition are coherent. Fine material detail remains soft at the small native inference size. Owner approval has not been recorded.
- The supplied office reference is a finished poster with baked-in typography. Whole-image regeneration distorted some lettering and spatial details. It did **not** pass a claim of exact reference fidelity. Use the exact-layout workflow to retain an existing poster, or a clean photo/reference for visual regeneration.
- The final selective-edit boundary was visually improved and protected-pixel equality was verified. Generated geometry inside the selection can still drift. This does not guarantee exact face/body identity or seamless edits for every input.
- The saved InteriFY icon-and-wordmark asset is marked **reference only**, not approved. The owner must confirm the current approved brand asset before automatic approved-logo reuse.
- “4K” is an enlarged export, not native 4K image/video generation. The new studio exports use Lanczos resizing. The separate existing v1.4 Real-ESRGAN route remains available; the new studio does not claim to invoke it.
- New video inference was not rerun for this release. The existing implementation and a saved playable result were checked; no video-quality improvement is claimed.
- OpenAI/Hybrid external routing was not tested with a live key and remains off. The optional routing adapter chooses a provider; it does not ensemble both model outputs.
- The fixed seven-case collection covers portraits, products, interiors, advertisements, typography, reference fidelity and editing. Interior/reference/editing/layout received real checks; a complete paired baseline/candidate evaluation across all cases is still pending. The 20 UI categories are brief categories, not 20 separately validated model systems.
- Layout is controlled by text/logo layers and numeric position/size controls. Two fonts are bundled. Custom fonts, vector drawing, background removal, outpainting, pose/depth control, batch variations and dedicated subject-consistency training remain later work. SVG contains embedded raster images and editable text; rendering may vary by editor.
- Projects and assets stay on this Mac. Account separation and local sessions are implemented, but the standard-library server is not intended for public internet exposure. Keep the Mac awake during inference. CPU generation takes minutes; no guaranteed latency or persistent ChatGPT GPU is available.
- Uploaded data was not used for training. The benchmark is held out; future adaptation requires permissioned data, an actual training run and evaluation.

## Deployment and recovery

Live source: `/Users/a1989/Library/Application Support/SYnerGY/v1.5`.

Existing data: `/Users/a1989/Library/Application Support/SYnerGY/v1.4-data`.

Preserved source: `/Users/a1989/Library/Application Support/SYnerGY/v1.4`.

Backup: `/Users/a1989/Library/Application Support/SYnerGY/backups/aerny-v15-20261104-113010` contains the pre-upgrade database backup, previous LaunchAgent plist and rollback record. The source archive retains its prior v1.4 version history. Restore the backed-up LaunchAgent to use v1.4; do not overwrite newer user data with an old database without reviewing it. Full setup and rollback steps are in `BACKEND_SETUP.md`.

Open the recent conversation **Aerny v1.5 · InteriFY studio preview**, or **Saved projects → InteriFY · office launch draft**, to review the delivered example. The original logo and headline are composed separately from the generated office photo.
