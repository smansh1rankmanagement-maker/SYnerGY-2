const {test}=require('node:test'),assert=require('node:assert/strict');
const {handle}=require('../static/composer-paste.js');
function fixture({text='',files=[],items=[],selected=null,busy=false,value='',start=0,end=start,maxLength=6000}={}){
 const result={prevented:false,selection:selected,notices:[]};
 const e={clipboardData:{getData:t=>t==='text/plain'?text:'<script>not executed</script>',files,items},preventDefault(){result.prevented=true;}};
 const input={value,selectionStart:start,selectionEnd:end,maxLength};
 const ctx={notify:t=>result.notices.push(t),getSelection:()=>selected,isBusy:()=>busy,selectFiles:f=>result.selection=f};
 return{result,e,input,ctx,run(){handle(e,input,ctx);return result;}};
}
test('text paste stays native in Chat Work and Beast, including code and Unicode',()=>{
 for(const mode of ['chat','work','beast']){
  const f=fixture({text:'Hello\nनमस्ते\n<script>alert(1)</script>\nconst x = 1;',value:'draft',start:2,end:2});
  assert.equal(f.run().prevented,false,mode);assert.equal(f.input.value,'draft');assert.equal(f.result.selection,null);
 }
});
test('pasted screenshot is selected without sending or changing the draft',()=>{
 const file={name:'image.png',type:'image/png',size:4096};const f=fixture({files:[file],value:'Describe this',start:13});
 assert.deepEqual(f.run().selection,[file]);assert.equal(f.result.prevented,true);assert.equal(f.input.value,'Describe this');
});
test('clipboard item fallback and null file entries are handled',()=>{
 const file={name:'photo.png',size:42};const f=fixture({items:[{kind:'string'},{kind:'file',getAsFile:()=>null},{kind:'file',getAsFile:()=>file}]});
 assert.deepEqual(f.run().selection,[file]);
});
test('files merge with current pending files without discarding them',()=>{
 const first={name:'a.pdf',size:4},second={name:'b.png',size:4};
 assert.deepEqual(fixture({files:[second],selected:first}).run().selection,[first,second]);
 assert.deepEqual(fixture({files:[second],selected:{folder:true,files:[first]}}).run().selection,[first,second]);
});
test('mixed clipboard text retains native insertion while attaching the file',()=>{
 const f=fixture({text:'Caption',files:[{name:'photo.png',size:5}]});assert.equal(f.run().prevented,false);assert.equal(f.result.selection.length,1);
});
test('size and count limits preserve the previous selection',()=>{
 const old={name:'keep.pdf',size:10};
 for(const files of [[{name:'huge.png',size:200*1024*1024}],Array.from({length:200},()=>({size:1}))]){
  const f=fixture({files,selected:old});assert.equal(f.run().selection,old);assert.equal(f.result.prevented,true);assert.match(f.result.notices[0],/200 MB/);
 }
 assert.equal(fixture({files:[{size:200*1024*1024}]}).run().selection.length,1);
});
test('saved attachments and working jobs are not overwritten',()=>{
 const saved={savedIds:['saved-file'],name:'Keep'};
 for(const f of [fixture({selected:saved,files:[{size:1}]}),fixture({busy:true,files:[{size:1}]})]){
  f.run();assert.equal(f.result.prevented,true);assert.equal(f.result.selection,f.ctx.getSelection());
 }
 assert.equal(fixture({busy:true,text:'Continue with this suggestion'}).run().prevented,false);
});
test('oversized pasted text is rejected visibly instead of silently truncated',()=>{
 const f=fixture({text:'x'.repeat(6001),value:'draft'});assert.equal(f.run().prevented,true);assert.equal(f.input.value,'draft');assert.match(f.result.notices[0],/character message limit/);
 assert.equal(fixture({text:'x'.repeat(6000),value:'replace',start:0,end:7}).run().prevented,false);
});
test('empty clipboard is a no-op',()=>{
 const f=fixture();assert.equal(f.run().prevented,false);assert.deepEqual(f.result.notices,[]);
});
