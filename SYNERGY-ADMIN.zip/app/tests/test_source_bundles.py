import unittest,tempfile,zipfile,io,sqlite3
from pathlib import Path
from workspace import Workspace
from beast.store import Beast
from source_bundles import SourceBundles
class BundleTest(unittest.TestCase):
 def test_merged_export_preserves_assets_and_source_deletions(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);w=Workspace(root/'db');b=Beast(w.db,root/'beast');store=SourceBundles(w,b,root/'bundles')
   with w.connect() as c:c.execute('CREATE TABLE research_files(id TEXT,user_id INTEGER,name TEXT,created REAL)')
   s=b.create(1,{'name':'bundle','files':{'main.py':'print(1)','old.py':'print(0)'}});p=w.save_project(1,{'name':'Bundle','beast_project_id':s['id']});z=root/'base.zip'
   with zipfile.ZipFile(z,'w') as out:out.writestr('main.py','print(1)');out.writestr('old.py','print(0)');out.writestr('movie.mp4',b'asset-bytes')
   store.attach(1,p['id'],z,{'editable_paths':['main.py','old.py']});b.edit(1,{'project_id':s['id'],'revision':1,'action':'write','path':'main.py','content':'print(2)'});b.edit(1,{'project_id':s['id'],'revision':2,'action':'delete','path':'old.py'})
   name,raw=store.export(1,p['id'])
   with zipfile.ZipFile(io.BytesIO(raw)) as out:self.assertEqual(out.read('main.py'),b'print(2)');self.assertEqual(out.read('movie.mp4'),b'asset-bytes');self.assertNotIn('old.py',out.namelist())
   with self.assertRaises(KeyError):store.export(2,p['id'])
