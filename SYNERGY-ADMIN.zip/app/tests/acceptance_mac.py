"""Real HTTP acceptance test; run only against the isolated Mac staging server."""
from pathlib import Path
import base64,http.cookiejar,io,json,time,urllib.request,secrets
from PIL import Image,ImageDraw,ImageChops
BASE='http://127.0.0.1:8091';root=Path.home()/'Library/Application Support/SYnerGY';evidence=root/'v15-evidence';assets=evidence/'input-assets'
jar=http.cookiejar.CookieJar();client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def call(path,d=None,binary=False):
 req=urllib.request.Request(BASE+path,data=json.dumps(d).encode() if d is not None else None,headers={'Content-Type':'application/json'} if d is not None else {})
 with client.open(req,timeout=600) as r:return r.read() if binary else json.load(r)
def asset(file):return call('/api/studio/assets',{'name':file.name,'data':base64.b64encode(file.read_bytes()).decode()})
def run(project,spec):
 p=call('/api/studio/projects',{'id':project.get('id') if project else None,'revision':project.get('revision') if project else None,'title':'InteriFY · office launch acceptance','spec':spec});j=call('/api/studio/jobs',{'project_id':p['id']});print('Job',j['id'],spec['workflow'],flush=True)
 while j['state'] in {'queued','running'}:
  time.sleep(3);j=call('/api/studio/jobs/'+j['id'])
 if j['state']!='succeeded':raise RuntimeError(j.get('error') or j['state'])
 print('Completed',j['id'],j['result']['seconds'],flush=True)
 return call('/api/studio/projects/'+p['id']),j
password=secrets.token_urlsafe(24);username='v15_acceptance_'+secrets.token_hex(3)
call('/api/auth/register',{'username':username,'password':password})
ref=asset(assets/'InteriFY open office concept for 1rank.png');logo=asset(assets/'Transparent InteriFY logo cutout(1).png')
# This test uses the saved reference logo; it does not claim new brand approval.
call('/api/studio/brands',{'name':'InteriFY reference','logo_id':logo['id'],'colour':'#d6a575','font':'bold','approved':False})
spec={'workflow':'transform','prompt':'Architectural office interior concept, open workspace, walnut desks, glass partitions, cream lounge furniture, warm daylight, keep the spatial arrangement from the reference, no lettering','width':1080,'height':1350,'quality':'fast','strength':.25,'seed':145,'reference_id':ref['id'],'layers':[]}
p,j1=run(None,spec)
reference=Image.open(io.BytesIO(call('/api/studio/jobs/'+j1['id']+'/base.png',binary=True))).convert('RGB')
mask=Image.new('L',reference.size,0);ImageDraw.Draw(mask).rectangle((620,650,850,890),fill=255);maskfile=evidence/'acceptance-mask.png';mask.save(maskfile);m=asset(maskfile)
spec.update(workflow='inpaint',prompt='Warm walnut office table, polished wood, realistic natural texture, soft daylight',reference_id=j1['result']['base_asset_id'],mask_id=m['id'],strength=.6)
p,j2=run(p,spec)
edited=Image.open(io.BytesIO(call('/api/studio/jobs/'+j2['id']+'/base.png',binary=True))).convert('RGB')
diff=ImageChops.difference(reference,edited);outside=Image.composite(diff,Image.new('RGB',reference.size),ImageChops.invert(mask));assert outside.getbbox() is None,'Protected pixels changed'
assert diff.getbbox() is not None,'The selected area did not change'
spec.update(workflow='layout',reference_id=j2['result']['base_asset_id'],layers=[{'type':'text','text':'OFFICE LAUNCH','x':5,'y':5,'width':64,'height':16,'size':7,'colour':'#ffffff','font':'bold','panel':True,'panel_colour':'#241e19'},{'type':'logo','asset_id':logo['id'],'x':72,'y':4,'width':23,'height':20}])
p,j3=run(p,spec)
output=call(j3['result_url'],binary=True);(evidence/'interify-acceptance.png').write_bytes(output);assert Image.open(io.BytesIO(output)).size==(1080,1350)
svg=call('/api/studio/jobs/'+j3['id']+'/output.svg',binary=True);assert b'OFFICE LAUNCH' in svg;(evidence/'interify-acceptance.svg').write_bytes(svg)
reopened=call('/api/studio/projects/'+p['id']);assert len(reopened['jobs'])==3;assert reopened['spec']['layers'][0]['text']=='OFFICE LAUNCH'
report={'passed':True,'reference_file':'InteriFY open office concept for 1rank.png','logo_file':'Transparent InteriFY logo cutout(1).png','brand_approval':'Saved reference asset; final brand approval remains with owner','project_id':p['id'],'jobs':[j1,j2,j3],'protected_pixels_changed':0,'selected_area_changed':True,'download_dimensions':[1080,1350],'reopened_jobs':len(reopened['jobs']),'account':username}
(evidence/'acceptance-report.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='jobs'}),flush=True)
