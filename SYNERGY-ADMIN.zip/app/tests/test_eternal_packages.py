import json,tempfile,subprocess,sys,unittest
from pathlib import Path
from eternal_lab.validation import normalise
from eternal_lab.scaffold import files
class PackageTests(unittest.TestCase):
 def test_all_34_independent_packages_with_domain_content(self):
  root=Path(__file__).resolve().parents[1]/'skills/expertise';paths=sorted(root.glob('*/package.json'));self.assertEqual(len(paths),34);names=set();briefs=set()
  for i,p in enumerate(paths,1):
   s=json.loads(p.read_text());normalise('skill',s);self.assertTrue(p.parent.name.startswith(f'{i:02d}-'));self.assertTrue((p.parent/'SKILL.md').exists());names.add(s['name']);briefs.add(s['examples'][0]['input']);self.assertGreaterEqual(len(s['procedures']),5);self.assertEqual(s['review']['status'],'pending');self.assertTrue(all(e['status']=='not_run' for e in s['evaluations']))
  self.assertEqual(len(names),34);self.assertEqual(len(briefs),34)
 def test_trusted_generated_scaffold_real_stdio_test(self):
  with tempfile.TemporaryDirectory() as d:
   for name,content in files().items():(Path(d)/name).write_text(content)
   p=subprocess.run([sys.executable,'test_server.py'],cwd=d,capture_output=True,text=True,timeout=5);self.assertEqual(p.returncode,0,p.stderr)
if __name__=='__main__':unittest.main()
