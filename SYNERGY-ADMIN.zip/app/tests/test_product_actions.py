import unittest
from unittest.mock import patch
from test_research import ResearchTests
from product_actions import intent

class Routing(unittest.TestCase):
 def test_download_variations(self):
  for p in ['give me the extension file','send synergy extension zip','Where can I download the Chrome extension?','install the synergy extension','please provide the extention file']:
   self.assertEqual(intent(p),{'tool':'extension_download'},p)
 def test_no_hijacking(self):
  for p in ['Create a browser extension','Debug my extension','Fix the extension login','What is a file extension? Explain it.','Create a PDF about extensions','Create a video about extensions']:
   self.assertIsNone(intent(p),p)

class ProductActionTests(ResearchTests):
 def test_extension_all_modes_and_profiles_no_model(self):
  with patch.object(self.r,'model',side_effect=AssertionError('No model needed')),patch.object(self.r.web,'search',side_effect=AssertionError('No web needed')):
   for mode in ['chat','work','beast']:
    for family in ['eternal','aerny']:
     j=self.wait(self.submit(prompt='give me the extension file',mode=mode,model_family=family))
     self.assertEqual(j['state'],'succeeded',j)
     self.assertEqual(j['detail']['artifacts'][0]['url'],'/api/extension/download')
     self.assertIsNone(j['request']['creation'])
     self.assertIn('chrome://extensions',j['reply'])
     saved=self.w.chat(1,j['conversation_id'])['messages'][-1]
     self.assertEqual(saved['metadata']['artifacts'],j['detail']['artifacts'])
