import unittest
import test_extension_leads as fixture
from test_backend import app
from browser_extension import EXTENSION_ORIGIN
class BrowserHTTPTests(fixture.ExtensionLeadsTest):
 test_extension_scope_cors_revocation_and_lead_workbook=None
 test_install_routed_before_model_in_all_modes=None
 def test_authenticated_complete_flow_and_denials(self):
  owner=self.register('browser180_owner');other=self.register('browser180_other')
  token=self.call('POST','/api/extension/pair',{},cookie=owner)[1]['token'];h={'bearer':token,'origin':EXTENSION_ORIGIN}
  session={'device':'device'+'a'*26,'session':'session'+'a'*25,'tabs':[7]}
  self.assertEqual(self.call('POST','/api/extension/browser/connect',session,cookie=owner)[0],403)
  code,lease,_=self.call('POST','/api/extension/browser/connect',session,**h);self.assertEqual(code,200,lease)
  ticket=lease['probe'];claim={**session,**ticket,'secret':lease['secret']}
  self.assertEqual(self.call('POST','/api/extension/browser/claim',claim,cookie=owner)[0],403)
  self.assertEqual(self.call('POST','/api/extension/browser/claim',claim,**h)[0],200)
  self.assertEqual(self.call('POST','/api/extension/browser/complete',{**claim,'verified':True},**h)[0],200)
  self.assertEqual(self.call('POST','/api/extension/browser/claim',claim,**h)[0],403)
  plan={'lease':lease['lease'],'tab_id':7,'prompt':'Open my selected test website, fill its sample form and inspect console errors.','page':{'url':'https://example.com/','observation':'obs','elements':[]},'history':[]}
  self.assertEqual(self.call('POST','/api/extension/browser/plan',plan,cookie=owner)[1]['command']['tool'],'browser_diagnostics_start')
  self.assertEqual(self.call('POST','/api/extension/browser/plan',plan,cookie=other)[0],403)
  self.assertEqual(self.call('POST','/api/extension/browser/plan',plan,**h)[0],403)
  command={'lease':lease['lease'],'command':{'tool':'browser_read_page','tab_id':8}}
  self.assertEqual(self.call('POST','/api/extension/browser/prepare',command,cookie=owner)[0],403)
  command['command']['tab_id']=7
  code,t,_=self.call('POST','/api/extension/browser/prepare',command,cookie=owner);self.assertEqual(code,200)
  self.call('POST','/api/extension/browser/control',{'lease':lease['lease'],'action':'pause'},cookie=owner)
  self.assertEqual(self.call('POST','/api/extension/browser/claim',{**session,**t,'secret':lease['secret']},**h)[0],403)
  self.call('POST','/api/extension/browser/control',{'lease':lease['lease'],'action':'stop'},cookie=owner)
  self.assertEqual(self.call('POST','/api/extension/browser/heartbeat',{**session,**lease},**h)[0],403)
if __name__=='__main__':unittest.main()
