import unittest,tempfile,json
from pathlib import Path
from workspace import Workspace
from beast.store import Beast,Conflict,validate_proposal
from support import Support
class SupportTest(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();root=Path(self.tmp.name);self.db=root/'a.db';self.w=Workspace(self.db)
  with self.w.connect() as c:c.execute('CREATE TABLE IF NOT EXISTS research_files(id TEXT,user_id INTEGER,name TEXT,parsed TEXT,created REAL)')
  self.b=Beast(self.db,root/'beast');self.s=Support(self.db,self.b);self.source=self.b.create(1,{'name':'Test source','files':{'main.py':'def total(items):\n    return sum(item["price"] for item in item)\n'}});self.project=self.w.save_project(1,{'name':'Test project','kind':'app','beast_project_id':self.source['id']})
 def tearDown(self):self.tmp.cleanup()
 def ticket(self,**kw):return self.s.create(1,{'title':'Fix total prices','description':'The total function crashes for prices 100 and 200; expected 300.','project_id':self.project['id'],'request_key':'ticketrequest01',**kw})
 def test_owner_isolation_and_idempotency(self):
  t=self.ticket();self.assertEqual(t['id'],self.ticket()['id']);self.assertEqual(len(self.s.list(1)),1);self.assertEqual(self.s.list(2),[])
  with self.assertRaises(KeyError):self.s.get(2,t['id'])
  with self.assertRaises(KeyError):self.w.save_project(2,{'name':'Stolen','beast_project_id':self.source['id']})
  with self.assertRaises(KeyError):self.s.create(2,{'title':'Stolen source','description':'Attempt cross account access','project_id':self.project['id'],'request_key':'crossaccount'})
 def finish_job(self,t,failed=False):
  self.s.tick();t=self.s.get(1,t['id']);j=self.b.job(1,t['job_id']);r,_=validate_proposal({'summary':'correct iterator','changes':[{'path':'main.py','operation':'replace','before':'in item)','content':'in items)'}]},self.source['files'],j['request']);r['checks']={'passed':0 if failed else 1,'failed':1 if failed else 0,'skipped':0}
  with self.b.connect() as c:c.execute("UPDATE beast_jobs SET state='awaiting_review',result=? WHERE id=?",(json.dumps(r),j['id']))
  self.s.last_tick=0;self.s.tick();return self.s.get(1,t['id'])
 def test_saved_fix_requires_verification_and_reopens(self):
  t=self.finish_job(self.ticket());self.assertEqual(t['status'],'needs_validation');self.assertIn('in items)',self.b.project(1,self.source['id'])['files']['main.py']['content']);self.assertEqual(self.b.project(1,self.source['id'])['revision'],2)
  t=self.s.feedback(1,{'id':t['id'],'revision':t['revision'],'message':'Works now, I am satisfied','decision':'comment'});self.assertEqual(t['status'],'closed');self.assertIn('glad to have you',t['events'][-1]['message']);self.assertTrue(self.s.notifications(1))
  t=self.s.feedback(1,{'id':t['id'],'revision':t['revision'],'message':'Actually still broken with empty values','decision':'comment'});self.assertEqual(t['status'],'queued');self.assertIsNone(t['job_id'])
 def test_failed_checks_do_not_apply_or_close(self):
  t=self.finish_job(self.ticket(),True);self.assertEqual(t['status'],'needs_review');self.assertEqual(self.b.project(1,self.source['id'])['revision'],1)
  with self.assertRaises(ValueError):self.s.feedback(1,{'id':t['id'],'revision':t['revision'],'message':'good','decision':'satisfied'})
 def test_no_source_and_cancellation(self):
  t=self.ticket(project_id=None);self.s.tick();t=self.s.get(1,t['id']);self.assertEqual(t['status'],'needs_information');t=self.s.feedback(1,{'id':t['id'],'revision':t['revision'],'message':'Withdraw request','decision':'cancel'});self.assertEqual(t['status'],'cancelled')
 def test_restart_and_stale_feedback(self):
  t=self.ticket();other=Support(self.db,self.b);other.tick();t2=other.get(1,t['id']);self.assertEqual(t2['status'],'investigating');self.assertTrue(t2['job_id']);other.last_tick=0;other.tick();self.assertEqual(other.get(1,t['id'])['job_id'],t2['job_id'])
  with self.assertRaises(Conflict):self.s.feedback(1,{'id':t['id'],'revision':t['revision'],'message':'old action','decision':'reopen'})
 def test_optional_review(self):
  t=self.finish_job(self.ticket(auto_apply=False));self.assertEqual(t['status'],'needs_review');self.assertEqual(self.b.project(1,self.source['id'])['revision'],1)
