import json,sqlite3,tempfile,time,unittest,uuid,subprocess,sys
from pathlib import Path
from membership import Membership
from workspace import Workspace
from specialists.store import explain
from specialists.service import Specialists
from specialists.client import call as mcp_call
from specialists.routing import route

class SpecialistTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.db=self.root/'accounts.sqlite3'
  with sqlite3.connect(self.db) as c:c.executescript('CREATE TABLE users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,salt BLOB,password BLOB);CREATE TABLE sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER,expires REAL);')
  self.m=Membership(self.db);self.u=self.m.register({'email':'owner@example.org','password':'Private test password 2026'})['id'];self.v=self.m.register({'email':'other@example.org','password':'Other test password 2026'})['id']
  with self.m.connect() as c:c.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?,?,NULL,?,?)',(uuid.uuid4().hex,self.u,'beast',time.time()-2,time.time()+86400,'active',time.time(),'test_fixture'))
  self.ws=Workspace(self.db);self.services=Specialists(self.ws,self.root,self.m.require)
 def tearDown(self):self.tmp.cleanup()
 def call(self,tool,args=None,server='vedics',uid=None,key=None):return mcp_call(self.root,uid or self.u,server,tool,args or {},key or uuid.uuid4().hex)
 def test_actual_stdio_handshake_list_and_call(self):
  messages=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-11-25'}},{'jsonrpc':'2.0','method':'notifications/initialized'},{'jsonrpc':'2.0','id':2,'method':'tools/list'},{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'question_explain','arguments':{'expression':'1/2 + 1/4'}}}]
  r=subprocess.run([sys.executable,'backend/specialists/server.py','--data',str(self.root),'--user',str(self.u),'--server','vedics'],input='\n'.join(map(json.dumps,messages))+'\n',text=True,capture_output=True,check=True)
  out=[json.loads(x) for x in r.stdout.splitlines()];self.assertEqual(len(out),3);self.assertEqual(out[0]['result']['protocolVersion'],'2025-11-25');self.assertIn('exam_submit',[x['name'] for x in out[1]['result']['tools']]);self.assertEqual(out[2]['result']['structuredContent']['answer'],'3/4')
 def test_fraction_math_and_invalid_expression(self):
  for expression,answer in [('1/3 + 1/6','1/2'),('19 - 30','-11'),('-1/4 + 3/8','1/8')]:self.assertEqual(explain(expression)['answer'],answer)
  for value in ['1/0 + 1/2','__import__("os")','1 * 2','1/2/3+4']:
   with self.assertRaises(ValueError):explain(value)
 def test_lesson_metadata_and_curriculum_version_review(self):
  r=self.call('lesson_create',{'topic':'fractions','metadata':{'grade':'5','language':'English'}})['record'];self.assertIn('3/4',r['data']['content']);self.assertEqual(r['data']['metadata']['administrator'],'Foundation Professor')
  for args in [{'topic':'chemistry','metadata':{}},{'topic':'fractions','metadata':{'grade':'12','board':'ICSE'}}]:
   with self.assertRaises(ValueError):self.call('lesson_create',args)
  r=self.call('curriculum_save',{'title':'Original scope','metadata':{'grade':'5'},'content':'Own original arithmetic scope.','permission_confirmed':True})['record']
  v={'record_id':r['id'],'revision':1,'decision':'approved','note':'Reviewed the original scope.'};r=self.call('knowledge_review',v)['record'];self.assertEqual(r['data']['metadata']['verification'],'approved')
  with self.assertRaises(ValueError):self.call('knowledge_review',v)
 def test_practice_freeze_grade_pdf(self):
  p=self.call('practice_generate',{'topic':'fractions','count':4})['record'];self.assertEqual(len(p['data']['questions']),4)
  e=self.call('exam_create',{'title':'Fraction assessment','practice_id':p['id']})['record'];self.assertTrue(e['data']['frozen']);self.assertNotIn('answer',e['data']['questions'][0])
  answers=[{'question_id':q['id'],'answer':q['answer']} for q in p['data']['questions']];answers[0]['answer']='-999'
  a=self.call('exam_submit',{'exam_id':e['id'],'answers':answers})['record'];self.assertEqual(a['data']['score'],3);self.assertEqual(a['data']['status'],'graded')
  out=self.call('scorecard_export',{'attempt_id':a['id']});pdf=next(x for x in out['artifacts'] if x['kind']=='pdf');f=self.root/'specialists/files'/str(self.u)/a['id']/'1'/pdf['name'];self.assertTrue(f.read_bytes().startswith(b'%PDF'))
  from pypdf import PdfReader
  self.assertIn('Fraction assessment',PdfReader(f).pages[0].extract_text())
 def test_equivalent_fraction_and_descriptive_review(self):
  e=self.call('exam_create',{'title':'Mixed','questions':[{'id':'one','prompt':'1/2+1/4','answer':'3/4','kind':'objective','marks':2},{'id':'two','prompt':'Explain a denominator','kind':'descriptive','rubric':'Two marks for equal parts; one for example.','marks':3}]})['record']
  a=self.call('exam_submit',{'exam_id':e['id'],'answers':[{'question_id':'one','answer':'6/8'},{'question_id':'two','answer':'Equal parts of a whole.'}]})['record'];self.assertEqual(a['data']['score'],2);self.assertEqual(a['data']['status'],'pending_review')
  v={'attempt_id':a['id'],'reviews':[{'question_id':'two','marks':2,'note':'Equal parts explained; example missing.'}]}
  with self.assertRaises(ValueError):self.call('assessment_grade',v)
  v['human_review_confirmed']=True;r=self.call('assessment_grade',v)['record'];self.assertEqual(r['revision'],2);self.assertEqual(r['data']['score'],4)
 def test_isolation_guardian_and_retention(self):
  r=self.call('lesson_create',{'topic':'fractions','metadata':{}})['record']
  with self.assertRaises(ValueError):self.call('record_get',{'record_id':r['id']},uid=self.v)
  with self.assertRaises(ValueError):self.call('question_explain',{'expression':'1+1','user_id':self.u},uid=self.v)
  self.assertFalse(self.call('records_list',uid=self.v)['records'])
  j=self.services.submit(self.u,'vedics','question_explain',{'expression':'1+1'})
  with self.assertRaises(KeyError):self.services.job(self.v,j['id'])
  with self.assertRaises(KeyError):self.services.file(self.v,'vedics',r['id'],'1','output.pdf')
  a={'alias':'Learner A','grade':'5','minor':True,'save_progress':True}
  with self.assertRaises(ValueError):self.call('learning_plan_update',a)
  a['guardian_confirmed']=True;l=self.call('learning_plan_update',a)['record'];lesson=self.call('lesson_create',{'topic':'fractions','metadata':{},'learner_id':l['id']})['record']
  r=self.call('record_delete',{'record_id':l['id'],'confirm':True});self.assertIn(lesson['id'],r['deleted'])
 def test_task_revision_entitlement_crm_dedup(self):
  a=self.call('task_assign',{'title':'Review launch','due':'2026-11-09'},'foundr')['record'];b=self.call('task_assign',{'task_id':a['id'],'title':'Review launch','status':'done'},'foundr')['record'];self.assertEqual(b['revision'],2);self.assertEqual(b['data']['due'],'2026-11-09')
  with self.assertRaises(ValueError):self.call('task_assign',{'title':'No paid mode'},'foundr',uid=self.v)
  a=self.call('crm_contact_update',{'name':'Client A','email':'Client@example.com','source':'User input','opt_out':True},'foundr')['record'];b=self.call('crm_contact_update',{'name':'Client A','email':'client@example.com','source':'Owner update','notes':'Needs proposal'},'foundr')['record'];self.assertEqual(a['id'],b['id']);self.assertTrue(b['data']['opt_out'])
 def test_payroll_formulas_decimals_and_injection(self):
  a={'period':'2026-11','effective_date':'2026-11-01','currency':'INR','rules':'Only supplied amounts; no inferred tax.','employees':[{'name':'=HYPERLINK("evil")','gross':'30000.10','additions':'1000.20','deductions':'500.05'}]}
  r=self.call('payroll_calculate',a,'foundr');self.assertEqual(r['record']['data']['total_net'],'30500.25');self.assertFalse(r['record']['data']['paid'])
  from openpyxl import load_workbook
  wb=load_workbook(self.root/'specialists/files'/str(self.u)/r['record']['id']/'1/payroll.xlsx');self.assertEqual(wb['Payroll']['E2'].value,'=ROUND(B2+C2-D2,2)');self.assertEqual(wb['Payroll']['A2'].data_type,'s');self.assertTrue(wb.calculation.fullCalcOnLoad)
  a['employees'][0]['gross']='NaN'
  with self.assertRaises(ValueError):self.call('payroll_calculate',a,'foundr')
 def test_strategy_compliance_availability_and_brand_scope(self):
  args={'title':'Launch decision','goal':'Validate demand','evidence':'No measured conversion data','assumptions':'Founder can run interviews','growth':'Test one segment','finance':'Budget unknown','operations':'One-week experiment','customer':'Interview five volunteers','risks':'Low response rate','next_action':'Prepare interview questions'}
  r=self.call('strategy_brief_create',args,'foundr');self.assertTrue(r['artifacts']);self.assertEqual(r['record']['data']['approval'],'Not approved')
  r=self.call('compliance_calendar_create',{'title':'Owner-supplied dates','jurisdiction':'India','effective_date':'2026-11-01','items':[{'task':'Review supplied filing date','due':'2026-11-20','source':'User-supplied authorised calendar; verification required'}]},'foundr');self.assertFalse(r['record']['data']['filings_submitted'])
  r=self.call('meeting_find_slots',{'timezone':'Asia/Kolkata','duration_minutes':30,'windows':[{'start':'2026-11-09T09:00:00+05:30','end':'2026-11-09T10:00:00+05:30'}]},'foundr');self.assertEqual(r['slots'][0]['end'],'2026-11-09T09:30:00+05:30')
  from operations.store import Operations
  ops=Operations(self.db,self.root/'operations');brand=ops.save_brand(self.u,{'name':'Private brand','config':{}})
  task=self.call('task_assign',{'title':'Scoped task','brand_id':brand['id']},'foundr')['record']
  with self.m.connect() as c:c.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?,?,NULL,?,?)',(uuid.uuid4().hex,self.v,'work',time.time()-2,time.time()+86400,'active',time.time(),'test_fixture'))
  with self.assertRaises(ValueError):self.call('task_assign',{'title':'Cross-client task','brand_id':brand['id']},'foundr',uid=self.v)
  self.call('record_delete',{'record_id':task['id'],'confirm':True},'foundr')
  with self.m.connect() as c:self.assertIsNone(c.execute('SELECT id FROM ops_tasks WHERE id=?',(task['id'],)).fetchone())
 def test_media_queue_and_account_status(self):
  r=self.call('creative_job_create',{'kind':'image','prompt':'Four equal slices of a whole circular cake.'})
  self.assertEqual(r['state'],'queued');status=self.call('video_job_status',{'request_id':r['request_id']});self.assertEqual(status['state'],'queued');self.assertIsNone(status['task_id'])
  with self.assertRaises(ValueError):self.call('video_job_status',{'request_id':r['request_id']},uid=self.v)
  with self.assertRaises(ValueError):self.call('task_assign',{'title':'  '},'foundr')
 def test_documents_ics_and_external_send_blocker(self):
  r=self.call('document_draft',{'title':'Launch plan','content':'# Goal\nValidate the idea.','category':'business'},'foundr');self.assertEqual({a['kind'] for a in r['artifacts']},{'pdf','document','source'})
  r=self.call('meeting_create',{'title':'Founder review','start':'2026-11-09T09:00:00+05:30','end':'2026-11-09T09:30:00+05:30','timezone':'Asia/Kolkata'},'foundr');self.assertFalse(r['invitations_sent']);path=self.root/'specialists/files'/str(self.u)/r['record']['id']/'1/meeting.ics';self.assertIn('DTSTART:20261109T033000Z',path.read_text())
  d=self.call('email_draft',{'to':'client@example.org','subject':'Draft','body':'Review this.'},'foundr')['record'];r=self.call('email_send',{'draft_id':d['id']},'foundr');self.assertFalse(r['sent']);self.assertEqual(r['status'],'blocked')
 def test_duplicate_recovery_and_cancel(self):
  key=uuid.uuid4().hex;a={'title':'One task'};r=self.call('task_assign',a,'foundr',key=key);rr=self.call('task_assign',a,'foundr',key=key);self.assertEqual(r,rr)
  with self.assertRaises(ValueError):self.call('task_assign',{'title':'Changed'},'foundr',key=key)
  j=self.services.submit(self.u,'foundr','task_assign',a,request_id='retry-request-1');self.assertEqual(j['id'],self.services.submit(self.u,'foundr','task_assign',a,request_id='retry-request-1')['id'])
  self.services.once();self.assertEqual(self.services.job(self.u,j['id'])['state'],'complete')
  with self.services.connect() as c:c.execute("UPDATE sp_jobs SET state='running' WHERE id=?",(j['id'],))
  self.services.recover();self.services.once();self.assertEqual(len(self.call('records_list',server='foundr')['records']),2)
  q=self.services.submit(self.u,'vedics','question_explain',{'expression':'1+1'});self.assertEqual(self.services.cancel(self.u,q['id'])['state'],'cancelled')
 def test_34_contracts_and_routing(self):
  skills=[s for s in self.ws.skills(self.u) if s['id'].startswith('eternal-')];self.assertEqual(len(skills),34);self.assertEqual(len({s['id'] for s in skills}),34)
  for s in skills:
   for field in ['Inputs:','Tools:','Checks:','Permissions:','Acceptance example:']:self.assertIn(field,s['instructions'],s['id'])
   self.assertTrue(s['tools']);self.assertTrue(s['evaluation']['checks'])
  from creation import choose_skill
  self.assertEqual(choose_skill(self.ws,self.u,'Teach me fractions')[0]['id'],'eternal-education');self.assertEqual(choose_skill(self.ws,self.u,'Calculate payroll from explicit employee figures')[0]['id'],'eternal-hr-operations')
  for p in ['What can VEDICS do?','VEDICS how do I create an exam?','I want details about a video','FOUNDR can you send emails?']:self.assertIsNone(route(p))
  self.assertEqual(route('VEDICS explain 1/2 + 1/4')['tool'],'question_explain');self.assertEqual(route('FOUNDR create task: Review the brief')['tool'],'task_assign');self.assertEqual(route('VEDICS create a 5-question fractions quiz for class 5')['arguments']['count'],5)
if __name__=='__main__':unittest.main()
