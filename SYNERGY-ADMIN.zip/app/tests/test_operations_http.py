from membership_fixtures import registration_fixture,paid_fixture
import json,threading,unittest,os
from http.client import HTTPConnection
from unittest.mock import patch
from test_backend import app
from operations.worker import Worker

class OperationsHTTPTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.server=app.ThreadingHTTPServer(('127.0.0.1',18090),app.Handler);threading.Thread(target=cls.server.serve_forever,daemon=True).start()
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close()
 def call(self,method,path,data=None,cookie=None,origin=None):
  data=registration_fixture(path,data)
  c=HTTPConnection('127.0.0.1',18090,timeout=15);h={}
  if cookie:h['Cookie']=cookie
  if origin:h['Origin']=origin
  if data is not None:data=json.dumps(data);h['Content-Type']='application/json'
  c.request(method,path,data,h);r=c.getresponse();body=r.read();result=(r.status,json.loads(body) if r.getheader('Content-Type')=='application/json' else body,r.getheader('Set-Cookie'),r.getheader('Content-Disposition'));paid_fixture(app,path);c.close();return result
 def test_chat_install_full_workflow_download_and_external_gate(self):
  app.RATE.clear();cookies=[]
  for name in ['ops_http_owner','ops_http_other']:
   status,_,cookie,_=self.call('POST','/api/auth/register',{'username':name,'password':'a secure acceptance test password','invite_code':'test-invite-code'});self.assertEqual(status,200);cookies.append(cookie.split(';')[0])
  owner,other=cookies
  self.assertEqual(self.call('GET','/api/operations/dashboard')[0],401)
  self.assertEqual(self.call('POST','/api/operations/brands',{'name':'InteriFY'},owner,'https://wrong.example')[0],403)
  status,b,_,_=self.call('POST','/api/operations/brands',{'name':'InteriFY','config':{'brief':'Interior design.','source':'Test fixture'}},owner);self.assertEqual(status,201)
  self.assertEqual(self.call('GET','/api/operations/brands/'+b['id'],cookie=other)[0],404)
  _,chat,_,_=self.call('POST','/api/conversations',{},owner)
  status,d,_,_=self.call('POST','/api/operations/chat',{'conversation_id':chat['id'],'prompt':'Create a weekly automation for InteriFY Monday at 09:00'},owner);self.assertEqual(status,201);w=d['workflow'];self.assertEqual(w['state'],'draft')
  self.assertEqual(self.call('POST','/api/operations/workflows/action',{'id':w['id'],'action':'activate','reviewed_hash':w['hash']},other)[0],404)
  self.assertEqual(self.call('POST','/api/operations/workflows/action',{'id':w['id'],'action':'activate','reviewed_hash':w['hash']},owner)[0],200)
  status,r,_,_=self.call('POST','/api/operations/run',{'workflow_id':w['id'],'idempotency_key':'http-e2e'},owner);self.assertEqual(status,202)
  worker=Worker(app.operations)
  with patch.dict(os.environ,{'SYNERGY_OPERATIONS_AERNY':'0'}):worker.process(worker.claim())
  status,result,_,_=self.call('GET','/api/operations/runs/'+r['id'],cookie=owner);self.assertEqual(result['state'],'completed_with_blockers')
  for a in result['artifacts']:
   self.assertEqual(self.call('GET','/api/operations/artifacts/'+a['id'],cookie=other)[0],404)
   status,raw,_,disposition=self.call('GET','/api/operations/artifacts/'+a['id'],cookie=owner);self.assertEqual(status,200);self.assertEqual(len(raw),a['size']);self.assertIn('attachment',disposition)
  approval=result['approvals'][0]
  self.assertEqual(self.call('POST','/api/operations/approvals',{'id':approval['id'],'decision':'approved','artifact_hash':approval['artifact_hash']},other)[0],404)
  self.assertEqual(self.call('POST','/api/operations/external-action',{'brand_id':b['id'],'kind':'publish'},owner)[0],409)

if __name__=='__main__':unittest.main()
