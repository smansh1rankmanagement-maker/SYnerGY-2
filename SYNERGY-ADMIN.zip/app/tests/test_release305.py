import io,json,sys,tempfile,threading,time,unittest,uuid,base64
from pathlib import Path
from unittest.mock import patch,MagicMock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
import hybrid_router,model_router
from workspace import Workspace
from research.service import Research
from uploads import Uploads
from PIL import Image

class HybridOrder(unittest.TestCase):
 def setUp(self):
  self.stack=[]
  for target,value in [('hybrid_router.free_router.respond',(None,{'attempts':[]})),('hybrid_router.model_router.external_config',('hidden','configured',True)),('hybrid_router.model_router.openai_response','external answer'),('hybrid_router.free_router.audit',None)]:
   p=patch(target,return_value=value);self.stack.append(p);setattr(self,target.rsplit('.',1)[-1],p.start())
  p=patch('hybrid_router.model_router.select_openai',return_value='gpt-6.1-sol');self.stack.append(p);self.select=p.start()
 def tearDown(self):
  for p in reversed(self.stack):p.stop()
 def run_route(self,**kw):
  return hybrid_router.respond([{'role':'system','content':'Answer truthfully'},{'role':'user','content':'Hi'}],100,permission=True,user_id=7,**kw)
 def test_openai_precedes_legacy_services(self):
  answer,meta=self.run_route();self.assertEqual(answer,'external answer');self.respond.assert_not_called();self.assertEqual(meta['actual_model'],'gpt-6.1-sol')
 def test_model_selection_uses_authenticated_owner_and_mode(self):
  self.run_route(mode='beast');self.select.assert_called_with(7,'beast','auto')
 def test_unavailable_services_use_local_last(self):
  self.openai_response.side_effect=ValueError('sensitive diagnostic')
  answer,meta=self.run_route();self.assertIsNone(answer);self.assertEqual(meta['status'],'local_fallback');self.respond.assert_not_called();self.assertNotIn('sensitive diagnostic',json.dumps(meta))
 def test_provider_budget_rejection_falls_back_locally(self):
  self.openai_response.side_effect=ValueError('Allowance reached')
  answer,meta=self.run_route();self.assertIsNone(answer);self.assertEqual(meta['status'],'local_fallback')
 def test_permission_off_does_not_call_external_services(self):
  answer,_=hybrid_router.respond([],100,permission=False);self.assertIsNone(answer);self.respond.assert_not_called();self.openai_response.assert_not_called()
 def test_account_denial_cannot_be_overridden(self):
  self.select.side_effect=PermissionError()
  self.run_route();self.openai_response.assert_not_called()
 def test_deadline_preserved(self):
  self.run_route(deadline=time.monotonic()-1);self.respond.assert_not_called();self.openai_response.assert_not_called()
 def test_structured_invalid_answer_not_accepted(self):
  self.openai_response.return_value='not JSON';self.assertIsNone(self.run_route(structured=True)[0])
 def test_hybrid_never_selects_local_draft_review(self):
  for family in ['aerny','eternal']:
   for mode in ['chat','work','beast']:
    for effort in ['instant','medium','high','max','ultra']:
     s=model_router.route('hybrid','auto',effort,'Hello',mode=mode,family=family);self.assertEqual(s['workflow'],'hybrid_free')

class Attachments(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.ws=Workspace(self.root/'db');self.r=Research(self.ws,self.root/'research',lambda *a:[],{},threading.Lock(),lambda:False);self.u=Uploads(self.ws,self.r,self.root/'uploads');self.r.uploads=self.u;self.cid=self.ws.create_chat(1)['id']
 def tearDown(self):self.r.close();self.tmp.cleanup()
 def save(self,name,data):
  r=self.u.create(1,{'name':name,'size':len(data),'batch_id':uuid.uuid4().hex,'conversation_id':self.cid});self.u.chunk(1,{'id':r['id'],'index':0,'data':base64.b64encode(data).decode()});return self.u.finish(1,r['id'])['id']
 def test_preview_preserves_original_and_checks_owner(self):
  raw=io.BytesIO();Image.new('RGB',(900,600),'red').save(raw,'PNG');original=raw.getvalue();rid=self.save('reference.png',original);preview=self.u.thumbnail(1,rid)
  with Image.open(io.BytesIO(preview)) as im:self.assertEqual(im.size,(512,341))
  self.assertEqual(self.u.path(1,rid).read_bytes(),original)
  with self.assertRaises(KeyError):self.u.thumbnail(2,rid)
  self.u.delete(1,rid)
  with self.assertRaises(KeyError):self.u.thumbnail(1,rid)
 def test_metadata_survives_message_reopen(self):
  rid=self.save('brief.txt',b'Project: Test Office. Deadline: Friday.')
  with patch.object(self.r,'run'):
   result=self.r.submit(1,{'prompt':'Extract the deadline from my attachment','conversation_id':self.cid,'attachment_ids':[rid],'search_mode':'off'})
  chat=self.ws.chat(1,self.cid);message=next(m for m in chat['messages'] if m['role']=='user');self.assertEqual(message['content'],'Extract the deadline from my attachment');self.assertEqual(message['metadata']['attachments'][0]['id'],rid)
  fid=message['metadata']['file_id'];self.assertIn('Friday',json.dumps(self.r.file(1,fid)['parsed']))
 def test_cross_user_and_cross_conversation_denied(self):
  rid=self.save('brief.txt',b'private')
  with self.assertRaises(KeyError):self.u.message_assets(2,self.cid,[rid])
  other=self.ws.create_chat(1)['id']
  with self.assertRaises(ValueError):self.u.message_assets(1,other,[rid])
  with self.assertRaises(ValueError):self.u.message_assets(1,self.cid,[rid,rid])
 def test_nonimage_cannot_be_rendered_as_image(self):
  rid=self.save('fake.png',b'<script>alert(1)</script>')
  with self.assertRaises(ValueError):self.u.thumbnail(1,rid)

if __name__=='__main__':unittest.main()
