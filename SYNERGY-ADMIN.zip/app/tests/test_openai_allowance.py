import concurrent.futures,os,tempfile,unittest
from unittest.mock import patch
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
import openai_budget as budget
class AllowanceTests(unittest.TestCase):
 def setUp(self):
  self.root=tempfile.TemporaryDirectory();self.addCleanup(self.root.cleanup)
  self.env=patch.dict(os.environ,{'SYNERGY_DATA_DIR':self.root.name,'SYNERGY_OPENAI_BUDGET_USD':'0.10'});self.env.start();self.addCleanup(self.env.stop)
 def request(self):return {'model':'gpt-6.1-sol','input':'fixture','max_output_tokens':2048}
 def test_reserve_settle_and_duplicate_settle(self):
  req=self.request();token=budget.reserve(req);self.assertGreater(budget.status()['reserved_usd'],0)
  budget.finish(token,{'input_tokens':10,'output_tokens':20});budget.finish(token,{'input_tokens':999,'output_tokens':999})
  self.assertEqual(budget.status()['accounted_usd'],.00022);self.assertEqual(budget.status()['reserved_usd'],0)
 def test_concurrent_reservations_cannot_exceed_shared_allowance(self):
  def run(_):
   try:return budget.reserve(self.request())
   except ValueError:return None
  with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(run,range(12)))
  self.assertLess(sum(bool(x) for x in results),12);self.assertLessEqual(budget.status()['reserved_usd'],.10)
 def test_interrupted_requests_stay_reserved_and_unsupported_models_denied(self):
  token=budget.reserve(self.request());before=budget.status();budget.finish(token,{})
  self.assertEqual(before,budget.status())
  with self.assertRaises(ValueError):budget.reserve({**self.request(),'model':'unreviewed-model'})
  with self.assertRaises(ValueError):budget.reserve({**self.request(),'input':'x'*64001})
 def test_no_allowance_never_permits_external_call(self):
  with patch.dict(os.environ,{'SYNERGY_OPENAI_BUDGET_USD':'0'}):
   with self.assertRaises(ValueError):budget.reserve(self.request())
if __name__=='__main__':unittest.main()
