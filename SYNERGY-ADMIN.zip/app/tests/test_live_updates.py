import json,sys,tempfile,unittest,uuid,threading
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from workspace import Workspace
from research.service import Research
from beast.store import Beast
from live_updates import LiveUpdates

class LiveTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();root=Path(self.tmp.name);self.ws=Workspace(root/'db');self.r=Research(self.ws,root/'research',lambda *a:[],{},threading.Lock(),lambda:False);self.b=Beast(root/'db',root/'beast');self.allowed=True
  self.q=LiveUpdates(self.ws,self.r,self.b,self.access)
 def access(self,uid,mode):
  if not self.allowed:raise PermissionError('Subscription expired.')
 def tearDown(self):self.r.close();self.tmp.cleanup()
 def parent(self,mode='chat'):
  with patch('research.service.threading.Thread.start'):return self.r.submit(1,{'prompt':'Write a short greeting','mode':mode,'search_mode':'off'})
 def add(self,t,text='Make it three sentences.',key=None):return self.q.submit(1,{'kind':'research','target_id':t['id'],'text':text,'request_key':key or uuid.uuid4().hex})
 def finish(self,t,state='succeeded'):
  with self.ws.connect() as c:c.execute('UPDATE research_tasks SET state=? WHERE id=?',(state,t['id']))
 def test_all_modes_durable_ordered_followup_and_idempotency(self):
  for mode in ['chat','work','beast']:
   t=self.parent(mode);a=self.add(t,key='same-key-'+mode);b=self.add(t,'Keep the tone friendly.');self.q.tick();self.assertEqual(self.q.list(1,t['conversation_id'])[0]['state'],'queued')
   self.finish(t)
   q=LiveUpdates(self.ws,self.r,self.b,self.access)
   with patch('research.service.threading.Thread.start'):q.tick();q.tick()
   rows=q.list(1,t['conversation_id']);self.assertEqual({x['state'] for x in rows},{'started'});self.assertEqual(len({x['child_id'] for x in rows}),1)
   child=self.r.task(1,rows[0]['child_id']);self.assertEqual(child['request']['prompt'],'Make it three sentences.\n\nKeep the tone friendly.');self.assertEqual(child['request']['mode'],mode);self.finish(child)
   self.assertEqual(self.add(t,key='same-key-'+mode)['id'],a['id'])
 def test_scope_cancel_and_expired_access(self):
  t=self.parent();a=self.add(t)
  with self.assertRaises(KeyError):self.q.list(2,t['conversation_id'])
  with self.assertRaises(KeyError):self.q.cancel(2,a['id'])
  self.q.cancel(1,a['id']);self.assertEqual(self.q.list(1,t['conversation_id'])[0]['state'],'cancelled')
  self.add(t);self.finish(t,'cancelled');self.q.tick();self.assertIn('stopped',self.q.list(1,t['conversation_id'])[0]['error'])
  t=self.parent('work');self.add(t);self.allowed=False;self.finish(t);self.q.tick();self.assertIn('expired',self.q.list(1,t['conversation_id'])[0]['error'])
 def test_crash_after_child_submission_recovers_without_duplicates(self):
  t=self.parent();a=self.add(t);self.finish(t)
  with patch('research.service.threading.Thread.start'):child=self.r.submit(1,{**t['request'],'conversation_id':t['conversation_id'],'prompt':a['text'],'request_id':'followup-'+a['id']})
  with self.ws.connect() as c:c.execute("UPDATE live_updates SET state='dispatching',batch_id=? WHERE id=?",(a['id'],a['id']))
  with patch('research.service.threading.Thread.start'):self.q.tick()
  self.assertEqual(self.q.list(1,t['conversation_id'])[0]['child_id'],child['id'])
  self.assertEqual(len(self.r.list(1)),2)
 def test_beast_preserves_skill_reference_and_review_boundary(self):
  p=self.b.create(1,{'name':'Followup','template':'python'});cid=self.ws.create_chat(1)['id'];t=self.b.submit(1,{'project_id':p['id'],'revision':1,'prompt':'Add a greeting.','conversation_id':cid,'idempotency_key':'original-job'},'Preserve all source.')
  a=self.q.submit(1,{'kind':'beast','target_id':t['id'],'text':'Use a friendly greeting.','request_key':'beast-followup'})
  with self.ws.connect() as c:c.execute("UPDATE beast_jobs SET state='awaiting_review' WHERE id=?",(t['id'],))
  self.q.tick();row=self.q.list(1,cid)[0];self.assertEqual(row['state'],'started');self.assertEqual(self.b.project(1,p['id'])['revision'],1);self.assertEqual(self.b.job(1,t['id'])['state'],'cancelled')
  with self.ws.connect() as c:req=json.loads(c.execute('SELECT request FROM beast_jobs WHERE id=?',(row['child_id'],)).fetchone()[0])
  self.assertEqual(req['skill'],'Preserve all source.');self.assertIn('friendly greeting',req['prompt'])

if __name__=='__main__':unittest.main()
