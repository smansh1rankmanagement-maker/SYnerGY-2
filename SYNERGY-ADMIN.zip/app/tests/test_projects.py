import json,sqlite3,tempfile,unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from workspace import Workspace
class ProjectTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.db=Path(self.temp.name)/'accounts.sqlite3'
  with sqlite3.connect(self.db) as c:
   c.executescript('CREATE TABLE users(id INTEGER PRIMARY KEY,username TEXT,salt BLOB,password BLOB); CREATE TABLE sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER,expires INTEGER); CREATE TABLE conversations(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,title TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL,archived INTEGER NOT NULL DEFAULT 0); CREATE TABLE research_files(id TEXT PRIMARY KEY,user_id INTEGER,name TEXT,parsed TEXT,created REAL);')
   c.execute('INSERT INTO users VALUES(1,?,?,?)',('existing',b'unchanged salt',b'unchanged hash'));c.execute('INSERT INTO sessions VALUES(?,?,?)',('existing-session-hash',1,9999999999));c.execute("INSERT INTO conversations VALUES('old',1,'Saved chat',1,1,0)")
  self.w=Workspace(self.db)
 def tearDown(self):self.temp.cleanup()
 def test_migration_preserves_auth_and_old_chat_idempotently(self):
  Workspace(self.db)
  with sqlite3.connect(self.db) as c:
   self.assertEqual(c.execute('SELECT * FROM users').fetchone(),(1,'existing',b'unchanged salt',b'unchanged hash'))
   self.assertEqual(c.execute('SELECT * FROM sessions').fetchone(),('existing-session-hash',1,9999999999))
  self.assertEqual(self.w.chat(1,'old')['title'],'Saved chat');self.assertIsNone(self.w.chat(1,'old')['project_id'])
 def test_three_modes_projects_and_isolation(self):
  p=self.w.save_project(1,{'name':'InteriFY','instructions':'Use ivory.'})
  for mode in ['chat','work','beast']:self.w.create_chat(1,project_id=p['id'],mode=mode)
  self.assertEqual({x['mode'] for x in self.w.project(1,p['id'])['conversations']},{'chat','work','beast'})
  self.assertEqual(self.w.projects(2),[])
  for fn in [lambda:self.w.project(2,p['id']),lambda:self.w.create_chat(2,project_id=p['id']),lambda:self.w.save_project(2,{'id':p['id'],'name':'Hijack'}),lambda:self.w.move_chat(2,'old',p['id'])]:
   with self.assertRaises(KeyError):fn()
 def test_project_context_only_in_selected_project(self):
  p=self.w.save_project(1,{'name':'A','instructions':'Approved colour: ivory'});q=self.w.save_project(1,{'name':'B'})
  with sqlite3.connect(self.db) as c:c.execute('INSERT INTO research_files VALUES(?,?,?,?,?)',('f1',1,'brief.txt',json.dumps({'sections':[{'label':'Brief','text':'Launch date is November 20.'}]}),1))
  self.w.link_project_file(1,p['id'],'f1');a=self.w.create_chat(1,project_id=p['id']);b=self.w.create_chat(1,project_id=q['id'])
  self.assertIn('November 20',self.w.project_context(1,a['id'])['sources'][0]['excerpt']);self.assertEqual(self.w.project_context(1,b['id'])['sources'],[])
  with self.assertRaises(KeyError):self.w.project_context(2,a['id'])
  self.w.move_chat(1,a['id'],q['id']);self.assertEqual(self.w.project_context(1,a['id'])['sources'],[])
 def test_foreign_file_cannot_be_linked(self):
  p=self.w.save_project(1,{'name':'A'})
  with sqlite3.connect(self.db) as c:c.execute('INSERT INTO research_files VALUES(?,?,?,?,?)',('other',2,'secret.txt','{}',1))
  with self.assertRaises(KeyError):self.w.link_project_file(1,p['id'],'other')
if __name__=='__main__':unittest.main()
