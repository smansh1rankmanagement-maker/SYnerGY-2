import base64,hashlib,io,json,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from beast.store import Beast
from beast.references import References
from beast.templates import starter
from beast.design import guidance
from beast.react_preview import render,available
from model_router import route
import builder_tools
class BuilderTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.b=Beast(self.root/'db',self.root/'beast');self.p=self.b.create(1,{'name':'Reference QA','template':'react'});self.refs=References(self.b)
 def tearDown(self):self.tmp.cleanup()
 def video(self):
  p=self.root/'reference.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=320x180:rate=8','-t','2','-threads','1','-c:v','libx264','-pix_fmt','yuv420p',str(p)],check=True);return p.read_bytes()
 def test_video_original_frames_and_private_reopen(self):
  raw=self.video();ref=self.refs.upload(1,self.p['id'],raw,'screen.mp4');self.assertEqual(ref['metadata']['sha256'],hashlib.sha256(raw).hexdigest());self.assertEqual(self.refs.bytes(1,self.p['id'],ref['id'])[0],raw);self.assertEqual(len(self.refs.images(1,self.p['id'],ref['id'])),4)
  self.assertEqual(References(self.b).list(1,self.p['id'])[0]['id'],ref['id'])
  with self.assertRaises(KeyError):self.refs.get(2,self.p['id'],ref['id'])
  with self.assertRaises(ValueError):self.refs.upload(1,self.p['id'],b'garbage','invalid.mp4')
  j=self.b.submit(1,{'project_id':self.p['id'],'revision':1,'prompt':'Recreate this design','video_reference_id':ref['id'],'idempotency_key':'video-design-qa'})
  with self.assertRaises(ValueError):self.refs.delete(1,self.p['id'],ref['id'])
  self.b.job_action(1,{'id':j['id'],'action':'cancel'});self.refs.delete(1,self.p['id'],ref['id']);self.assertEqual(self.refs.list(1,self.p['id']),[])
 def test_video_reference_cannot_cross_projects(self):
  other=self.b.create(2,{'name':'Private','template':'empty'});ref=self.refs.upload(2,other['id'],self.video(),'private.mp4')
  with self.assertRaises(KeyError):self.b.submit(1,{'project_id':self.p['id'],'revision':1,'prompt':'Recreate this design','video_reference_id':ref['id'],'idempotency_key':'blocked-video'})
 def test_installed_design_guidance_and_honest_apper(self):
  d=guidance('Design a responsive interior studio website',self.p['files']);self.assertEqual(d['source'],'UI/UX Pro Max');self.assertIn('motion',d);self.assertIsNone(guidance('Fix this Python addition function',{}))
  self.assertIn('not connected',builder_tools.request('Use Apper to build my app'));self.assertIsNone(builder_tools.request('Build without Apper'))
 def test_fast_routing_preserves_complex_quality(self):
  self.assertIn('fast',route(effort='instant',prompt='Write a friendly three-word greeting')['model'])
  for p in ['Research current interior designers with sources','Debug this Python function','Compare two mortgage options','Explain security architecture']:
   self.assertNotIn('fast',route(effort='instant',prompt=p)['model'])
  self.assertNotIn('fast',route(effort='instant',prompt='Hi',complex_context=True)['model'])
 def test_real_react_motion_compile_and_isolation(self):
  if not available():self.skipTest('Run this check in the installed deployment runtime.')
  html,warnings,csp=render(self.p['files'],'src/main.jsx');self.assertIn('Your preview is interactive',html);self.assertIn('sha256-',csp);self.assertIn('sandbox allow-scripts',csp);self.assertNotIn('allow-same-origin',csp);self.assertIn("connect-src 'none'",csp)
  files=dict(self.p['files']);files['src/main.jsx']={'encoding':'utf-8','content':'import fs from "node:fs"; console.log(fs);'}
  with self.assertRaisesRegex(ValueError,'Unsupported'):render(files,'src/main.jsx')
  files['src/main.jsx']={'encoding':'utf-8','content':'import x from "https://evil.invalid/script.js";'}
  with self.assertRaisesRegex(ValueError,'Unsupported'):render(files,'src/main.jsx')
if __name__=='__main__':unittest.main()
