"""Paid user fixtures for existing feature tests; never imported by application code."""
import time

def registration_fixture(path,data):
    if path=='/api/auth/register' and isinstance(data,dict) and 'email' not in data:
        return {**data,'email':data['username']+'@qa.invalid'}
    return data

def paid_fixture(app,path):
    if path!='/api/auth/register':return
    with app.membership.connect() as c:
        for u in c.execute("SELECT id FROM users WHERE email LIKE '%@qa.invalid'").fetchall():
            c.execute('INSERT OR IGNORE INTO subscriptions VALUES(?,?,?,?,?,?,NULL,?,?)',('fixture-'+str(u[0]),u[0],'beast',time.time()-10,time.time()+86400,'active',time.time(),'test_fixture'))
