import base64,hashlib,json,subprocess,sys,tempfile,threading,unittest,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from workspace import Workspace
from research.service import Research
from uploads import Uploads,MAX_UPLOAD,CHUNK
from observation_mcp import observe
class UploadTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.ws=Workspace(self.root/'db');self.r=Research(self.ws,self.root/'research',lambda *a:[],{},threading.Lock(),lambda:False);self.u=Uploads(self.ws,self.r,self.root/'uploads');self.cid=self.ws.create_chat(1)['id']
 def tearDown(self):self.r.close();self.tmp.cleanup()
 def create(self,name='notes.txt',size=5,batch=None):return self.u.create(1,{'name':name,'size':size,'batch_id':batch or uuid.uuid4().hex,'conversation_id':self.cid})
 def test_chunks_integrity_resume_download_and_ownership(self):
  data=b'A'*(CHUNK+43);row=self.create(size=len(data));rid=row['id']
  with self.assertRaises(ValueError):self.u.finish(1,rid)
  chunk={'id':rid,'index':0,'data':base64.b64encode(data[:CHUNK]).decode()};self.u.chunk(1,chunk);self.assertTrue(self.u.chunk(1,chunk)['duplicate'])
  with self.assertRaises(ValueError):self.u.chunk(1,{**chunk,'data':base64.b64encode(b'B'*CHUNK).decode()})
  with self.assertRaises(KeyError):self.u.chunk(2,chunk)
  reopened=Uploads(self.ws,self.r,self.root/'uploads');reopened.chunk(1,{'id':rid,'index':1,'data':base64.b64encode(data[CHUNK:]).decode()});done=reopened.finish(1,rid);self.assertEqual(done['sha256'],hashlib.sha256(data).hexdigest());self.assertEqual(reopened.path(1,rid).read_bytes(),data);self.assertEqual(reopened.finish(1,rid)['sha256'],done['sha256'])
  f=reopened.prepare(1,[rid])['file'];self.assertTrue(f['parsed']['partial']);self.assertEqual((self.r.root/'files'/f['id']/'original').stat().st_size,len(data));reopened.delete(1,rid)
  with self.assertRaises(KeyError):reopened.get(1,rid)
 def test_200mb_boundary_and_folder_total(self):
  batch=uuid.uuid4().hex;r=self.create('folder/large.bin',MAX_UPLOAD,batch)
  with self.assertRaises(ValueError):self.create('folder/extra.bin',1,batch)
  with self.assertRaises(ValueError):self.create(size=MAX_UPLOAD+1)
  for name in ['../escape','/absolute','folder//x','bad\x00name']:
   with self.assertRaises(ValueError):self.create(name)
  self.u.delete(1,r['id'])
 def test_real_mcp_tool_and_no_false_positive_approval(self):
  requests=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{}},{'jsonrpc':'2.0','id':2,'method':'tools/list'},{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'synergy_observe_feedback','arguments':{'text':'Not what I asked. Explain in detail with bullet points.'}}}]
  p=subprocess.run([sys.executable,str(Path(__file__).resolve().parents[1]/'backend/observation_mcp.py')],input='\n'.join(json.dumps(r) for r in requests)+'\n',text=True,capture_output=True,check=True);answers=[json.loads(x) for x in p.stdout.splitlines()];self.assertEqual(len(answers),3);signals=answers[-1]['result']['structuredContent'];self.assertEqual({s['signal'] for s in signals['signals']},{'correction_requested','more_detail'});self.assertIn('unknown',signals['inference']);self.assertFalse(observe('I am not satisfied')['signals']);self.assertEqual(observe('Hello')['signals'],[])
if __name__=='__main__':unittest.main()
