import io,json,os,sys,tempfile,time,unittest,urllib.error
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
import free_router,model_router
class Reply(io.BytesIO):
 def __enter__(self):return self
 def __exit__(self,*a):self.close()
def response(text='Complete answer.',model='fixture/free',finish='stop'):
 return Reply(json.dumps({'model':model,'choices':[{'message':{'content':text},'finish_reason':finish}],'usage':{'total_tokens':12}}).encode())
def rejected(code,provider=False):
 return urllib.error.HTTPError('https://openrouter.ai',code,'Unavailable',{'Retry-After':'120'},io.BytesIO(json.dumps({'error':{'metadata':{'provider_name':'fixture'} if provider else {}}}).encode()))
class FreeRoutingTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.env=patch.dict(os.environ,{'SYNERGY_DATA_DIR':self.tmp.name});self.env.start();self.messages=[{'role':'user','content':'private fixture text'}]
 def tearDown(self):self.env.stop();self.tmp.cleanup()
 def models(self):return [{'id':'fixture/first:free'},{'id':'fixture/second:free'}]
 def test_no_external_calls_without_account_optin(self):
  with patch.object(free_router,'candidates') as choose:
   reply,meta=free_router.respond(self.messages,100,False)
  choose.assert_not_called();self.assertIsNone(reply);self.assertEqual(meta['status'],'local')
 def test_model_specific_limit_fails_over_and_audit_excludes_prompt(self):
  with patch.object(free_router,'candidates',return_value=self.models()),patch.object(free_router,'credential',return_value='private fixture secret'),patch('free_router.urllib.request.urlopen',side_effect=[rejected(429,True),response()]) as call:
   reply,meta=free_router.respond(self.messages,100,True)
  self.assertEqual(reply,'Complete answer.');self.assertEqual(len(meta['attempts']),2);self.assertEqual(call.call_count,2)
  for request in [c.args[0] for c in call.call_args_list]:
   d=json.loads(request.data);self.assertEqual(d['provider']['max_price'],{'prompt':0,'completion':0});self.assertEqual(d['provider']['data_collection'],'deny')
  with free_router.database() as c:audit=[dict(r) for r in c.execute('SELECT * FROM routes')]
  self.assertNotIn('private fixture',json.dumps(audit));self.assertTrue(free_router.cooling('fixture/first:free'))
 def test_account_limit_stops_rotation_and_falls_back_locally(self):
  with patch.object(free_router,'candidates',return_value=self.models()),patch('free_router.urllib.request.urlopen',side_effect=rejected(429)) as call:
   reply,meta=free_router.respond(self.messages,100,True)
  self.assertIsNone(reply);self.assertEqual(call.call_count,1);self.assertEqual(meta['status'],'local_fallback');self.assertTrue(free_router.cooling('account'))
 def test_invalid_key_does_not_try_multiple_models(self):
  with patch.object(free_router,'candidates',return_value=self.models()),patch('free_router.urllib.request.urlopen',side_effect=rejected(401)) as call:
   reply,meta=free_router.respond(self.messages,100,True)
  self.assertIsNone(reply);self.assertEqual(call.call_count,1)
 def test_paid_or_non_text_models_never_enter_free_pool(self):
  def m(name,price,output=['text']):return free_router.public_model({'id':name,'pricing':{'prompt':str(price),'completion':'0'},'architecture':{'input_modalities':['text'],'output_modalities':output}})
  models=[m('paid/one',.01),m('free/one',0),m('audio/one',0,['audio']),m('hidden/request',0)]
  models[-1]['free']=False
  with patch.object(free_router,'credential',return_value='fixture'),patch.object(free_router,'catalog',return_value={'models':models}):self.assertEqual([m['id'] for m in free_router.candidates(self.messages)],['free/one'])
  self.assertFalse(free_router.public_model({'id':'test','pricing':{'prompt':'0','completion':'0','request':'.01'}})['free'])
 def test_incomplete_answer_not_mixed_with_next_provider(self):
  with patch.object(free_router,'candidates',return_value=self.models()),patch('free_router.urllib.request.urlopen',side_effect=[response('Cut off',finish='length'),response('Complete second answer.')]):
   reply,meta=free_router.respond(self.messages,100,True)
  self.assertEqual(reply,'Complete second answer.');self.assertNotIn('Cut off',reply)
 def test_paid_openai_is_not_selected_for_default_hybrid_any_family(self):
  with patch.object(free_router,'enabled',return_value=True),patch('model_router.external_config',return_value=('configured','gpt-6.1-sol',True)):
   for family in ['aerny','eternal']:
    for mode in ['chat','work','beast']:
     selected=model_router.route('hybrid','auto','ultra','debug this architecture',mode=mode,family=family)
     self.assertEqual(selected['workflow'],'hybrid_free');self.assertEqual(selected['provider'],'synergy')
 def test_structured_proposal_requires_json(self):
  with patch.object(free_router,'candidates',return_value=self.models()),patch('free_router.urllib.request.urlopen',side_effect=[response('not json'),response('{"changes":[]}',model='fixture/second')]):
   reply,meta=free_router.respond(self.messages,100,True,structured=True)
  self.assertEqual(json.loads(reply),{'changes':[]})
 def test_quota_notice_is_temporary_and_contains_no_model_name(self):
  notices=[]
  with patch.object(free_router,'candidates',return_value=self.models()),patch('free_router.urllib.request.urlopen',side_effect=[rejected(429,True),response()]):
   reply,meta=free_router.respond(self.messages,100,True,notice=notices.append)
  self.assertEqual(len(notices),1);self.assertEqual(notices[0]['message'],'Switched to another available service.')
  self.assertLess(notices[0]['expires']-notices[0]['created'],9);self.assertNotIn('fixture',json.dumps(notices))
 def test_connection_error_is_not_claimed_as_quota_exhaustion(self):
  notices=[]
  with patch.object(free_router,'candidates',return_value=self.models()),patch('free_router.urllib.request.urlopen',side_effect=[rejected(404),response()]):
   free_router.respond(self.messages,100,True,notice=notices.append)
  self.assertFalse(notices)
 def test_direct_gemini_requires_separate_data_use_consent(self):
  with patch.object(free_router,'candidates',return_value=[]),patch.object(free_router,'gemini_enabled',return_value=True),patch.object(free_router,'gemini_paid_access',return_value=True),patch('free_router.urllib.request.urlopen') as call:
   reply,meta=free_router.respond(self.messages,100,True)
  call.assert_not_called();self.assertIsNone(reply)
 def test_gemini_receives_authorized_messages_and_json_configuration(self):
  data={'modelVersion':'gemini-fixture','candidates':[{'finishReason':'STOP','content':{'parts':[{'text':'{"changes":[]}'}]}}]}
  with patch.object(free_router,'candidates',return_value=[]),patch.object(free_router,'gemini_enabled',return_value=True),patch.object(free_router,'gemini_paid_access',return_value=True),patch.object(free_router,'gemini_credential',return_value='fixture-secret'),patch('free_router.urllib.request.urlopen',return_value=Reply(json.dumps(data).encode())) as call:
   reply,meta=free_router.respond(self.messages,100,True,structured=True,free_data_permission=True)
  self.assertEqual(meta['actual_provider'],'gemini');self.assertEqual(json.loads(reply),{'changes':[]})
  body=json.loads(call.call_args.args[0].data);self.assertEqual(body['generationConfig']['responseMimeType'],'application/json');self.assertNotIn('fixture-secret',json.dumps(body))
 def test_gemini_quota_limit_stops_shared_provider_then_local(self):
  notices=[]
  with patch.object(free_router,'candidates',return_value=[]),patch.object(free_router,'gemini_enabled',return_value=True),patch.object(free_router,'gemini_paid_access',return_value=True),patch('free_router.urllib.request.urlopen',side_effect=rejected(429)) as call:
   reply,meta=free_router.respond(self.messages,100,True,free_data_permission=True,notice=notices.append)
  self.assertEqual(call.call_count,1);self.assertTrue(free_router.cooling('gemini_account'));self.assertFalse(notices);self.assertIsNone(reply)
if __name__=='__main__':unittest.main()
