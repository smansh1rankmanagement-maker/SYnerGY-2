"""Check real job orchestration without pretending a model inference ran."""
import base64
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend' / 'image_studio'))
from core import Jobs, EXPORT_SIZES

# Valid 1x1 PNG, used as a file fixture only. The model is not called.
PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/aN0AAAAASUVORK5CYII=')

class ImageJobsTest(unittest.TestCase):
    def test_image_reference_is_passed_to_worker_and_job_completes(self):
        with tempfile.TemporaryDirectory() as d:
            observed = {}
            manager = None
            def fake_worker(jid):
                folder = manager.folder(jid)
                observed['ref'] = (folder / 'reference.bin').read_bytes()
                observed['job'] = json.loads((folder / 'job.json').read_text())
                (folder / 'image.png').write_bytes(PNG)
                (folder / 'result.json').write_text(json.dumps({'blocked': False, 'fixture': True}))
            manager = Jobs(Path(d), runner=fake_worker)
            with patch.object(manager, 'status', return_value={'ready': True}):
                job = manager.submit({'prompt': 'A portrait', 'size': 'yt_thumbnail_4k', 'quality': 'detail', 'reference_b64': base64.b64encode(PNG).decode()})
                until = time.monotonic() + 3
                while manager.get(job['id'])['state'] in {'queued','running'} and time.monotonic() < until:
                    time.sleep(.01)
                result = manager.get(job['id'])
            self.assertEqual(result['state'], 'succeeded')
            self.assertEqual(observed['ref'], PNG)
            self.assertTrue(observed['job']['reference'])
            self.assertEqual(EXPORT_SIZES[observed['job']['size']], (3840, 2160))
            self.assertTrue(result['result']['fixture'])
            manager.close()
    def test_invalid_reference_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            manager = Jobs(Path(d))
            with self.assertRaises(ValueError):
                manager.submit({'prompt':'Test', 'reference_b64':base64.b64encode(b'not an image').decode()})
            manager.close()

if __name__ == '__main__': unittest.main()
