"""Actual authenticated HTTP/MCP/chat pipeline against temporary application data."""
from membership_fixtures import registration_fixture,paid_fixture
import base64,hashlib,io,json,os,threading,time,unittest,uuid
from http.client import HTTPConnection
from PIL import Image
from test_backend import app
from media.worker import Worker
MEDIA_PY=os.environ.get('SYNERGY_MEDIA_TEST_PYTHON')

class MediaHTTPTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.server=app.ThreadingHTTPServer(('127.0.0.1',18090),app.Handler);threading.Thread(target=cls.server.serve_forever,daemon=True).start()
  cls.worker=Worker(app.media,MEDIA_PY or os.sys.executable);cls.thread=None
  if MEDIA_PY:cls.thread=threading.Thread(target=cls.worker.run,daemon=True);cls.thread.start()
 @classmethod
 def tearDownClass(cls):
  cls.worker.stop.set()
  if cls.thread:cls.thread.join(10)
  cls.server.shutdown();cls.server.server_close()
 def req(self,method,path,data=None,cookie=None,headers=None):
  data=registration_fixture(path,data);c=HTTPConnection('127.0.0.1',18090,timeout=45);h=headers or {}
  if data is not None:h['Content-Type']='application/json';data=json.dumps(data)
  if cookie:h['Cookie']=cookie
  c.request(method,path,data,h);r=c.getresponse();raw=r.read();out=json.loads(raw) if r.getheader('Content-Type')=='application/json' else raw;status=r.status;rh=dict(r.getheaders());c.close();paid_fixture(app,path);return status,out,rh
 def user(self):return self.req('POST','/api/auth/register',{'username':'media'+uuid.uuid4().hex[:10],'password':'Long test password 2026'})[2]['Set-Cookie']
 def upload(self,cookie):
  cid=self.req('POST','/api/conversations',{},cookie)[1]['id'];b=io.BytesIO();Image.new('RGB',(240,160),'#37634f').save(b,'PNG');raw=b.getvalue();status,r,_=self.req('POST','/api/uploads/create',{'conversation_id':cid,'name':'fixture.png','size':len(raw),'batch_id':uuid.uuid4().hex},cookie);self.assertEqual(status,200,r)
  self.req('POST','/api/uploads/chunk',{'id':r['id'],'index':0,'data':base64.b64encode(raw).decode()},cookie);self.req('POST','/api/uploads/finish',{'id':r['id']},cookie);return cid,r['id']
 def wait(self,cookie,path):
  until=time.monotonic()+60
  while time.monotonic()<until:
   status,r,_=self.req('GET',path,cookie=cookie);self.assertEqual(status,200)
   if r['state'] not in {'queued','running','cancelling'}:return r
   time.sleep(.1)
  self.fail('Media job exceeded test timeout.')
 def test_auth_scope_schema_and_csrf(self):
  a,b=self.user(),self.user();cid,rid=self.upload(a);self.assertEqual(self.req('GET','/api/media-tools')[0],401)
  self.assertEqual(self.req('POST','/api/media-tools/submit',{'conversation_id':cid,'upload_ids':[rid],'recipe':{'kind':'analyze'}},b)[0],404)
  self.assertEqual(self.req('POST','/api/media-tools/call',{'tool':'media_submit','arguments':{'conversation_id':cid,'recipe':{'kind':'analyze'},'user_id':1}},a)[0],400)
  self.assertEqual(self.req('POST','/api/media-tools/submit',{'conversation_id':cid,'recipe':{'kind':'analyze'}},a,{'Origin':'https://evil.test'})[0],403)
  self.assertEqual(self.req('POST','/api/media-tools/submit',{'conversation_id':cid,'source_path':'/etc/passwd','recipe':{'kind':'analyze'}},a)[0],400)
 @unittest.skipUnless(MEDIA_PY,'Requires installed media runtime')
 def test_real_download_range_isolation_and_saved_versions(self):
  a,b=self.user(),self.user();cid,rid=self.upload(a);status,j,_=self.req('POST','/api/media-tools/call',{'tool':'media_submit','mode':'chat','arguments':{'conversation_id':cid,'upload_ids':[rid],'recipe':{'kind':'image','operations':[{'op':'resize','width':320,'height':240}]} }},a);self.assertEqual(status,200,j);done=self.wait(a,'/api/media-tools/jobs/'+j['id']);self.assertEqual(done['state'],'succeeded',done);r=done['result']
  status,raw,h=self.req('GET',r['url'],cookie=a);self.assertEqual(status,200);self.assertEqual(hashlib.sha256(raw).hexdigest(),r['sha256']);self.assertEqual(Image.open(io.BytesIO(raw)).size,(320,240));self.assertIn('no-store',h['Cache-Control'])
  status,part,h=self.req('GET',r['url'],cookie=a,headers={'Range':'bytes=0-15'});self.assertEqual(status,206);self.assertEqual(part,raw[:16]);self.assertTrue(h['Content-Range'].startswith('bytes 0-15/'))
  self.assertEqual(self.req('GET',r['download_url'],cookie=b)[0],404);self.assertEqual(self.req('GET',r['url'])[0],401);self.assertEqual(self.req('GET',r['preview_url'],cookie=b)[0],404);self.assertEqual(self.req('GET','/api/media-tools/projects/'+r['project_id'],cookie=a)[1]['versions'][-1]['id'],r['asset_id'])
  _,task,_=self.req('POST','/api/research/tasks',{'conversation_id':cid,'prompt':'Make it brighter','search_mode':'off'},a)
  follow=self.wait(a,'/api/research/tasks/'+task['id']);self.assertEqual(follow['state'],'succeeded',follow);self.assertEqual(follow['request']['media']['source_id'],r['asset_id'])
  self.assertEqual(follow['request']['media']['project_id'],r['project_id'])
 @unittest.skipUnless(MEDIA_PY,'Requires installed media runtime')
 def test_chat_work_beast_eternal_aerny_actual_mcp_and_followup(self):
  cookie=self.user()
  for family in ['eternal','aerny']:
   for mode in ['chat','work','beast']:
    cid,rid=self.upload(cookie);status,t,_=self.req('POST','/api/research/tasks',{'conversation_id':cid,'upload_ids':[rid],'prompt':'Resize this image to 320 x 240','model_family':family,'mode':mode,'provider':'synergy','search_mode':'off','request_id':uuid.uuid4().hex},cookie);self.assertEqual(status,202,t);done=self.wait(cookie,'/api/research/tasks/'+t['id']);self.assertEqual(done['state'],'succeeded',done);self.assertTrue(done['detail']['metrics']['actual_mcp_call']);self.assertTrue(done['detail']['artifacts']);self.assertEqual(done['request']['model_family'],family)
  _,t,_=self.req('POST','/api/research/tasks',{'conversation_id':cid,'prompt':'Make it brighter','model_family':'aerny','mode':'beast','search_mode':'off'},cookie);follow=self.wait(cookie,'/api/research/tasks/'+t['id']);self.assertEqual(follow['state'],'succeeded',follow);history=self.req('GET','/api/conversations/'+cid,cookie=cookie)[1];self.assertTrue(history['messages'][-1]['metadata']['media_result']);self.assertGreater(history['messages'][-1]['metadata']['media_result']['version'],2)
 def test_ambiguous_edit_clarifies_without_job(self):
  cookie=self.user();cid,rid=self.upload(cookie)
  status,t,_=self.req('POST','/api/research/tasks',{'conversation_id':cid,'upload_ids':[rid],'prompt':'Resize this image','search_mode':'off'},cookie);self.assertEqual(status,202,t);done=self.wait(cookie,'/api/research/tasks/'+t['id']);self.assertEqual(done['state'],'succeeded');self.assertIn('dimensions',done['reply']);self.assertFalse(done['detail']['metrics']['actual_mcp_call']);self.assertNotIn('media_job_id',done['detail'])

if __name__=='__main__':unittest.main()
