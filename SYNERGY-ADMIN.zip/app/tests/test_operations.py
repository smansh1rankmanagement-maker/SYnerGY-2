import datetime as dt,hashlib,hmac,json,os,sqlite3,sys,tempfile,time,unittest,zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from operations.store import Operations,next_due,dump
from operations.worker import Worker
from operations.seo import audit
from operations.artifacts import workbook

class OperationsTest(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.path=Path(self.tmp.name);self.db=self.path/'accounts.sqlite3'
  with sqlite3.connect(self.db) as c:c.execute('CREATE TABLE users(id INTEGER PRIMARY KEY,username TEXT)');c.executemany('INSERT INTO users VALUES(?,?)',[(1,'owner'),(2,'other'),(3,'reviewer'),(4,'member')])
  self.o=Operations(self.db,self.path/'operations');self.b=self.o.save_brand(1,{'name':'InteriFY','config':{'brief':'Interior design for offices and homes.','source':'Permissioned fixture','services':'Interior design'}})
 def workflow(self,s=None):
  w=self.o.save_workflow(1,{'brand_id':self.b['id'],'name':'Weekly review','schedule':s or {'kind':'manual','timezone':'Asia/Kolkata'}})
  return self.o.workflow_action(1,w['id'],{'action':'activate','reviewed_hash':w['hash']})
 def run_all(self):
  w=self.workflow();r=self.o.enqueue(1,w['id'],'test');worker=Worker(self.o)
  with patch.dict(os.environ,{'SYNERGY_OPERATIONS_AERNY':'0'}):
   for _ in range(10):
    rid=worker.claim()
    if rid:worker.process(rid)
    result=self.o.run(1,r['id'])
    if result['state'] not in {'queued','running'}:return result
    time.sleep(2.1)
  self.fail('Run did not finish')
 def test_retention_keeps_trigger_receipt(self):
  w=self.workflow();r=self.o.enqueue(1,w['id'],'retained')
  with self.o.connect() as c:c.execute("UPDATE ops_runs SET state='cancelled',finished=? WHERE id=?",(time.time()-400*86400,r['id']))
  self.assertEqual(self.o.purge_expired(),1)
  with self.assertRaises(KeyError):self.o.run(1,r['id'])
  with self.assertRaises(ValueError):self.o.enqueue(1,w['id'],'retained')
 def test_brand_deletion_removes_scratch_outputs(self):
  w=self.workflow();r=self.o.enqueue(1,w['id'],'delete-test');self.o.run_action(1,r['id'],'cancel')
  scratch=self.o.root/'scratch'/r['id'];scratch.mkdir();(scratch/'draft.txt').write_text('Private brand draft')
  self.o.delete_brand(1,self.b['id'],'InteriFY');self.assertFalse(scratch.exists())
 def test_credential_fields_are_rejected(self):
  with self.assertRaises(ValueError):self.o.save_brand(1,{'name':'Unsafe','config':{'brief':'api_key: never-copy-me'}})
 def test_brand_and_data_isolation(self):
  self.assertEqual(self.o.brands(2),[])
  with self.assertRaises(KeyError):self.o.brand(2,self.b['id'])
  with self.assertRaises(KeyError):self.o.save_lead(2,self.b['id'],{'name':'Not allowed'})
  self.o.member(1,self.b['id'],'member','member');self.o.member(1,self.b['id'],'reviewer','reviewer')
  with self.assertRaises(PermissionError):self.o.save_workflow(4,{'brand_id':self.b['id']})
  with self.assertRaises(PermissionError):self.o.save_lead(3,self.b['id'],{'name':'No write'})
  self.o.member(1,self.b['id'],'member','remove')
  with self.assertRaises(KeyError):self.o.brand(4,self.b['id'])
 def test_brand_revision_approval_is_invalidated(self):
  b=self.o.approve_brand(1,self.b['id'],1);self.assertEqual(b['approved_revision'],1)
  b=self.o.save_brand(1,{'id':b['id'],'revision':1,'name':b['name'],'config':{**b['config'],'brief':'Changed'}})
  self.assertEqual(b['revision'],2);self.assertEqual(b['approved_revision'],0)
  with self.assertRaises(ValueError):self.o.approve_brand(1,b['id'],1)
 def test_activation_requires_exact_reviewed_definition(self):
  w=self.o.save_workflow(1,{'brand_id':self.b['id']})
  with self.assertRaises(ValueError):self.o.enqueue(1,w['id'])
  with self.assertRaises(ValueError):self.o.workflow_action(1,w['id'],{'action':'activate','reviewed_hash':'stale'})
  self.o.workflow_action(1,w['id'],{'action':'activate','reviewed_hash':w['hash']})
  new=self.o.save_workflow(1,{'id':w['id'],'version':1,'brand_id':self.b['id'],'schedule':{'kind':'weekly','time':'10:00','weekday':2,'timezone':'Asia/Kolkata'}})
  self.assertEqual(new['version'],2);self.assertEqual(new['state'],'draft')
  with self.o.connect() as c:self.assertEqual(c.execute('SELECT count(*) FROM ops_versions').fetchone()[0],2)
 def test_timezone_weekly_and_dst(self):
  stamp=dt.datetime(2026,11,4,10,tzinfo=dt.timezone.utc).timestamp();s={'kind':'weekly','weekday':0,'time':'09:00','timezone':'Asia/Kolkata'}
  self.assertEqual(dt.datetime.fromtimestamp(next_due(s,stamp),dt.timezone.utc).isoformat(),'2026-11-09T03:30:00+00:00')
  # New York spring gap at 02:30 skips the non-existent occurrence.
  s={'kind':'weekly','weekday':6,'time':'02:30','timezone':'America/New_York'}
  after=dt.datetime(2026,3,7,12,tzinfo=dt.timezone.utc).timestamp()
  self.assertEqual(dt.datetime.fromtimestamp(next_due(s,after),dt.timezone.utc).date(),dt.date(2026,3,15))
 def test_concurrent_duplicate_triggers_are_one_run(self):
  w=self.workflow()
  with ThreadPoolExecutor(max_workers=5) as pool:ids=list(pool.map(lambda _:self.o.enqueue(1,w['id'],'same')['id'],range(5)))
  self.assertEqual(len(set(ids)),1)
 def test_scheduler_catchup_and_pause(self):
  w=self.workflow({'kind':'weekly','weekday':0,'time':'09:00','timezone':'Asia/Kolkata'})
  due=w['next_run'];self.assertEqual(len(self.o.tick(due+1)),1);self.assertEqual(self.o.tick(due+2),[])
  self.o.workflow_action(1,w['id'],{'action':'pause'});self.assertEqual(self.o.tick(due+604801),[])
 def test_event_receipts_are_idempotent(self):
  w=self.workflow({'kind':'event','event':'brand.updated','timezone':'Asia/Kolkata'})
  self.o.save_brand(1,{'id':self.b['id'],'revision':1,'name':'InteriFY','config':{'brief':'New'}})
  self.assertEqual(len(self.o.tick()),1);self.assertEqual(self.o.tick(),[])
 def test_signed_webhook_and_replay(self):
  w=self.workflow({'kind':'webhook','timezone':'Asia/Kolkata'});key=self.o.webhook_key(1,w['id'])['key'];stamp=str(int(time.time()));body=b'{"event":"changed"}';eid='external-1'
  sig=hmac.new(key.encode(),stamp.encode()+b'\n'+eid.encode()+b'\n'+body,hashlib.sha256).hexdigest()
  a=self.o.webhook(w['id'],stamp,eid,sig,body);self.assertEqual(a,self.o.webhook(w['id'],stamp,eid,sig,body))
  with self.assertRaises(PermissionError):self.o.webhook(w['id'],stamp,eid,sig,b'changed')
  with self.assertRaises(PermissionError):self.o.webhook(w['id'],'1',eid,sig,body)
 def test_pause_cancel_and_recovery(self):
  w=self.workflow();r=self.o.enqueue(1,w['id']);self.o.run_action(1,r['id'],'pause');self.assertIsNone(Worker(self.o).claim());self.o.run_action(1,r['id'],'resume');self.assertEqual(Worker(self.o).claim(),r['id'])
  with self.o.connect() as c:c.execute("UPDATE ops_steps SET state='complete',result='{}' WHERE run_id=? AND key='inputs'",(r['id'],))
  Worker(self.o).recover();r=self.o.run(1,r['id']);self.assertEqual(r['state'],'queued');self.assertEqual(r['steps'][0]['state'],'complete')
  self.o.run_action(1,r['id'],'cancel');self.assertIsNone(Worker(self.o).claim())
 def test_lead_deduplication_and_optout(self):
  a=self.o.save_lead(1,self.b['id'],{'name':'A','email':'A@example.com','opt_out':True});b=self.o.save_lead(1,self.b['id'],{'name':'Updated','email':'a@example.com','opt_out':True});self.assertEqual(a['id'],b['id'])
  with self.assertRaises(ValueError):self.o.save_lead(1,self.b['id'],{'name':'A','email':'a@example.com','opt_out':False})
 def test_robots_and_failed_connections(self):
  b={**self.b,'config':{**self.b['config'],'website':'https://example.com','website_authorized':True}}
  def blocked(url,**kw):return {'url':url,'status':200,'body':b'User-agent: *\nDisallow: /','headers':{},'redirects':[]}
  a=audit(b,blocked);self.assertEqual(a['state'],'blocked');self.assertEqual(a['pages'][0]['access'],'robots disallowed')
  def failed(*a,**kw):raise TimeoutError('offline')
  self.assertIn('offline',audit(b,failed)['blocker'])
 def test_crawl_extracts_evidence_without_metric_fabrication(self):
  b={**self.b,'config':{**self.b['config'],'website':'https://example.com','website_authorized':True}}
  def reader(url,**kw):
   status=404 if url.endswith(('robots.txt','sitemap.xml')) else 200
   return {'url':url,'status':status,'body':b'<html><head><title>Office concepts</title></head><body><h1>Office concepts</h1></body></html>','headers':{},'redirects':[]}
  a=audit(b,reader);self.assertEqual(a['state'],'complete');self.assertTrue(any(x['key'].startswith('description') for x in a['issues']));self.assertIsNone(a['performance']);self.assertEqual(len(a['pages']),1)
 def test_real_exports_and_version_bound_approvals(self):
  r=self.run_all();self.assertEqual(r['state'],'completed_with_blockers',r);self.assertEqual({a['kind'] for a in r['artifacts']},{'xlsx','pdf','markdown','evidence'});self.assertEqual(len(r['approvals']),1)
  for a in r['artifacts']:
   with self.assertRaises(KeyError):self.o.artifact(2,a['id'])
   _,p=self.o.artifact(1,a['id']);self.assertGreater(p.stat().st_size,100)
   if a['kind']=='xlsx':
    import openpyxl
    wb=openpyxl.load_workbook(p,data_only=False);cache=openpyxl.load_workbook(p,data_only=True)
    self.assertEqual(wb['Calendar']['B4'].value,'=COUNTA(D8:D14)');self.assertEqual(cache['Calendar']['B4'].value,7);self.assertEqual(cache['SEO tasks']['B5'].value,'n.a.');self.assertTrue(wb['Calendar'].tables);self.assertTrue(wb['Calendar'].data_validations.dataValidation)
   if a['kind']=='pdf':
    from pypdf import PdfReader
    pdf=PdfReader(p);self.assertGreaterEqual(len(pdf.pages),2);self.assertIn('InteriFY',pdf.pages[0].extract_text())
  a=r['approvals'][0]
  with self.assertRaises(ValueError):self.o.approve(1,a['id'],{'decision':'approved','artifact_hash':'wrong'})
  self.o.approve(1,a['id'],{'decision':'approved','artifact_hash':a['artifact_hash']})
  posts=next(s for s in r['steps'] if s['key']=='calendar')['result']['posts'];posts[0]['caption']='Revised caption';new=self.o.revise(1,r['id'],posts);self.assertNotEqual(new['id'],r['id']);self.assertEqual(new['approvals'],[]);self.assertEqual(self.o.run(1,r['id'])['approvals'][0]['state'],'approved')
 def test_deletion_removes_client_records(self):
  self.o.save_lead(1,self.b['id'],{'name':'Delete fixture'})
  with self.assertRaises(ValueError):self.o.delete_brand(1,self.b['id'],'wrong')
  self.o.delete_brand(1,self.b['id'],'InteriFY');self.assertEqual(self.o.brands(1),[])
  with self.o.connect() as c:self.assertEqual(c.execute('SELECT count(*) FROM ops_leads').fetchone()[0],0)

if __name__=='__main__':unittest.main()
