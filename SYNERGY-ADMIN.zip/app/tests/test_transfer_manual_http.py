"""Real HTTP isolation checks for approved source transfers and generated manuals."""
import io,json,threading,unittest,uuid,zipfile
from http.client import HTTPConnection
from test_backend import app

class TransferManualHTTP(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.server=app.ThreadingHTTPServer(('127.0.0.1',18090),app.Handler);threading.Thread(target=cls.server.serve_forever,daemon=True).start()
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close()
 def call(self,method,path,data=None,cookie=None):
  h={};c=HTTPConnection('127.0.0.1',18090,timeout=20)
  if cookie:h['Cookie']=cookie
  if data is not None:h['Content-Type']='application/json';data=json.dumps(data)
  c.request(method,path,data,h);r=c.getresponse();raw=r.read();out=(r.status,json.loads(raw) if r.getheader('Content-Type')=='application/json' else raw,dict(r.getheaders()));c.close();return out
 def register(self):
  app.RATE.clear();status,u,h=self.call('POST','/api/auth/register',{'email':uuid.uuid4().hex+'@transfer.example','password':'Transfer test password 2026'});self.assertEqual(status,200,u);return u,h['Set-Cookie'].split(';')[0]
 def setUp(self):
  self.owner,self.oc=self.register();self.target,self.tc=self.register();self.other,self.xc=self.register();self.admin,self.ac=self.register()
  with app.membership.connect() as c:c.execute("UPDATE users SET role='admin' WHERE id=?",(self.admin['id'],))
 def setup_source(self):
  self.b=app.beast.create(self.owner['id'],{'name':'Private transferred source','files':{'main.py':'print("PRIVATE SOURCE")'}})
  self.p=app.workspace.save_project(self.owner['id'],{'name':'Imported ChatGPT project','beast_project_id':self.b['id']})
  self.chat=app.workspace.create_chat(self.owner['id'],'Private source conversation',self.p['id'])
  self.file=app.research.upload(self.owner['id'],b'PRIVATE NOTES','notes.txt');app.workspace.link_project_file(self.owner['id'],self.p['id'],self.file['id'])
  app.workspace.add(self.owner['id'],self.chat['id'],'assistant','PRIVATE SOURCE discussion',{'file_id':self.file['id']})
  archive=app.DATA/('transfer-test-'+uuid.uuid4().hex+'.zip')
  with zipfile.ZipFile(archive,'w') as z:z.writestr('main.py','print("PRIVATE SOURCE")')
  app.source_bundles.attach(self.owner['id'],self.p['id'],archive,{'editable_paths':['main.py'],'origin':'ChatGPT source import'});archive.unlink();app.project_transfers.bootstrap()
 def review(self,action='approve',user=None,version=None):
  row=next(r for r in app.project_transfers.list(self.admin['id']) if r['project_id']==self.p['id'])
  return self.call('POST','/api/admin/transfers/review',{'project_id':self.p['id'],'version':row['version'] if version is None else version,'action':action,'email':(user or self.target)['email'],'identity_confirmed':True,'note':'Verified recipient for isolated acceptance'},self.ac)
 def hidden(self,cookie):
  for path in ['/api/projects/'+self.p['id'],'/api/projects/'+self.p['id']+'/source.zip','/api/beast/projects/'+self.b['id'],'/api/beast/projects/'+self.b['id']+'/export','/api/conversations/'+self.chat['id'],'/api/research/files/'+self.file['id']+'/original']:
   self.assertEqual(self.call('GET',path,cookie=cookie)[0],404,path)
  for path,key,ident in [('/api/projects','projects',self.p['id']),('/api/beast/projects','projects',self.b['id']),('/api/conversations','conversations',self.chat['id']),('/api/research/history?q=Private','conversations',self.chat['id']),('/api/research/files','files',self.file['id'])]:
   status,d,_=self.call('GET',path,cookie=cookie);self.assertEqual(status,200,d);self.assertNotIn(ident,[r['id'] for r in d[key]],path)
 def test_pending_approve_reassign_revoke_and_direct_download_isolation(self):
  self.setup_source()
  for cookie in [self.oc,self.tc,self.xc,self.ac]:self.hidden(cookie)
  self.assertEqual(self.call('GET','/api/admin/transfers',cookie=self.oc)[0],403)
  self.assertEqual(self.review(user={'email':'unregistered@example.invalid'})[0],400)
  self.assertEqual(self.review()[0],200);self.assertEqual(self.call('GET','/api/projects/'+self.p['id'],cookie=self.tc)[0],200)
  self.assertEqual(self.call('GET','/api/conversations/'+self.chat['id'],cookie=self.tc)[1]['messages'][0]['content'],'PRIVATE SOURCE discussion')
  status,raw,_=self.call('GET','/api/projects/'+self.p['id']+'/source.zip',cookie=self.tc);self.assertEqual(status,200);self.assertIn(b'PRIVATE SOURCE',zipfile.ZipFile(io.BytesIO(raw)).read('main.py'))
  app.project_transfers.bootstrap();self.assertEqual(self.call('GET','/api/projects/'+self.p['id'],cookie=self.tc)[0],200)
  self.hidden(self.oc);self.hidden(self.xc)
  self.assertEqual(self.review(user=self.other,version=1)[0],400)
  self.assertEqual(self.call('POST','/api/account/profile',{'email':'changed@example.invalid','password':'Transfer test password 2026'},self.tc)[0],400)
  self.assertEqual(self.call('POST','/api/projects/move-chat',{'conversation_id':self.chat['id'],'project_id':None},self.tc)[0],400)
  self.assertEqual(self.review(user=self.other)[0],200);self.hidden(self.tc);self.assertEqual(self.call('GET','/api/projects/'+self.p['id'],cookie=self.xc)[0],200)
  self.assertEqual(self.review('revoke')[0],200)
  for cookie in [self.oc,self.tc,self.xc,self.ac]:self.hidden(cookie)
  # No account or authentication record was deleted by project revocation.
  for cookie in [self.oc,self.tc,self.xc,self.ac]:self.assertEqual(self.call('GET','/api/me',cookie=cookie)[0],200)
 def test_manual_is_private_current_and_updates_from_user_catalogue(self):
  self.assertEqual(self.call('GET','/api/manual')[0],401)
  status,d,_=self.call('GET','/api/manual',cookie=self.tc);self.assertEqual(status,200);self.assertEqual(d['version'],app.VERSION);before=d['revision'];self.assertTrue(any('Projects' in s['title'] for s in d['sections']))
  skill=app.workspace.save_skill(self.target['id'],{'name':'Private test workflow','description':'Only the target can see this entry','instructions':'Use this user-owned workflow.'})
  updated=self.call('GET','/api/manual',cookie=self.tc)[1];self.assertNotEqual(before,updated['revision']);self.assertIn(skill['name'],[s['name'] for s in updated['skills']]);self.assertNotIn(skill['name'],[s['name'] for s in self.call('GET','/api/manual',cookie=self.oc)[1]['skills']])
  self.assertEqual(self.call('GET','/guide')[0],200)

if __name__=='__main__':unittest.main()
