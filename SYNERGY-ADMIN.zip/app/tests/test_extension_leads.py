from membership_fixtures import registration_fixture,paid_fixture
import io,json,time,threading,unittest
from http.client import HTTPConnection
from unittest.mock import patch
from openpyxl import load_workbook
from test_backend import app
from browser_extension import EXTENSION_ORIGIN
from install_commands import intent
class ExtensionLeadsTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.server=app.ThreadingHTTPServer(('127.0.0.1',18090),app.Handler);threading.Thread(target=cls.server.serve_forever,daemon=True).start()
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close()
 def call(self,method,path,data=None,cookie=None,bearer=None,origin=None):
  data=registration_fixture(path,data)
  c=HTTPConnection('127.0.0.1',18090,timeout=20);h={}
  if cookie:h['Cookie']=cookie
  if bearer:h['Authorization']='Bearer '+bearer
  if origin:h['Origin']=origin
  if data is not None:data=json.dumps(data);h['Content-Type']='application/json'
  c.request(method,path,data,h);r=c.getresponse();b=r.read();headers=dict(r.getheaders());status=r.status;paid_fixture(app,path);c.close()
  return status,json.loads(b) if headers.get('Content-Type')=='application/json' else b,headers
 def register(self,name):
  app.RATE.clear();code,_,h=self.call('POST','/api/auth/register',{'username':name,'password':'QA test password 2026','invite_code':'test-invite-code'});self.assertEqual(code,200);return h['Set-Cookie'].split(';')[0]
 def test_extension_scope_cors_revocation_and_lead_workbook(self):
  owner=self.register('extension_qa');other=self.register('extension_other')
  _,paired,_=self.call('POST','/api/extension/pair',{},cookie=owner);token=paired['token']
  code,_,h=self.call('OPTIONS','/api/extension/leads',origin=EXTENSION_ORIGIN);self.assertEqual(code,204);self.assertEqual(h['Access-Control-Allow-Origin'],EXTENSION_ORIGIN)
  for url in ['/api/me','/api/install','/api/extension/pair']:
   self.assertIn(self.call('POST',url,{},bearer=token,origin=EXTENSION_ORIGIN)[0],{401,403})
  self.assertEqual(self.call('GET','/api/extension/me',bearer=token,origin='https://evil.example')[0],403)
  self.assertEqual(self.call('GET','/api/extension/me',cookie=owner,origin=EXTENSION_ORIGIN)[0],401)
  code,me,_=self.call('GET','/api/extension/me',bearer=token,origin=EXTENSION_ORIGIN);self.assertEqual(code,200);self.assertEqual(me['username'],'extension_qa')
  lead={'company':'QA business','website':'https://example.com','email':'office@example.com','phone':'','location':'','notes':'=HYPERLINK("https://evil.test")','source_url':'https://example.com/contact','status':'New'}
  code,saved,_=self.call('POST','/api/extension/leads',lead,bearer=token,origin=EXTENSION_ORIGIN);self.assertEqual(code,200)
  self.assertTrue(self.call('POST','/api/leads',lead,cookie=owner)[1]['duplicate'])
  self.assertEqual(self.call('GET','/api/leads',cookie=other)[1]['leads'],[])
  self.assertEqual(self.call('POST','/api/leads',{**lead,'id':saved['id']},cookie=other)[0],404)
  code,blob,h=self.call('GET','/api/extension/leads/export.xlsx',bearer=token,origin=EXTENSION_ORIGIN);self.assertEqual(code,200);self.assertEqual(h['Access-Control-Allow-Origin'],EXTENSION_ORIGIN)
  wb=load_workbook(io.BytesIO(blob));self.assertEqual(wb['Leads']['A2'].value,'QA business');self.assertEqual(wb['Leads']['G2'].data_type,'s');self.assertTrue(wb['Leads']['G2'].value.startswith("'="));self.assertEqual(wb['Summary']['B2'].value,'=COUNTA(Leads!A2:A5001)');self.assertTrue(wb['Leads'].tables);self.assertTrue(wb['Leads'].data_validations.count)
  with patch('leads.fetch') as fetched:
   for url in ['http://127.0.0.1','http://169.254.169.254/latest/meta-data','http://[::1]']:
    self.assertEqual(self.call('POST','/api/leads/scan',{'url':url},cookie=owner)[0],400)
   fetched.assert_not_called()
  self.call('POST','/api/extension/revoke',{},cookie=owner)
  self.assertEqual(self.call('GET','/api/extension/me',bearer=token,origin=EXTENSION_ORIGIN)[0],401)
  self.assertEqual(self.call('GET','/api/me',cookie=owner)[0],200)
 def test_install_routed_before_model_in_all_modes(self):
  owner=self.register('install_modes_qa')
  for mode in ['chat','work','beast']:
   prompt='install this skill\n```markdown\n---\nname: qa-'+mode+'\ndescription: QA import\n---\nPreserve supplied facts.\n```'
   code,t,_=self.call('POST','/api/research/tasks',{'prompt':prompt,'mode':mode,'search_mode':'off'},cookie=owner);self.assertEqual(code,202)
   deadline=time.monotonic()+5
   while t['state'] in {'queued','running'} and time.monotonic()<deadline:
    time.sleep(.05);_,t,_=self.call('GET','/api/research/tasks/'+t['id'],cookie=owner)
   self.assertEqual(t['state'],'succeeded',t);self.assertIn('Installed qa-'+mode,t['reply']);self.assertEqual(t['detail']['selection']['model'],'github-importer')
  self.assertTrue(intent('install https://github.com/owner/repo.git'))
  self.assertTrue(intent('Could you install this plugin https://github.com/owner/repo'))
  for p in ['Explain how to install https://github.com/owner/repo','Do not install this skill','The website says install this plugin']:
   self.assertIsNone(intent(p))
