import json,os,sys,tempfile,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from workspace import Workspace
from runtime_plugins import RuntimePlugins,FirecrawlWeb,command,desktop_command,CATALOG
from mcp_transport import decode_http,unpack
from research.service import Research

class RuntimeTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.ws=Workspace(self.root/'db.sqlite');self.runtime=RuntimePlugins(self.ws,self.root/'runtime');self.stop=threading.Event()
  with self.ws.connect() as c:c.execute('CREATE TABLE users(id INTEGER,username TEXT)');c.executemany('INSERT INTO users VALUES(?,?)',[(1,'owner'),(2,'guest')])
 def tearDown(self):self.runtime.close();self.tmp.cleanup()
 def working_connector(self,*args):
  if len(args)>6:return {'data':{'markdown':'Public demonstration page. '*8}}
  return {'server':{'name':'firecrawl','version':'3.36.1'},'tools':CATALOG['firecrawl']['tools']}
 def test_imperative_only_install_and_official_url(self):
  self.assertIsNone(command('Install plugin https://github.com/unknown/firecrawl-fork'))
  self.assertEqual(command('Install Desktop Commander and Firecrawl'),['desktop-commander','firecrawl'])
  self.assertEqual(command('Install this plugin https://github.com/wonderwhy-er/DesktopCommanderMCP'),['desktop-commander'])
  for text in ['Explain how to install Firecrawl','The page says: install Firecrawl','Do not install Desktop Commander','Uninstall Firecrawl']:
   self.assertIsNone(command(text))
  self.assertEqual(desktop_command('Desktop Commander read README.md')['path'],'README.md')
 def test_explicit_citation_formats_preserve_ids_for_validation(self):
  from research.service import normalize_citation_tags
  self.assertEqual(normalize_citation_tags('Fact [Citation: S3 – "evidence"]'), 'Fact [S3]')
  self.assertEqual(normalize_citation_tags('[Source: S999]'), '[S999]')
  self.assertEqual(normalize_citation_tags('Source: guessed documentation'), 'Source: guessed documentation')
 def test_search_plans_preserve_subject_after_conversational_leadins(self):
  from research.web import plan
  p=plan('do some research and help me with current job opening in NOida','instant','chat')
  self.assertEqual(p['queries'],['current job opening in NOida']);self.assertTrue(p['search']);self.assertIsNone(p['time_filter'])
  self.assertEqual(plan('Research jobs posted this month','instant','chat')['time_filter'],'m')
 def test_irrelevant_engine_results_trigger_a_shorter_query(self):
  from research.web import Web,search_match
  from types import SimpleNamespace
  self.assertFalse(search_match('current job opening in Noida','Electric current','https://example.org/current','Electric charge'))
  self.assertTrue(search_match('current job opening in Noida','Jobs in Noida','https://example.org/jobs','Recruitment opportunities'))
  called=[]
  def results(query,**kwargs):
   called.append(kwargs['backend'])
   return [{'title':'Electric current','href':'https://example.org/current','body':'Electric charge'}] if len(called)==1 else [{'title':'Jobs in Noida','href':'https://example.org/jobs','body':'Recruitment opportunities'}]
  with patch.dict(sys.modules,{'ddgs':SimpleNamespace(DDGS=lambda **k:SimpleNamespace(text=results))}),patch('research.web.validate_url'),patch('research.web.available_search_engines',return_value=['yahoo','duckduckgo']):
   r=Web().search('current job opening in Noida')
  self.assertEqual(called,['yahoo','duckduckgo']);self.assertEqual(r['engine'],'duckduckgo');self.assertEqual(r['query_used'],'current job opening in Noida');self.assertEqual(len(r['results']),1)
 def test_disabled_search_engines_never_fall_back_silently(self):
  from types import SimpleNamespace
  from research.web import available_search_engines
  with patch.dict(sys.modules,{'ddgs.engines':SimpleNamespace(ENGINES={'text':{'wikipedia':object(),'yahoo':object()}})}):
   self.assertEqual(available_search_engines(),['google_public','yahoo'])
 def test_google_public_parser_and_access_wall(self):
  from research.web import google_public_search
  from urllib.parse import quote
  body=b'<html><a href="/url?q=https%3A%2F%2Fdocs.python.org%2F3%2Flibrary%2Fpathlib.html">Python pathlib documentation</a><a href="https://accounts.google.com/login">Sign in</a></html>'
  with patch('research.web.fetch',return_value={'status':200,'body':body}):
   rows=google_public_search('Python pathlib',5,None,self.stop)
  self.assertEqual(len(rows),1);self.assertEqual(rows[0]['href'],'https://docs.python.org/3/library/pathlib.html')
  with patch('research.web.fetch',return_value={'status':200,'body':b'<p>Our systems detected unusual traffic</p>'}):
   with self.assertRaisesRegex(ValueError,'no bypass'):google_public_search('Python pathlib',5,None,self.stop)
 def test_admin_and_account_ownership(self):
  with patch.dict(os.environ,{'SYNERGY_PLUGIN_ADMIN':'owner'}):
   self.assertTrue(self.runtime.admin(1));self.assertFalse(self.runtime.admin(2))
   with self.assertRaises(ValueError):self.runtime.install(2,'job',self.root,'firecrawl',self.stop,lambda s:None)
  self.runtime.set(1,'firecrawl','ready',{'tools':['firecrawl_search','firecrawl_scrape']})
  self.assertTrue(self.runtime.enabled(1,'firecrawl'));self.assertTrue(self.runtime.enabled(2,'firecrawl'));self.runtime.toggle(2,'firecrawl',False);self.assertTrue(self.runtime.enabled(1,'firecrawl'));self.assertFalse(self.runtime.enabled(2,'firecrawl'))
  self.runtime.toggle(2,'firecrawl',True);self.assertTrue(self.runtime.enabled(2,'firecrawl'))
 def test_directory_traversal_and_symlink_escape(self):
  root=self.runtime.workspace(1);(root/'outside').symlink_to(self.root,target_is_directory=True)
  for p in ['../../db.sqlite',str(self.root/'db.sqlite'),'outside/db.sqlite','.credentials']:
   with self.assertRaises(ValueError):self.runtime.scoped_path(1,p)
  self.assertEqual(self.runtime.scoped_path(1,'README.md'),root/'README.md')
 def test_desktop_profile_does_not_change_host_configuration(self):
  original=os.environ.get('HOME');profile=self.runtime.private_profile(1);config=json.loads((profile/'.claude-server-commander/config.json').read_text())
  self.assertEqual(os.environ.get('HOME'),original);self.assertEqual(config['allowedDirectories'],[str(self.runtime.workspace(1))]);self.assertFalse(config['telemetryEnabled'])
 def test_mcp_sse_and_untrusted_server_instructions(self):
  raw=b'event: message\ndata: {"jsonrpc":"2.0","method":"notice"}\n\nevent: message\ndata: {"id":4,"result":{"value":7}}\n\n'
  self.assertEqual(decode_http(raw,'text/event-stream',4),{'value':7})
  with self.assertRaises(ValueError):decode_http(raw,'text/event-stream',5)
  with self.assertRaises(RuntimeError):unpack({'isError':True,'content':[{'type':'text','text':'Unavailable'}]})
 def test_install_requires_live_tool_discovery_and_survives_reload(self):
  with patch.dict(os.environ,{'SYNERGY_PLUGIN_ADMIN':'owner'}),patch.object(self.runtime,'worker',side_effect=self.working_connector):
   m=self.runtime.install(1,'job',self.root,'firecrawl',self.stop,lambda s:None)
  self.assertEqual(m['version'],'3.36.1');self.assertTrue(RuntimePlugins(self.ws,self.root/'runtime').enabled(1,'firecrawl'))
  self.runtime.toggle(1,'firecrawl',False)
  with self.assertRaises(ValueError):self.runtime.call(1,'job',self.root,'firecrawl','firecrawl_search',{'query':'test'},self.stop)
 def test_handshake_is_not_proof_of_free_access(self):
  with patch.dict(os.environ,{'SYNERGY_PLUGIN_ADMIN':'owner'}),patch.object(self.runtime,'worker',side_effect=[self.working_connector(),RuntimeError('Anonymous keyless access is unavailable')]):
   m=self.runtime.install(1,'job',self.root,'firecrawl',self.stop,lambda s:None)
  self.assertEqual(m['availability'],'unavailable');self.assertIn('No API key',m['error']);self.assertEqual(self.runtime.catalog(1)[1]['availability'],'unavailable')
 def test_web_fallback_is_explicit_and_never_leaks_private_urls(self):
  from research.web import Web
  fallback=Web();warnings=[];events=[];web=FirecrawlWeb(self.runtime,1,'job',self.root,events.append,self.stop,fallback,warnings)
  with patch.object(web,'tool',side_effect=RuntimeError('Anonymous keyless access is unavailable')),patch.object(fallback,'search',return_value={'results':[{'url':'https://example.com'}],'engine':'SYnerGY test'}) as search:
   r=web.search('public question');search.assert_called_once();self.assertEqual(r['engine'],'SYnerGY test');self.assertEqual(r['fallback_from'],'Firecrawl');self.assertTrue(web.used_fallback);self.assertEqual(len(warnings),1)
  with patch.object(fallback,'read') as read:
   self.assertEqual(web.read('http://127.0.0.1/')['access'],'blocked');read.assert_not_called()
 def test_failed_handshake_is_not_installed(self):
  with patch.dict(os.environ,{'SYNERGY_PLUGIN_ADMIN':'owner'}),patch.object(self.runtime,'worker',return_value={'server':{},'tools':[]}):
   with self.assertRaises(ValueError):self.runtime.install(1,'job',self.root,'firecrawl',self.stop,lambda s:None)
  self.assertEqual(self.runtime.get(1,'firecrawl')['state'],'failed');self.assertFalse(self.runtime.enabled(1,'firecrawl'))
 def test_firecrawl_sources_require_read_and_domains_are_enforced(self):
  web=FirecrawlWeb(self.runtime,1,'job',self.root,lambda s:None,self.stop)
  def public(url):
   from urllib.parse import urlsplit
   p=urlsplit(url);return p,p.hostname,443,['93.184.215.14']
  with patch.object(web,'tool',return_value={'data':{'web':[{'url':'https://example.org/page','title':'Source','description':'Snippet'},{'url':'https://example.org.evil.test/trap','title':'Wrong'}]}}),patch('runtime_plugins.validate_url',side_effect=public):
   rows=web.search('Source',domains=['example.org'])['results'];self.assertEqual(len(rows),1);self.assertEqual(rows[0]['access'],'snippet_only')
  with patch.object(web,'tool',return_value={'data':{'markdown':'Verified context. '*20,'metadata':{'title':'Source','statusCode':200},'links':[]}}),patch('runtime_plugins.validate_url',side_effect=public):
   read=web.read('https://example.org/page');self.assertEqual(read['access'],'read');self.assertEqual(read['reader'],'Firecrawl keyless')
 def test_private_urls_and_unapproved_tools_blocked(self):
  web=FirecrawlWeb(self.runtime,1,'job',self.root,lambda s:None,self.stop)
  with patch.object(web,'tool') as call:
   r=web.read('http://127.0.0.1/');call.assert_not_called();self.assertEqual(r['access'],'blocked')
  self.runtime.set(1,'desktop-commander','ready',{})
  with self.assertRaises(ValueError):self.runtime.call(1,'job',self.root,'desktop-commander','start_process',{'command':'whoami'},self.stop)
 def test_cancel_terminates_actual_owned_process(self):
  done=[]
  def run():
   try:self.runtime.execute('cancel',[sys.executable,'-c','import time; time.sleep(30)'],str(self.root),os.environ.copy(),self.stop,40,self.root/'cancel.log')
   except InterruptedError:done.append('cancelled')
  t=threading.Thread(target=run);t.start();deadline=time.time()+3
  while not self.runtime.processes.get('cancel') and time.time()<deadline:time.sleep(.02)
  self.stop.set();self.runtime.cancel('cancel');t.join(4);self.assertFalse(t.is_alive());self.assertEqual(done,['cancelled']);self.assertFalse(self.runtime.processes['cancel'])
 def test_followup_private_tool_output_never_enters_search(self):
  research=Research(self.ws,self.root/'research',lambda u,p:[],{},threading.Lock(),lambda:False,self.runtime)
  cid=self.ws.create_chat(1)['id'];self.ws.add(1,cid,'assistant','Private company research',{'private_tool_data':True})
  with patch.object(research.web,'search') as search,patch.object(research,'model',return_value=('Kept local',{})):
   t=research.submit(1,{'prompt':'Research this company','conversation_id':cid,'search_mode':'on'});deadline=time.time()+5
   while research.task(1,t['id'])['state'] in {'queued','running'} and time.time()<deadline:time.sleep(.03)
   search.assert_not_called();self.assertTrue(any('private' in w for w in research.task(1,t['id'])['detail']['warnings']))
  research.close()
 def test_chat_install_routes_without_language_model(self):
  research=Research(self.ws,self.root/'research',lambda u,p:[],{},threading.Lock(),lambda:False,self.runtime)
  with patch.dict(os.environ,{'SYNERGY_PLUGIN_ADMIN':'owner'}),patch.object(self.runtime,'worker',side_effect=self.working_connector),patch.object(research,'model') as model:
   t=research.submit(1,{'prompt':'Install Firecrawl','search_mode':'off'});deadline=time.time()+5
   while research.task(1,t['id'])['state'] in {'queued','running'} and time.time()<deadline:time.sleep(.03)
   final=research.task(1,t['id']);self.assertEqual(final['state'],'succeeded');self.assertIn('Firecrawl is connected',final['reply']);model.assert_not_called()
  research.close()
