from membership_fixtures import registration_fixture,paid_fixture
import json,threading,time,unittest,uuid
from http.client import HTTPConnection
from test_backend import app

class SpecialistHTTPTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.server=app.ThreadingHTTPServer(('127.0.0.1',18090),app.Handler);threading.Thread(target=cls.server.serve_forever,daemon=True).start()
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close()
 def req(self,method,path,data=None,cookie=None):
  data=registration_fixture(path,data);c=HTTPConnection('127.0.0.1',18090,timeout=60);headers={}
  if data is not None:headers['Content-Type']='application/json';data=json.dumps(data)
  if cookie:headers['Cookie']=cookie
  c.request(method,path,data,headers);r=c.getresponse();raw=r.read();out=json.loads(raw) if r.getheader('Content-Type')=='application/json' else raw;status=r.status;token=r.getheader('Set-Cookie');c.close();paid_fixture(app,path);return status,out,token
 def user(self):return self.req('POST','/api/auth/register',{'username':'spec'+uuid.uuid4().hex[:10],'password':'Long test password 2026'})[2]
 def wait(self,cookie,jid,path='/api/specialists/jobs/'):
  for _ in range(150):
   r=self.req('GET',path+jid,cookie=cookie)[1]
   if r['state'] in {'complete','succeeded','failed','cancelled'}:return r
   time.sleep(.1)
  self.fail('Job did not finish.')
 def test_authenticated_tools_chat_preview_and_download(self):
  owner,other=self.user(),self.user();self.assertEqual(self.req('GET','/api/specialists')[0],401)
  status,catalog,_=self.req('GET','/api/specialists',cookie=owner);self.assertEqual(status,200);self.assertEqual({s['id'] for s in catalog['servers']},{'vedics','foundr'})
  status,j,_=self.req('POST','/api/research/tasks',{'prompt':'VEDICS explain 1/2 + 1/4','search_mode':'off'},owner);self.assertEqual(status,202);done=self.wait(owner,j['id'],'/api/research/tasks/');self.assertEqual(done['state'],'succeeded',done);self.assertIn('3/4',done['reply']);self.assertTrue(done['detail']['metrics']['actual_mcp_call'])
  _,j,_=self.req('POST','/api/research/tasks',{'prompt':'FOUNDR create task: Review the launch brief','mode':'work','search_mode':'off'},owner);done=self.wait(owner,j['id'],'/api/research/tasks/');self.assertEqual(done['state'],'succeeded',done)
  status,j,_=self.req('POST','/api/specialists/foundr/call',{'tool':'document_draft','arguments':{'title':'Private document','content':'This draft belongs only to its account.'},'request_id':uuid.uuid4().hex},owner);self.assertEqual(status,202)
  done=self.wait(owner,j['id']);self.assertEqual(done['state'],'complete',done);a=next(a for a in done['result']['artifacts'] if a['kind']=='pdf');self.assertEqual(self.req('GET',a['url'],cookie=other)[0],404);status,pdf,_=self.req('GET',a['url'],cookie=owner);self.assertEqual(status,200);self.assertTrue(pdf.startswith(b'%PDF'));self.assertEqual(self.req('GET','/api/specialists/jobs/'+j['id'],cookie=other)[0],404)
  rid=done['result']['record']['id'];self.assertEqual(self.req('GET','/api/specialists/foundr/records/'+rid,cookie=other)[0],404)
  status,_,_=self.req('POST','/api/specialists/vedics/call',{'tool':'question_explain','arguments':{'expression':'1+1'},'user_id':1},owner);self.assertEqual(status,400)
 def test_extension_scope_cannot_start_specialist_write(self):
  owner=self.user();status,result,_=self.req('POST','/api/research/tasks',{'prompt':'/foundr task_assign {"title":"Bad authority"}','_extension_readonly':True},owner);self.assertEqual(status,400)

if __name__=='__main__':unittest.main()
