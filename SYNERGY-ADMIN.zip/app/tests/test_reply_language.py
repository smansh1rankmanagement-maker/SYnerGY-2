"""Language defaults, explicit choices, and contracts through the real job path."""
import json,unittest
from unittest.mock import patch
import test_research as fixture
from reply_language import instruction,normalise_settings

class ReplyLanguageTests(unittest.TestCase):
 setUp=fixture.ResearchTests.setUp
 tearDown=fixture.ResearchTests.tearDown
 wait=fixture.ResearchTests.wait
 submit=fixture.ResearchTests.submit
 def test_new_account_defaults_to_english(self):
  self.assertEqual(self.r.settings(1)['language'],'english')
  self.assertEqual(self.r.settings(2)['language'],'english')
 def test_legacy_auto_is_english_without_changing_privacy_or_data(self):
  old={'language':'auto','allow_external':False,'web_search':False}
  with self.r.connect() as c:c.execute('INSERT INTO research_settings VALUES(?,?)',(1,json.dumps(old)))
  effective=self.r.settings(1)
  self.assertEqual(effective['language'],'english');self.assertFalse(effective['allow_external']);self.assertFalse(effective['web_search'])
  with self.r.connect() as c:self.assertEqual(json.loads(c.execute('SELECT settings FROM research_settings WHERE user_id=1').fetchone()[0]),old)
 def test_explicit_languages_and_auto_remain_account_scoped(self):
  for language in ['hindi','hinglish','auto','english']:
   self.r.settings(1,{'language':language})
   self.assertEqual(self.r.settings(1)['language'],language)
   self.assertEqual(self.r.settings(2)['language'],'english')
  self.assertEqual(normalise_settings({'language':'hindi'})['language'],'hindi')
  with self.assertRaises(ValueError):self.r.settings(1,{'language':'unsupported'})
 def test_language_contract_for_all_modes_families_and_providers(self):
  self.r.settings(1,{'allow_external':True,'response_cache':False})
  cid=self.w.create_chat(1)['id'];self.w.add(1,cid,'user','hi');self.w.add(1,cid,'assistant','안녕하세요!')
  for mode in ['chat','work','beast']:
   for family in ['aerny','eternal']:
    for provider in ['synergy','hybrid','openai']:
     with self.subTest(mode=mode,family=family,provider=provider),patch('model_router.external_config',return_value=('test-secret','gpt-6.1-sol',True)),patch('model_router.select_openai',return_value='gpt-6.1-sol'),patch.object(self.r,'model',return_value=('Hello! How can I help?',{})) as model:
      t=self.wait(self.submit(prompt='hi',conversation_id=cid,mode=mode,model_family=family,provider=provider))
      self.assertEqual(t['state'],'succeeded',t['detail'])
      system=model.call_args.args[2][0]['content']
      self.assertIn('Write your reply in English.',system)
      self.assertIn('earlier assistant replies',system)
      self.assertNotIn('Answer the actual question in the user’s language',system)
 def test_document_path_keeps_language_policy_and_evidence(self):
  f=self.r.upload(1,'Office reference: 안녕하세요. Two desks.'.encode(),'reference.txt')
  with patch.object(self.r,'model',return_value=('Two desks [D1].',{})) as model:
   t=self.wait(self.submit(prompt='How many desks?',file_id=f['id']))
  self.assertEqual(t['state'],'succeeded');system=model.call_args.args[2][0]['content']
  self.assertIn('Write your reply in English.',system);self.assertIn('untrusted',system)
 def test_explicit_request_can_override_default_and_auto_has_english_fallback(self):
  policy=instruction({'language':'english'})
  self.assertIn('explicit language or translation request',policy)
  self.assertIn('takes priority',policy)
  self.assertIn('use English',instruction({'language':'auto'}))
  with patch.object(self.r,'model',return_value=('नमस्ते!',{})) as model:
   self.wait(self.submit(prompt='Reply in Hindi: say hello.'))
  self.assertEqual(model.call_args.args[2][-1]['content'],'Reply in Hindi: say hello.')

 def test_script_guard_ignores_code_quotes_and_requested_translation(self):
  from reply_language import unexpected_script
  korean='안녕하세요! 무엇을 도와드릴까요?'
  self.assertTrue(unexpected_script(korean,'hi',{'language':'english'}))
  for reply in ['The name is 김.','Example: `'+korean+'`','> '+korean,'Quoted: "'+korean+'"','```text\n'+korean+'\n```']:
   self.assertFalse(unexpected_script(reply,'Explain',{'language':'english'}))
  self.assertFalse(unexpected_script(korean,'Translate hello into Korean',{'language':'english'}))
 def test_wrong_script_is_corrected_once_using_local_balanced(self):
  with patch.object(self.r,'model',side_effect=[('안녕하세요! 무엇을 도와드릴까요?',{}),('Hello! How can I help you?',{})]) as model:
   t=self.wait(self.submit(prompt='hi',local_model='fast'))
  self.assertEqual(t['state'],'succeeded');self.assertEqual(t['reply'],'Hello! How can I help you?');self.assertEqual(model.call_count,2)
  self.assertNotIn('fast',model.call_args.args[3]['model']);self.assertEqual(t['detail']['language_correction']['state'],'completed')
 def test_failed_correction_is_bounded_and_not_reported_as_success(self):
  with patch.object(self.r,'model',return_value=('안녕하세요! 무엇을 도와드릴까요?',{})) as model:
   t=self.wait(self.submit(prompt='hi',local_model='fast'))
  self.assertEqual(model.call_count,2);self.assertEqual(t['state'],'failed')
