"""Trusted fixtures only. Real local processing is enabled by SYNERGY_MEDIA_TEST_PYTHON."""
import base64,hashlib,importlib.util,io,json,os,sqlite3,subprocess,sys,tempfile,threading,time,unittest,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from PIL import Image,ImageChops,ImageStat
from workspace import Workspace
from uploads import Uploads
from media.store import Media,digest
from media.schema import validate,MAX_BYTES
from media.worker import Worker
from media.chat import plan,intent
from media.mcp import call

MEDIA_PY=os.environ.get('SYNERGY_MEDIA_TEST_PYTHON')
class MediaTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.data=Path(self.tmp.name);self.ws=Workspace(self.data/'accounts.sqlite3');self.cid=self.ws.create_chat(1)['id'];self.other=self.ws.create_chat(2)['id'];self.up=Uploads(self.ws,None,self.data/'uploads');self.m=Media(self.data);self.worker=Worker(self.m,MEDIA_PY or sys.executable)
 def tearDown(self):self.worker.stop.set();self.worker.terminate();self.tmp.cleanup()
 def upload(self,data,name='photo.png',uid=1,cid=None):
  r=self.up.create(uid,{'conversation_id':cid or self.cid,'name':name,'size':len(data),'batch_id':uuid.uuid4().hex})
  from uploads import CHUNK
  for i in range(0,len(data),CHUNK):self.up.chunk(uid,{'id':r['id'],'index':i//CHUNK,'data':base64.b64encode(data[i:i+CHUNK]).decode()})
  return self.up.finish(uid,r['id'])['id']
 def png(self,colour=(70,100,130),size=(320,240)):
  b=io.BytesIO();Image.new('RGB',size,colour).save(b,'PNG');return b.getvalue()
 def submit(self,recipe,ids=None,**extra):return self.m.submit(1,{'conversation_id':self.cid,'upload_ids':ids or [],'recipe':recipe,**extra})
 def execute(self,job):
  claim=self.worker.claim();self.assertEqual(claim['id'],job['id']);done=self.worker.execute(claim);self.assertEqual(done['state'],'succeeded',done);return done
 def test_schema_rejects_commands_urls_unknown_nan_and_expensive_values(self):
  cases=[{'kind':'video','operations':[{'op':'shell','command':'echo bad'}]},{'kind':'image','operations':[{'op':'resize','width':4097,'height':300}]},{'kind':'video','operations':[{'op':'trim','start':0,'end':121}]},{'kind':'image','operations':[{'op':'adjust','brightness':float('nan')}]},{'kind':'image','operations':[{'op':'logo','upload_id':'../../other'}]},{'kind':'ai','operation':'generate','prompt':'Tree','width':257},{'kind':'video','operations':[{'op':'captions','cues':[{'start':3,'end':2,'text':'bad'}]}]},{'kind':'analyze','url':'http://example.com'}]
  for s in cases:
   with self.subTest(recipe=s),self.assertRaises(ValueError):validate(s)
 def test_cross_account_upload_asset_job_and_project_denied(self):
  rid=self.upload(self.png());j=self.submit({'kind':'image','operations':[{'op':'convert'}]},[rid]);source=j['source_id']
  for method,args in [(self.m.asset,(2,source)),(self.m.asset_path,(2,source)),(self.m.project,(2,j['project_id'])),(self.m.job,(2,j['id'])),(self.m.cancel,(2,j['id']))]:
   with self.assertRaises(KeyError):method(*args)
  with self.assertRaises(KeyError):self.m.submit(2,{'conversation_id':self.other,'upload_ids':[rid],'recipe':{'kind':'analyze'}})
  with self.assertRaises(ValueError):self.m.submit(1,{'conversation_id':self.ws.create_chat(1)['id'],'source_id':source,'recipe':{'kind':'analyze'}})
 def test_original_is_copied_and_input_digest_checked(self):
  data=self.png();rid=self.upload(data);j=self.submit({'kind':'analyze'},[rid]);p=self.m.asset_path(1,j['source_id']);self.assertEqual(p.read_bytes(),data);self.assertNotEqual(p.stat().st_ino,self.up.path(1,rid).stat().st_ino)
  self.up.path(1,rid).write_bytes(b'bad')
  with self.assertRaises(ValueError):self.submit({'kind':'analyze'},[rid])
  self.assertEqual(p.read_bytes(),data)
 def test_duplicate_submit_returns_same_job_and_queue_bound(self):
  rid=self.upload(self.png());d={'kind':'analyze'};j=self.submit(d,[rid],request_id='fixed-request');self.assertEqual(self.submit(d,[rid],request_id='fixed-request')['id'],j['id'])
  with self.assertRaises(ValueError):self.submit({'kind':'image','operations':[{'op':'convert'}]},[rid],request_id='fixed-request')
  for _ in range(3):self.submit(d,[rid])
  with self.assertRaises(ValueError):self.submit(d,[rid])
 def test_cancel_queued_delete_retains_original(self):
  rid=self.upload(self.png());j=self.submit({'kind':'analyze'},[rid])
  with self.assertRaises(ValueError):self.m.delete_project(1,j['project_id'])
  self.assertEqual(self.m.cancel(1,j['id'])['state'],'cancelled');self.m.delete_project(1,j['project_id']);self.assertTrue(self.up.path(1,rid).is_file())
 def test_restart_recovery_bounded_and_pinned(self):
  rid=self.upload(self.png());j=self.submit({'kind':'analyze'},[rid]);self.worker.claim();self.worker.recover();self.assertEqual(self.m.job(1,j['id'])['state'],'queued');self.worker.claim();self.worker.recover();self.assertEqual(self.m.job(1,j['id'])['state'],'failed');self.assertEqual(self.m.job(1,j['id'])['engine_version'],'1.0.0')
 def test_manual_and_mcp_call_equivalent_validation(self):
  rid=self.upload(self.png());args={'conversation_id':self.cid,'upload_ids':[rid],'recipe':{'kind':'image','operations':[{'op':'resize','width':128,'height':128}]},'request_id':'manual-mcp-equivalence'}
  manual=self.m.submit(1,args);mcp=call(self.m,1,'chat','media_submit',args);self.assertEqual(manual['id'],mcp['id']);self.assertEqual(manual['recipe'],mcp['recipe'])
  with self.assertRaises(ValueError):call(self.m,1,'chat','media_submit',{**args,'user_id':2})
 def test_mode_permission_and_disabled_plugin_checked(self):
  def deny(uid,mode):raise PermissionError('Mode unavailable')
  self.m.access=deny
  with self.assertRaises(PermissionError):self.submit({'kind':'analyze'})
  self.m.access=None;self.ws.toggle(1,'synergy-media',False)
  with self.assertRaises(ValueError):self.submit({'kind':'analyze'})
 def test_natural_routing_and_questions_not_rendered(self):
  for p in ['How do I trim a video?','Explain video compression','Do not resize this image','Give details of Diffusers','Convert this document to PDF','Add text to the Word document','Merge these Excel spreadsheets']:
   self.assertIsNone(plan(p,['photo.png'],['a'*32]))
  self.assertIn('question',plan('trim this video',['clip.mp4'],['a'*32]))
  r=plan('Trim this video from 2 to 5 seconds',['clip.mp4'],['a'*32]);self.assertEqual(r['recipe']['operations'],[{'op':'trim','start':2.,'end':5.}])
  r=plan('Resize to 640 × 480 and add text "Hello" at 10, 20 size 24 #ff0000',['photo.png'],['a'*32]);self.assertEqual(len(r['recipe']['operations']),2);self.assertEqual(r['recipe']['operations'][1]['text'],'Hello')
  r=plan('Make it brighter',[],[],{'asset_id':'b'*32,'project_id':'c'*32,'file':'output.png'});self.assertEqual(r['source_id'],'b'*32)
 @unittest.skipUnless(MEDIA_PY,'Set media test Python with OpenCV for real processing fixtures')
 def test_real_image_layers_formats_analysis_and_versions(self):
  data=self.png();rid=self.upload(data);logo=self.upload(self.png((255,0,0),(20,20)),'logo.png')
  j=self.submit({'kind':'image','operations':[{'op':'resize','width':640,'height':480,'fit':'stretch'},{'op':'text','text':'InteriFY','x':20,'y':20,'size':30,'colour':'#FFFFFF'},{'op':'logo','upload_id':logo,'x':500,'y':300,'width':50}]},[rid,logo]);done=self.execute(j);r=done['result'];p=self.m.asset_path(1,r['asset_id']);im=Image.open(p);self.assertEqual(im.size,(640,480));self.assertEqual(im.getpixel((510,310))[:3],(255,0,0));self.assertEqual(r['metadata']['analysis']['component'],'OpenCV');self.assertEqual(digest(p),r['sha256']);self.assertEqual(self.up.path(1,rid).read_bytes(),data)
  follow=self.execute(self.submit({'kind':'image','format':'jpeg','operations':[{'op':'crop','x':0,'y':0,'width':300,'height':200},{'op':'rotate','angle':90},{'op':'adjust','brightness':1.2}]},source_id=r['asset_id']));self.assertEqual(Image.open(self.m.asset_path(1,follow['result']['asset_id'])).size,(200,300));reopened=Media(self.data);versions=reopened.versions(1,r['project_id']);self.assertEqual(len(versions),4);self.assertEqual(versions[-1]['parent_id'],r['asset_id']);self.assertTrue(reopened.asset_path(1,r['asset_id']).is_file())
 @unittest.skipUnless(MEDIA_PY,'Set media test Python with OpenCV for real processing fixtures')
 def test_real_bad_file_fails_with_original_preserved(self):
  rid=self.upload(b'not an image');j=self.submit({'kind':'image','operations':[{'op':'convert'}]},[rid]);r=self.worker.execute(self.worker.claim());self.assertEqual(r['state'],'failed');self.assertFalse(r['result']);self.assertEqual(self.up.path(1,rid).read_bytes(),b'not an image')

if __name__=='__main__':unittest.main()
