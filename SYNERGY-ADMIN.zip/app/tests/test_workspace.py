import io,json,sqlite3,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from workspace import Workspace
import extensions

class WorkspaceTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'db.sqlite';self.w=Workspace(self.path)
 def tearDown(self):self.tmp.cleanup()
 def test_conversations_survive_restart_and_are_private(self):
  c=self.w.create_chat(1);self.w.add(1,c['id'],'user','Remember the orange chair');self.w.add(1,c['id'],'assistant','Orange chair noted',{'effort':'high'})
  restored=Workspace(self.path);self.assertEqual(len(restored.chat(1,c['id'])['messages']),2)
  self.assertEqual(restored.chats(1)[0]['title'],'Remember the orange chair');self.assertEqual(restored.chats(2),[])
  with self.assertRaises(KeyError):restored.chat(2,c['id'])
  with self.assertRaises(KeyError):restored.add(2,c['id'],'user','replace')
  restored.edit_chat(1,c['id'],title='Design ideas');self.assertEqual(restored.chat(1,c['id'])['title'],'Design ideas')
  restored.edit_chat(1,c['id'],archive=True);self.assertEqual(restored.chats(1),[])
 def test_skill_plugin_scope_and_disable(self):
  p=self.w.save_plugin(1,{'name':'Studio','description':'Studio workflow','source':'https://github.com/example/studio','status':'ready'})
  s=self.w.save_skill(1,{'name':'Materials','instructions':'Use natural materials','plugin_id':p})
  self.assertIsNotNone(self.w.get_skill(1,s['id']));self.assertIsNone(self.w.get_skill(2,s['id']))
  with self.assertRaises(ValueError):self.w.save_skill(2,{'name':'Foreign','instructions':'x','plugin_id':p})
  self.w.toggle(1,p,False);self.assertIsNone(self.w.get_skill(1,s['id']))
  self.w.toggle(1,'image',False);self.assertFalse(self.w.tool_enabled(1,'image'));self.assertTrue(self.w.tool_enabled(2,'image'))
 def test_github_bundle_is_pinned_and_usable(self):
  commit='a'*40;tree='b'*40;urls=[]
  def fake(url,limit=0):
   urls.append(url)
   if '/commits/' in url:return json.dumps({'sha':commit,'commit':{'tree':{'sha':tree}}}).encode()
   if '/git/trees/' in url:return json.dumps({'tree':[{'path':'skills/style/SKILL.md','type':'blob'},{'path':'skills/style/examples/tone.md','type':'blob'}],'truncated':False}).encode()
   if url.endswith('/examples/tone.md'):return b'Write clear action items.'
   return b'---\nname: Studio style\ndescription: Use a clear voice\n---\nUse short sentences and precise details. See [tone](examples/tone.md).'
  with patch.object(extensions,'fetch',side_effect=fake):result=extensions.install(self.w,1,'plugin','https://github.com/example/studio')
  self.assertEqual(len(result['installed']),1);self.assertIn('/'+commit+'/',urls[-1]);self.assertIn(tree,urls[1])
  self.assertIn('short sentences',self.w.get_skill(1,result['installed'][0])['instructions'])
  self.assertIn('Write clear action items.',self.w.get_skill(1,result['installed'][0])['instructions'])
  self.assertEqual(self.w.plugins(2)[-1]['id'],'knowledge')
 def test_bad_repository_urls_never_fetch(self):
  with patch.object(extensions,'fetch') as fetch:
   for url in ['http://github.com/a/b','https://evil.test/a/b','https://github.com@evil.test/a/b','https://github.com/../b','https://github.com:8000/a/b','file:///tmp/SKILL.md']:
    with self.assertRaises(ValueError):extensions.repository(url)
   fetch.assert_not_called()
 def test_unsupported_repository_does_not_claim_installation(self):
  with patch.object(extensions,'repository',return_value={'name':'generic','source':'https://github.com/example/generic','commit':'a'*40,'skills':[],'runtime_manifest':True}):
   with self.assertRaises(ValueError):extensions.install(self.w,1,'plugin','https://github.com/example/generic')
  self.assertTrue(all(p['builtin'] for p in self.w.plugins(1)))
 def test_pasted_skill_is_saved_without_execution(self):
  r=extensions.install(self.w,1,'skill',content='---\nname: Concise reply\n---\nUse one sentence.')
  self.assertEqual(self.w.get_skill(1,r['installed'][0])['instructions'],'Use one sentence.')

if __name__=='__main__':unittest.main()
