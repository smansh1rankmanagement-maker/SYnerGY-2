"""Trial/subscription boundaries for free Chat and extension Work."""
import time,unittest
from unittest.mock import patch
import test_product200 as product_fixture
import test_extension_work_http as http_fixture
from membership import AccessRequired
from test_backend import app
from browser_extension import EXTENSION_ORIGIN
class PolicyTests(unittest.TestCase):
 setUp=product_fixture.Product200.setUp
 tearDown=product_fixture.Product200.tearDown
 insert=product_fixture.Product200.insert
 def test_trial_paid_expiry_and_local_family(self):
  uid=self.insert();ent=self.m.entitlement(uid)
  self.assertEqual(ent['chat_model'],'eternal');self.m.require_extension_work(uid);self.assertFalse(ent['access']['work'])
  with self.m.connect() as c:c.execute('UPDATE launch_members SET trial_expires=? WHERE user_id=?',(time.time()-1,uid))
  ent=self.m.entitlement(uid);self.assertEqual(ent['chat_model'],'aerny');self.assertTrue(ent['access']['chat']);self.assertFalse(ent['extension_work']);self.assertIsNone(ent['plan']['expires']);self.assertTrue(ent['provider_access']['hybrid']);self.assertEqual(self.m.chat_family(uid,'eternal'),'aerny')
  with self.assertRaises(AccessRequired):self.m.require_extension_work(uid)
  admin=self.insert(role='admin');self.m.subscription_action(admin,{'action':'grant','user_id':uid,'plan_id':'early-work-30','note':'Entitlement test'})
  self.m.require_extension_work(uid);self.assertEqual(self.m.chat_family(uid,'eternal'),'eternal')
  with self.m.connect() as c:c.execute('UPDATE subscriptions SET expires=? WHERE user_id=?',(time.time()-1,uid))
  self.assertEqual(self.m.chat_family(uid,'eternal'),'aerny')
  with self.assertRaises(AccessRequired):self.m.require_extension_work(uid)
  with self.m.connect() as c:c.execute("UPDATE users SET account_state='suspended' WHERE id=?",(uid,))
  with self.assertRaises(AccessRequired):self.m.require(uid,'chat')
  self.assertFalse(self.m.entitlement(uid)['extension_work'])
 def test_aerny_hybrid_uses_validated_connected_first_orchestration(self):
  import model_router
  with patch('model_router.external_config',return_value=('secret','example-model',True)),patch('free_router.enabled',return_value=False):
   r=model_router.route('hybrid',effort='ultra',prompt='Debug this architecture',family='aerny');self.assertEqual(r['provider'],'synergy');self.assertEqual(r['workflow'],'hybrid_free')
 def test_scheduled_subscription_does_not_unlock_early(self):
  uid=self.insert();admin=self.insert(role='admin');self.m.subscription_action(admin,{'action':'grant','user_id':uid,'plan_id':'early-beast-30','note':'Future plan fixture'})
  with self.m.connect() as c:
   c.execute('UPDATE launch_members SET trial_expires=? WHERE user_id=?',(time.time()-1,uid));c.execute('UPDATE subscriptions SET starts=?,expires=? WHERE user_id=?',(time.time()+100,time.time()+10000,uid))
  self.assertFalse(self.m.entitlement(uid)['extension_work']);self.assertEqual(self.m.chat_family(uid,'eternal'),'aerny')
class AccessHTTPTests(http_fixture.WorkHTTPTests):
 test_work_http_auth_owner_revision_and_download=None
 def test_expiry_locks_work_retains_items_and_keeps_chat(self):
  cookie=self.register('trial_ext_boundary');uid=self.call('GET','/api/me',cookie=cookie)[1]['id']
  with app.membership.connect() as c:c.execute('DELETE FROM subscriptions WHERE user_id=?',(uid,))
  token=self.call('POST','/api/extension/pair',{},cookie=cookie)[1]['token'];h={'bearer':token,'origin':EXTENSION_ORIGIN}
  self.assertTrue(self.call('GET','/api/extension/me',**h)[1]['extension_work'])
  code,note,_=self.call('POST','/api/extension/work/save',{'kind':'note','title':'Retained note','text':'Keep after expiry'},**h);self.assertEqual(code,200,note)
  with app.membership.connect() as c:c.execute('UPDATE launch_members SET trial_expires=? WHERE user_id=?',(time.time()-1,uid))
  me=self.call('GET','/api/extension/me',**h)[1];self.assertFalse(me['extension_work']);self.assertTrue(me['membership']['chat']);self.assertEqual(me['chat_model'],'aerny')
  for method,path,data in [('GET','/api/extension/work',None),('POST','/api/extension/work/save',{'kind':'note','title':'Denied'}),('POST','/api/extension/work/delete',{'id':note['id'],'revision':note['revision']}),('GET','/api/extension/leads',None),('GET','/api/extension/leads/export.xlsx',None),('POST','/api/extension/leads/scan',{'url':'https://example.com'})]:self.assertIn(self.call(method,path,data,**h)[0],{402,403},path)
  self.assertEqual(app.browser_extension.work.rows(uid)[0]['title'],'Retained note')
  self.assertFalse(self.call('GET','/api/extension/models?mode=chat',**h)[1]['providers'][0]['locked'])
  with patch.object(app.research,'run'):
   code,data,_=self.call('POST','/api/extension/ask',{'mode':'chat','model_family':'eternal','provider':'hybrid','prompt':'Explain a triangle','search_mode':'off'},**h)
  self.assertEqual(code,202,data);task=app.research.task(uid,data['task']['id']);self.assertEqual(task['request']['model_family'],'aerny');app.research.cancel(uid,task['id'])
  self.assertIn(self.call('POST','/api/extension/ask',{'mode':'work','prompt':'Hello'},**h)[0],{402,403})
