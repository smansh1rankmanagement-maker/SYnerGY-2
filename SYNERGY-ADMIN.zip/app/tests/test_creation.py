from membership_fixtures import registration_fixture,paid_fixture
import io
import json
import time
import unittest
import uuid
from http.client import HTTPConnection
from unittest.mock import patch
from pathlib import Path
import threading
from PIL import Image
from pypdf import PdfReader
from test_backend import app
from creation import intent, choose_skill


class CreationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=app.ThreadingHTTPServer(('127.0.0.1',18090),app.Handler)
        threading.Thread(target=cls.server.serve_forever,daemon=True).start()
        app.RATE.clear()
        cls.cookies=[]
        for i in range(2):
            status,_,token=cls.call('POST','/api/auth/register',{'username':'creation_'+str(i),'password':'creation test password 123','invite_code':'test-invite-code'})
            assert status==200
            cls.cookies.append(token.split(';')[0])
    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close()
    @classmethod
    def call(cls,method,path,data=None,cookie=None):
        data=registration_fixture(path,data)
        c=HTTPConnection('127.0.0.1',18090,timeout=10);headers={}
        if cookie:headers['Cookie']=cookie
        if data is not None:data=json.dumps(data);headers['Content-Type']='application/json'
        c.request(method,path,data,headers);r=c.getresponse();b=r.read();out=json.loads(b) if r.getheader('Content-Type')=='application/json' else b;token=r.getheader('Set-Cookie');status=r.status;paid_fixture(app,path);c.close();return status,out,token
    def request(self,prompt,**values):
        status,task,_=self.call('POST','/api/research/tasks',{'prompt':prompt,'mode':'chat','search_mode':'off',**values},self.cookies[0]);self.assertEqual(status,202,task);return task
    def done(self,task):
        deadline=time.monotonic()+20
        while task['state'] in {'queued','running'}:
            self.assertLess(time.monotonic(),deadline,task)
            time.sleep(.1);task=self.call('GET','/api/research/tasks/'+task['id'],cookie=self.cookies[0])[1]
        return task
    def test_intent_boundaries(self):
        for p,k in [('Create a PDF about generating video','document'),('Create a PDF. Exact content: create a video and image','document'),('Create a photo of video screens','image'),('create image of a garden','image'),('Draw a cat','image'),('make instagram post of a walnut desk','image'),('Create a poster about gardens as PDF','image'),('make a video of rain','video'),('Create a PDF about offices','document'),('save the previous answer as PDF','document'),('Please make a Word document about gardens','document'),('image banao sunset ka','image')]:
            self.assertEqual(intent(p)['kind'],k,p)
        for p in ['How do I create a PDF?','Do not generate an image','Research image generation','Write a caption for an Instagram post','Create a prompt for a video','Explain why photos fail','Create a workflow that generates a PDF','"create image of this"','What is a good image model?']:
            self.assertIsNone(intent(p),p)
    def test_pdf_and_docx_real_files_all_modes_and_scope(self):
        for mode in ['chat','work','beast']:
            task=self.done(self.request('Create a PDF and Word document. Exact content: # Studio brief\n\nOwner: Smansh.\nDeadline: unspecified.\n\n| Item | Quantity |\n|---|---|\n| Chair | 2 |',mode=mode))
            self.assertEqual(task['state'],'succeeded',task['detail'])
            self.assertEqual(task['request']['selected_skill']['id'],'document-creation')
            pdf=next(a for a in task['detail']['artifacts'] if a['kind']=='pdf')
            code,data,_=self.call('GET',pdf['url'],cookie=self.cookies[0]);self.assertEqual(code,200)
            conn=HTTPConnection('127.0.0.1',18090,timeout=10)
            conn.request('GET',pdf['url'],headers={'Cookie':self.cookies[0]})
            response=conn.getresponse();response.read()
            self.assertEqual(response.getheader('X-Frame-Options'),'SAMEORIGIN')
            self.assertIn("frame-ancestors 'self'",response.getheader('Content-Security-Policy'))
            conn.close()
            text=' '.join(p.extract_text() for p in PdfReader(io.BytesIO(data)).pages)
            for term in ['Smansh','unspecified','Chair']:self.assertIn(term,text)
            self.assertEqual(self.call('GET',pdf['url'],cookie=self.cookies[1])[0],404)
            self.assertEqual(self.call('GET',pdf['url'])[0],401)
            chat=self.call('GET','/api/conversations/'+task['conversation_id'],cookie=self.cookies[0])[1]
            self.assertEqual(chat['messages'][-1]['metadata']['artifacts'],task['detail']['artifacts'])
    def test_previous_answer_export_does_not_call_model(self):
        uid=app.research.ws.chat # get current account through task
        task=self.done(self.request('Create PDF. Exact text: Preserve 100 and 200.'))
        cid=task['conversation_id']
        with app.connect() as c:user=c.execute('SELECT user_id FROM conversations WHERE id=?',(cid,)).fetchone()[0]
        app.workspace.add(user,cid,'assistant','Exact previous answer: total 300. No deadline supplied.',{'state':'succeeded'})
        with patch.object(app.research,'model',side_effect=AssertionError('Must not regenerate content')):
            result=self.done(self.request('Export the previous answer as PDF',conversation_id=cid))
        data=self.call('GET',result['detail']['artifacts'][0]['url'],cookie=self.cookies[0])[1]
        self.assertIn('total 300',PdfReader(io.BytesIO(data)).pages[0].extract_text())
    def test_pdf_drafting_uses_model_then_renderer(self):
        seen=[]
        def draft(uid,jid,messages,*args):seen.extend(messages);return '# Office plan\n\n## Discovery\nConfirm the brief before design.',{}
        with patch.object(app.research,'model',side_effect=draft):task=self.done(self.request('Create a PDF about an office design process.'))
        self.assertEqual(task['state'],'succeeded',task)
        self.assertTrue(task['detail']['artifacts'])
        self.assertIn('COMPLETE document',seen[0]['content'])
    def test_poster_layout_followup_and_exact_text(self):
        task=self.done(self.request('Create PDF. Exact text: setup'))
        with app.connect() as c:uid=c.execute('SELECT user_id FROM conversations WHERE id=?',(task['conversation_id'],)).fetchone()[0]
        buf=io.BytesIO();Image.new('RGB',(420,300),'#a47750').save(buf,format='PNG')
        f=app.research.upload(uid,buf.getvalue(),'reference.png')
        first=self.done(self.request('Create an Instagram post. Keep the image unchanged. Headline "Spaces for work". 1080 x 1350.',file_id=f['id']))
        self.assertEqual(first['state'],'succeeded',first)
        self.assertEqual(first['detail']['creation']['workflow'],'layout')
        image=self.call('GET',first['detail']['artifacts'][0]['url'],cookie=self.cookies[0])[1]
        self.assertEqual(Image.open(io.BytesIO(image)).size,(1080,1350))
        follow=self.done(self.request('Change only the headline to "Spaces that feel like you."',conversation_id=first['conversation_id']))
        self.assertEqual(follow['state'],'succeeded',follow)
        self.assertEqual(follow['detail']['generation']['checks']['layers'][0]['text'],'Spaces that feel like you.')
        self.assertNotEqual(first['detail']['creation']['project_id'],follow['detail']['creation']['project_id'])
    def test_a4_document_png_and_followup(self):
        task=self.done(self.request('Create a PDF hall ticket. Exact text: # Examination ticket\n\nCandidate: QA SAMPLE.\nExam time: unspecified.'))
        self.assertEqual(task['state'],'succeeded')
        result=self.done(self.request('okay give me in the PNG file',conversation_id=task['conversation_id']))
        self.assertEqual(result['state'],'succeeded',result)
        png=self.call('GET',result['detail']['artifacts'][0]['url'],cookie=self.cookies[0])[1]
        self.assertEqual(Image.open(io.BytesIO(png)).size,(2480,3508))
        text=self.call('GET',result['detail']['artifacts'][-1]['url'],cookie=self.cookies[0])[1].decode()
        self.assertIn('QA SAMPLE',text);self.assertIn('unspecified',text)
        history=[{'role':'user','content':'Please design an A4 hall ticket.'}]
        self.assertEqual(intent('Here are the details. Now create it',None,history)['kind'],'document')

    def test_missing_models_cannot_succeed_or_fabricate_file(self):
        with patch.object(app.studio,'manifest',Path('/not-installed/model.json')):
            task=self.done(self.request('Create a photo of a red mug'))
        self.assertEqual(task['state'],'failed');self.assertIn('not installed',task['detail']['error']);self.assertFalse(task['detail'].get('artifacts'))
        self.assertEqual(self.call('GET','/api/research/tasks/'+task['id']+'/output.png',cookie=self.cookies[0])[0],404)
        with patch.object(app.video_jobs,'status',return_value={'ready':False,'detail':'Motion adapter missing'}):task=self.done(self.request('Create a video of waves'))
        self.assertEqual(task['state'],'failed');self.assertIn('Motion adapter missing',task['detail']['error'])
    def test_deduplication_and_legacy_chat_dispatch(self):
        request_id=uuid.uuid4().hex
        one=self.done(self.request('Create PDF. Exact text: One output only.',request_id=request_id))
        two=self.request('Create PDF. Exact text: One output only.',request_id=request_id)
        self.assertEqual(one['id'],two['id'])
        code,task,_=self.call('POST','/api/chat',{'prompt':'Create PDF. Exact text: Direct chat API.','mode':'chat'},self.cookies[0]);self.assertEqual(code,202)
        self.assertEqual(self.done(task)['state'],'succeeded')
    def test_cancel_queued_image_releases_child(self):
        with patch.object(app.studio,'busy',return_value=True):
            task=self.request('Create a poster. Layout only. Headline "Cancellation check".')
            deadline=time.monotonic()+5
            while not task['detail'].get('creation',{}).get('job_id'):
                self.assertLess(time.monotonic(),deadline);time.sleep(.05)
                task=self.call('GET','/api/research/tasks/'+task['id'],cookie=self.cookies[0])[1]
            self.call('POST','/api/research/cancel',{'id':task['id']},self.cookies[0])
            task=self.done(task)
        self.assertEqual(task['state'],'cancelled')
        with app.connect() as c:child=c.execute('SELECT state FROM studio_jobs WHERE id=?',(task['detail']['creation']['job_id'],)).fetchone()
        self.assertEqual(child['state'],'cancelled')
        self.assertEqual(self.call('GET','/api/research/tasks/'+task['id']+'/output.png',cookie=self.cookies[0])[0],404)

    def test_video_cancellation_does_not_become_failure(self):
        import tempfile
        from jobs import VideoJobs
        started=threading.Event();release=threading.Event()
        def runner(jid):started.set();release.wait(5)
        with tempfile.TemporaryDirectory() as tmp:
            queue=VideoJobs(tmp,runner=runner)
            with patch.object(queue,'status',return_value={'ready':True}):job=queue.submit('A plant','1080p')
            self.assertTrue(started.wait(2));queue.cancel(job['id']);release.set()
            deadline=time.monotonic()+3
            while queue.active:
                self.assertLess(time.monotonic(),deadline);time.sleep(.05)
            self.assertEqual(queue.get(job['id'])['state'],'cancelled');queue.close()

    def test_custom_skills_and_disabled_tools(self):
        task=self.done(self.request('Create PDF. Exact text: Setup'))
        with app.connect() as c:uid=c.execute('SELECT user_id FROM conversations WHERE id=?',(task['conversation_id'],)).fetchone()[0]
        s=app.workspace.save_skill(uid,{'name':'InteriFY document voice','description':'interior proposals documents','instructions':'Keep every fact supplied by the user.'})
        selected,automatic=choose_skill(app.workspace,uid,'Create a PDF using InteriFY document voice',intent('Create a PDF'))
        self.assertEqual(selected['id'],s['id']);self.assertTrue(automatic)
        app.workspace.toggle(uid,'documents',False)
        try:
            task=self.done(self.request('Create PDF. Exact text: Should be disabled.'))
            self.assertEqual(task['state'],'failed');self.assertFalse(task['detail'].get('artifacts'))
        finally:app.workspace.toggle(uid,'documents',True)


if __name__=='__main__':unittest.main()
