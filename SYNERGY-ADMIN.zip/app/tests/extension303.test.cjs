const {test}=require('node:test'),assert=require('node:assert/strict');
const {selection}=require('../extension/access-policy.js');
test('expired trial uses Aerny chat and locks Work toolbar',()=>{assert.deepEqual(selection({membership:{chat:true,work:false},chat_model:'aerny',extension_work:false},'work','eternal'),{mode:'chat',family:'aerny',work:false});});
test('Chat trial unlocks tools without granting Work model',()=>{assert.deepEqual(selection({membership:{chat:true,work:false},chat_model:'eternal',extension_work:true},'work','eternal'),{mode:'chat',family:'eternal',work:true});});
test('paid account retains selected Aerny; expiry overrides stored ETERNAL',()=>{assert.equal(selection({membership:{chat:true,work:true},chat_model:'eternal',extension_work:true},'chat','aerny').family,'aerny');assert.equal(selection({membership:{chat:true},chat_model:'aerny'},'chat','eternal').family,'aerny');});
