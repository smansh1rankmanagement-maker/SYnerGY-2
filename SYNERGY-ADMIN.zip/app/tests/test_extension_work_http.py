import test_extension_leads as fixture
from test_backend import app
from browser_extension import EXTENSION_ORIGIN
import unittest
class WorkHTTPTests(fixture.ExtensionLeadsTest):
 # Reuse only HTTP fixture helpers, not inherited acceptance methods.
 test_extension_scope_cors_revocation_and_lead_workbook=None
 test_install_routed_before_model_in_all_modes=None
 def test_work_http_auth_owner_revision_and_download(self):
  cookie=self.register('workext_qa');other=self.register('workext_other')
  token=self.call('POST','/api/extension/pair',{},cookie=cookie)[1]['token'];token2=self.call('POST','/api/extension/pair',{},cookie=other)[1]['token']
  self.assertEqual(self.call('GET','/api/extension/work')[0],401)
  self.assertEqual(self.call('GET','/api/extension/work',bearer=token,origin='https://evil.test')[0],403)
  code,item,_=self.call('POST','/api/extension/work/save',{'kind':'note','title':'Private QA note','text':'saved'},bearer=token,origin=EXTENSION_ORIGIN);self.assertEqual(code,200,item)
  self.assertEqual(self.call('GET','/api/extension/work',bearer=token2,origin=EXTENSION_ORIGIN)[1]['items'],[])
  self.assertEqual(self.call('POST','/api/extension/work/save',{**item,'text':'changed'},bearer=token2,origin=EXTENSION_ORIGIN)[0],404)
  self.assertEqual(self.call('POST','/api/extension/work/save',{**item,'text':'changed'},bearer=token,origin=EXTENSION_ORIGIN)[0],200)
  self.assertEqual(self.call('POST','/api/extension/work/save',item,bearer=token,origin=EXTENSION_ORIGIN)[0],400)
  rows=self.call('GET','/api/extension/work',bearer=token,origin=EXTENSION_ORIGIN)[1];self.assertEqual(rows['items'][0]['text'],'changed');self.assertFalse(rows['calendar']['connected'])
  import io,zipfile
  blob=self.call('GET','/api/extension/download',cookie=cookie)[1]
  with zipfile.ZipFile(io.BytesIO(blob)) as z:self.assertIn('work.js',z.namelist());self.assertNotIn('id="disconnect"',z.read('panel.html').decode())
  with app.workspace.connect() as c:c.execute("UPDATE users SET account_state='terminated' WHERE username='workext_qa'")
  self.assertEqual(self.call('GET','/api/extension/work',bearer=token,origin=EXTENSION_ORIGIN)[0],401)
