import concurrent.futures,json,sqlite3,tempfile,time,unittest,uuid
from pathlib import Path
from membership import Membership,AccessRequired
from launch_pricing import allocate,PLANS
from observation_learning import Observation
from observation_mcp import learning_call

class Product200(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.db=Path(self.tmp.name)/'accounts.sqlite3'
  with sqlite3.connect(self.db) as c:
   c.executescript('CREATE TABLE users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,salt BLOB,password BLOB);CREATE TABLE sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER,expires REAL);')
  self.m=Membership(self.db)
 def tearDown(self):self.tmp.cleanup()
 def insert(self,n=1,role='user',suffix='example.org'):
  with self.m.connect() as c:
   c.execute('BEGIN IMMEDIATE')
   for i in range(n):
    name=uuid.uuid4().hex;uid=c.execute('INSERT INTO users(username,email,role,account_state,salt,password) VALUES(?,?,?,?,?,?)',(name,name+'@'+suffix,role,'active',b's',b'p')).lastrowid;allocate(c,uid)
  return uid
 def test_exact_new_prices(self):
  self.assertEqual([p['amount_paise'] for p in PLANS.values()],[9900,29900,299900,1199900,199900,1199900,499900,4999900])
  self.assertEqual([p['days'] for p in PLANS.values()],[7,30,30,365,30,365,30,365])
 def test_501_boundary_qa_admin_exclusion_and_permanence(self):
  self.insert(role='admin');self.insert(suffix='qa.invalid');self.insert(500);early=self.insert();late=self.insert()
  self.assertEqual(self.m.catalog(early)['member_number'],501);self.assertEqual(self.m.catalog(early)['tier'],'early');self.assertEqual(self.m.catalog(late)['tier'],'regular')
  with self.m.connect() as c:c.execute("UPDATE users SET account_state='suspended' WHERE id=?",(early,))
  self.assertEqual(self.m.catalog(late)['tier'],'regular');self.assertEqual(self.m.catalog(early)['tier'],'early')
 def test_concurrent_allocations_unique(self):
  with concurrent.futures.ThreadPoolExecutor(4) as pool:list(pool.map(lambda _:self.insert(),range(12)))
  with self.m.connect() as c:self.assertEqual(c.execute('SELECT count(DISTINCT ordinal) FROM launch_members').fetchone()[0],12)
 def test_trial_expiry_and_paid_chat_access(self):
  uid=self.insert();self.m.require(uid,'chat')
  with self.m.connect() as c:c.execute('UPDATE launch_members SET trial_expires=? WHERE user_id=?',(time.time()-1,uid))
  self.m.require(uid,'chat');self.assertEqual(self.m.entitlement(uid)['chat_model'],'aerny')
  admin=self.insert(role='admin');self.m.subscription_action(admin,{'action':'grant','user_id':uid,'plan_id':'early-work-30','note':'Authorised test grant'})
  self.m.require(uid,'chat');self.m.require(uid,'work')
 def test_tier_and_amount_not_client_controlled(self):
  uid=self.insert()
  with self.assertRaises(ValueError):self.m.checkout(uid,{'plan_id':'regular-work-365','request_key':uuid.uuid4().hex})
  o=self.m.checkout(uid,{'plan_id':'early-work-30','amount_paise':1,'request_key':uuid.uuid4().hex});self.assertEqual(o['amount_paise'],29900)
 def test_pending_legacy_purchase_preserved(self):
  uid=self.insert();oid='legacy-order';key=uuid.uuid4().hex
  with self.m.connect() as c:c.execute('INSERT INTO payment_orders(id,user_id,plan_id,amount_paise,currency,state,created,request_key) VALUES(?,?,?,?,?,?,?,?)',(oid,uid,'beast-15',114900,'INR','created',time.time(),key))
  old=self.m.checkout(uid,{'plan_id':'beast-15','request_key':key});self.assertEqual(old['amount_paise'],114900)
  result=self.m.submit_payment(uid,{'id':oid,'utr':'LEGACY12345678','transaction_id':'TRANS12345678'});sub=result['membership']['subscriptions'][0];self.assertEqual(sub['expires']-sub['starts'],15*86400)
 def test_restart_keeps_cohort_and_trial(self):
  uid=self.insert();before=self.m.catalog(uid);Membership(self.db);after=self.m.catalog(uid);self.assertEqual(before,after)

class ObservationTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.obs=Observation(Path(self.tmp.name)/'db');self.prompt='Explain Python local variable scopes';self.reply='Python function variables are local unless declared global or nonlocal. Inspect lexical scope carefully.'
 def tearDown(self):self.tmp.cleanup()
 def capture(self,**kw):return self.obs.capture(1,self.prompt,self.reply,enabled=True,**kw)
 def test_off_and_external_consent(self):
  self.assertEqual(self.obs.capture(1,self.prompt,self.reply)['status'],'off');self.assertEqual(self.capture(external=True)['status'],'external_consent_required');self.assertEqual(self.capture(private=True)['status'],'excluded_private_context')
 def test_review_scope_isolation_and_retrieval(self):
  item=self.capture();self.assertEqual(self.obs.retrieve(1,self.prompt,enabled=True),[])
  with self.assertRaises(KeyError):self.obs.review(2,item['id'],'approve')
  self.obs.review(1,item['id'],'approve');self.assertEqual(len(self.obs.retrieve(1,self.prompt,enabled=True)),1);self.assertEqual(self.obs.retrieve(2,self.prompt,enabled=True),[]);self.assertEqual(self.obs.retrieve(1,self.prompt,'another-project',enabled=True),[])
 def test_secret_pattern_and_personal_contact_excluded(self):
  for value in ['password=extremelyprivate','contact me at test@example.org','sk-'+'x'*30]:self.assertEqual(self.obs.capture(1,value,self.reply,enabled=True)['status'],'excluded_sensitive_pattern')
 def test_freshness_and_deletion(self):
  item=self.capture();self.obs.review(1,item['id'],'approve');self.assertEqual(self.obs.retrieve(1,'Latest Python local variable scopes',enabled=True),[])
  with self.obs.connect() as c:c.execute('UPDATE observation_examples SET created=?',(time.time()-8*86400,))
  self.assertEqual(self.obs.retrieve(1,self.prompt,enabled=True),[]);self.obs.clear(1);self.assertEqual(self.obs.list(1)['examples'],[])
 def test_mcp_binds_account_and_validates_arguments(self):
  item=self.capture();self.assertEqual(learning_call(self.obs,2,'observation_examples',{})['examples'],[])
  with self.assertRaises(ValueError):learning_call(self.obs,1,'observation_examples',{'user_id':2})
  self.assertTrue(learning_call(self.obs,1,'observation_review',{'id':item['id'],'decision':'approve'})['ok'])
 def test_deduplicate_and_no_training_claim(self):
  item=self.capture();self.assertEqual(self.capture()['id'],item['id']);self.assertFalse(self.obs.list(1)['training_completed'])
 def test_retention(self):
  self.capture()
  with self.obs.connect() as c:c.execute('UPDATE observation_examples SET expires=?',(time.time()-1,))
  self.assertEqual(self.obs.list(1)['examples'],[])
class ObservationPipelineTests(unittest.TestCase):
 def test_local_capture_review_and_retrieval_through_research(self):
  import threading
  from unittest.mock import patch
  from workspace import Workspace
  from research.service import Research
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);ws=Workspace(root/'db');r=Research(ws,root/'research',lambda u,p:[],{},threading.Lock(),lambda:False)
   r.settings(1,{'observation_learning':True,'response_cache':False})
   def run(uid):
    t=r.submit(uid,{'prompt':'Explain Python local variable scopes briefly','provider':'synergy','search_mode':'off','effort':'instant'})
    until=time.monotonic()+4
    while time.monotonic()<until:
     t=r.task(uid,t['id'])
     if t['state'] not in {'queued','running'}:return t
     time.sleep(.02)
    self.fail('Bounded fixture did not finish')
   try:
    with patch.object(r,'model',return_value=('Python function variables are local bindings unless global or nonlocal declarations change their scope.',{})) as model:
     a=run(1);self.assertEqual(a['state'],'succeeded');examples=r.observations.list(1)['examples'];self.assertEqual(len(examples),1);self.assertEqual(examples[0]['provenance']['provider'],'synergy');r.observations.review(1,examples[0]['id'],'approve');b=run(1);self.assertEqual(b['detail'].get('observation_reused'),1);self.assertIn('PRIVATE REVIEWED EXAMPLES',model.call_args.args[2][-1]['content']);run(2);self.assertNotIn('PRIVATE REVIEWED EXAMPLES',model.call_args.args[2][-1]['content'])
   finally:r.close()
 def test_hybrid_external_retrieval_requires_separate_consent(self):
  from observation_learning import may_retrieve,provenance_provider
  prefs={'observation_learning':True,'allow_external':True}
  self.assertFalse(may_retrieve({'provider':'synergy','workflow':'hybrid_free'},prefs));self.assertTrue(may_retrieve({'provider':'synergy'},prefs));self.assertTrue(may_retrieve({'provider':'synergy','workflow':'hybrid_free'},{**prefs,'observation_external':True}));self.assertEqual(provenance_provider({'provider':'synergy'},{'routing':{'actual_provider':'gemini','actual_model':'test-model'}}),('gemini','test-model'));self.assertEqual(provenance_provider({'provider':'synergy'},{'review':{'status':'reviewed','review_model':'test-model'}}),('openai','test-model'))
if __name__=='__main__':unittest.main()
