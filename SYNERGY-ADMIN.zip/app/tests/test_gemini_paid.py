import io,json,os,sqlite3,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
import free_router

class GeminiPaidTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  self.env=patch.dict(os.environ,{'SYNERGY_DATA_DIR':str(self.root),'SYNERGY_GEMINI_MODELS':'gemini-3.1-pro-preview'});self.env.start()
  with self.db() as c:
   c.executescript('CREATE TABLE users(id INTEGER PRIMARY KEY,role TEXT,account_state TEXT); CREATE TABLE subscriptions(user_id INTEGER,mode TEXT,state TEXT,starts REAL,expires REAL);')
   c.executemany('INSERT INTO users VALUES(?,?,?)',[(1,'user','active'),(2,'user','active'),(3,'admin','active'),(4,'user','suspended')])
  self.grant(1);self.grant(4)
 def db(self):return sqlite3.connect(self.root/'accounts.sqlite3')
 def grant(self,uid,mode='work',state='active',start=-60,end=3600):
  with self.db() as c:c.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?)',(uid,mode,state,time.time()+start,time.time()+end))
 def tearDown(self):self.env.stop();self.tmp.cleanup()
 def test_only_current_subscriptions_unlock_key(self):
  self.assertTrue(free_router.gemini_paid_access(1))
  self.assertFalse(free_router.gemini_paid_access(2))
  self.assertFalse(free_router.gemini_paid_access(3))
  self.assertFalse(free_router.gemini_paid_access(4))
 def test_expiry_and_revocation_take_effect_without_restart(self):
  with self.db() as c:c.execute('UPDATE subscriptions SET expires=? WHERE user_id=1',(time.time()-1,))
  self.assertFalse(free_router.gemini_paid_access(1))
  self.grant(1,mode='beast');self.assertTrue(free_router.gemini_paid_access(1))
  with self.db() as c:c.execute("UPDATE subscriptions SET state='revoked' WHERE user_id=1")
  self.assertFalse(free_router.gemini_paid_access(1))
 def test_future_or_chat_subscription_is_ineligible(self):
  self.grant(2,start=3600,end=7200);self.grant(2,mode='chat')
  self.assertFalse(free_router.gemini_paid_access(2))
 def test_missing_forged_identity_or_database_fails_closed(self):
  for uid in [None,True,'1',-1,99]:self.assertFalse(free_router.gemini_paid_access(uid))
  (self.root/'accounts.sqlite3').unlink();self.assertFalse(free_router.gemini_paid_access(1))
 def request(self,uid,permission=True,data_permission=True):
  payload={'modelVersion':'gemini-fixture','candidates':[{'finishReason':'STOP','content':{'parts':[{'text':'Paid response.'}]}}]}
  with patch.object(free_router,'candidates',return_value=[]),patch.object(free_router,'gemini_enabled',return_value=True),patch.object(free_router,'gemini_credential',return_value='fixture-secret'),patch('free_router.urllib.request.urlopen',return_value=io.BytesIO(json.dumps(payload).encode())) as net:
   answer,meta=free_router.respond([{'role':'user','content':'Connection fixture'}],128,permission,free_data_permission=data_permission,user_id=uid)
   return answer,meta,net.call_count
 def test_free_account_never_sends_gemini_request(self):
  answer,meta,calls=self.request(2);self.assertIsNone(answer);self.assertEqual(calls,0)
 def test_subscribed_account_uses_real_router_path(self):
  answer,meta,calls=self.request(1);self.assertEqual(answer,'Paid response.');self.assertEqual(calls,1);self.assertEqual(meta['actual_provider'],'gemini')
 def test_subscription_does_not_override_privacy_consent(self):
  for external,free_data in [(False,True),(True,False)]:
   answer,meta,calls=self.request(1,external,free_data);self.assertEqual(calls,0)
 def test_model_configuration_cannot_redirect_credentials(self):
  with patch.dict(os.environ,{'SYNERGY_GEMINI_MODELS':'https://attacker.invalid,gemini-3.1-pro-preview,../escape'}):self.assertEqual(free_router.gemini_models(),['gemini-3.1-pro-preview'])

if __name__=='__main__':unittest.main()
