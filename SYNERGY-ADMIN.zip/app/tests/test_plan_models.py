"""Account boundaries and cost accounting for the Sol/Luna integration."""
import io,json,os,sqlite3,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from membership import Membership
import model_router,openai_budget,hybrid_router

class PlanModels(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name)
  env=patch.dict(os.environ,{'SYNERGY_DATA_DIR':str(self.root),'SYNERGY_ALLOW_OPENAI':'1','SYNERGY_OPENAI_MODEL':'gpt-6.1-sol','OPENAI_API_KEY':'test-fixture-only','SYNERGY_OPENAI_BUDGET_USD':'2'})
  env.start();self.addCleanup(env.stop)
  with sqlite3.connect(self.root/'accounts.sqlite3') as c:
   c.executescript('CREATE TABLE users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL,salt BLOB NOT NULL,password BLOB NOT NULL);CREATE TABLE sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER,expires REAL);')
  self.m=Membership(self.root/'accounts.sqlite3')
  self.free=self.m.register({'email':'free@example.org','password':'Long test password 2026'})['id']
  self.paid=self.m.register({'email':'paid@example.org','password':'Long test password 2026'})['id']
  self.admin=self.m.register({'email':'admin@example.org','password':'Long test password 2026'})['id']
  with self.m.connect() as c:
   c.execute("UPDATE users SET role='admin' WHERE id=?",(self.admin,))
   c.execute("INSERT INTO subscriptions VALUES('paid',?,'beast',?,?,'active',NULL,?,'test_fixture')",(self.paid,time.time()-1,time.time()+3600,time.time()))
 def route(self,uid,**kw):return model_router.route('openai',user_id=uid,**kw)
 def test_default_models_and_trial_is_not_paid(self):
  self.assertEqual(self.route(self.free)['model'],'gpt-6-luna')
  for uid in [self.paid,self.admin]:self.assertEqual(self.route(uid)['model'],'gpt-6.1-sol')
 def test_free_cannot_request_sol_or_forge_selection(self):
  with self.assertRaises(ValueError):self.route(self.free,openai_model='gpt-6.1-sol')
  with patch('model_router.urllib.request.urlopen') as net:
   with self.assertRaises(ValueError):model_router.openai_response([],{'provider':'openai','model':'gpt-6.1-sol','user_id':self.free},16)
   net.assert_not_called()
 def test_unknown_model_and_missing_owner_denied(self):
  for uid,model in [(self.free,'unreviewed'),(None,'auto'),(True,'auto')]:
   with self.assertRaises(ValueError):self.route(uid,openai_model=model)
 def test_expiry_revocation_and_suspension_rechecked_at_execution(self):
  selection=self.route(self.paid)
  with self.m.connect() as c:c.execute("UPDATE subscriptions SET state='revoked' WHERE user_id=?",(self.paid,))
  with self.assertRaises(ValueError):model_router.validate_openai(selection)
  with self.m.connect() as c:c.execute("UPDATE users SET account_state='suspended' WHERE id=?",(self.admin,))
  with self.assertRaises(PermissionError):self.route(self.admin)
 def test_paid_can_explicitly_choose_luna(self):
  self.assertEqual(self.route(self.paid,openai_model='gpt-6-luna')['model'],'gpt-6-luna')
 def test_mode_permissions_still_apply(self):
  with self.assertRaises(PermissionError):self.route(self.free,mode='beast')
  self.assertEqual(self.route(self.paid,mode='beast')['model'],'gpt-6.1-sol')
 def test_hybrid_single_plan_and_no_legacy_provider_calls(self):
  for uid,model in [(self.free,'gpt-6-luna'),(self.paid,'gpt-6.1-sol')]:
   plan=model_router.route('hybrid',user_id=uid)
   self.assertEqual(plan['routing_decisions'],1);self.assertEqual(plan['planned_openai_model'],model)
   with patch('model_router.openai_response',return_value='Answer') as call,patch('free_router.respond') as legacy,patch('free_router.audit'):
    answer,meta=hybrid_router.respond([],16,True,user_id=uid,planned_model=plan['planned_openai_model'])
    self.assertEqual(answer,'Answer');self.assertEqual(meta['actual_model'],model)
    self.assertEqual(call.call_args.args[1]['user_id'],uid);legacy.assert_not_called()
 def test_hybrid_failure_keeps_local_fallback_and_no_secret_diagnostic(self):
  with patch('model_router.openai_response',side_effect=ValueError('private detail')),patch('free_router.audit'):
   answer,meta=hybrid_router.respond([],16,True,user_id=self.free)
   self.assertIsNone(answer);self.assertEqual(meta['status'],'local_fallback');self.assertNotIn('private detail',json.dumps(meta))
 def test_privacy_off_never_calls_provider(self):
  with patch('model_router.openai_response') as call:
   hybrid_router.respond([],16,False,user_id=self.admin);call.assert_not_called()
 def test_catalog_locks_sol_for_free(self):
  catalog={'providers':[{'id':k,'available':True} for k in ['synergy','openai','hybrid']],'openai_model':'configured','openai_models':[{'id':m,'available':True,'paid':m=='gpt-6.1-sol'} for m in model_router.OPENAI_MODELS]}
  for uid,expected in [(self.free,'gpt-6-luna'),(self.paid,'gpt-6.1-sol'),(self.admin,'gpt-6.1-sol')]:
   c=self.m.provider_catalog(uid,catalog)
   self.assertEqual(c['openai_model'],expected)
   self.assertEqual(c['openai_models'][1]['locked'],uid==self.free)
 def test_luna_sol_rates_and_idempotent_settlement(self):
  for model,expected in [('gpt-6-luna',11),('gpt-6.1-sol',220)]:
   token=openai_budget.reserve({'model':model,'max_output_tokens':16},user_id=self.paid)
   openai_budget.finish(token,{'input_tokens':10,'output_tokens':20})
   openai_budget.finish(token,{'input_tokens':999,'output_tokens':999})
   with openai_budget.db() as c:r=c.execute('SELECT model,user_id,charged FROM requests WHERE id=?',(token,)).fetchone()
   self.assertEqual(tuple(r),(model,self.paid,expected))
 def test_daily_allowance_and_global_cap_remain_enforced(self):
  with patch.dict(os.environ,{'SYNERGY_OPENAI_FREE_DAILY_USD':'0'}):
   with self.assertRaises(ValueError):openai_budget.reserve({'model':'gpt-6-luna'},user_id=self.free)
  with patch.dict(os.environ,{'SYNERGY_OPENAI_BUDGET_USD':'0'}):
   with self.assertRaises(ValueError):openai_budget.reserve({'model':'gpt-6-luna'},user_id=self.paid)
 def test_existing_ledger_migration_preserves_spend(self):
  with sqlite3.connect(self.root/'openai-usage.sqlite3') as c:
   c.execute('CREATE TABLE requests(id TEXT PRIMARY KEY,reserved INTEGER NOT NULL,charged INTEGER,state TEXT NOT NULL,created REAL NOT NULL,input_tokens INTEGER,output_tokens INTEGER)')
   c.execute("INSERT INTO requests VALUES('old',200,200,'completed',?,10,18)",(time.time(),))
  self.assertEqual(openai_budget.status()['accounted_usd'],.0002)
  with openai_budget.db() as c:self.assertEqual(c.execute("SELECT model FROM requests WHERE id='old'").fetchone()[0],'gpt-6.1-sol')

if __name__=='__main__':unittest.main()
