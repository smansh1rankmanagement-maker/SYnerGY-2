"""Privacy, freshness, cancellation and real pipeline regression fixtures."""
import json,sqlite3,sys,tempfile,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from workspace import Workspace
from research.service import Research
from research.cache import AnswerCache,key,ttl
from research.latency import PhaseStop,BudgetExpired,policy
from research.web import Web,plan,relevance
from deployment_policy import validate,target,status,require_publication_provider

class ResponseSpeedTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  self.w=Workspace(self.root/'db.sqlite');self.r=Research(self.w,self.root/'research',lambda u,p:[],{},threading.Lock(),lambda:False)
 def tearDown(self):
  self.r.close()
  end=time.monotonic()+3
  while self.r.stops and time.monotonic()<end:time.sleep(.01)
  self.tmp.cleanup()
 def request(self,uid=1,**data):
  task=self.r.submit(uid,{'prompt':'Explain a triangle briefly','effort':'medium','search_mode':'off',**data})
  end=time.monotonic()+4
  while time.monotonic()<end:
   result=self.r.task(uid,task['id'])
   if result['state'] not in {'queued','running'}:return result
   time.sleep(.01)
  self.fail('Fixture exceeded bounded test time')
 def test_cache_isolation_expiry_limit_and_canonical_key(self):
  c=self.r.answer_cache
  self.assertEqual(key({'a':1,'b':2}),key({'b':2,'a':1}))
  with patch('research.cache.time.time',return_value=100):c.put(1,'same',{'reply':'Private to account'},300)
  with patch('research.cache.time.time',return_value=102):
   self.assertEqual(c.get(1,'same')['reply'],'Private to account');self.assertIsNone(c.get(2,'same'))
  with patch('research.cache.time.time',return_value=401):self.assertIsNone(c.get(1,'same'))
  for n in range(30):c.put(1,str(n),{'reply':'a'},300)
  with c.connect() as con:self.assertEqual(con.execute('SELECT count(*) FROM response_cache WHERE user_id=1').fetchone()[0],20)
  for q in ['latest news','stock price today','medical diagnosis','legal rules','refresh this']:
   self.assertEqual(ttl(q),0)
 def test_repeat_skips_model_refresh_and_history_invalidate(self):
  with patch.object(self.r,'model',return_value=('A triangle has three sides.',{})) as model:
   a=self.request();b=self.request()
   self.assertEqual(a['state'],'succeeded');self.assertTrue(b['detail']['cache']['hit']);self.assertEqual(model.call_count,1)
   self.request(uid=2);self.assertEqual(model.call_count,2)
   self.request(fresh_research=True);self.assertEqual(model.call_count,3)
   self.request(conversation_id=a['conversation_id']);self.assertEqual(model.call_count,4)
   self.r.settings(1,{'response_cache':False});self.request();self.assertEqual(model.call_count,5)
 def test_private_uploads_and_current_prompts_never_cache(self):
  f=self.r.upload(1,b'Approved material is walnut.','brief.txt')
  with patch.object(self.r,'model',return_value=('The material is walnut. [D1]',{})) as model:
   self.request(file_id=f['id']);self.request(file_id=f['id']);self.assertEqual(model.call_count,2)
   self.request(prompt='Explain current changes',search_mode='off');self.request(prompt='Explain current changes',search_mode='off');self.assertEqual(model.call_count,4)
  with self.r.connect() as con:self.assertEqual(con.execute('SELECT COUNT(*) FROM response_cache').fetchone()[0],0)
 def test_time_budget_partial_not_cached_and_honest(self):
  def slow(uid,jid,messages,selection,options,stop,permission):
   self.r.update(uid,jid,reply='An unfinished response [S99].')
   while True:time.sleep(.02);self.r.check(stop)
  with patch('research.service.policy',return_value={**policy('instant'),'seconds':.01,'job_timeout_seconds':.12}),patch.object(self.r,'model',side_effect=slow):
   a=self.request(effort='instant')
  self.assertEqual(a['state'],'partial');self.assertIn('partial answer',a['reply']);self.assertNotIn('[S99]',a['reply']);self.assertFalse(a['detail']['metrics']['target_met'])
  with self.r.connect() as con:self.assertEqual(con.execute('SELECT COUNT(*) FROM response_cache').fetchone()[0],0)
 def test_length_budget_is_partial_not_success(self):
  with patch.object(self.r,'model',return_value=('Unfinished',{'usage':{'done_reason':'length'}})):
   a=self.request()
  self.assertEqual(a['state'],'partial');self.assertIn('Unfinished',a['reply'])
 def test_soft_target_does_not_truncate_any_mode(self):
  def complete(*args):time.sleep(.35);return 'A completed answer after the target.',{}
  with patch('research.service.policy',return_value={**policy('medium'),'seconds':.01}),patch.object(self.r,'model',side_effect=complete):
   for mode in ['chat','work','beast']:
    a=self.request(mode=mode,fresh_research=True)
    self.assertEqual(a['state'],'succeeded',a['reply']);self.assertFalse(a['detail']['metrics']['target_met'])
    self.assertIsNone(a['detail']['response_budget']['message_quota'])
 def test_truncated_model_output_continues_with_context_and_can_finish(self):
  with patch.object(self.r,'model',side_effect=[('First half. ',{'usage':{'done_reason':'length'}}),('Second half.',{'usage':{'done_reason':'stop'}})]) as model:
   a=self.request()
  self.assertEqual(a['state'],'succeeded');self.assertEqual(a['reply'],'First half. Second half.')
  self.assertEqual(model.call_args.kwargs['prefix'],'First half. ')
  self.assertEqual(model.call_args.args[2][-2],{'role':'assistant','content':'First half. '})
 def test_cancel_is_not_treated_as_a_target_timeout(self):
  def cancel(uid,jid,messages,selection,options,stop,permission):stop.set();self.r.check(stop)
  with patch.object(self.r,'model',side_effect=cancel):a=self.request()
  self.assertEqual(a['state'],'cancelled');self.assertNotIn('budget',a['reply'].lower())
 def test_failed_first_research_round_recovers_and_retains_evidence(self):
  source={'title':'Guide','url':'https://example.org/recovery','source':'https://example.org/recovery','text':'Verified fixture instructions '*20,'access':'read','retrieved':'2026-11-06T00:00:00Z'}
  results=[{'results':[],'error':'First engine failed'}, {'results':[{'url':source['url'],'title':'Guide','snippet':'Instructions'}],'engine':'google'}]
  with patch.object(self.r.web,'search',side_effect=results),patch.object(self.r.web,'read',return_value=source),patch.object(self.r,'model',return_value=('Recovered answer [S1].',{})):
   a=self.request(prompt='How to configure a fixture?',search_mode='on')
  self.assertEqual(a['state'],'succeeded',a['reply']);self.assertTrue(a['detail']['metrics']['research_recovery_attempted'])
  self.assertEqual(a['detail']['recovery_searches'][0]['engine'],'google');self.assertEqual(a['detail']['sources'][0]['access'],'read')
 def test_private_context_never_enters_recovery_search(self):
  f=self.r.upload(1,b'Private approved instructions.','private.txt')
  with patch.object(self.r.web,'search') as search,patch.object(self.r,'model',return_value=('Private answer [D1].',{})):
   a=self.request(prompt='How to configure my private instructions?',file_id=f['id'],search_mode='on')
  search.assert_not_called();self.assertEqual(a['state'],'succeeded')
 def test_page_reads_are_parallel_and_keep_dates(self):
  active=0;peak=0;guard=threading.Lock()
  def read(url,*args):
   nonlocal active,peak
   with guard:active+=1;peak=max(peak,active)
   time.sleep(.12)
   with guard:active-=1
   return {'title':'Fixture','source':url,'url':url,'text':'Triangle evidence '*20,'access':'read','retrieved':'2026-01-01T00:00:00Z'}
  with patch.object(self.r.web,'read',side_effect=read),patch.object(self.r,'model',return_value=('Supported [S1].',{})):
   a=self.request(prompt='Compare https://example.org/one https://example.org/two https://example.org/three',search_mode='auto')
  self.assertEqual(a['state'],'succeeded',a['reply']);self.assertGreaterEqual(peak,2);self.assertTrue(all(s['retrieved']=='2026-01-01T00:00:00Z' for s in a['detail']['sources']))
 def test_page_cache_respects_owner_refresh_and_response_headers(self):
  web=Web();url='https://example.org/guide'
  response={'url':url,'status':200,'mime':'text/html','body':b'<html><title>Fixture</title><p>'+b'Triangle source text. '*12+b'</p></html>','seconds':.1,'redirects':[],'headers':{}}
  stop=lambda uid,cache=True:PhaseStop(threading.Event(),time.monotonic()+10,cache,uid)
  with patch('research.web.fetch',return_value=response) as fetch:
   a=web.read(url,'triangle',stop(1));b=web.read(url,'triangle',stop(1));self.assertEqual(fetch.call_count,1);self.assertTrue(b['cached']);self.assertEqual(a['retrieved'],b['retrieved'])
   web.read(url,'triangle',stop(2));web.read(url,'triangle',stop(1,False));self.assertEqual(fetch.call_count,3)
   web.clear(1);web.read(url,'triangle',stop(1));self.assertEqual(fetch.call_count,4)
  for extra in [{'headers':{'cache-control':'no-store'}},{'headers':{'cache-control':'private'}},{'sets_cookie':True},{'headers':{'cache-control':'max-age=0'}}]:
   web=Web()
   with patch('research.web.fetch',return_value={**response,**extra}) as fetch:
    web.read(url,'triangle',stop(1));web.read(url,'triangle',stop(1));self.assertEqual(fetch.call_count,2)
 def test_explicit_sources_do_not_trigger_unrequested_web_expansion(self):
  p=plan('Read https://docs.python.org/3/library/ast.html and explain ast.unparse with sources.','high','chat')
  self.assertFalse(p['search']);self.assertFalse(p['follow_links'])
  self.assertTrue(plan('Search additional sources for https://example.org','high','chat')['search'])
  text='Generic attributes and AST introduction.\n'*12+'ast.unparse returns generated code from an abstract syntax tree.'
  self.assertIn('ast.unparse returns',relevance(text,'Read https://docs.python.org and explain ast.unparse',300))
 def test_existing_reader_excerpt_is_not_lost_to_stored_page_truncation(self):
  source={'title':'Long source','url':'https://example.org/long','source':'https://example.org/long','text':'A long page introduction '*40,'excerpt':'Specific answer found after the stored page limit.','access':'read','retrieved':'2026-11-06T00:00:00+00:00'}
  with patch.object(self.r.web,'read',return_value=source),patch.object(self.r,'model',return_value=('The answer [S1].',{})) as m:
   self.request(prompt='Read https://example.org/long')
  self.assertIn('Specific answer found',m.call_args.args[2][-1]['content'])
 def test_dotted_identifiers_survive_html_inline_spacing(self):
  text='General introduction.\n'*30+'ast. unparse (node) returns Python source code from the tree.'
  self.assertTrue(relevance(text,'Explain ast.unparse',160).startswith('ast.unparse'))
 def test_model_time_does_not_expire_completed_retrieval_cache(self):
  def model(*args):time.sleep(.15);return 'A completed answer.',{}
  with patch('research.service.policy',return_value={**policy('medium'),'research_seconds':.05}),patch.object(self.r,'model',side_effect=model) as m:
   self.request();b=self.request();self.assertEqual(m.call_count,1);self.assertTrue(b['detail']['cache']['hit'])
 def test_no_store_sources_never_enter_answer_cache(self):
  source={'title':'No-store source','url':'https://example.org/guide','source':'https://example.org/guide','text':'Source details '*20,'access':'read','retrieved':'2026-11-06T00:00:00+00:00','cache_ttl_seconds':0}
  with patch.object(self.r.web,'read',return_value=source),patch.object(self.r,'model',return_value=('A claim [S1].',{})) as model:
   self.request(prompt='Read https://example.org/guide');self.request(prompt='Read https://example.org/guide');self.assertEqual(model.call_count,2)
  with self.r.connect() as con:self.assertEqual(con.execute('SELECT count(*) FROM response_cache').fetchone()[0],0)
 def test_deployment_target_rejects_wrong_identity_and_origin(self):
  t=target();identity={'verified':True,'account_id':t['aws_account_id'],'region':t['aws_region'],'instance_id':t['aws_instance_id']}
  self.assertEqual(validate(identity,t['public_origin'])['hosting_provider'],'aws')
  for wrong in [{'account_id':'wrong'},{'region':'us-east-1'},{'instance_id':'wrong'},{'verified':False}]:
   with self.assertRaises(PermissionError):validate({**identity,**wrong},t['public_origin'])
  with self.assertRaises(PermissionError):validate(identity,'https://other.example')
  self.assertFalse(t['automatic_paid_resources'])
  with patch.dict('os.environ',{'SYNERGY_DEPLOYMENT_HOST':'aws'}):
   with self.assertRaises(ValueError):require_publication_provider('hostinger')
   require_publication_provider('aws')
if __name__=='__main__':unittest.main()
