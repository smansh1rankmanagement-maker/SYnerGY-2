# SYnerGY 1.5.2 — Chat tools verification

Verified on 4 November 2026 on the connected Intel Mac (16 GB RAM). Live local app: http://127.0.0.1:8090/ . Model profile remains Aerny v1.5.

## What is delivered

The owner can send **Install Desktop Commander and Firecrawl** in SYnerGY Chat mode. SYnerGY downloads the pinned Desktop Commander runtime, discovers the real MCP tools, tests Firecrawl page access and saves connector state for that account. Installation progress, Stop, errors and retry are part of the existing Chat task system. The Plugins page shows versions, availability and enable/disable controls. No prices, subscriptions or credits were added.

Desktop Commander is working. Firecrawl's connector is installed, but its hosted service rejected anonymous search and scrape requests. That is a failed Firecrawl functional test, despite a successful MCP handshake. The UI explicitly reports the restriction and attributes fallback research to SYnerGY's built-in public web tools. No API key or paid service was connected.

## Actual components

| Component | Installed / observed version | Result |
| --- | --- | --- |
| Desktop Commander | `@wonderwhy-er/desktop-commander@0.3.1`, MIT | Real local MCP process; read/list/file-info tools discovered; file read passed |
| Node / npm | 24.21.0 / 11.19.0 | Locked local npm install with lifecycle scripts disabled; no global package installation |
| Firecrawl | Official hosted MCP, server 3.36.1 | Handshake passed; keyless search and scrape refused; clearly labelled fallback active |
| Public search | DDGS 9.16.1, primp 1.3.1, click 8.5.0, lxml 6.1.3 | Separate dependency directory; available engines checked; Yahoo returned relevant results |
| Browser inspection | Existing local Playwright/Chromium worker | Public page loaded, screenshot and console/network evidence produced |
| Answer model | Existing local Ollama Aerny v1.5 Balanced profile | Actual inference used for research; no new model training |

The downloaded Desktop Commander package and lock identity were verified. The evidence JSON includes its npm integrity value and the SHA-256 hashes of downloaded search wheels. Upstream npm dependencies emitted deprecation notices; this release does not claim a complete third-party vulnerability audit.

## Real acceptance evidence

All commands below were submitted through SYnerGY's own Chat UI. Direct backend diagnostics were supplementary and were not used to fake installed state.

| Test | Observed result | Time / task |
| --- | --- | --- |
| Install Desktop Commander and Firecrawl | Desktop Commander installed and connected. Firecrawl connector saved with free-access failure clearly shown. | 21.8 s · `ccab9ebd16ab44e390aba77a79e1e681` |
| Desktop Commander read README.md | Read the actual 10-line file inside owner account 2's tool workspace. | 2.6 s · `195afaf71312447f99ef2e0220a314d4` |
| Inspect example.com | HTTP 200; real isolated-browser screenshot; no captured uncaught JavaScript or failed-network event. | 10.9 s · `1f3c9731fc7b4e12bad3a9fdaa4ac4cb` |
| Search current job openings in Noida | Relevant results retrieved; LinkedIn page read; Naukri/Indeed explicitly marked unread. One valid source ID. Individual vacancies were not verified. | 103.7 s · `55ce34aa7e744c7fb167ce74d3dc5e9d` |
| Read Playwright isolation documentation | Concise two-sentence answer with a valid S1 citation. Three official documentation pages read. | 50.1 s · `4c847c6484f843e0b938cd4b7ca0163f` |
| Restart and reopen | Installed connector records and existing owner session survived service restarts; saved conversations reopened. | Live UI and stored-state checks |
| Code identity | All 92 compared deployed code, test, script and dependency files matched the supplied source hashes. | Evidence JSON |

The Noida response remained verbose and overgeneralized what the limited accessible evidence could establish. It is recorded as a retrieval/citation test, **not** proof of a satisfactory job-research answer. Those diagnostic conversations were archived, not deleted. The final technical-documentation answer was inspected and accurately described browser-context isolation.

The reader followed two related documentation links even though the test prompt requested only one page. The answer cited the requested page, but strict single-page retrieval is not enforced in this release. This is recorded as a remaining workflow limitation.

## Automated verification

**70 tests passed**, plus Python compilation and JavaScript syntax checks. The suite covers owner authorization, per-account state, official install intent, unknown repository rejection, directory traversal and symlink escape, private-context search blocking, MCP response decoding, unavailable-provider handling, explicit fallback, real child-process cancellation, search relevance/query retries, disabled-engine detection, and the existing auth, conversations, media and studio flows.

These are implementation checks. Citation-ID validation and passing tests do not prove every generated claim correct, nor do they prove subjective answer quality.

## Preserved data and recovery

All pre-upgrade rows in the checked tables were unchanged: **2 users, 6 conversations, 22 messages, 1 studio project, 2 studio jobs, 5 assets and 1 brand kit**. New test conversations and connector records were additive.

- Previous 1.5.1 source remains at `/Users/a1989/Library/Application Support/SYnerGY/v1.5.1`.
- Original-release backup: `/Users/a1989/Library/Application Support/SYnerGY/backups/chat-tools-v152-20261104-143130`.
- Final dependency-switch backup: `/Users/a1989/Library/Application Support/SYnerGY/backups/chat-tools-v152-20261104-150638`.
- Each deployment backup contains source, a consistent SQLite copy and the previous LaunchAgent.
- The first macOS reload attempt was delayed; the previous service was restored and the deployer now retries the asynchronous bootstrap safely. Final deployment completed successfully.

See **PLUGINS_SETUP.md** for deployment and rollback. Old research dependencies remain intact; the new search dependencies occupy `runtime/research-search-v152`.

## Limits to keep explicit

- Desktop Commander is scoped to this account's dedicated file workspace. Arbitrary terminal execution, unrestricted computer access and private Chrome sessions are not exposed.
- Firecrawl itself is not operational without provider access on this connection. Self-hosted Firecrawl was not installed; Docker and its supporting service stack are absent.
- Public search depends on upstream availability. Login walls, verification challenges and HTTP 403 pages are not bypassed. Search snippets are not treated as read pages.
- This is a local Mac application, not a publicly deployed multi-user service. CPU model responses can take tens of seconds or longer.
- There is no autonomous weight learning, ChatGPT-weight transfer or new fine-tuning. This release improves tool execution and routing.
- The prior image/video implementation is preserved; this update does not claim a new image/video model or quality upgrade.

Official component references: https://github.com/wonderwhy-er/DesktopCommanderMCP ; https://github.com/firecrawl/firecrawl-mcp-server ; https://docs.firecrawl.dev/contributing/self-host ; https://github.com/deedy5/ddgs .
