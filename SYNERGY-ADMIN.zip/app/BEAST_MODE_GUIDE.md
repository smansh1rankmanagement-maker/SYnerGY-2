# SYnerGY Beast · application 1.7.0

Beast is now a persistent coding and interface-design workspace inside SYnerGY. The model remains **Aerny v1.5**. This release changes the application and development workflow; it does not train new model weights.

Open **http://127.0.0.1:8090/** on the configured Mac, sign in and select **Beast mode** or **Beast workspace**. The address is local to that Mac, not a public hosted website.

Open the verified saved example directly at **http://127.0.0.1:8090/?beast=6cc46c05b64f46ff8fd4d5af291bc32a** using its owning account. It contains the reviewed revision-2 website source.

## Use the workspace

1. Create a project from a responsive website starter, a Python starter, or an empty README. Alternatively import source files or a ZIP. Supplied starters are labelled templates, not model-generated results.
2. Use **Code** to browse files, edit highlighted source, find/replace text and save. Save state is explicit. Add, rename and delete files; use History to recover earlier versions.
3. In **Sources**, select the files Aerny should read. Context is bounded; oversized source is rejected, never silently truncated. Optionally attach completed research from the same conversation, choose a skill, or supply a reference image.
4. Keep **Develop project** checked to send the chat brief to the development queue. Choose **Propose changes** or **Explain code**, and use the existing provider, model and response-level controls. Uncheck it to use normal research/chat while keeping the project open.
5. Review **Changes**, the actual file diff and **Checks**. Proposed files are not applied automatically. **Apply reviewed changes** creates a new revision. A stale proposal cannot overwrite a newer edit.
6. **Preview** renders saved HTML, CSS and local raster assets. Choose an HTML entry, desktop fit, 768-pixel tablet or 390-pixel mobile preview. This is a design preview: scripts, forms, embedded applications and external network resources are disabled.
7. Save a named checkpoint through **•••**, restore revisions, export a patch or download a complete source ZIP. Export includes a separate `SYNERGY_VALIDATION.json` with the revision and actual check status.

The Chat, Work, Brand Operations, research, browser-inspection, image/video, Plugins and Skills features remain available. Beast uses the same authenticated account. Brand Operations retains its separate brand membership rules and worker. The UI/UX design skill is available alongside existing skills.

## Feature status

| Capability | Status in this release | Evidence or boundary |
|---|---|---|
| Private saved projects and revisions | Implemented and tested | Account isolation, reload, optimistic revision conflicts |
| Explorer, editor, line numbers, highlighting, search/replace | Implemented | Browser-tested saving and restoration; highlighting is lightweight, not a language server |
| File and ZIP import | Implemented and tested | UTF-8 source and PNG/JPEG/GIF/WebP assets; traversal, symlinks, collisions and extraction limits rejected |
| Named checkpoints and rollback | Implemented and tested | Restoring creates a new revision; original history remains |
| ZIP and patch export | Implemented and tested at authenticated HTTP boundary | ZIP contents and revision report checked; browser download helper stalled, so native file-save completion is not claimed |
| Static design preview | Implemented and browser-tested | Saved HTML/CSS and local raster assets; scripts, forms and network blocked |
| Structured model changes | Implemented and tested with real local inference | Whole-file, exact-anchor replacement and append operations; canonical diff before apply |
| Multi-file changes | Implemented and tested | Real Python + README change, preserved function and entry point, reviewed and saved |
| Selected-region editing | Implemented and tested | Outside-region characters preserved by deterministic assembly |
| Regression guard | Implemented and tested | Rejects unrequested loss of top-level Python definitions and certain explicitly protected changes; not a general semantic verifier |
| Durable task queue | Implemented and tested | One worker, persistent states/logs, reload recovery, duplicate-request prevention |
| Cancellation and restart | Implemented and tested with real processes | Model client terminated on cancellation/parent death; interrupted job retried once; source not auto-applied |
| Error recovery | Implemented and tested | Invalid model connection, schema, source scope and preservation failures show actionable errors |
| Python, JavaScript and JSON syntax checks | Implemented and tested | Python AST parser, Node `--check`, JSON parser; no application execution |
| HTML checks | Implemented and tested | Metadata, local references and image alt attributes; not a full HTML/accessibility validator |
| CSS validation | Visual preview only | No full CSS parser; marked unsupported in Checks |
| Language assistance | 47 named language/file categories | Generation, explanation and editing depend on the connected model; not a claim of expertise or correctness in every language |
| UI/UX assistance | Implemented | Design skill and coding instructions cover hierarchy, responsiveness, keyboard access, states and reduced motion; requires visual/human review |
| Reference-image guidance | Implemented; actual image-understanding request passed | Installed Aerny Vision correctly described the supplied SYNERGY wordmark; no promise of pixel-perfect screenshot reconstruction |
| Research and selected skills | Existing tools retained; bounded attachment supported | Sources can be selected from completed account-owned research, up to three excerpts; no autonomous unrestricted browsing |
| React/Next/Vue/Svelte/Angular and backend frameworks | Source assistance only | Dependencies and application runtimes are not installed or executed automatically |
| General code execution, builds and test suites | Unavailable | No configured isolated execution service; host-shell execution is not substituted |
| Deployment from Beast | Export/setup guidance only | No public publishing, production database changes, domain changes or paid services |

## Languages and UI/UX

The Languages dialog separates model assistance, syntax checking, preview, build, tests and deployment. It lists HTML, CSS, JavaScript, TypeScript, Python, PHP, SQL, Java, C, C++, C#, Go, Rust, Ruby, Swift, Kotlin, Dart, Bash, PowerShell, R, JSON, Vue, Svelte, Lua, Scala, Elixir, Erlang, Haskell, Clojure, Perl, Julia, F#, Objective-C, Solidity, Zig, Fortran, COBOL, Assembly, OCaml, Lisp, Groovy, Terraform, D, Pascal, Visual Basic, Verilog and VHDL. Many additional source extensions are accepted for editing. Unsupported syntax checks are labelled unavailable; an installed host executable does not mean safe application execution is available.

Examples:

- “Build a responsive landing page with an accessible enquiry flow.”
- “Explain these files before suggesting changes.”
- “Fix the error in app.js and preserve the existing copy.”
- “Add a typed function to this Python module and document it.”
- “Use this screenshot as a composition reference; identify what you cannot infer.”

For larger work, choose a small set of relevant files and work in reviewed steps. The 4B local model can make meaningful mistakes. In acceptance testing it initially removed an existing Python function. The change was never applied; a preservation check and targeted-edit operations were added, and a later proposal preserved the source correctly. A passing parser check is not proof of correct behaviour, accessibility or security.

## Actual components and machine

| Component | Actual implementation |
|---|---|
| Web application | Existing Python HTTP backend with authenticated cookie sessions and origin checks; app 1.7.0 |
| Project storage | SQLite `beast_*` tables in the existing account database; compressed immutable source snapshots |
| Development worker | Separate `in.1rank.synergy-beast` macOS LaunchAgent; trusted Python model/check clients |
| Existing Work worker | `in.1rank.synergy-operations`, retained |
| Coding model | `aerny:v1.5`, Qwen3 4B Instruct 2507 Q4_K_M through Ollama on localhost:11434 |
| Other model choices | Existing `aerny-fast:v1.5` and `qwen3-vl:2b-instruct` |
| Host | Intel MacBook Pro, 16 GB RAM; CPU inference; no production GPU supplied by ChatGPT |
| Application Python | Managed CPython 3.12.15 |
| JavaScript syntax | Node 24.21.0, parse-only `--check` with 64 MB V8 heap and a five-second limit |
| Frontend | Existing HTML/CSS/JavaScript; lightweight escaped-token highlighting, native textarea, sandboxed design iframe |
| Preview security | Sanitized allow-listed markup and inline/local CSS; empty iframe sandbox and response CSP; no script execution, external resources, parent APIs or form submissions |
| Image validation | Existing Pillow dependency |
| New paid service / package installation | None |

OpenAI is not connected on this machine. Provider routing is reused. An external provider needs existing server configuration and explicit account privacy opt-in. Hybrid stays local while external use is unavailable or disabled. Keys are not placed in source files, model context, project previews or exports.

The existing Qwen model notices declare Apache-2.0 upstream terms. Python, SQLite, Node, Pillow, fonts and other existing dependencies retain their bundled/upstream notices. Model weights are not redistributed in the source ZIP. See `backend/THIRD_PARTY_NOTICES/` for existing component notices.

## Limits and security boundaries

- 50 projects/account, 100 files/project, 4 MB decoded project contents.
- Text files up to 256 KB; raster assets up to 1 MB and 16 million pixels; ZIP input up to 8 MB with 200 archive entries maximum.
- 250 revisions/project, 100 named checkpoints, 512 MB compressed history/account.
- Model context: up to 12 selected text files and 22,000 characters across code, prompt, selected skill and research excerpts. No silent source truncation. Up to eight changed files per proposal.
- Queue concurrency: one development task. At most eight queued/running tasks. One active/reviewable task per project. An interrupted task has at most two attempts; manual retry creates a new task.
- Model-client deadline: seven minutes. Checks have individual five-second process limits and a 30-second overall budget, plus the current check. They do not execute submitted code.
- Python preservation checks are conservative. They cannot prove behaviour preservation for arbitrary Python, JavaScript or other languages.
- The credential detector rejects known private-key/token patterns and suspicious literal assignments. It is a safeguard, **not comprehensive secret detection**. Review source before importing or exporting it.
- The local app is loopback-only. The Mac must be awake and the user session active. This is not an always-on multi-tenant cloud deployment.
- Existing image/video quality and CPU limits remain. This release does not enhance their model weights.

## Setup and operation

Existing installation paths:

```text
Source: /Users/a1989/Library/Application Support/SYnerGY/v1.7.0
Prior source: /Users/a1989/Library/Application Support/SYnerGY/v1.6.0
Data: /Users/a1989/Library/Application Support/SYnerGY/v1.4-data
Database: accounts.sqlite3
```

On a fresh compatible setup, install the existing application requirements and configure local Ollama as described in the earlier setup guides. Beast adds no new package dependency. Start the app and Beast worker as separate processes, using the same data directory:

```sh
export SYNERGY_DATA_DIR="$HOME/.synergy-next"
python3 backend/server.py
# In a separate process:
python3 backend/beast/worker.py --data "$SYNERGY_DATA_DIR"
```

Keep the existing Brand Operations worker running separately if that feature is configured. The project export is not a deployment of its contents.

For the configured Mac, the upgrade script is:

```sh
python3 scripts/deploy-beast-macos.py --source "/Users/a1989/Library/Application Support/SYnerGY/v1.7.0"
```

It requires the existing app and Work LaunchAgents, checks for active jobs, makes a consistent SQLite backup, copies the prior source and LaunchAgent files, adds the Beast worker, restarts the existing app/Work worker against the new source, and verifies app/worker health and preservation of existing record counts. Failure restores the original LaunchAgent configuration. It does not overwrite the production database with staging data.

Check services:

```sh
launchctl print "gui/$(id -u)/in.1rank.synergy-v14"
launchctl print "gui/$(id -u)/in.1rank.synergy-operations"
launchctl print "gui/$(id -u)/in.1rank.synergy-beast"
```

App logs use the existing configured destinations. Beast worker logs are in `~/Library/Application Support/SYnerGY/beast-worker.log` and `beast-worker-error.log`; generated source is not written into those logs.

## Backup and recovery

`DEPLOYMENT_BEAST.json` records the actual upgrade backup directory and prior source. Keep the existing data directory, source packages and model manifests backed up. Make database backups using SQLite's backup API, not a live raw file copy.

To recover a failed development task, restart the Beast LaunchAgent. A running task is retried once; repeated interruption becomes an explicit failure. Awaiting-review proposals and saved revisions survive restart. Cancelled jobs never apply changes.

To roll back application code, stop the app and both workers, restore their prior LaunchAgent files from the recorded backup, remove/disable the newly added Beast LaunchAgent, and bootstrap the original app and Work agents. The old source remains intact. New `beast_*` tables can remain unused in the database; do not restore an old database merely to roll back code, because that would discard newer account activity. A full data restore requires a stopped service and an explicitly selected consistent backup.

The example project and test evidence are independent of production account credentials. Source packages contain no account database, sessions, tokens, model weights or private runtime configuration.

## Next stage

Framework builds, dependency installation, application test execution and backend/API previews require a real isolated execution service with filesystem, network, process, memory, CPU and time boundaries. Docker is not installed on the observed Mac. This release intentionally does not turn model text into host-shell commands. After an isolation service is configured, add a small framework allow-list, real builds/tests and browser validation before advertising that capability.

Relevant platform references: [HTML iframe sandbox standard](https://html.spec.whatwg.org/multipage/iframe-embed-object.html), [CSP sandbox](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Security-Policy/sandbox). The implemented policy is more restrictive than a script-enabled iframe.
