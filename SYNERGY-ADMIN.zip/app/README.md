> Current release: SYnerGY 1.8.1. Plain chat now dispatches image, short-video, poster/social design and PDF/Word/A4 PNG requests to real local tools. Preview, download and follow-up exports are integrated. Start with `../docs/CREATION-UPDATE.md`, or `../START-HERE.md` for a new domain server. The historical app documentation below describes inherited capabilities; see `../docs/FEATURE-STATUS.md` for current limits.

# SYnerGY AI · Beast workspace 1.7.0 · Aerny v1.5

A free local creation workspace with accounts, saved conversations, Chat / Work / Beast modes, skills, image editing and short video generation. The supplied SYnerGY logo is retained. There are no prices, subscriptions or credit balances.

## New in Beast workspace 1.7.0

Beast adds private code projects, a file explorer and highlighted editor, model-driven proposals, exact source replacements, review/apply, checkpoints, patch/ZIP exports and an isolated HTML/CSS design preview. It reuses the existing chat, research, skills, account and model controls. A separate durable worker produces source proposals without depending on an open browser tab.

Read **BEAST_MODE_GUIDE.md** for capability status, language/UI/UX support, limits, setup and recovery. **BEAST_MODE_VERIFICATION.md** records actual tests. The original brief is preserved in `specifications/BEAST_MODE_USER_PROMPT.md`. This is application tooling, not new model training. General code execution, framework builds and deployment are unavailable until an isolated execution service is configured.

## New in Work mode 1.6.0

Open **Brand Operations** to manage isolated client workspaces, teams, knowledge, tasks, leads, approvals, saved files and run history. Create the first brand-review automation through a form or in Work chat: `Create a weekly automation for InteriFY Monday at 09:00`. Review its definition before activating it.

A separate local scheduler and worker run the bounded workflow without an open browser. It checks inputs, audits an authorised website, creates tasks, drafts seven organic posts with local Aerny, and exports a real XLSX, PDF, editable Markdown report and evidence. Missing permissions or inputs remain visible; independent steps continue. No external publishing, outreach, advertising or paid infrastructure is enabled.

Read **WORK_MODE_GUIDE.md** for feature status, use, setup, backup and recovery. **WORK_MODE_VERIFICATION.md** records real runs and limitations. The full requested specification is preserved in `specifications/BRAND_OPERATIONS_USER_PROMPT.md`.

## New in chat tools 1.5.2

Send **Install Desktop Commander and Firecrawl** from Chat mode. The configured owner can install these two reviewed runtime connectors with actual progress, cancellation and connection checks. The Plugins page shows their status and lets each account disable its connectors.

Desktop Commander 0.3.1 runs locally and reads, lists and searches this account's private tool workspace. Firecrawl's official keyless MCP endpoint is configured for public search and page reading. In the real November 4 test it refused anonymous access; SYnerGY reports that limitation and uses its existing free public web tools. It does not label those fallback results as Firecrawl results or connect a paid key.

See **PLUGINS_SETUP.md** for commands, scope, deployment and rollback. **PLUGINS_VERIFICATION.md** records the observed results. This update adds application tools and routing, not model training.

## New in research 1.5.1

- Streamed local research chat with web search, real page reads, citations and a right-side Sources / Activity preview.
- Private document uploads, page/line references, source search, original downloads and saved reports.
- Stop, retry, edit in a preserved conversation branch, history search and language/privacy settings.
- Public-website inspection in an isolated browser: screenshots, DOM, console/network errors and explicit button testing.
- Auto uses Balanced for substantive requests; a bounded local calculator handles simple arithmetic.

Start with **RESEARCH_SETUP.md** for the installed runtime, actual models, limits and rollback. **RESEARCH_VERIFICATION.md** records passed checks and remaining quality limitations. This release changes the application and tools; the existing Aerny v1.5 model profiles remain.

## Existing creation features

- SYnerGY / OpenAI / Hybrid provider selection and capability-based Auto / Fast / Balanced / Vision models.
- Actual elapsed working time and the model used on completed replies. Auto selects the existing small local model for greetings and the stronger profile for substantive requests.
- Image studio: text-to-image, reference-to-image, brush-mask selective edits, custom dimensions, exact text/logo layers, a poster-header layout, private saved projects and PNG/SVG/JSON downloads.
- Persistent single-worker image queue, real inference steps, cancellation, retries and restart recovery. Image workloads release inactive chat weights; chat reports local-compute contention instead of overloading the 16 GB Mac.
- Conversational follow-up edits: reopen a design, then ask `Change headline to "Office launch"` or `Resize to 1080 × 1350`. Selection requests without a mask open the editor.
- Approved brand kits can be retrieved by name. Saving a logo as a reference does not mark it approved; the owner controls that checkbox.

Aerny v1.5 is the application/profile version. Existing Qwen chat weights, epiCRealism and an existing LCM acceleration adapter power it. No foundation-model training or new LoRA training was performed. ChatGPT weights, training data and persistent GPU capacity are not used.

## Use

Open `http://127.0.0.1:8090/` on the configured Mac. Sign in, choose Chat mode and start a brief. Image studio is also available from the left panel. Home with recents, Plugins and Skills remain available. The composer retains +, model capability and Instant / Medium / High / Max / Ultra.

For an exact poster: upload the original artwork, choose **Exact layout**, add original logo/text layers and choose dimensions. For a localized change: upload the reference, paint the target area and choose **Selective edit**. Run the job, review the right-side preview and download. Reopen from **Saved projects**. Each completed job retains its settings and output.

For new visual content, use Text to image or Reference to image. Fast uses LCM-LoRA; Enhanced and Detail use DPM++ Karras. The CPU model has a modest native render budget; 4K means an enlarged export. Regenerated subjects, anatomy, materials and layout need visual review. Selective editing retains zero-mask pixels before overlays and blends inside the editable boundary.

SVG exports embed raster images and font data with editable text/image layers; they are not all-vector reconstructions. SVG rendering can vary between editors. PNG is the exact rendered output. Two DejaVu font choices are bundled. Arbitrary font upload, editable vector drawing, background extraction, outpainting, ControlNet pose/depth, batch variations and custom subject training are later work.

## Providers

SYnerGY runs locally. OpenAI is disabled because no approved external configuration is present. Hybrid therefore selects local models only. The code includes an optional Responses API adapter, covered by mocked contract tests, but no live OpenAI request or paid connection was made. Enabling it later requires an explicit administrator decision and configuration described in BACKEND_SETUP.md. Images always run locally, regardless of chat provider.

## Existing tools

Short video generation remains the local AnimateDiff-Lightning / epiCRealism pipeline, with interpolated 24 fps and enlarged 1080p/4K export. It is not native 4K video and exact character preservation is not guaranteed. This release focuses on image creation/editing; it does not claim new video weights or a video-quality upgrade.

GitHub `Install this skill/plugin` commands import compatible SKILL.md workflows pinned to a commit. They do not execute arbitrary repository code or automatically configure credentialed connectors. Knowledge notes remain private reference retrieval, not autonomous training.

See BACKEND_SETUP.md for installation and rollback, VERIFICATION_V15.md for real test evidence and limitations, benchmarks/collection.json for fixed evaluation briefs, and backend/studio/models.lock.json for pinned model details. Private accounts, model weights and generated user assets are excluded from the source package.
