# Aerny v1.5 installation and rollback

## Observed target

macOS 26.6.2; Intel i7-1068NG7; 16 GB RAM; integrated Intel Iris Plus; approximately 335 GB free at inspection. Inference is CPU float32. There is no CUDA GPU and this Intel Mac is not an Apple Silicon MPS target. The website and Ollama are loopback services on the same machine; no public inference tunnel is opened.

The web process must use the managed Python 3.12 with `hashlib.scrypt`, plus Pillow 11.3.0 in an isolated web dependency directory. The existing media process uses Python 3.9 with torch 2.2.2, diffusers 0.30.3, transformers 4.44.2, Pillow, Accelerate and Safetensors. Keep their binary dependency directories separate: the Apple Python lacks scrypt and Python 3.12 Pillow cannot run under Python 3.9.

## Configuration

| Variable | Purpose |
|---|---|
| SYNERGY_DATA_DIR | Existing private application data; schema changes are additive |
| SYNERGY_PORT | 8090, loopback only |
| SYNERGY_OLLAMA_MODEL | aerny:v1.5 |
| SYNERGY_IMAGE_PYTHON | Absolute path to the existing media Python |
| PYTHONPATH | Web-only Pillow dependency directory |
| SYNERGY_STUDIO_WORKER_PATH | Media-only PEFT directory plus existing video dependency directories, separated with `:` on macOS |
| SYNERGY_LCM_ADAPTER | Verified local LCM-LoRA SDv1.5 directory |
| SYNERGY_INVITE_CODE | Optional registration code; unchanged from existing configuration |

The existing `$SYNERGY_DATA_DIR/image/model.json` must point to the complete local epiCRealism safetensors directory. Existing video environment variables remain configured as documented in BACKEND_SETUP_V14.md. The updated image, studio and video subprocess launchers use the separate media path.

Install Pillow 11.3.0 with the web Python into `runtime/v15-web-deps`. Install PEFT 0.12.0 with the media Python into `runtime/v15-deps`, retaining existing Torch/Diffusers/Transformers versions. The acceleration adapter is downloaded from the official Hugging Face repository at the exact revision in `backend/studio/models.lock.json`; verify its SHA-256 before creating `verified.json`. Do not load arbitrary pickled weights. The installed image safety checker is required.

Create the balanced profile with `ollama create aerny:v1.5 -f backend/AeRny.Modelfile`. Create Fast from `backend/AernyFast.Modelfile` when qwen3:0.6b is present. On the inspected Mac the equivalent existing aerny-craft:v1.3 parent was reused, without a new weight download. The vision profile is the already installed qwen3-vl:2b-instruct.

## Deployment and rollback

1. Keep the v1.4 source directory and previous source archive intact.
2. Before switching, back up the live SQLite database using SQLite's backup API and copy the current LaunchAgent plist. Confirm no generation is active.
3. Stage the new source in a separate v1.5 directory. Test using port 8091 and a separate data directory; use `localhost:8091` in the browser to avoid replacing the production `127.0.0.1` session cookie.
4. Stop the existing LaunchAgent. Keep its label and launcher compatibility; update ProgramArguments to the v1.5 server, keep the managed Python 3.12 executable, and set the variables above. Retain existing video settings and the live data path.
5. Bootstrap/kickstart the LaunchAgent and verify `/api/auth/config` returns version 1.5. Sign-in, prior conversations and media should remain available.
6. Roll back by stopping the agent and restoring the backed-up plist, then bootstrap again. The v1.4 source remains untouched and ignores the additive studio tables. Do not replace a live database with the backup if new user activity must be kept; consult the backup first.

This standard-library local server is not an internet-hardened public deployment. Keep it bound to loopback. A public deployment requires a deliberate authenticated inference gateway, HTTPS and production hosting design.

## OpenAI remains off

Only if the owner later authorizes an external service, configure `OPENAI_API_KEY`, an explicit `SYNERGY_OPENAI_MODEL`, and `SYNERGY_ALLOW_OPENAI=1` on the server. All three are required. Never put a key in browser JavaScript. Hybrid then routes complex text requests to that configured model and simpler ones locally. It does not ensemble both outputs or send every request to both. Current tests use fixtures; live OpenAI behavior remains unverified. Image inference never uses this adapter.

## Verification

Run `python -m unittest discover -s tests -v` using a Python with Pillow and scrypt. The isolated Mac integration script is `tests/acceptance_mac.py`; it uploads real references through the HTTP API, generates, selectively edits, composes exact branding/text, downloads and reopens a project. It creates a test-only account on port 8091. It must not target an unrelated production host.

The fixed benchmark collection is held out from future adaptation datasets. Record native size, seed, scheduler, runtime, actual files and visual-review findings. Automated dimension/pixel checks are not evidence of perfect visual quality. Keep the Mac awake for generation; closing the browser is safe, shutting down the Mac interrupts active work and leaves a retryable error.
