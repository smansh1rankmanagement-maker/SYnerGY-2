(() => {
'use strict';
const $=s=>document.querySelector(s);
let ctx,active=false,epoch=0,recorder,stream,ac,analyser,tick,limit,clock,controller,audioURL;
let chunks=[],awaiting=false,previousReply=null,state='off',started=0;
function setState(next,label,hint=''){
 state=next;$('#voice-bar').dataset.state=next;$('#voice-status').textContent=label;
 $('#voice-hint').textContent=hint;$('#voice-finish').disabled=next!=='listening';
 $('#voice-retry').hidden=!['review','error','speaking','paused'].includes(next);
 $('#voice-review').hidden=next!=='review';$('#voice-language').disabled=['transcribing','responding','preparing'].includes(next);
 clearInterval(clock);$('#voice-elapsed').textContent='';
 if(['transcribing','responding','preparing'].includes(next)){const start=Date.now();clock=setInterval(()=>$('#voice-elapsed').textContent=Math.floor((Date.now()-start)/1000)+'s',1000);}
}
function release(){
 clearInterval(tick);clearTimeout(limit);stream?.getTracks().forEach(t=>t.stop());stream=null;
 ac?.close().catch(()=>{});ac=null;analyser=null;
 $('#voice-meter').setAttribute('aria-valuenow','0');$('#voice-meter span').style.width='0%';
}
function silencePlayer(){const audio=$('#voice-audio');audio.onended=null;audio.onplaying=null;audio.onpause=null;audio.pause();audio.classList.add('hidden');audio.removeAttribute('src');if(audioURL)URL.revokeObjectURL(audioURL);audioURL=null;}
function stop(){
 active=false;epoch++;awaiting=false;controller?.abort();
 if(recorder?.state==='recording'){recorder.onstop=null;recorder.stop();}release();silencePlayer();
 setState('off','Voice is off');$('#voice-bar').classList.add('hidden');$('#voice-button').setAttribute('aria-pressed','false');$('#voice-button').setAttribute('aria-label','Start voice conversation');
}
function fail(message){release();setState('error','Voice needs attention',message+' Your typed chat remains available.');}
async function listen(){
 if(!active)return;const token=++epoch;controller?.abort();silencePlayer();awaiting=false;
 $('#voice-transcript').value='';setState('permission','Opening microphone','Allow microphone access for SYnerGY when your browser asks.');
 try{
  const incoming=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
  if(!active||token!==epoch){incoming.getTracks().forEach(t=>t.stop());return;}stream=incoming;
  ac=new AudioContext();await ac.resume();if(!active||token!==epoch){release();return;}
  analyser=ac.createAnalyser();analyser.fftSize=1024;ac.createMediaStreamSource(stream).connect(analyser);
  const mime=['audio/webm;codecs=opus','audio/webm','audio/mp4'].find(t=>MediaRecorder.isTypeSupported(t));
  recorder=new MediaRecorder(stream,mime?{mimeType:mime}:{});chunks=[];started=Date.now();let lastSpeech=started,speechFrames=0,noise=.003;
  recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
  recorder.onerror=()=>{if(token===epoch){recorder.onstop=null;release();fail('The browser stopped recording. Listen again to retry.');}};
  recorder.onstop=()=>{const blob=new Blob(chunks,{type:recorder.mimeType});release();if(active&&token===epoch)transcribe(blob,token);};
  recorder.start(250);setState('listening','Listening','Speak naturally. Pause for 2.4 seconds, or choose Transcribe now.');
  tick=setInterval(()=>{
   if(!analyser)return;const samples=new Float32Array(analyser.fftSize);analyser.getFloatTimeDomainData(samples);
   const rms=Math.sqrt(samples.reduce((a,n)=>a+n*n,0)/samples.length),level=Math.min(100,Math.round(rms*1200));
   $('#voice-meter').setAttribute('aria-valuenow',String(level));$('#voice-meter span').style.width=level+'%';$('#voice-elapsed').textContent=Math.floor((Date.now()-started)/1000)+' / 60s';
   const threshold=Math.max(.008,Math.min(.04,noise*2.5));
   if(rms>threshold){speechFrames++;lastSpeech=Date.now();}else noise=noise*.95+rms*.05;
   if(speechFrames>=3&&Date.now()-lastSpeech>2400&&Date.now()-started>3000)finish();
  },120);
  limit=setTimeout(finish,60000);
 }catch(e){if(token===epoch)fail(e.name==='NotAllowedError'?'Microphone permission was not granted. Allow it in your browser’s site settings, then choose Listen again.':'No working microphone was found. Check your input device, then choose Listen again.');}
}
function finish(){if(recorder?.state==='recording'){clearInterval(tick);clearTimeout(limit);setState('transcribing','Transcribing','Recognising your words on the SYnerGY server…');recorder.stop();}}
async function transcribe(blob,token){
 try{
  if(blob.size<500)throw Error('No clear speech was captured.');controller=new AbortController();const body=new FormData();
  body.append('file',blob,'voice.webm');body.append('language',$('#voice-language').value);
  const d=await ctx.api('/api/voice/transcribe',{method:'POST',body,signal:controller.signal});
  if(!active||token!==epoch)return;if(!d.text?.trim())throw Error(d.warning||'No clear speech was recognised.');
  $('#voice-transcript').value=d.text;setState('review','Transcript ready',d.warning||'Check names and wording, then send. You can edit any word.');
  if($('#voice-handsfree').checked&&!d.needs_review&&!ctx.state.chatBusy)await sendTranscript();
 }catch(e){if(token===epoch&&e.name!=='AbortError')fail(e.message);}
}
async function sendTranscript(){
 if(!active||state!=='review')return;const text=$('#voice-transcript').value.trim();if(!text)return;
 if(ctx.state.chatBusy)return setState('review','Transcript saved','The current answer is still running. Send this transcript when it finishes.');
 if($('#chat-input').value.trim())return setState('review','Transcript saved','Send or clear the typed draft first. Your transcript is kept here.');
 const token=epoch;try{previousReply=ctx.state.cid?(await ctx.api('/api/conversations/'+ctx.state.cid)).messages.at(-1)?.id:null;
  if(!active||token!==epoch)return;$('#chat-input').value=text;awaiting=true;setState('responding','Responding','Your transcript is now in chat. The answer will be read aloud.');$('#chat-form').requestSubmit();
 }catch(e){if(token===epoch)setState('review','Transcript saved',e.message);}
}
async function replyReady(cid){
 if(!active||!awaiting||!cid)return;awaiting=false;const token=epoch;
 try{
  const saved=await ctx.api('/api/conversations/'+cid);if(!active||token!==epoch)return;const last=saved.messages.at(-1);
  if(last?.role!=='assistant'||last.id===previousReply)throw Error('No new spoken reply is ready. Check the saved chat.');
  setState('preparing','Preparing speech','The answer is ready in chat; Jarvis is preparing the audio.');controller=new AbortController();
  const r=await fetch('/api/voice/speak',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({conversation_id:cid,message_id:last.id}),signal:controller.signal});
  if(!r.ok){let d={};try{d=await r.json();}catch{}throw Error(d.detail||'The reply could not be read aloud.');}
  const blob=await r.blob();if(!active||token!==epoch)return;silencePlayer();audioURL=URL.createObjectURL(blob);const audio=$('#voice-audio');audio.src=audioURL;audio.classList.remove('hidden');
  audio.onplaying=()=>setState('speaking','Speaking','Jarvis is reading the reply. Listen again to interrupt, or End voice to stop.');
  audio.onpause=()=>{if(active&&token===epoch&&!audio.ended)setState('paused','Speech paused','Press Play to continue, or Listen again.');};
  audio.onended=()=>{if(active&&token===epoch)listen();};
  try{await audio.play();}catch{setState('paused','Reply ready to play','Your browser paused autoplay. Press Play to hear Jarvis.');}
 }catch(e){if(token===epoch&&e.name!=='AbortError')fail(e.message);}
}
window.SynergyVoice={stop,replyReady,init(c){ctx=c;
 $('#voice-button').onclick=async()=>{
  if(active)return stop();if(ctx.state.chatBusy)return ctx.toast('Finish the current reply first.');
  if($('#chat-input').value.trim())return ctx.toast('Send or clear your draft before starting voice.');
  if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)return ctx.toast('Voice needs an HTTPS browser with microphone recording support.');
  try{const d=await ctx.api('/api/voice/status');if(!d.ready)throw Error(d.detail||'Voice is starting. Try again shortly.');
   active=true;$('#voice-button').setAttribute('aria-pressed','true');$('#voice-button').setAttribute('aria-label','End voice conversation');$('#voice-bar').classList.remove('hidden');$('#voice-profile').textContent=d.profile?.name||'SYnerGY Jarvis';await listen();
  }catch(e){ctx.toast(e.message);}
 };
 $('#voice-finish').onclick=finish;$('#voice-retry').onclick=listen;$('#voice-stop').onclick=stop;$('#voice-send').onclick=sendTranscript;
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&active)stop();});window.addEventListener('pagehide',stop);
}};
})();
