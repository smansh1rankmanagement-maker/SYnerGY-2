/* Account-scoped settings. The server remains authoritative for access. */
(() => {
  'use strict';
  const $ = s => document.querySelector(s), EXTENSION = 'fcaldehcmldbepekmdafhglcibnniacb';
  let c, selected = 'profile', account, version, epoch = 0, checkResult;
  const panels = {}, tabs = {};
  const el = (tag, text = '', cls = '') => c.el(tag, cls, text);
  const safe = fn => async () => { try { await fn(); } catch (e) { c.toast(e.message); } };
  function button(text, fn, cls = 'outline-button') { const b = el('button', text, cls); b.type = 'button'; b.onclick = safe(fn); return b; }
  function link(text, href, cls = 'outline-button') { const a = el('a', text, cls); a.href = href; return a; }
  function field(text, type, value = '') { const l = el('label', text, 'member-field'), input = el(type === 'textarea' ? 'textarea' : 'input'); if(type !== 'textarea') input.type = type; input.value = value; l.append(input); return {l, input}; }
  const date = n => n ? new Date(n*1000).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'}) + ' IST' : 'No expiry';
  function syncMode() { if(!c) return; document.querySelectorAll('[data-work-modes]').forEach(b => b.classList.toggle('hidden', !b.dataset.workModes.split(' ').includes(c.state.mode))); }
  function updateAccount(a) {
    account = a; tabs.admin.classList.toggle('hidden', a.profile.role !== 'admin');$('#open-settings').title=(a.profile.full_name||a.profile.email||a.profile.username)+' · '+a.plan.label;
    $('#extension-source-fix').classList.toggle('hidden', a.profile.role !== 'admin');
    if(c.state.page === 'settings' && selected === 'profile') profile();
  }
  function profile() {
    const root = panels.profile, a = account || window.SynergyMembership.getAccount(); if(!a) return;
    const p=a.profile;root.replaceChildren(el('h2','Profile'));
    const card=el('section','','profile-summary'), avatar=el('span',(p.full_name||p.email||p.username).slice(0,1).toUpperCase(),'profile-avatar');
    const identity=el('div');identity.append(el('h3',p.full_name||p.username),el('p',p.email||'Email not added'),el('span',a.plan.label,'plan-pill'));
    card.append(avatar,identity);root.append(card);
    const details=el('dl','','profile-details');for(const [k,v] of [['Account',p.account_state],['Activated email',p.email||'Add your email below'],['Current plan',a.plan.label],['Access until',date(a.plan.expires)],['Plan source',a.plan.source.replaceAll('_',' ')]]){details.append(el('dt',k),el('dd',v));}root.append(details,el('p','Unlimited local requests in your included modes. No message credits or daily/monthly request cap. Shared queues and per-request safeguards still apply.','muted'),button('Manage subscription',()=>open('subscriptions')));
    const f=el('form','','member-section');f.id='member-profile';f.append(el('h3','Account details'));
    const email=field('Email','email',p.email||''),name=field('Display name','text',p.full_name||''),phone=field('Contact number','tel',p.phone||''),pw=field('Current password · for changing email or recovery key','password');email.input.required=true;name.input.maxLength=100;phone.input.maxLength=24;pw.input.autocomplete='current-password';
    f.append(email.l,name.l,phone.l,pw.l);const save=el('button','Save profile','primary small');save.type='submit';f.append(save);
    f.onsubmit=async e=>{e.preventDefault();save.disabled=true;try{await c.api('/api/account/profile',c.json({email:email.input.value,full_name:name.input.value,phone:phone.input.value,password:pw.input.value}));await window.SynergyMembership.refresh();c.toast('Profile saved');}catch(e){c.toast(e.message);}finally{save.disabled=false;}};
    const recovery=el('details');recovery.append(el('summary','Password recovery'),el('p','Create a private recovery key after confirming your current password. Keep the key somewhere safe.'),button('Create recovery key',async()=>{const d=await c.api('/api/account/recovery-key',c.json({password:pw.input.value}));pw.input.value='';window.SynergyMembership.showKey(d.recovery_key);}));f.append(recovery);root.append(f);
  }
  async function mcp() {
    const root=panels.mcp;root.replaceChildren(el('h2','MCP Tools'),el('p','Connected tools and their setup status. Your private records stay in your account.','muted'));
    const d=await c.api('/api/plugins');if(c.state.page!=='settings'||selected!=='mcp')return;
    const grid=el('div','','settings-tool-grid');
    for(const p of d.plugins.filter(p=>p.runtime || /mcp/i.test(p.name||''))){const card=el('article','','settings-tool');card.append(el('h3',p.name),el('p',p.description),el('small',(p.enabled?'Enabled':'Disabled')+' · '+p.status.replaceAll('_',' ')));
      if(p.id==='graphify')card.append(button('Map a code project',()=>{c.page('home');$('#chat-input').value='Use Graphify to map this project';$('#chat-input').focus();}));
      else if(p.id==='observation')card.append(button('Learning controls',()=>open('learning')));
      else if(p.id==='synergy-media')card.append(button('Open Media tools',()=>window.SynergyMedia.open()));
      else if(['vedics','foundr'].includes(p.action))card.append(button('Open '+p.name,()=>c.page(p.action)));
      else if(p.action==='connections')card.append(button('Open Connections',()=>open('connections')));
      else if(p.action==='settings')card.append(button('Preferences',()=>open('preferences')));
      else card.append(button('Manage in Plugins',()=>c.page('plugins')));
      grid.append(card);
    }root.append(grid,button('All plugins',()=>c.page('plugins')));
  }
  async function preferences() {
    const root=panels.preferences;root.replaceChildren(el('h2','Preferences'));const data=await c.api('/api/research/settings');
    if(selected!=='preferences')return;const form=el('form','','settings-preferences');
    const toggles={response_cache:'Reuse recent answers privately for up to five minutes',eternal_reminders:'Suggest ETERNAL while I use Aerny',observe_feedback:'Use my explicit feedback to adjust replies',adaptive_memory:'Remember response preferences only when I explicitly ask',web_search:'Allow public web search',allow_private_search:'Allow search queries when using private files',allow_external:'Allow an external model when configured'};
    for(const [key,label]of Object.entries(toggles)){const l=el('label','','setting-toggle'),i=el('input');i.type='checkbox';i.name=key;i.checked=data[key];l.append(el('span',label),i);form.append(l);}
    const l=el('label','Reply language','member-field'),language=el('select');for(const [v,t]of [['english','English (default)'],['hindi','Hindi'],['hinglish','Hinglish'],['auto','Match my message (optional)']])language.append(new Option(t,v));language.value=data.language;l.append(language);form.append(l);
    const save=el('button','Save preferences','primary small');save.type='submit';form.append(save);form.onsubmit=async e=>{e.preventDefault();save.disabled=true;try{const body={language:language.value};for(const key of Object.keys(toggles))body[key]=form.elements[key].checked;await c.api('/api/research/settings',c.json(body));c.toast('Preferences saved');}catch(e){c.toast(e.message);}finally{save.disabled=false;}};
    root.append(form,button('Clear my response cache',async()=>{await c.api('/api/research/cache/clear',c.json({}));c.toast('Your response cache was cleared');}),button('Research and saved-file settings',()=>$('#research-settings').click()));
    const memory=await c.api('/api/research/preferences');if(selected!=='preferences')return;
    const box=el('section','','member-section');box.append(el('h3','Remembered response preferences'),el('p','Private to your account. Say “Remember: use short replies and bullet points.” This adjusts context; it does not train model weights.'));
    box.append(el('p',Object.entries(memory.preferences).map(([k,v])=>k+': '+v).join(' · ')||'No preferences saved.','muted'),button('Clear remembered preferences',async()=>{await c.api('/api/research/preferences/clear',c.json({}));await preferences();c.toast('Remembered preferences cleared');}));root.append(box);
    const voice=await c.api('/api/voice/status');if(selected!=='preferences')return;const vb=el('section','','member-section');vb.append(el('h3','SYnerGY Jarvis voice'),el('p',(voice.ready?'Installed and ready':'Currently unavailable')+' · Chat, Work and Beast'),el('p','Local Faster-Whisper and Kokoro speech. Uses the installed English/Hindi voices. A clone of your personal voice requires a recording and has not been trained.','muted'));root.append(vb);
  }
  async function learning() {
    const root=panels.learning;root.replaceChildren(el('h2','Personalization & learning'));
    const [prefs,data]=await Promise.all([c.api('/api/research/settings'),c.api('/api/research/observations')]);if(selected!=='learning')return;
    root.append(el('h3','SYNERGY Observation MCP'),el('p',data.policy,'muted'));
    const form=el('form');for(const [key,label] of [['observation_learning','Save eligible completed exchanges for my review'],['observation_external','Allow saving and reusing reviewed examples from external models']]){const l=el('label','','setting-toggle'),input=el('input');input.type='checkbox';input.name=key;input.checked=prefs[key];l.append(el('span',label),input);form.append(l);}
    const save=el('button','Save learning controls','primary small');save.type='submit';form.append(save);form.onsubmit=async e=>{e.preventDefault();await safe(async()=>{await c.api('/api/research/settings',c.json({observation_learning:form.elements.observation_learning.checked,observation_external:form.elements.observation_external.checked}));c.toast('Private learning controls saved');})();};root.append(form,button('Delete all saved examples',async()=>{await c.api('/api/research/observations/clear',c.json({}));await learning();}),el('h3','Review queue · '+data.examples.length));
    for(const x of data.examples){const box=el('details','','learning-example');box.append(el('summary',x.prompt.slice(0,110)+' · '+x.state),el('p',x.response),el('small','Saved '+date(x.created)+' · expires '+date(x.expires)+' · '+x.provenance.agent));if(x.state!=='approved')box.append(button('Approve for private reuse',async()=>{await c.api('/api/research/observations/review',c.json({id:x.id,decision:'approve'}));await learning();}));box.append(button('Delete',async()=>{await c.api('/api/research/observations/review',c.json({id:x.id,decision:'delete'}));await learning();}));root.append(box);}
    if(!data.examples.length)root.append(el('p','No examples saved. Turn on capture above to collect eligible future exchanges.','muted'));
  }
  async function profileMenu(){const menu=$('#profile-menu');if(!menu.classList.contains('hidden')){menu.classList.add('hidden');$('#open-settings').setAttribute('aria-expanded','false');return;}if(!account){try{await window.SynergyMembership.refresh();}catch(e){c.toast(e.message);return;}}const a=account||window.SynergyMembership.getAccount();menu.replaceChildren(el('strong',a?.profile.full_name||a?.profile.username||'Your profile'),el('small',a?.plan.label||'Your plan'));for(const [id,label]of [['subscriptions','Upgrade plan'],['learning','Personalization'],['profile','Profile'],['preferences','Settings'],['manual','Help'],['logout','Log out']])menu.append(button(label,()=>{menu.classList.add('hidden');$('#open-settings').setAttribute('aria-expanded','false');if(id==='logout')$('#logout').click();else open(id);},'profile-menu-item'));menu.classList.remove('hidden');$('#open-settings').setAttribute('aria-expanded','true');menu.querySelector('button').focus();}
  function about() {
    const root=panels.about;root.replaceChildren(el('h2','About & contact'),el('p','SYnerGY — A friendly assistant between you and the knowledge.'),el('p','Owned by 1Rank, a brand management company. We help you find resources and knowledge, and create what you imagine.'));
    const site=link('Visit 1Rank','https://www.1rank.in');site.target='_blank';site.rel='noopener';root.append(site);
    const f=el('form','','member-section'),name=field('Name','text',account?.profile.full_name||''),email=field('Email','email',account?.profile.email||''),message=field('How can we help?','textarea');name.input.required=true;email.input.required=true;message.input.required=true;message.input.maxLength=3000;
    const label=el('label','Reason for contact','member-field'),reason=el('select');for(const v of ['General enquiry','Enterprise plans','Payment or subscription','Technical support','Feedback'])reason.append(new Option(v,v));label.append(reason);f.append(name.l,email.l,label,message.l);const row=el('div','','button-row');for(const [v,t]of [['email','Email'],['whatsapp','WhatsApp']]){const b=el('button',t,'outline-button');b.type='submit';b.value=v;row.append(b);}f.append(row);
    f.onsubmit=e=>{e.preventDefault();const title='SYnerGY · '+reason.value,body='Name: '+name.input.value+'\nEmail: '+email.input.value+'\nReason: '+reason.value+'\n\n'+message.input.value;location.href=e.submitter.value==='email'?'mailto:synergyai@1rank.in?subject='+encodeURIComponent(title)+'&body='+encodeURIComponent(body):'https://wa.me/919113432032?text='+encodeURIComponent(title+'\n'+body);};root.append(f);
  }
  async function sendExtension(type) {
    if(!window.chrome?.runtime?.sendMessage)throw Error('Extension not detected. Install the ZIP, then reload this page.');
    let timer;try{return await Promise.race([chrome.runtime.sendMessage(EXTENSION,{type}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('The extension did not respond. Reload it in Chrome and check again.')),5000);})]);}finally{clearTimeout(timer);}
  }
  async function extensionCheck(repair=false) {
    const generation=epoch,root=$('#extension-health');root.textContent=repair?'Checking and repairing the connection…':'Checking the connection…';
    try{
      const d=await c.api('/api/extension/status');if(generation!==epoch)return;version=d.version;$('#extension-version').textContent='Version '+d.version+' · Chat and Work tools';
      let installed;try{installed=await sendExtension(repair?'synergy-extension-repair':'synergy-extension-status');}catch(e){checkResult='SYnerGY server available · extension not detected. Install or reload version '+d.version+'.';root.textContent=checkResult;return;}
      if(installed?.error)throw Error(installed.error);
      const same=installed.account_id===c.state.user.id,old=installed.version!==d.version;
      checkResult=(installed.connected&&same?'Connected to this account.':installed.connected?'Connected to another SYnerGY account. Click Connect extension to switch.':'Not connected. Click Connect extension.')+(old?' Update available: '+d.version+'. Download, replace the folder files and reload in Chrome.':' Version '+d.version+' is current.')+(repair&&installed.repaired?' Side panel restored.':'');root.textContent=checkResult;
    }catch(e){root.textContent=e.message;}
  }
  async function setupDialog() {
    const root=$('#extension-dialog-body');root.replaceChildren(el('p','SYNERGY FOR CHROME','eyebrow'),el('h2','Connect your browser'),el('p','Chat, notes, tasks, leads and meetings beside your current page.'));
    const feedback=el('p','Checking for SYNERGY…','extension-health');root.append(feedback);if(!$('#extension-dialog').open)$('#extension-dialog').showModal();
    let installed;try{installed=await sendExtension('synergy-extension-status');}catch{}
    if(installed&&!installed.error){const same=installed.connected&&installed.account_id===c.state.user.id;feedback.textContent=same?'Connected to this account.': 'Extension found. Connect your signed-in SYNERGY account.';root.append(button(same?'Reconnect this account':'Connect',async()=>{feedback.textContent='Connecting…';try{await window.SynergyLeads.connect();feedback.textContent='Connected. Open SYNERGY from your Chrome toolbar.';}catch(e){feedback.textContent=e.message;}},'primary small'));if(installed.version!==version&&version)root.append(el('p','A new extension version is available. Chrome must approve the extension update.','muted'));}
    else feedback.textContent='First-time installation requires Chrome approval. A Chrome Web Store listing is not published yet. Once installed, Connect pairs your account in one click.';
    const advanced=el('details');advanced.append(el('summary','Install or update the development extension'));
    const download=link('Download extension ZIP','/api/extension/download','outline-button');download.download='SYnerGY-Chrome-Extension.zip';advanced.append(download,el('p','Extract once, open chrome://extensions, enable Developer mode and choose Load unpacked. For updates, replace the existing folder contents and click Reload. Return here and click Connect.'));
    root.append(advanced,button('Connection settings',()=>{$('#extension-dialog').close();open('extension');}));
  }
  function offerExtension() {
    if(!c.state.user)return;const key='synergy-extension-offer:'+c.state.user.id+':1.4';if(localStorage.getItem(key))return;
    localStorage.setItem(key,'shown');const card=el('aside','','extension-offer');card.id='extension-offer';card.setAttribute('aria-label','Add SYnerGY extension');card.append(el('strong','Take ETERNAL to the web'),el('p','Use SYnerGY beside the page you are viewing.'));
    card.append(button('Add extension',()=>{card.remove();setupDialog();},'primary small'),button('Not now',()=>card.remove(),'text-button'));document.body.append(card);
  }
  async function open(id='profile') {
    if(!panels[id])id='profile';if(id==='admin'&&c.state.user?.role!=='admin'){c.toast('Administrator access required.');id='profile';}
    $('#profile-menu').classList.add('hidden');selected=id;c.page('settings');for(const [key,panel]of Object.entries(panels))panel.classList.toggle('hidden',key!==id);for(const [key,tab]of Object.entries(tabs))tab.setAttribute('aria-current',key===id?'page':'false');
    try{if(id==='profile'){await window.SynergyMembership.refresh();profile();}else if(id==='subscriptions')await window.SynergyMembership.refresh();else if(id==='admin')await window.SynergyMembership.adminRefresh();else if(id==='connections')await window.SynergyConnections.refresh(panels.connections);else if(id==='mcp')await mcp();else if(id==='preferences')await preferences();else if(id==='learning')await learning();else if(id==='about')about();else if(id==='extension')await extensionCheck();else if(id==='manual')await window.SynergyManual.load();else if(id==='support')await window.SynergySupport.refresh();}catch(e){c.toast(e.message);}
  }
  function init(ctx) {
    c=ctx;const nav=$('#settings-nav'),content=$('#settings-content');
    const source={subscriptions:'#billing-page',admin:'#admin-page',manual:'#manual-page',support:'#support-page',extension:'#extension-settings-panel'};
    for(const [id,text]of [['preferences','General'],['profile','Profile & security'],['subscriptions','Subscriptions'],['learning','Personalization'],['mcp','MCP Tools'],['connections','Connections'],['extension','Chrome extension'],['about','About & contact'],['manual','User manual'],['support','Troubleshoot'],['admin','Administration']]){
      if(id==='preferences'||id==='mcp'||id==='about'||id==='admin')nav.append(el('p',({preferences:'Personal',mcp:'Integrations',about:'Support',admin:'Administration'})[id],'settings-group'));const b=button(text,()=>open(id),'settings-tab');b.dataset.settings=id;if(id==='admin'){b.id='member-admin-nav';b.classList.add('hidden');}if(id==='support'){const badge=el('span');badge.id='support-badge';b.append(badge);}nav.append(b);tabs[id]=b;
      const panel=source[id]?$(source[id]):el('section');panel.classList.add('settings-section','hidden');panel.classList.remove('page');panel.dataset.settingsPanel=id;content.append(panel);panels[id]=panel;
    }
    const search=el('input','','settings-search');search.type='search';search.placeholder='Search settings';search.setAttribute('aria-label','Search settings');nav.prepend(search);search.oninput=()=>{for(const [key,tab]of Object.entries(tabs))tab.hidden=!tab.textContent.toLowerCase().includes(search.value.toLowerCase());};$('#open-settings').onclick=profileMenu;$('#mobile-profile').onclick=profileMenu;$('#open-settings').setAttribute('aria-expanded','false');$('#rail-settings').onclick=()=>open('preferences');$('#rail-projects').onclick=()=>{c.page('home');$('#app-view').classList.remove('navigation-collapsed');$('#sidebar').classList.add('open');$('#create-work-project').focus();};document.addEventListener('click',e=>{if(!e.target.closest('#profile-menu,#open-settings')){$('#profile-menu').classList.add('hidden');$('#open-settings').setAttribute('aria-expanded','false');}});document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('#profile-menu').classList.add('hidden');$('#open-settings').setAttribute('aria-expanded','false');}});$('#close-settings').onclick=()=>c.page('home');$('#close-extension-dialog').onclick=()=>$('#extension-dialog').close();$('#extension-show-setup').onclick=setupDialog;$('#leads-add-extension').onclick=()=>open('extension');
    $('#extension-check').onclick=()=>extensionCheck();$('#extension-repair').onclick=()=>extensionCheck(true);
    $('#extension-ticket').onclick=safe(async()=>{await open('support');$('#support-create').open=true;$('#support-title').value='SYnerGY extension issue';$('#support-description').value='Extension version: '+(version||'not checked')+'\nConnection check: '+(checkResult||'not run')+'\n\nExpected result:\n\nWhat happened:\n';$('#support-auto').checked=false;$('#support-title').dispatchEvent(new Event('input',{bubbles:true}));$('#support-description').focus();});
    $('#extension-source-fix').onclick=safe(async()=>{await open('admin');const b=$('[data-section="source"]');b?.click();const section=$('#admin-eternal');if(section)section.open=true;c.toast('Select the extension files and describe the ticket in ETERNAL Beast. Review and test the proposal before releasing it.');});
    syncMode();
  }
  function reset(){epoch++;selected='profile';c.page('home');account=null;version=null;checkResult=null;$('#extension-offer')?.remove();$('#extension-dialog').close();$('#profile-menu').classList.add('hidden');for(const k of ['profile','mcp','preferences','about','learning'])panels[k]?.replaceChildren();panels.admin?.querySelector('#admin-root')?.replaceChildren();}
  window.SynergySettings={setupDialog,init,open,updateAccount,syncMode,offerExtension,reset,extensionCheck};
})();
