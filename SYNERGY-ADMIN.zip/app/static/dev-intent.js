/* Deliberately conservative: discussion stays in chat, explicit code work starts a job. */
(function(root){'use strict';const wants=(text,{project=false,manual=false}={})=>{
 const s=String(text||'').trim();if(/^(?:please\s+)?(?:explain|describe|tell|what|why|how|research|find|compare|summarise|summarize|give me details)\b/i.test(s))return false;
 if(/\b(?:do not|don't|never)\s+(?:build|create|edit|change|fix|implement|update|develop)\b/i.test(s))return false;
 const action=/\b(?:build|create|develop|implement|fix|debug|refactor|code|change|update|edit|add|remove)\b/i.test(s);
 const code=/\b(?:website|web\s?app|app|application|code|function|component|html|css|javascript|typescript|python|react|rust|api|repository|repo|bug|layout|hero|navbar|landing page)\b/i.test(s);
 const other=/\b(?:image|video|poster|photo|pdf|spreadsheet|calendar|meeting|logo|email)\b/i.test(s);
 return action&&(code||((project||manual)&&!other));
};root.SynergyDevIntent={wants};if(typeof module!=='undefined')module.exports={wants};})(typeof window!=='undefined'?window:globalThis);
