/* Native paste only. No clipboard reads, buttons, permissions or auto-send. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.SynergyPaste=api;})(typeof window==='undefined'?this:window,()=>{'use strict';
 const MAX_BYTES=200*1024*1024,MAX_FILES=200;
 function handle(event,input,ctx){
  const data=event.clipboardData;if(!data)return;
  const text=data.getData('text/plain')||'';
  const capacity=input.maxLength>0?input.maxLength:Infinity;
  const replacing=Math.max(0,(input.selectionEnd||0)-(input.selectionStart||0));
  if(text.length+input.value.length-replacing>capacity){
   event.preventDefault();ctx.notify('This text exceeds the '+capacity.toLocaleString()+'-character message limit. Paste a shorter section or attach it as a text file.');return;
  }
  let files=Array.from(data.files||[]);
  if(!files.length)files=Array.from(data.items||[]).filter(item=>item.kind==='file').map(item=>item.getAsFile()).filter(Boolean);
  if(!files.length)return; // Preserve native plain-text paste, cursor and undo.
  if(ctx.isBusy()){event.preventDefault();ctx.notify('Paste text suggestions while a reply is running. Add files after it finishes.');return;}
  const selected=ctx.getSelection();
  if(selected?.savedIds){event.preventDefault();ctx.notify('Remove the saved attachment before pasting new files. Your saved file remains available.');return;}
  const existing=selected?(selected.folder?selected.files||[]:[selected]):[];
  const combined=[...existing,...files];
  if(combined.length>MAX_FILES||combined.some(f=>!Number.isFinite(f.size)||f.size<0)||combined.reduce((n,f)=>n+f.size,0)>MAX_BYTES){
   event.preventDefault();ctx.notify('Select up to 200 files and 200 MB total. Your existing attachments are unchanged.');return;
  }
  ctx.selectFiles(combined);
  if(!text)event.preventDefault();
  ctx.notify(files.length===1?'Pasted '+(files[0].name||'image')+'. Add your instructions, then send.':'Pasted '+files.length+' files. Add your instructions, then send.');
 }
 function init(ctx){
  const input=document.querySelector('#chat-input');
  input.addEventListener('paste',event=>handle(event,input,{
   notify:ctx.toast,getSelection:()=>ctx.state.file,
   isBusy:()=>ctx.state.chatBusy||ctx.state.mediaBusy,
   selectFiles:files=>window.SynergyUploads.select(files)
  }));
 }
 return{handle,init};
});
