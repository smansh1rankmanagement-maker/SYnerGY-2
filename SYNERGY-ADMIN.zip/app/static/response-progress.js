/* Render actual job events. This is activity reporting, not model reasoning. */
window.SynergyProgress=(()=>{
 'use strict';
 const states=new WeakMap();
 const el=(tag,cls,text)=>{const e=document.createElement(tag);e.className=cls;if(text!==undefined)e.textContent=text;return e;};
 const duration=s=>{s=Math.max(0,Math.floor(s||0));return s<60?s+'s':Math.floor(s/60)+'m '+s%60+'s';};
 function update(parent,task){
  if(!parent)return;
  let state=states.get(parent);
  if(!state){
   const root=el('section','response-progress'),header=el('div','response-working'),notice=el('small','quota-switch hidden'),current=el('p','response-update'),details=el('details','response-activity'),summary=el('summary','','Activity'),list=el('div','response-events');
   notice.setAttribute('role','status');notice.setAttribute('aria-live','polite');details.append(summary,list);root.append(header,notice,current,details);
   parent.insertBefore(root,parent.querySelector('.message-copy'));state={root,header,notice,current,details,summary,list,seen:new Set(),queue:[],showing:false};states.set(parent,state);
  }
  const active=['running','queued'].includes(task.state),events=(task.events||[]).filter(x=>typeof x.action==='string');
  state.header.textContent=(active?'Working for ':task.state==='cancelled'?'Stopped after ':'Worked for ')+duration(task.elapsed);
  state.root.classList.toggle('is-working',active);
  state.current.textContent=active?(task.stage||'Preparing your reply.'):'Completed activity';
  state.current.hidden=!active;
  state.summary.textContent=events.length+' activity '+(events.length===1?'update':'updates');state.details.hidden=!events.length;
  const signature=JSON.stringify(events);
  if(state.signature!==signature){state.signature=signature;state.list.replaceChildren();for(const item of events){const row=el('div','response-activity-row'),icon=el('span','response-activity-icon',/search|source|browser|web/i.test(item.action)?'◎':/read|file/i.test(item.action)?'▧':'↳');icon.setAttribute('aria-hidden','true');row.append(icon,el('span','',item.action));state.list.append(row);}}
  if(state.wasActive===undefined)state.details.open=active;
  if(state.wasActive&&!active)state.details.open=false;
  state.wasActive=active;
  for(const n of task.notices||[]){if(!n||state.seen.has(n.id)||n.expires*1000<Date.now())continue;state.seen.add(n.id);state.queue.push(n);}
  function show(){if(state.showing||!state.queue.length)return;state.showing=true;const n=state.queue.shift();state.notice.textContent=n.message;state.notice.classList.remove('hidden');setTimeout(()=>{state.notice.classList.add('hidden');state.notice.textContent='';state.showing=false;show();},4500);}
  show();
 }
 return {update};
})();
