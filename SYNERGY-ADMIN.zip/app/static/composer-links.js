(() => {
  'use strict';let c;const $=s=>document.querySelector(s);
  function action(text,fn){const b=c.el('button','context-choice',text);b.type='button';b.onclick=async()=>{try{await fn();}catch(e){c.toast(e.message);}};return b;}
  function dialog(title){const d=c.el('dialog','context-dialog'),head=c.el('div','dialog-heading'),close=action('Close',()=>d.close());head.append(c.el('h2','',title),close);d.append(head);document.body.append(d);d.onclose=()=>d.remove();d.showModal();return d;}
  async function projects(){
    if(c.state.chatBusy)return c.toast('Finish or stop the current reply before changing projects.');
    await window.SynergyProjects.refresh();const d=dialog('Choose project'),search=c.el('input'),list=c.el('div','context-choices');search.type='search';search.placeholder='Find a project';search.setAttribute('aria-label','Find a project');
    const draw=()=>{list.replaceChildren();list.append(action('No project · new chat',async()=>{await window.SynergyProjects.choose(null);d.close();}));for(const p of window.SynergyProjects.list().filter(p=>p.name.toLowerCase().includes(search.value.toLowerCase()))){const b=action(p.name,async()=>{await window.SynergyProjects.choose(p.id);d.close();});b.append(c.el('small','',p.kind+' · '+p.chat_count+' chats'));if(p.id===c.state.projectId)b.setAttribute('aria-current','true');list.append(b);}};search.oninput=draw;
    d.append(search,list,action('＋ Create project',()=>{d.close();$('#create-work-project').click();}));draw();search.focus();
  }
  function files(){const d=dialog('Connect files');d.append(c.el('p','muted','Add files or a folder, or reuse an upload saved in this conversation. Up to 200 MB per selection.'));
    for(const [text,id]of [['Upload files','attach-file'],['Upload a folder','attach-folder'],['Saved uploads','saved-uploads']])d.append(action(text,()=>{d.close();$('#'+id).click();}));
    if(c.state.projectId)d.append(action('Project reference files',()=>{d.close();$('#manage-work-project').click();}));
  }
  window.SynergyComposerLinks={init(ctx){c=ctx;$('#composer-project').onclick=()=>projects().catch(e=>c.toast(e.message));$('#composer-files').onclick=files;$('#composer-plugins').onclick=()=>c.page('plugins');$('#composer-extension').onclick=()=>window.SynergySettings.setupDialog();}};
})();
