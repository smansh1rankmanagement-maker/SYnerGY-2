/* Original source stays read-only. All source operations require backend admin access. */
(() => {
  const el = (tag, text = '', className = '') => {
    const node = document.createElement(tag); node.textContent = text; node.className = className; return node;
  };
  const label = (text, input) => { const node = el('label', text, 'member-field'); input.setAttribute('aria-label',text); node.append(input); return node; };
  const download = (name, value, type = 'text/plain;charset=utf-8') => {
    const url = URL.createObjectURL(new Blob([value], {type}));
    const a = el('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  function mount(root, c) {
    mountWorkspace(root,c);
    const section = el('details', '', 'member-section admin-source');
    section.id = 'admin-source'; section.append(el('summary', 'Source code · synergy'));
    const panel = el('div'); section.append(panel); root.append(section);
    let loaded = false;
    section.addEventListener('toggle', async () => {
      if (!section.open || loaded) return;
      loaded = true; panel.replaceChildren(el('p', 'Loading reviewed source…'));
      try { await render(await c.api('/api/admin/source')); }
      catch (error) { loaded = false; panel.replaceChildren(el('p', error.message)); }
    });
    async function render(catalog) {
      panel.replaceChildren(el('h2', 'synergy/'), el('p', `${catalog.files.length} reviewed files · release ${catalog.version}. Application, MCP implementations, skills, tools, tests and deployment files.`));
      panel.append(el('p', 'Administrator access only. Production secrets, databases, user files, model weights and private mappings are excluded. Viewing or scrambling never changes the live source.'));
      const zip = el('a', 'Download synergy folder ZIP', 'primary small'); zip.href = '/api/admin/source/synergy.zip'; panel.append(zip);
      const search = el('input'); search.type = 'search'; search.placeholder = 'Find a source file';
      const files = el('select'); files.size = 8;
      const viewer = el('pre', '', 'admin-source-code'); viewer.tabIndex = 0; viewer.setAttribute('aria-label', 'Original source preview');
      const path = el('strong'), fileLink = el('a', 'Download selected original', 'secondary small');
      const use = el('button', 'Use selected Python file', 'secondary small'); use.type = 'button'; use.disabled = true;
      const selectedActions = el('div', '', 'member-actions'); selectedActions.append(fileLink, use);
      const browse = el('div', '', 'admin-source-browse'); browse.append(label('Find files in synergy', search), label('Source files', files), path, selectedActions, viewer); panel.append(browse);
      const form = el('form', '', 'member-section'); form.append(el('h2', 'Python Code Scrambler'), el('p', 'One Python file, up to 256 KiB. Syntax checks only; submitted code is never executed. Unsupported functions are reported and skipped.'));
      const input = el('textarea'); input.rows = 10; input.maxLength = 262144; input.spellcheck = false;
      input.value = 'def total(prices, *, discount=0):\n    subtotal = 0\n    for price in prices:\n        subtotal += price\n    return subtotal - discount\n';
      const upload = el('input'); upload.type = 'file'; upload.accept = '.py';
      upload.onchange = async () => {
        const file = upload.files[0]; if (!file) return;
        if (file.size > 262144) { c.toast('Use a Python file no larger than 256 KiB.'); return; }
        input.value = await file.text(); c.toast('Source loaded as UTF-8. Use the CLI for other file encodings.');
      };
      const preserve = el('input'); preserve.placeholder = 'important_name another_name';
      const mapping = el('input'); mapping.type = 'checkbox';
      const mappingLabel = label('Include private debugging mapping', mapping);
      const submit = el('button', 'Scramble a copy', 'primary'); submit.type = 'submit';
      const result = el('div'); result.setAttribute('aria-live', 'polite');
      form.append(label('Upload a UTF-8 Python file', upload), label('Python source', input), label('Preserve identifiers', preserve), mappingLabel, submit, result); panel.append(form);
      let current = null;
      const choose = async () => {
        if (!files.value) return;
        try {
          current = await c.api('/api/admin/source/file/' + files.value);
          path.textContent = 'synergy/' + current.path;
          viewer.textContent = current.text ?? 'Preview unavailable for this binary/large file. Download the original to inspect it.';
          fileLink.href = '/api/admin/source/download/' + current.id;
          use.disabled = !current.preview_available || !current.path.endsWith('.py');
        } catch (error) { c.toast(error.message); }
      };
      const filter = () => {
        const selected = files.value; files.replaceChildren();
        for (const f of catalog.files.filter(f => f.path.toLowerCase().includes(search.value.toLowerCase()))) files.append(new Option(f.path, f.id));
        if ([...files.options].some(o => o.value === selected)) files.value = selected;
        if (!files.value) { current = null; use.disabled = true; fileLink.removeAttribute('href'); viewer.textContent = 'No files match.'; path.textContent = ''; }
      };
      search.oninput = () => { filter(); choose(); }; files.onchange = choose;
      use.onclick = () => { if (current?.text) { input.value = current.text; input.scrollIntoView({block:'center',behavior:'smooth'}); } };
      form.onsubmit = async event => {
        event.preventDefault(); submit.disabled = true; result.replaceChildren(el('p', 'Checking scope and regenerating source…'));
        try {
          if (new TextEncoder().encode(input.value).length > 262144) throw Error('Source exceeds 256 KiB.');
          const data = await c.api('/api/admin/source/scramble', c.json({source:input.value,preserved_names:preserve.value.trim() ? preserve.value.trim().split(/\s+/) : [],options:{include_mapping:mapping.checked}}));
          result.replaceChildren(el('h3', 'Syntax validation passed · Behaviour not tested'), el('p', `${data.report.renamed_variables} local variables renamed. ${data.skipped.length} functions skipped. Original source unchanged.`));
          const out = el('textarea'); out.rows = 12; out.readOnly = true; out.spellcheck = false; out.value = data.source;
          result.append(label('Transformed Python source', out));
          const actions = el('div', '', 'member-actions');
          const button = (name, action) => { const b = el('button', name, 'secondary small'); b.type = 'button'; b.onclick = action; actions.append(b); };
          button('Download transformed .py', () => download('scrambled.py', data.source));
          button('Download report', () => download('scrambler-report.json', JSON.stringify(data.report,null,2),'application/json'));
          if (data.mapping) button('Download PRIVATE mapping', () => download('private-mapping.json',JSON.stringify(data.mapping,null,2),'application/json'));
          result.append(actions);
          for (const row of data.report.functions) result.append(el('p', `${row.function} · line ${row.line} · ${row.status}${row.reasons.length ? ': ' + row.reasons.join('; ') : ''}`));
          result.append(el('p', 'Comments and formatting change; docstrings remain. Review licence comments and test trusted code before distribution. Keep API keys, passwords and mappings private. No obfuscation prevents determined reverse engineering.'));
        } catch (error) { result.replaceChildren(el('p', error.message)); }
        finally { submit.disabled = false; }
      };
      filter(); await choose();
    }
  }
  function mountWorkspace(root,c) {
    const section=el('details','','member-section admin-source'); section.id='admin-eternal'; section.classList.add('admin-chat');
    section.append(el('summary','ETERNAL · Admin workspace')); root.append(section);
    const body=el('div'); section.append(body); let initialized=false, workspace=null, timer=null, selected=new Set(), busy=false;
    const call=(path,data)=>c.api('/api/admin/source/workspace'+path,data===undefined?{}:c.json(data));
    const safe=fn=>async()=>{try{await fn();}catch(e){c.toast(e.message);}};
    const button=(text,fn,cls='secondary small')=>{const b=el('button',text,cls); b.type='button'; b.onclick=safe(fn); return b;};
    const status=el('p'),actions=el('div','','member-actions'),form=el('form'),result=el('div'); result.setAttribute('aria-live','polite');
    const mode=el('select'); mode.append(new Option('ETERNAL Work · analyse and plan','work'),new Option('ETERNAL Beast · propose code changes','beast'));
    const effort=el('select'); for(const value of ['instant','medium','high','max','ultra'])effort.append(new Option(value,value)); effort.value='medium';
    const search=el('input'); search.type='search';search.placeholder='Filter context files';
    const files=el('select'); files.multiple=true;files.size=8;
    const prompt=el('textarea');prompt.rows=5;prompt.maxLength=6000;prompt.required=true;prompt.placeholder='Describe the change or ask about the selected source. Include what must stay unchanged.';
    const send=el('button','Send to ETERNAL','primary');send.type='submit';
    const auto=el('input');auto.type='checkbox';auto.checked=true;const autoLabel=label('Automatically save validated Beast changes to the private source copy',auto);
    const contextNote=el('p','','muted'), omitted=el('details');omitted.append(el('summary','Files preserved in the ZIP but unavailable for code editing'));
    const full=button('Open full Beast editor',async()=>{c.state.modelFamily='eternal';c.updateComposer();await window.SynergyBeast.open(workspace.project_id);});
    const exported=el('a','Download edited source ZIP','secondary small');exported.href='/api/admin/source/workspace/export';
    actions.append(button('Refresh workspace',refresh),full,exported);
    form.append(label('Administrator mode',mode),label('Response level',effort),label('Find context files',search),label('Selected source context',files),contextNote,label('Admin task',prompt),autoLabel,send);
    function filter(){
      files.replaceChildren();
      for(const f of (workspace?.files||[]).filter(f=>f.encoding==='utf-8'&&f.path.toLowerCase().includes(search.value.toLowerCase()))){const o=new Option(f.path,f.path);o.selected=selected.has(f.path);files.append(o);}
      contextNote.textContent=selected.size+' file(s) selected. Up to 12 files and 22,000 context characters per task. Source is never silently truncated. Ctrl/Cmd-click to select several; filter selections remain selected.';
    }
    files.onchange=()=>{for(const o of files.options){if(o.selected)selected.add(o.value);else selected.delete(o.value);}filter();};search.oninput=filter;
    function show(){
      if(!workspace?.created){body.replaceChildren(el('p','Use the local ETERNAL model to analyse SYnerGY and propose changes in a private, revisioned copy.'),button('Open ETERNAL workspace',async()=>{workspace=await call('',{});render();},'primary'));return;}
      status.textContent=`synergy · source ${workspace.source_version} · revision ${workspace.revision} · ${workspace.worker.running?'Worker online':'Worker offline'}`;
      send.disabled=busy||workspace.jobs.some(j=>['queued','running','awaiting_review'].includes(j.state));
      result.replaceChildren();
      for(const j of workspace.jobs){
        const card=el('article','','admin-chat-turn'); card.append(el('h3',j.request.task_mode==='explain'?'ETERNAL Work':'ETERNAL Beast'),el('p',j.request.prompt),el('strong',j.state.replaceAll('_',' ')+' · '+new Date(j.created*1000).toLocaleString()));
        if(['queued','running'].includes(j.state))card.append(el('p',Math.floor(Date.now()/1000-j.created)+' seconds · saved task continues with this tab closed.'));
        const activity=(workspace.activity||[]).filter(a=>a.job_id===j.id).slice().reverse();if(activity.length){const log=el('ol','','admin-progress');for(const a of activity.slice(-8))log.append(el('li',new Date(a.created*1000).toLocaleTimeString()+' · '+a.message));card.append(log);}if(j.result?.applied_revision)card.append(el('p','Saved to private source revision '+j.result.applied_revision+'. Live deployment is separate.','plan-pill'));
        if(j.error)card.append(el('p',j.error));
        if(j.result){const r=j.result;card.append(el('p',r.model_summary||r.summary));for(const line of r.plan||[])card.append(el('p',line));for(const line of r.notes||[])card.append(el('p',line,'muted'));if(r.diff)card.append(el('pre',r.diff,'admin-source-code'));
          if(r.checks)card.append(el('p',`${r.checks.passed} parse checks passed · ${r.checks.failed} failed · ${r.checks.skipped} skipped. ${r.checks.execution}`));
          if(j.state==='awaiting_review')card.append(button('Apply reviewed diff to private copy',async()=>{await call('/action',{id:j.id,action:'apply',revision:j.base_revision,reviewed_hash:r.hash});await refresh();},'primary small'));
        }
        if(['queued','running','awaiting_review'].includes(j.state))card.append(button('Cancel this task',async()=>{await call('/action',{id:j.id,action:'cancel'});await refresh();}));
        result.append(card);
      }
    }
    function render(){
      if(workspace?.created){
        if(!selected.size){const initial=workspace.files.find(f=>f.path==='tools/python_scrambler/examples/input.py')||workspace.files.find(f=>f.encoding==='utf-8'&&f.characters<6000);if(initial)selected.add(initial.path);}
        body.replaceChildren(el('h2','Work on SYnerGY with ETERNAL'),status,el('p','Work explains and plans. Beast can save validated changes automatically to this private source copy. Progress and diffs appear below. Live deployment is separate.'),actions,form,omitted,result);
        omitted.replaceChildren(el('summary',workspace.bundle_only.length+' files preserved in the ZIP but unavailable for code editing'));
        for(const f of workspace.bundle_only)omitted.append(el('p',f.path+' · '+f.reason));
        filter();
      }
      show();
    }
    async function refresh(){const data=await call('');if(!section.isConnected||c.state.user?.role!=='admin')return;workspace=data;render();}
    form.onsubmit=async event=>{event.preventDefault();if(busy)return;busy=true;send.disabled=true;try{await call('/jobs',{prompt:prompt.value,mode:mode.value,effort:effort.value,paths:[...selected],revision:workspace.revision,idempotency_key:crypto.randomUUID(),auto_apply:mode.value==='beast'&&auto.checked});prompt.value='';await refresh();}catch(e){c.toast(e.message);}finally{busy=false;show();}};
    section.addEventListener('toggle',async()=>{
      clearInterval(timer);
      if(!section.open)return;
      if(!initialized){initialized=true;try{await refresh();}catch(e){initialized=false;body.replaceChildren(el('p',e.message));return;}}
      timer=setInterval(async()=>{if(!section.isConnected||!section.open||c.state.user?.role!=='admin'){clearInterval(timer);return;}if(c.state.page!=='settings'||section.closest('.hidden')||busy)return;try{workspace=await call('');show();}catch(e){clearInterval(timer);status.textContent=e.message;}},3000);
    });
  }
  window.SynergyAdminSource = {mount};
})();
