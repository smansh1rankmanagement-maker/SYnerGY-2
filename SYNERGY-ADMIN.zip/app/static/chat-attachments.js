window.SynergyAttachments=(()=>{'use strict';
const image=/\.(png|jpe?g|webp|gif|bmp)$/i, video=/\.(mp4|webm|mov|mkv|avi)$/i, urls=new Map();
function node(tag,cls,text){const n=document.createElement(tag);n.className=cls;if(text)n.textContent=text;return n;}
function items(selection){if(!selection)return [];if(selection.savedIds)return selection.savedIds.map(id=>({id,name:selection.name||'Saved file'}));return selection.folder?selection.files:[selection];}
function url(file){if(!urls.has(file))urls.set(file,URL.createObjectURL(file));return urls.get(file);}
function clean(){queueMicrotask(()=>{for(const [f,u]of urls)if(![...document.querySelectorAll('.chat-attachment-image')].some(n=>n.src===u)){URL.revokeObjectURL(u);urls.delete(f);}});}
function card(asset,temporary=false){
 const box=node('div','chat-attachment-card'),name=String(asset.name||'Attachment');
 if(image.test(name)){
  const img=node('img','chat-attachment-image');img.alt=name;img.loading='lazy';
  if(temporary&&asset instanceof Blob)img.src=url(asset);else if(/^[a-f0-9]{32}$/.test(asset.id||''))img.src='/api/uploads/'+asset.id+'/preview';
  img.onerror=()=>{img.remove();box.classList.add('preview-unavailable');};if(img.src)box.append(img);
 }
 const label=node('span','chat-attachment-label',name);box.append(label);
 if(asset.size!==undefined)box.append(node('small','',asset.size<1048576?Math.max(1,Math.ceil(asset.size/1024))+' KB':(asset.size/1048576).toFixed(1)+' MB'));
 else if(video.test(name))box.append(node('small','','Video'));
 if(!temporary&&/^[a-f0-9]{32}$/.test(asset.id||'')){const a=node('a','chat-attachment-download','Download');a.href='/api/uploads/'+asset.id+'/original';a.download='';box.append(a);}
 return box;
}
function group(assets,temporary){const row=node('div','chat-attachment-list');for(const asset of assets.slice(0,200))row.append(card(asset,temporary));return row;}
function draft(root,selection){root.append(group(items(selection),!selection.savedIds));clean();}
function render(root,metadata){
 const assets=metadata.attachments||metadata.upload_ids?.map(id=>({id,name:metadata.attachment_name||'Uploaded file'}))||[];
 const pending=metadata.pending_attachment;
 if(pending)root.prepend(group(items(pending),!pending.savedIds));
 else if(assets.length)root.prepend(group(assets,false));
 else if(metadata.attachment_name){const row=group([{name:metadata.attachment_name}],false);root.prepend(row);}
 clean();
}
return{draft,render};
})();
