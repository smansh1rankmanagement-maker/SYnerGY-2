# SYnerGY 1.5.2 — tools installed from Chat

## Use in SYnerGY

Open http://127.0.0.1:8090/ on the connected Mac, sign in to the owner account and select Chat mode. Send:

```
Install Desktop Commander and Firecrawl
```

Installation is handled by SYnerGY's backend, not by the language model pretending to execute a command. Activity shows actual download, connector discovery and access-test stages. Stop terminates owned installation/connector processes. A retry is safe and rechecks the connector. Installed state belongs to the account and survives restarts.

Try these messages:

```
Desktop Commander list files
Desktop Commander read README.md
Desktop Commander search "research"
Research Playwright browser contexts using official documentation. Cite the sources.
Inspect https://example.com and report observed browser issues.
```

The Plugins page provides Install in chat / Use in chat and enable/disable controls. Official repository URLs are accepted for these two catalog entries. Unknown repositories still use the existing reviewed SKILL import flow; arbitrary package code is not executed from pasted repository text.

## Components and observed limits

| Component | Actual software | Scope |
| --- | --- | --- |
| Local file tools | `@wonderwhy-er/desktop-commander@0.3.1`, MIT | MCP `read_file`, `list_directory`, `get_file_info`; bounded search reads up to 12 text files, 250 lines per file |
| Firecrawl connector | Official `https://mcp.firecrawl.dev/v2/mcp`, observed server 3.36.1 | Public `firecrawl_search` and `firecrawl_scrape`; no API key, paid route, document upload, crawl or agent tool |
| Free web fallback | Existing SYnerGY DDGS search (enabled engines only, Yahoo first) and validated public-page reader | Real search and page evidence, visibly labelled when Firecrawl is unavailable |
| Browser inspection | Existing local Playwright/Chromium worker | Isolated public-site inspection; does not reuse Chrome logins or bypass sign-in/paywalls |
| Answer model | Existing local Aerny v1.5 Ollama profiles | Existing Qwen weights; no new training or weight modification |

The hosted Firecrawl handshake succeeds, but the provider refused the real anonymous search and scrape tests on this Mac. That is an access failure, not a successful Firecrawl generation. The installed connector remains available for retry. SYnerGY records the failure, waits five minutes before automatically trying again, and visibly uses its built-in public web tools. No paid service is silently substituted.

Self-hosted Firecrawl is not installed by this release. The official deployment needs Docker and supporting Redis, PostgreSQL, RabbitMQ and browser services; Docker is absent on this Mac. A future self-hosted integration needs a separately tested local service deployment. Installing an MCP connector alone does not create that infrastructure.

## Files and privacy

The account's local Desktop Commander directory is:

```
$SYNERGY_DATA_DIR/runtime-plugins/accounts/<user_id>/workspace
```

For the existing owner (`smansh`, user ID 2), this is:

```
/Users/a1989/Library/Application Support/SYnerGY/v1.4-data/runtime-plugins/accounts/2/workspace
```

Place files there to use the file commands. This release does not automatically copy image outputs or uploaded research files into this directory. The gateway rejects path traversal, symlink escape, hidden files and oversized reads. The package has a separate profile and telemetry disabled. This is application-level scoping, not an operating-system sandbox. Terminal execution, unrestricted computer control and other users' files are not exposed to the model.

Public queries and URLs can be sent to search providers and Firecrawl. Private files stay local by default. Follow-ups containing Desktop Commander output are marked private and do not trigger web searches unless the account explicitly enables private-search sharing in Settings. The existing external-AI setting remains off by default. Retrieved page text cannot authorize installations or tool actions.

## Deployment on the existing Mac

Requirements: the working 1.5.1 installation and dependencies, Python 3.12, Node.js 22.12+ and npm. Observed here: Intel Mac, 16 GB RAM, Node 24.21.0, npm 11.19.0. No new GPU is required. Package dependencies are locked in `backend/runtime-locks/desktop-commander/`. `npm ci` disables lifecycle scripts and verifies the pinned main-package integrity. No global npm installation is performed.

1. Unpack this source into the new `v1.5.2` directory beside `v1.5.1`; retain the previous source. Install `requirements-search-v152.txt` with the web Python and `pip install --only-binary=:all: --target <SYnerGY-base>/runtime/research-search-v152 -r requirements-search-v152.txt`. The deployer prepends this separate dependency folder to the web server PYTHONPATH; it does not modify the old environment.
2. Wait for all active local media and research jobs to finish.
3. Run `scripts/deploy-plugins-macos.py --source <absolute-v1.5.2-path> --owner smansh` using Python 3.12. This saves the previous source, a consistent SQLite backup and the LaunchAgent, then switches only the web application source and adds the owner/Node/npm settings.
4. Open SYnerGY and send the install command in Chat. The production package download is performed by that Chat request.
5. Verify Desktop Commander file access and public research from the same UI.

The launcher retains all image/video worker and Ollama configuration. Auth, conversations, source citations, projects and outputs stay in the existing data directory. No prices, subscription plans or credits are added.

## Rollback

The deployment prints its backup directory under `SYnerGY/backups/chat-tools-v152-<timestamp>`. Boot out the current LaunchAgent, restore the saved plist and bootstrap it again. The preserved v1.5.1 source can use the unchanged core data; the extra connector table is additive. Restore `accounts.sqlite3` only for data corruption and only while the app is stopped, because a database rollback discards newer conversations. Connector files can remain on disk without being used by 1.5.1.

## Search corrections

The release uses DDGS 9.16.1 and primp 1.3.1, checks the installed engine registry to avoid hidden automatic fallbacks, strips conversational lead-ins, retries with a shorter query and rejects clearly unrelated result titles/snippets. Yahoo was the usable public engine in the acceptance tests; Google and Bing were disabled in this installed DDGS release. This is a lexical relevance check, not a factual-quality score. “Current” and “latest” no longer imply an unstated one-month filter; explicit date-window controls still apply. Citation formats that explicitly name a source ID are normalized and then validated against the actual read sources.

## Verification

Run `python3 -m unittest discover -s tests -v` and JavaScript syntax checks. The test suite covers installation intent, locked package identity, account isolation, path escape, private follow-ups, connector errors, explicit fallback, cancellation and the existing application features. Real UI acceptance results are separate from these automated tests in PLUGINS_VERIFICATION.md.

Official references: https://github.com/wonderwhy-er/DesktopCommanderMCP ; https://github.com/firecrawl/firecrawl-mcp-server ; https://docs.firecrawl.dev/contributing/self-host .
