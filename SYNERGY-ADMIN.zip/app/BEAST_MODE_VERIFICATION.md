# Beast 1.7.0 verification · 4 November 2026

## Deployed result

- Local app: http://127.0.0.1:8090/
- Example: http://127.0.0.1:8090/?beast=6cc46c05b64f46ff8fd4d5af291bc32a
- App version observed from `/api/auth/config`: **1.7.0**.
- Source: `/Users/a1989/Library/Application Support/SYnerGY/v1.7.0`.
- Backup: `/Users/a1989/Library/Application Support/SYnerGY/backups/beast-v170-20261104-220001`.
- Existing source 1.6.0 retained. Existing data directory reused; staging database was never copied over production.
- App, Brand Operations worker and Beast worker started successfully. Both workers passed heartbeat checks.
- Before/after upgrade counts matched: **2 accounts, 14 conversations, 40 messages, 1 operations workflow, 1 operations run, 4 operations artifacts**. A new Beast example project was then added for acceptance.
- The application remains free, with no pricing, credits, new paid services or model downloads.

## Automated checks

**109 tests passed** in the complete local regression suite, including 88 existing tests and 21 new Beast tests. The final full run took 36.369 seconds. The 21 Beast tests also passed on the deployment Mac in 1.724 seconds. JavaScript syntax checks and Python module compilation passed.

The checks cover:

- Authentication, host/origin enforcement and account isolation for projects, jobs, previews, diffs, revisions, downloads and mutations.
- Relative-path validation, traversal, symlinks, duplicate/case-colliding paths, file/folder collisions, ZIP expansion and file-size limits.
- Known secret-pattern rejection; this is not a guarantee that every possible secret is detected.
- File save, rename, delete, import conflict, persistent reopen, checkpoint restore and source ZIP content.
- Duplicate job submission, competing edits, required review hash, stale revision rejection and repeat-apply rejection.
- Model-output schema, allowed file scope, unsupported operations, exact replacement anchors and additive edits.
- Selected-region edits preserving surrounding source.
- Python definition loss and explicitly protected entry-point changes being rejected.
- Real Python/JavaScript parse errors and JSON errors. A source file containing a filesystem write was parsed without executing the write.
- Preview sanitization, local raster assets, script/network restrictions and authenticated response headers.
- Queue restart state, bounded recovery and unsupported runtime status.
- Existing Chat, Work, image/video, research, skills, authentication, Brand Operations, spreadsheet/PDF, approvals and scheduler regressions.

These are application checks, not evidence that arbitrary generated projects pass their own build or test suites.

## Real model and process tests

### JavaScript edit through the browser

Project `0d97707634b54ac19944857aee3d4392`, task `b42bfc6fef0f463399f0969a77900748`.

The browser created an InteriFY website study, selected `app.js` as context and submitted a missing-element guard request. Actual `aerny:v1.5` inference produced a reviewable diff in approximately **104 seconds**. The diff preserved the clipboard text and messaging. It was reviewed and applied as revision 2; the JavaScript parse-only check passed.

### Diagnostics, checkpoint and reload through the browser

A named checkpoint was saved at revision 2. The editor deliberately saved invalid JavaScript `const = ;` at revision 3. Node reported `SyntaxError: Unexpected token '='` with exit code 1. Restoring the checkpoint created revision 4. Reloading the page reopened the saved project and correctly labelled revision-3 diagnostics as stale. Rerunning checks passed for the restored JavaScript.

The actual saved HTML/CSS rendered in the right pane at desktop-fit and 390-pixel mobile preview widths. The layout was also inspected with a temporary narrow browser viewport; the measured root scroll width equalled its client width. The viewport override was reset. No browser console warnings/errors were reported during the final staged checks.

### Multi-file Python change and regression prevention

A real two-file request asked for a typed `add(a, b)` function and a README example while preserving `greet` and the existing command-line entry point.

The first model proposal removed `greet`; it was discarded before application. A later run was rejected by the new preservation gate with an explicit failure and no source change. Exact-anchor replacement and append operations were added to reduce unnecessary whole-file rewrites.

A subsequent real proposal changed both `main.py` and `README.md`, preserved the original function and entry point, and passed Python syntax parsing. It was reviewed and applied as revision 2. This is evidence of the reviewed example, not a guarantee of general semantic correctness. The generated Python application was not executed.

### Independent worker lifecycle

The real-process test ran against an isolated database without using a chat tab or HTTP server to submit, advance or finish work.

- Restart task `5b92bd93ccd844c4a571cdaeca536dea`: the worker was killed during a model request. Its orphan model client exited. Restart recovered the job on attempt 2; the real model proposal reached review in 39.45 seconds after restart. A duplicate request returned the same job. Source stayed at revision 1 until review/apply created revision 2.
- Cancellation task `da665b8df3634891961c147fb10fea71`: cancelling a running request terminated its model client. State became cancelled and revision 2 stayed unchanged.
- Failure task `f51ebe05fb9848b1898b21426e9a41aa`: an actual request to a deliberately nonexistent local model produced a useful connection failure. It did not change source.
- Process cleanup and no repeated source application were verified. A full seven-minute timeout stress test was not run.

### Live production acceptance

Project `6cc46c05b64f46ff8fd4d5af291bc32a`, task `edc07234c2c94c2ba62b206618d32022`.

The deployed worker used actual **Aerny v1.5 / Qwen3 4B Instruct 2507 Q4_K_M** to revise exactly one fallback message in `app.js`. Inference and proposal checks took **53.66 seconds**. Before applying, the proposed bytes were compared with the original file containing exactly the requested string replacement. No other character changes were permitted. Review/apply saved revision 2; saved-source checks passed.

The source export `InteriFY-r2.zip` is **5,036 bytes**, SHA-256:

```text
a256fe5cbe9c2bf274e399240ca3446222befebbe9b47c6bc8cf616981e46488
```

The live app version, worker heartbeat, project revision, generated proposal, check result and export checksum are recorded in `production-example.json`.

## Evidence and source changes

### Reference-image understanding

Task `c53b7446dbe5470bb0222c1cded5a66b` used the installed `qwen3-vl:2b-instruct` vision model with the supplied SYNERGY logo. It completed in **55.97 seconds**, correctly describing an orange, bold, blocky SYNERGY wordmark on a white background. It returned no source changes; the project remained at revision 1. The exact result is retained in `vision-final.json`.

The initial Explain request had proposed a source edit and was rejected before application. The Explain response schema was tightened to require an empty changes array. This successful follow-up verifies image routing and the bounded Explain workflow; it does not validate reconstruction of a complete UI from a screenshot.

The evidence package contains the local and Mac test logs, staged job records (including the rejected proposals), independent process test result, deployment record, live acceptance record and exported example ZIP. It excludes account databases, session cookies, credentials and model weights.

Primary additions: `backend/beast/{store,safety,templates,preview,checks,model_worker,worker,routes}.py`, `static/beast.{js,css}`, deployment/process-validation scripts, Beast tests, preserved specification and handover documents. Existing server, application shell, chat integration, research instructions and built-in skills were extended. Existing generation and Brand Operations implementations were retained.

## Boundaries

- Aerny remains an existing local model profile. No foundation-model training or adaptation was performed.
- General application execution, builds, dependency installation, framework dev servers, language servers and deployment adapters are not available in Beast yet. Host runtimes alone are not an isolated execution service.
- The preview is a real rendering of saved HTML/CSS, with scripts, forms and external resources disabled. It is not proof that JavaScript behaviour or backend APIs work.
- Python/JavaScript/JSON syntax and limited HTML checks do not prove behavioural correctness, security or accessibility. CSS and other unsupported checks remain clearly labelled.
- Reference-image routing passed the logo-description check above. Full screenshot-to-website reconstruction and pixel-level visual matching were not evaluated.
- Local inference can take one or more minutes on this CPU-only Mac. No speed, universal language expertise, perfect visual quality or flawless code is claimed.
- Authenticated ZIP/patch responses and exported bytes were verified. The browser download helper stalled and did not provide a confirmed native save path. The browser connection later became unavailable, preventing a fresh screenshot after production deployment. Earlier staged browser rendering and interaction checks completed successfully; the production backend was separately verified.
