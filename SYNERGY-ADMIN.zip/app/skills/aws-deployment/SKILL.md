---
name: aws-deployment
description: Set up or upgrade SYnerGY on AWS EC2 and a Hostinger subdomain, preserve existing accounts, verify the live site, and recover an earlier release.
---

# AWS deployment for SYnerGY

Use for AWS console setup, domain deployment, backups and in-place upgrades. This is an operational guide. SYnerGY's written skill does not itself grant AWS, DNS, terminal or billing access. Execute only through a configured authorised connection, otherwise give the owner the exact steps and record what remains unverified. Never claim a console action happened without its result.

## First decide: existing server or first installation

Ask for missing target details only after inspecting available source and authorised connections. For the existing SYnerGY service, the domain is `synergyai.1rank.in`, AWS region is Mumbai (`ap-south-1`), source is `/srv/synergy`, data is Docker volume `synergy_app_data`, and public traffic goes through Caddy to the app. Reuse this server; never run a fresh-host bootstrap over it. Aerny is a configured local model profile, not a newly trained foundation model.

## AWS console setup used for the initial deployment

1. Complete the account's contact verification, identity checks and billing enrolment in the official AWS console. The owner handles passwords, OTPs and payment credentials. Confirm the approved cost and credits; promotional credit is not a spending cap. Do not repeat enrolment for an existing account.
2. Select **Asia Pacific (Mumbai)** at the top of the console. Inspect EC2 Instances and Systems Manager before creating resources. The initial machine was Ubuntu 24.04 amd64 on `r6i.xlarge` (4 vCPU, 32 GiB RAM), with a 100 GiB encrypted gp3 disk. Check current pricing and quota before any new purchase or resize. The running deployment has no GPU.
3. In IAM, create an EC2-trusted role with `AmazonSSMManagedInstanceCore` and attach its instance profile. Reuse an existing matching role. This permits Session Manager administration without opening SSH.
4. In EC2, use the selected VPC/subnet with outbound internet. Attach a security group accepting public TCP **80 and 443 only**. Keep SSH 22, app 8090, Ollama 11434 and voice 8091 private. Require IMDSv2. Enable instance termination protection. Never paste cloud credentials into code, chat, logs or export files.
5. Launch the approved instance only if none exists. Wait for running state and status checks. Verify the SSM agent is online; if not, inspect agent, role and outbound connectivity before changing permissions.
6. Allocate one Elastic IP and associate it with the instance, or reuse the current IP. In Hostinger hPanel, open the domain's DNS zone. Set only A record **synergyai** to that IP with TTL 300. Preserve the main website and all MX/TXT/mail records. For this deployment the address was `13.204.133.193`; recheck it before changing DNS.
7. Check the authoritative nameservers and a public resolver. DNS must point to the server before certificate issuance. Do not mistake propagation or a cached page for a failed app.
8. In **EC2 → Instances**, tick the SYnerGY instance, click **Connect → Session Manager → Connect**. The Connect button is disabled until an instance is selected. A private command session opens. Do not switch to public SSH as a workaround.

## Install the first release on a clean host

9. Install Docker Engine and Compose from the approved distribution packages. Inspect the source archive and checksum, then upload/extract it into `/srv/synergy`. Keep the prior package for recovery. Do not execute a downloaded install script without reading it.
10. On a genuinely new host only, run the supplied configuration script with the HTTPS domain, certificate email and owner username. It creates a private `.env` and `secrets/invite-code.txt`. Use a long random invitation code. Keep files mode 600. Never include these files in a reusable source ZIP.
11. Build the supplied Dockerfile. The deployment uses separate web and media Python environments and UID 10001. A build issue encountered previously was a restricted PATH: use `/usr/sbin/useradd` explicitly. Do not run the app as root to bypass persistent-volume permission errors; ensure UID 10001 owns the data directories.
12. Read model licences and run the supplied model setup. Ollama serves Aerny profiles using Qwen models. Image/video inference uses separately downloaded compatible weights. An installed chat model does not generate images. Model weights live in persistent volumes, not the source archive. Do not enable a paid provider or GPU without authority.
13. Start the app, Operations worker, Beast worker, Ollama and Caddy. For the voice release, also build the pinned OpenJarvis voice image, run `voice-setup` once, and start the private voice service using `compose.voice.yaml`. Model files are downloaded into `synergy_voice_models`; the voice worker reads them offline. No additional public port is needed.
14. Let Caddy obtain and renew HTTPS certificates. Verify the HTTPS hostname, HTTP redirect, certificate chain and `/healthz`. Inspect service health and restricted public ports. A healthy homepage alone does not establish that inference works.
15. The owner registers with their own username/password and invitation code. The code is available privately through `sudo cat /srv/synergy/secrets/invite-code.txt`. Do not print it into reports. Accounts created on a separate Mac are not automatically present on a new cloud deployment; migration requires an explicit, compatible data transfer.

## Upgrade an existing deployment without resetting logins

16. Inspect current versions, source changes, free disk/RAM, running jobs and Compose volume mappings. Record the running image IDs. Check all workers before restart; let active jobs finish or obtain cancellation authority. Stage/build the new release while the old app continues running.
17. Retain `.env`, the invitation-code file, the Compose project name **synergy**, the data path `/var/lib/synergy`, and existing named volumes. Never run `docker compose down -v`, delete `accounts.sqlite3`, regenerate secrets, or re-run first-host configuration during an upgrade.
18. Create a private backup after stopping all data writers. Include SQLite, saved files and a separate environment/config copy. `deploy/manage.py backup` supports this sequence. Keep the old Docker image and source. Restore-test the archive into an isolated empty volume; check file hashes and SQLite integrity. Same-disk backups do not protect against disk loss.
19. Apply additive, transactional, idempotent migrations. Preserve `users` (including salts/password hashes) and `sessions` (token hashes/expiry). Compare every pre-existing row without printing secrets. Add fields/tables rather than rebuilding authentication. A valid browser cookie must resolve after restart; an already expired cookie still needs a normal sign-in, never a password reset.
20. Start the candidate against an isolated test database first. Check all three modes, project ownership, uploads, downloads and voice. Create new model aliases without deleting the previous ones. Switch only the application services to the verified image, keeping the same persistent volumes and Caddy domain.
21. Verify the live version, an existing session and login, saved conversations, project persistence, cross-account denial, and one real speech-to-text → assistant → text-to-speech request. Voice microphone permission is a browser permission, separate from the account login. Report synthetic-audio tests separately from a person's microphone test.
22. If the candidate fails, restore the previous source/config and Docker image while retaining data. Additive schema changes can remain only when the prior release tolerates them. If a data restore is required, stop every writer, preserve the current volume, restore into a new empty volume and verify before routing traffic. Do not overwrite live data blindly.

## Finish with evidence

Return the live URL, app/profile versions, actual components, checks performed, saved source, recovery instructions and remaining limits. Distinguish real generation from mocks or screenshots. Keep the customer-facing service free; hosting costs are separate. The current AWS connection in this chat does not automatically become an executable AWS plugin inside SYnerGY.
