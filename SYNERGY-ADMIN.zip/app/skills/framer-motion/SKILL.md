---
name: framer-motion-tutorials
description: Build React interface animations using the Net Ninja Framer Motion course examples. Use for iamshaunjp/framer-motion setup, motion variants, staggered entrances, hover effects, route transitions, modals and loaders.
---

# Framer Motion Tutorials

Use https://github.com/iamshaunjp/framer-motion as a teaching reference, not as the official animation library. Locate an existing checkout or clone with `gh repo clone iamshaunjp/framer-motion`; fall back to `git clone https://github.com/iamshaunjp/framer-motion.git` if gh is unavailable.

## Locate examples

The default master branch contains only a README. List remote lesson branches and select the required lesson. For the inspected completed example, fetch `lesson-18` and check it out on a local branch. Preserve any existing user changes and do not switch a dirty checkout without resolving them.

Read `pizzajoint/package.json` and components in `pizzajoint/src/components/`. The inspected course uses React 16, react-router-dom 5, react-scripts 3 and framer-motion 1.10.3. Treat these as historical examples. Do not downgrade a modern website to match them. Inspect the actual target project's dependencies and current official Motion documentation before adapting APIs.

## Implement animations

1. Identify the target component, user action and final visual state.
2. Read relevant examples: Header/Home for entrances, Base/Toppings for interactive selections, Modal for presence transitions, Loader for repeating motion, and App for routing.
3. Adapt motion elements, named variants, transitions and stagger timing to the target project's installed API. Match parent and child variant labels. Keep stable keys for exits and use the presence API supported by the installed version.
4. Animate transforms and opacity where practical. Honor reduced motion, preserve keyboard focus and keep interactive controls accessible. Avoid delaying access to navigation or essential content.
5. For Next.js, place hook-driven motion in a client component and preserve server rendering elsewhere.
6. Run the project's available build/checks and inspect mobile layout, route exits, rapid interactions and reduced-motion behavior.

For running the historical demo, install its lockfile dependencies in `pizzajoint/` and use its declared scripts. Report cloning, dependency installation and successful build separately. Do not modify the user's main website merely because examples were requested.
