/* Server entitlements are authoritative; this module only presents them. */
(function(root){'use strict';
 function selection(me,mode='chat',family='eternal'){
  const access=me.membership||{};
  return {mode:access[mode]?mode:'chat',family:(!access[mode]||mode==='chat')&&me.chat_model==='aerny'?'aerny':family,work:me.extension_work===true};
 }
 const api={selection};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.SynergyExtensionAccess=api;
})(globalThis);
