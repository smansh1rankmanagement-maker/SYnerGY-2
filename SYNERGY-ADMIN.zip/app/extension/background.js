'use strict';
importScripts('browser-control.js');
const ORIGIN = 'https://synergyai.1rank.in';
chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
chrome.runtime.onInstalled.addListener(()=>chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}));
chrome.runtime.onStartup.addListener(()=>chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}));
chrome.runtime.onMessageExternal.addListener((message,sender,respond)=>{
  if (!sender.url || new URL(sender.url).origin!==ORIGIN || sender.id) return false;
  if (!['synergy-pair-start','synergy-pair-complete','synergy-extension-status','synergy-extension-repair'].includes(message?.type)) return false;
  (async()=>{
    if(['synergy-extension-status','synergy-extension-repair'].includes(message.type)){
      const repair=message.type==='synergy-extension-repair';
      if(repair)await chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true});
      const version=chrome.runtime.getManifest().version,{synergyToken}=await chrome.storage.local.get('synergyToken');
      if(!synergyToken)return {version,connected:false,repaired:repair};
      const r=await fetch(ORIGIN+'/api/extension/me',{credentials:'omit',headers:{Authorization:'Bearer '+synergyToken}});
      if(r.status===401){if(repair)await chrome.storage.local.remove(['synergyToken','synergyConversation']);return {version,connected:false,repaired:repair,reason:'Pairing expired or revoked'};}
      if(!r.ok)throw Error('SYnerGY is temporarily unavailable. Your saved connection was retained.');
      const me=await r.json();return {version,connected:true,account_id:me.account_id,username:me.username,repaired:repair};
    }
    if(message.type==='synergy-pair-start'){
      const challenge=crypto.randomUUID();
      await chrome.storage.session.set({pairChallenge:{challenge,expires:Date.now()+180000}});
      return {challenge,version:chrome.runtime.getManifest().version};
    }
    const {pairChallenge}=await chrome.storage.session.get('pairChallenge');
    if(!pairChallenge||pairChallenge.challenge!==message.challenge||pairChallenge.expires<Date.now()) throw Error('Connection request expired. Click Connect extension again.');
    await chrome.storage.session.remove('pairChallenge');
    if(!/^sgx_[A-Za-z0-9_-]{40,80}$/.test(message.token||'')) throw Error('Invalid connection code.');
    const r=await fetch(ORIGIN+'/api/extension/me',{credentials:'omit',headers:{Authorization:'Bearer '+message.token}});
    if(!r.ok) throw Error('Connection could not be verified. Try again from SYnerGY.');
    const me=await r.json();
    await chrome.storage.local.remove('synergyConversation');
    await chrome.storage.local.set({synergyToken:message.token});
    return {connected:true,username:me.username};
  })().then(respond,e=>respond({error:e.message}));
  return true;
});

// Durable Chrome alarms: no open side panel required. API ownership is rechecked on delivery.
let workSync=Promise.resolve();
async function workData(){const {synergyToken}=await chrome.storage.local.get('synergyToken');if(!synergyToken)return null;const headers={Authorization:'Bearer '+synergyToken};const me=await fetch(ORIGIN+'/api/extension/me',{headers,credentials:'omit'});if(!me.ok)return null;const identity=await me.json();if(!identity.extension_work)return null;const r=await fetch(ORIGIN+'/api/extension/work',{headers,credentials:'omit'});if(!r.ok)return null;const data=await r.json();if((await chrome.storage.local.get('synergyToken')).synergyToken!==synergyToken)return null;return {...data,account:identity.account_id,token:synergyToken};}
async function syncWork(){const data=await workData();const alarms=await chrome.alarms.getAll();if(!data){for(const a of alarms)if(a.name.startsWith('meeting:'))await chrome.alarms.clear(a.name);return;}
 const desired=new Map(),now=Date.now(),stored=await chrome.storage.local.get('meetingDelivered');const delivered=stored.meetingDelivered||{};
 for(const item of data.items.filter(x=>x.kind==='meeting'&&!x.done)){const when=Date.parse(item.start);const name='meeting:'+data.account+':'+item.id+':'+item.revision;if(Number.isFinite(when)&&when>now-15*60000&&!delivered[name])desired.set(name,Math.max(when,now+1000));}
 for(const a of alarms)if(a.name.startsWith('meeting:')&&!desired.has(a.name))await chrome.alarms.clear(a.name);
 for(const [name,when]of desired)if(!alarms.some(a=>a.name===name))await chrome.alarms.create(name,{when});
}
const queueSync=()=>workSync=workSync.catch(()=>{}).then(syncWork);
chrome.runtime.onMessage.addListener((m,sender,reply)=>{if(sender.id!==chrome.runtime.id||m?.type!=='work-sync')return false;queueSync().then(()=>reply({ok:true}),()=>reply({ok:false}));return true;});
chrome.runtime.onInstalled.addListener(()=>{chrome.alarms.create('work-sync',{periodInMinutes:1});queueSync().catch(()=>{});});
chrome.runtime.onStartup.addListener(()=>{chrome.alarms.create('work-sync',{periodInMinutes:1});queueSync().catch(()=>{});});
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.synergyToken){chrome.notifications.getAll().then(n=>Promise.all(Object.keys(n).filter(k=>k.startsWith('meeting:')).map(k=>chrome.notifications.clear(k))));queueSync().catch(()=>{});}});
chrome.alarms.onAlarm.addListener(async alarm=>{try{if(alarm.name==='work-sync'){await queueSync();return;}const match=/^meeting:(\d+):([a-f0-9]{32}):(\d+)$/.exec(alarm.name);if(!match)return;const data=await workData();if(!data||data.account!==Number(match[1]))return;const item=data.items.find(i=>i.id===match[2]&&i.revision===Number(match[3])&&i.kind==='meeting'&&!i.done);if(!item||Math.abs(Date.now()-Date.parse(item.start))>15*60000)return;const stored=await chrome.storage.local.get('meetingDelivered'),delivered=stored.meetingDelivered||{};if(delivered[alarm.name])return;
 await chrome.notifications.create(alarm.name,{type:'basic',iconUrl:'icon.png',title:'SYNERGY meeting reminder',message:'Your scheduled meeting is starting. Click to open your meeting.',priority:1});delivered[alarm.name]=Date.now();await chrome.storage.local.set({meetingDelivered:Object.fromEntries(Object.entries(delivered).filter(([,t])=>Date.now()-t<2*86400000).slice(-500))});
 }catch{/* Next sync recovers an unacknowledged reminder; no private API errors in notifications. */}});
chrome.notifications.onClicked.addListener(async id=>{try{const parts=id.split(':');if(parts[0]!=='meeting')return;const data=await workData();if(!data||data.account!==Number(parts[1]))return;const item=data.items.find(i=>i.id===parts[2]&&i.revision===Number(parts[3]));if(!item)return;const url=/^https:\/\/meet\.google\.com\/[a-z]{3}-[a-z]{4}-[a-z]{3}$/.test(item.meet_url||'')?item.meet_url:ORIGIN+'/settings?section=extension';await chrome.tabs.create({url});await chrome.notifications.clear(id);}catch{}});
