# SYnerGY browser tasks — extension 1.8.0 / runtime 3.0.6

Install/update
1. Extract SYnerGY-Chrome-Extension-1.8.0.zip into a permanent folder. For an existing unpacked installation, replace the files in its existing folder, retaining a backup.
2. Open chrome://extensions and press Reload on SYnerGY. For first installation, use Developer mode → Load unpacked and select the extracted folder. Chrome must approve the declared debugger permission. Its debugging notice remains visible.
3. Refresh https://synergyai.1rank.in and sign in. The installed extension pairs with this account through the existing challenge and scoped bearer flow. An extension paired to a different account requires explicit reconnection in Settings → Extension.
4. Choose Connect browser → Choose tabs. Grant access only to the sites selected. The first selected tab is the default; activating another authorised tab makes it the default. Only a successful page read changes the browser status to Connected.

Use directly in chat
- Open my selected test website, fill its sample form and inspect console errors.
- Fill "Name" with "Smansh" on my selected tab.
- Read my selected tab and summarise it in three points.
- Inspect console errors and failed network requests on my selected tab.
- Scroll down on my selected tab.
- Take a screenshot of my selected tab.
- Click "Preview sample" on my selected tab.

The included test page is https://synergyai.1rank.in/browser-test.html. Select that tab once, then send the sample request in normal SYnerGY chat. It uses synthetic Name, Email and Message values and never submits the form. The page intentionally produces console errors and a failed request for diagnostic verification. Never use real credentials in this fixture.

Control and connection
Pause prevents subsequent steps and invalidates outstanding tickets. Stop cancels and revokes the selected session, clears the local selection, and detaches diagnostics. A synchronous click already dispatched cannot be undone. Inspect an uncertain result before retrying. Resume allows a fresh observed action; it does not replay an interrupted write. The current task and target appear in chat and the extension control page.

Same-browser sessions reconnect through stored session state and server heartbeat. Host grants alone do not authorise another tab. Authorisation renews while the connected chat is available; a long disconnection, Chrome restart, closed tab, origin change or revoked pairing requires fresh selection. The browser and device must remain running; browser tasks do not run while the device sleeps. Closing the SYnerGY chat interrupts its browser task loop. Backend-only workflows remain separate.

Safety and limits
Only fixed, validated operations run; no arbitrary page/model JavaScript, cookies, request headers or response bodies are exposed. Sensitive pages and password, hidden, payment, OTP, token and credential fields are excluded. Page text is untrusted and cannot grant action authority. Normal input values are omitted from page observations; fill verification returns a boolean. Console/network output contains error metadata, counts, resource types, status and origin, not message arguments or request payloads. Screenshots are withheld when editable, embedded, canvas or explicitly private content is visible; image pixels are displayed to the user and are not sent in the model context.

Clicks use an exact-action review in chat. Purchases, money transfers, sign-in, contracts and destructive controls remain manual. Navigation stays on the selected origin and rejects credential-bearing URLs and query strings. The planner supports explicit labelled fills, synthetic sample forms, reads, same-origin navigation, scrolling, screenshots and diagnostics. Ambiguous fields need exact labels; unsupported form controls and arbitrary multistep web workflows are not promised. Local ETERNAL/Aerny may map a quoted user value to a visible field, but cannot invent personal data or broaden access. At most 16 planned steps run per request.

Diagnostics attach before the requested sample navigation so load-time errors can be captured. Existing errors emitted before attachment cannot be recovered. DevTools or another debugger can block attachment; resolve the conflict in Chrome without suppressing its notices.

Existing Chat, Work, Notes, To-do, Leads, Meetings, reminders and account/subscription checks are retained. Desktop Commander remains the existing server-scoped integration; it is not used to bypass browser permissions.


## Earlier extension features

# SYnerGY for Chrome 1.3

1. Extract this ZIP to a permanent folder.
2. Open `chrome://extensions` in Chrome and enable Developer mode.
3. Select **Load unpacked** and choose the folder containing `manifest.json`.
4. Sign in at https://synergyai.1rank.in and open **Profile → Settings → Extension**.
5. Click **Connect extension**. If direct pairing is unavailable, use the private pairing code in the side panel. Never enter your website password as a pairing code.
6. Pin SYnerGY and click its icon on the webpage you want to use.

New sessions start with **ETERNAL Work**, with model choice ETERNAL/Aerny and Low,
Medium, High, Max, Ultra response levels. Low maps to the server's Instant budget.
Work and Beast require the account's active subscription; Chat is free. Saved
conversation modes and deliberate selections are retained. The extension does
not inherit a ChatGPT account or subscription.

Page text is read only after an explicit capture, then sent only with your
message. Review the excerpt and captured lead details before sending or saving.
This release keeps the existing extension identity and permissions.

## Updating and repair

Download the current ZIP from SYnerGY **Settings → Extension**. Replace the files
in the same installed folder, then click **Reload** in `chrome://extensions`.
Chrome requires this user action for unpacked extensions; the website cannot
silently install or replace extension code.

**Check connection** compares the installed version and paired account.
**Repair connection** restores side-panel behaviour and checks the saved token;
only an explicitly expired/revoked token is cleared. Temporary server errors
retain the connection. Reconnect from the signed-in website if needed.

Use **Report an extension issue** for a tracked repair request. Administrators can
prepare changes in the private ETERNAL source workspace, review the diff, test
the extension and deploy a new version. A proposed patch is not a verified fix.

Tokens stay in trusted extension storage and are never returned to web pages.
Pairing expires after 30 days and can be revoked without resetting your password.
The extension attachment limit is 8 MiB; use the main workspace for 200 MiB uploads.

## Version 1.5.0

- Google opens the query you typed in a new tab. Capture and review a result before sharing it.
- Provider availability follows the server, without the obsolete Chat or 30-day-plan lock. External privacy opt-in, actual credits and your mode entitlement still apply.
- Backend web research tries Firecrawl, then direct public search and readable sources. It does not read your other browser tabs automatically.
- Existing extension ID and pairing remain unchanged. Download the update from SYnerGY Settings → Extension and reload the unpacked extension.

## Version 1.6.0 — Work

The Work tab provides account-owned Notes, To-do, Leads and Meetings. Meeting reminders use Chrome alarms/notifications; Chrome must remain running and OS notifications allowed. Closing the side panel is supported. Restart/sleep may delay a reminder; reminders older than 15 minutes are not replayed. Expired/revoked accounts do not receive private reminders.

Connect an installed extension using Add extension → Connect on the signed-in website. First installation cannot happen silently. Until a Chrome Web Store listing exists, expand advanced setup, download and extract once, Load unpacked in chrome://extensions and return to Connect. Updates retain the same extension ID and pairing; reload the existing folder after replacing its files. New notification permission may require Chrome approval. Website Settings → Extension retains revocation.

Google Calendar requires a server-configured OAuth Web client and each user's consent. Without it, Review in Google Calendar opens a prefilled event for manual saving. With it, Save to Google Calendar creates/updates the reviewed meeting and requests a Google Meet link. The API does not send guest invitations. Delete a saved SYNERGY meeting to cancel its local reminder; remove its Google event separately in Calendar.

## Access in 1.6.1

The Work toolbar (Notes, To-do, Leads, Meetings) is included during the seven-day Chat trial and with any active subscription. At expiry, Work locks and its saved records are retained. Chat switches to permanently free Aerny 2.0; free Hybrid may use eligible external services with consent and local fallback. The website Work/Beast model modes still require their respective plans. The server checks access on every request and before reminder delivery. Refresh/update the extension for correct labels.

## Browser control pilot — extension 1.7.2
Download the extension from Settings > Chrome extension. Existing unpacked installs: replace files in the existing folder, open chrome://extensions, and click Reload for SYnerGY. Preserve its extension ID. There is no Chrome Web Store auto-update release.
In the extension click Connect browser > Choose tabs. Grant tab discovery, select up to ten tabs, then grant access only to selected origins. Connection is shown only after a successful page read. Sessions expire after 15 minutes.
From SYnerGY chat (ETERNAL or Aerny, any mode), use:
- Read this page and summarise it.
- Compare these two selected tabs.
- Fill "Name" with "Your supplied value" on this page.
- Click "Sample action" on this page. Review the click in the extension control tab before it runs.
- Inspect console errors and failed network requests on this page. Click Allow diagnostics in browser controls first; reproduce the issue after attaching.
- Scroll down 500 on this page.
- Navigate this tab to https://example.com/path (same selected origin only).
Use Pause or Stop; Stop detaches diagnostics. Chat can remain usable with permissions declined.
Limitations: top-level standard HTML only; no cross-origin frames, shadow-DOM traversal, password/payment pages, form submissions or automatic login. Click confirmation expires after 30 seconds. Screenshots require an active tab and Chrome capture permission, and are refused on pages with fields/iframes. Diagnostics report error kinds/statuses without console arguments, headers, request bodies or credentials; only events after attachment are available.
Device/browser must stay awake. No blind retries after uncertain actions. On debugger detachment or session expiry reconnect and observe again. Browser source excerpts sent to the selected model are bounded to 3,800 characters and are untrusted data, not instructions.
Desktop Commander is separate: the existing server-scoped connector does not give access to your personal Mac/Windows files or Chrome tabs.

1.7.1 fixes startup: Chrome requires debugger in the required permissions list. Chrome shows that permission at installation/update. Diagnostics additionally require Allow diagnostics in the browser controls and remain selected-tab-only. The exact shipping manifest startup test passed.

1.7.2 fixes checkbox collection in Connect selected tabs. The real Chrome UI test covers no selection, tab discovery, selected-tab connection and verified page read; its lease API is stubbed and backend isolation is tested separately.
