/* Isolated-world, packaged operations only. No eval, cookies, storage or arbitrary JS. */
(()=>{'use strict';if(globalThis.__synergyPage?.version==='1.8.0')return;
 let refs=new Map(),observation='',observed=0,revision=0;
 const secret=/password|secret|token|cookie|credential|one.?time|credit.?card|cvv|\botp\b|bank.?account|private.?key/i;
 const sensitive=e=>e.matches('input[type=password],input[type=hidden],input[type=file],[autocomplete*=password],[autocomplete^="cc-"],[autocomplete="one-time-code"],[data-private],[data-sensitive]')||secret.test([e.name,e.id,e.getAttribute('aria-label'),e.getAttribute('autocomplete')].join(' '));
 const clean=s=>String(s||'').replace(/\b(?:sk-[\w-]{12,}|AIza[\w-]+|Bearer\s+\S+|sgx_[\w-]+|eyJ[\w-]+\.[\w-]+\.[\w-]+)\b/g,'[redacted]').replace(/(?:password|token|secret|api[_ -]?key|cookie|authorization)\s*[:=]\s*[^\s,;]+/gi,'[redacted]').slice(0,12000);
 const visible=e=>e&&e.getClientRects().length>0&&!e.closest('[hidden],[aria-hidden="true"]')&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
 const safe=()=>{if(document.querySelector('input[type=password],input[autocomplete^="cc-"]')||/\/login|\/signin|\/checkout|\/payment|\/banking|\/oauth|\/api-keys/i.test(location.pathname))throw Error('Sensitive page: use the website directly');};
 const label=e=>clean(e.getAttribute('aria-label')||e.labels?.[0]?.innerText||e.innerText||e.placeholder||e.name||'').trim().slice(0,150);
 const fingerprint=e=>[e.tagName,e.type,e.name,e.id,label(e),e.getAttribute('href'),e.getAttribute('formaction')].join('|');
 new MutationObserver(()=>revision++).observe(document.documentElement,{subtree:true,childList:true,attributes:true,characterData:true});
 function read(){safe();refs=new Map();observation=crypto.randomUUID();observed=Date.now();const elements=[];
  for(const e of document.querySelectorAll('a,button,input,textarea,select,[role=button]')){if(elements.length>=150)break;if(!visible(e)||sensitive(e))continue;const ref='e'+(elements.length+1);refs.set(ref,{node:e,fingerprint:fingerprint(e)});elements.push({ref,tag:e.tagName.toLowerCase(),type:e.type||'',label:label(e),disabled:!!e.disabled});}
  const chunks=[],walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;while((n=walker.nextNode())&&chunks.join(' ').length<12000){const p=n.parentElement;if(!p||p.closest('script,style,input,textarea,select,iframe,canvas,[contenteditable],[data-private],[data-sensitive]')||!visible(p)||sensitive(p)||secret.test(p.id||''))continue;const text=n.textContent.trim();if(text)chunks.push(text);}
  return {verified:true,observation,url:location.origin+location.pathname,title:clean(document.title),text:clean(chunks.join(' ')),elements,untrusted:true,revision};
 }
 async function run(c){safe();const a=c.args||{};
  if(c.tool==='browser_read_page')return read();
  if(c.tool==='browser_scroll'){const before=scrollY;scrollBy({top:a.pixels,behavior:'instant'});await new Promise(r=>requestAnimationFrame(r));return {verified:true,scrolled:scrollY!==before,page:read()};}
  if(c.tool==='browser_screenshot'){if([...document.querySelectorAll('input,textarea,[contenteditable],iframe,canvas,[data-private],[data-sensitive]')].some(visible))throw Error('Screenshot withheld: editable, embedded or private content is visible');return {verified:true};}
  if(c.tool==='browser_fill'||c.tool==='browser_click'){
   if(a.observation!==observation||Date.now()-observed>30000)throw Error('Stale observation; read the page again');
   const saved=refs.get(a.ref),e=saved?.node;
   if(!e?.isConnected||!visible(e)||sensitive(e)||e.disabled||fingerprint(e)!==saved.fingerprint)throw Error('Element changed; observe again');
   const rect=e.getBoundingClientRect();if(rect.bottom<0||rect.top>innerHeight)e.scrollIntoView({block:'center'});
   const box=e.getBoundingClientRect(),top=document.elementFromPoint(Math.max(0,Math.min(innerWidth-1,box.x+box.width/2)),Math.max(0,Math.min(innerHeight-1,box.y+box.height/2)));
   if(top&&!e.contains(top)&&!top.contains(e))throw Error('Element is obscured; inspect the page');
   observation=''; // Consume before dispatch: never replay a write.
   if(c.tool==='browser_fill'){
    if(!e.matches('input:not([type]),input[type=text],input[type=email],input[type=search],input[type=tel],input[type=url],textarea'))throw Error('Unsupported or sensitive field');
    if(secret.test(a.value)||/\b(?:sgx_|sk-|AIza|eyJ)/.test(a.value))throw Error('Sensitive values must be entered by you');
    const setter=Object.getOwnPropertyDescriptor(e.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,'value').set;
    setter.call(e,a.value);e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));
    await new Promise(r=>setTimeout(r,120));return {verified:e.isConnected&&e.value===a.value,field:label(e),page:read()};
   }
   if(a.approved!==true)throw Error('This exact click needs approval');
   if(/buy|pay|purchase|transfer|delete|remove account|sign.?in|log.?in|sign contract/i.test(label(e)))throw Error('Complete this consequential action directly on the website');
   if(e.matches('a[href]')){const u=new URL(e.href,location.href);if(!/^https?:$/.test(u.protocol)||u.origin!==location.origin||u.username||u.password)throw Error('Select the destination tab first');if(e.target==='_blank')throw Error('Open and select the destination tab first');}
   const before=revision;e.click();await new Promise(r=>setTimeout(r,180));return {actionDispatched:true,verified:revision!==before,notice:revision!==before?'Page changed after click; inspect the result.':'Click dispatched but outcome is uncertain. Do not retry automatically.',page:read()};
  }
  throw Error('Unsupported page operation');
 }
 globalThis.__synergyPage={version:'1.8.0',run};
})();
