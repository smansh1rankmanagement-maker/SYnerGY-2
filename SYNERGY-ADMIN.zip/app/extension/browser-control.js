'use strict';
const BC_ORIGIN='https://synergyai.1rank.in';const diagnostics=new Map();let bcBusy=false,bcBlocked=false,bcWrites=Promise.resolve();
const bcState=async()=>(await chrome.storage.session.get('browserControl')).browserControl;
async function bcSave(s){const write=bcWrites.catch(()=>{}).then(async()=>{const current=await bcState();if(current&&current.epoch>s.epoch)throw Error('Cancelled by a newer browser control');await chrome.storage.session.set({browserControl:s});});bcWrites=write;return write;}
async function bcApi(path,data){const {synergyToken}=await chrome.storage.local.get('synergyToken');if(!synergyToken)throw Error('Pair your signed-in SYnerGY account first');const r=await fetch(BC_ORIGIN+'/api/extension/browser/'+path,{method:'POST',credentials:'omit',headers:{Authorization:'Bearer '+synergyToken,'Content-Type':'application/json'},body:JSON.stringify(data),signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error(r.status===401?'Pairing expired or revoked':(await r.json()).detail||'Browser request denied');return r.json();}
async function bcIdentity(){const {synergyToken}=await chrome.storage.local.get('synergyToken');if(!synergyToken)throw Error('Pair your account first');const r=await fetch(BC_ORIGIN+'/api/extension/me',{headers:{Authorization:'Bearer '+synergyToken},credentials:'omit',signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error('Reconnect your signed-in account');return r.json();}
const normalTab=t=>{try{const u=new URL(t.url);return !t.incognito&&['http:','https:'].includes(u.protocol)&&!u.username&&!u.password&&!['chromewebstore.google.com','accounts.google.com'].includes(u.hostname);}catch{return false;}};
async function bcCheck(epoch){const s=await bcState();if(bcBlocked||!s||s.paused||s.epoch!==epoch||s.expires*1000<Date.now())throw Error('Browser stopped, paused or unavailable');return s;}
async function bcTab(id,epoch){const s=await bcCheck(epoch);if(!s.tabs.includes(id))throw Error('Tab was not selected');const t=await chrome.tabs.get(id);if(!normalTab(t)||new URL(t.url).origin!==s.origins[id])throw Error('Tab closed or navigated outside its authorised origin; select it again');if(!await chrome.permissions.contains({origins:[s.origins[id]+'/*']}))throw Error('Site permission was removed');return t;}
async function bcPage(id,command,epoch){await bcTab(id,epoch);await chrome.scripting.executeScript({target:{tabId:id},files:['browser-page.js']});await bcTab(id,epoch);const rows=await chrome.scripting.executeScript({target:{tabId:id},func:async c=>{try{return {value:await globalThis.__synergyPage.run(c)};}catch(e){return {error:e.message};}},args:[command]});await bcCheck(epoch);if(rows[0]?.result?.error)throw Error(rows[0].result.error);if(!rows[0]?.result?.value)throw Error('Page did not respond; observe before retrying');return rows[0].result.value;}
async function bcDetachDiagnostics(){for(const id of diagnostics.keys()){try{await chrome.debugger.detach({tabId:id});}catch{}}diagnostics.clear();}
async function bcControl(action){if(action!=='resume')bcBlocked=true;const s=await bcState();if(!s)return {state:'stopped'};const next={...s,paused:action!=='resume',epoch:(s.epoch||0)+1,activeTask:null};await bcSave(next);await bcDetachDiagnostics();if(action==='stop'){next.stopped=true;next.tabs=[];next.verified=false;await bcSave(next);}try{await bcApi('control',{lease:s.lease,action});}catch(e){if(action==='resume')throw e;}if(action==='resume'){next.paused=false;next.verified=false;await bcSave(next);bcBlocked=false;}return {state:action};}
async function bcAttach(id,epoch){await bcPage(id,{tool:'browser_read_page'},epoch);if(diagnostics.has(id))return;await chrome.debugger.attach({tabId:id},'1.3');diagnostics.set(id,{console:[],network:[],started:Date.now()});try{await bcCheck(epoch);await chrome.debugger.sendCommand({tabId:id},'Runtime.enable');await chrome.debugger.sendCommand({tabId:id},'Network.enable');}catch(e){await chrome.debugger.detach({tabId:id}).catch(()=>{});diagnostics.delete(id);throw e;}}
async function bcExecute(c,epoch){const id=c.tab_id;await bcTab(id,epoch);
 if(c.tool==='browser_list_authorised_tabs'){const s=await bcCheck(epoch),tabs=[];for(const tid of s.tabs){try{const t=await bcTab(tid,epoch);tabs.push({id:t.id,title:t.title.slice(0,120),url:new URL(t.url).origin});}catch{}}return {verified:true,tabs};}
 if(c.tool==='browser_detach'){await bcControl('stop');return {verified:true,detached:true};}
 if(c.tool==='browser_navigate'){
  const t=await bcTab(id,epoch),u=new URL(c.args.url);if(u.origin!==new URL(t.url).origin||!['http:','https:'].includes(u.protocol)||u.username||u.password||u.search||u.hash)throw Error('Select the destination origin first');
  await chrome.tabs.update(id,{url:u.href});const deadline=Date.now()+15000;while(Date.now()<deadline){await bcCheck(epoch);const current=await bcTab(id,epoch);if(current.status==='complete'){try{const p=await bcPage(id,{tool:'browser_read_page'},epoch);if(p.url===u.origin+u.pathname)return {verified:true,page:p};}catch(e){if(/stopped|paused|authoris|Sensitive/.test(e.message))throw e;}}await new Promise(r=>setTimeout(r,200));}throw Error('Navigation outcome is uncertain; inspect before retrying');
 }
 if(c.tool==='browser_diagnostics_start'){await bcAttach(id,epoch);return {verified:true,capturing:true,notice:'Captures new events. Chrome’s debugging notice remains visible.'};}
 if(['browser_console_errors','browser_network_failures'].includes(c.tool)){await bcAttach(id,epoch);await new Promise(r=>setTimeout(r,150));await bcCheck(epoch);const d=diagnostics.get(id);return {verified:true,events:c.tool==='browser_console_errors'?d.console:d.network,since:d.started,notice:'Error metadata only; argument values, request headers, bodies, cookies and tokens are excluded.'};}
 if(c.tool==='browser_screenshot'){await bcPage(id,c,epoch);const attached=diagnostics.has(id);await bcAttach(id,epoch);try{await bcPage(id,c,epoch);const r=await chrome.debugger.sendCommand({tabId:id},'Page.captureScreenshot',{format:'jpeg',quality:65,captureBeyondViewport:false});await bcCheck(epoch);return {verified:true,image:'data:image/jpeg;base64,'+r.data};}finally{if(!attached){await chrome.debugger.detach({tabId:id}).catch(()=>{});diagnostics.delete(id);}}}
 return bcPage(id,c,epoch);
}
async function bcCommand(ticket){if(bcBusy)throw Error('Another browser action is running');bcBusy=true;let s;try{s=await bcState();if(!s||ticket?.lease!==s.lease||ticket.device!==s.device||ticket.session!==s.session||ticket.expires*1000<Date.now())throw Error('Wrong or expired browser session');const claimed=await bcApi('claim',{...ticket,secret:s.secret});s=await bcCheck(s.epoch);s.activeTask={tool:claimed.command.tool,tab:claimed.command.tab_id};await bcSave(s);const result=await bcExecute(claimed.command,s.epoch);await bcCheck(s.epoch);await bcApi('complete',{...ticket,secret:s.secret,verified:result.verified===true});s=await bcCheck(s.epoch);s.verified=result.verified===true;s.lastVerified=Date.now();s.activeTask=null;await bcSave(s);return {result};}finally{bcBusy=false;}}
async function bcStatus(account){const s=await bcState();if(!s||s.stopped)return {connected:false,paired:!!(await chrome.storage.local.get('synergyToken')).synergyToken,reason:'Choose tabs to authorise browser tasks'};if(account!==s.account_id)return {connected:false,accountMismatch:true,reason:'Extension is paired to another account'};let heartbeat;try{heartbeat=await bcApi('heartbeat',{lease:s.lease,device:s.device,session:s.session,secret:s.secret});}catch{return {connected:false,reason:'Browser or server unavailable; the device may be asleep or disconnected'};}s.expires=heartbeat.expires;s.paused=heartbeat.state==='paused';await bcSave(s);const tabs=[];for(const id of s.tabs){try{const t=await chrome.tabs.get(id);if(normalTab(t)&&new URL(t.url).origin===s.origins[id])tabs.push({id,title:t.title.slice(0,120),url:s.origins[id]});}catch{}}return {lease:s.lease,device:s.device,session:s.session,account_id:s.account_id,expires:s.expires,connected:s.verified&&!s.paused&&!bcBlocked&&tabs.length>0,paused:s.paused,verified:s.verified,tabs:tabs.map(t=>t.id),tabDetails:tabs,defaultTab:tabs.some(t=>t.id===s.defaultTab)?s.defaultTab:tabs.length===1?tabs[0].id:null,activeTask:s.activeTask,lastVerified:s.lastVerified};}
chrome.debugger.onEvent.addListener((src,method,p)=>{const d=diagnostics.get(src.tabId);if(!d)return;const origin=u=>{try{return new URL(u).origin;}catch{return undefined;}};
 if(method==='Runtime.exceptionThrown')d.console.push({kind:'JavaScript exception',line:p.exceptionDetails?.lineNumber,origin:origin(p.exceptionDetails?.url)});
 if(method==='Runtime.consoleAPICalled'&&p.type==='error')d.console.push({kind:'console.error',timestamp:p.timestamp});
 if(method==='Network.loadingFailed')d.network.push({kind:'request failed',resourceType:p.type,cancelled:!!p.canceled});
 if(method==='Network.responseReceived'&&p.response?.status>=400)d.network.push({kind:'HTTP error',status:p.response.status,resourceType:p.type,origin:origin(p.response.url)});
 d.console=d.console.slice(-50);d.network=d.network.slice(-50);
});
chrome.debugger.onDetach.addListener(src=>diagnostics.delete(src.tabId));
chrome.tabs.onActivated.addListener(async({tabId})=>{const s=await bcState();if(s?.tabs.includes(tabId)){s.defaultTab=tabId;await bcSave(s);}});
chrome.tabs.onRemoved.addListener(async id=>{diagnostics.delete(id);const s=await bcState();if(s?.tabs.includes(id)){s.tabs=s.tabs.filter(t=>t!==id);s.epoch++;s.verified=false;s.activeTask=null;await bcSave(s);}});
chrome.tabs.onUpdated.addListener(async(id,change)=>{if(!change.url)return;const s=await bcState();if(!s?.tabs.includes(id))return;if(new URL(change.url).origin!==s.origins[id]){s.tabs=s.tabs.filter(t=>t!==id);s.epoch++;s.verified=false;s.activeTask=null;await bcSave(s);if(diagnostics.has(id)){await chrome.debugger.detach({tabId:id}).catch(()=>{});diagnostics.delete(id);}}});
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.synergyToken){bcControl('stop').catch(()=>{});}});
chrome.runtime.onMessage.addListener((m,sender,reply)=>{if(sender.id!==chrome.runtime.id||!['browser.html','panel.html'].some(p=>sender.url===chrome.runtime.getURL(p)))return false;
 if(!m?.type?.startsWith('bc-'))return false;
 (async()=>{
  if(['bc-stop','bc-pause','bc-resume'].includes(m.type))return bcControl(m.type.slice(3));
  if(m.type==='bc-tabs')return {tabs:(await chrome.tabs.query({currentWindow:true})).filter(normalTab).map(t=>({id:t.id,title:t.title,url:new URL(t.url).origin}))};
  if(m.type==='bc-status'){const me=await bcIdentity();return bcStatus(me.account_id);}
  if(m.type==='bc-select'){
   const me=await bcIdentity(),tabs=[],origins={};if(!Array.isArray(m.tabs)||!m.tabs.length||m.tabs.length>10)throw Error('Select 1–10 tabs');
   for(const id of [...new Set(m.tabs)]){const t=await chrome.tabs.get(id);if(!normalTab(t))throw Error('Unsupported tab');tabs.push(id);origins[id]=new URL(t.url).origin;if(!await chrome.permissions.contains({origins:[origins[id]+'/*']}))throw Error('Grant access to the selected site');}
   await bcControl('stop');let {browserDevice}=await chrome.storage.local.get('browserDevice');if(!browserDevice){browserDevice=crypto.randomUUID();await chrome.storage.local.set({browserDevice});}
   const session=crypto.randomUUID(),lease=await bcApi('connect',{device:browserDevice,session,tabs});const s={...lease,device:browserDevice,session,tabs,origins,account_id:me.account_id,paused:false,epoch:Date.now(),verified:false,defaultTab:tabs[0]};delete s.probe;await bcSave(s);bcBlocked=false;const result=await bcCommand(lease.probe);return {connected:result.result.verified,observation:result.result};
  }
  throw Error('Unsupported browser control');
 })().then(reply,e=>reply({error:e.message}));return true;
});
chrome.runtime.onMessageExternal.addListener((m,sender,reply)=>{if(sender.id||sender.frameId!==0||!sender.url||new URL(sender.url).origin!==BC_ORIGIN||!['bc-status','bc-command','bc-choose','bc-stop','bc-pause','bc-resume'].includes(m?.type))return false;
 (async()=>{
  if(m.type==='bc-choose'){await chrome.tabs.create({url:chrome.runtime.getURL('browser.html')});return {selectTabs:true};}
  if(m.type==='bc-status')return bcStatus(m.account_id);
  const s=await bcState();if(!s||s.account_id!==m.account_id)throw Error('Wrong signed-in account');
  if(['bc-stop','bc-pause','bc-resume'].includes(m.type))return bcControl(m.type.slice(3));
  return bcCommand(m.ticket);
 })().then(reply,e=>reply({error:e.message}));return true;
});
