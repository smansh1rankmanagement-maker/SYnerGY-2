# SYnerGY Work mode 1.6.0

The first Brand Operations release is deployed on the existing Mac at http://127.0.0.1:8090/. It retains Chat, research, uploads, skills, image studio, video tools and saved projects. The app stays free: no subscriptions, prices or credits were added.

The source specification is preserved verbatim in `specifications/BRAND_OPERATIONS_USER_PROMPT.md`. This release implements the first bounded workflow. The wider specification remains the roadmap; the table below distinguishes what works now.

## Use

1. Sign in and choose **Work mode → Brand Operations**.
2. Select a brand. **Brands → Edit inputs** holds its brief, organisation/client details, audience, positioning, services, asset references, website authority, goals, projects, campaigns, approval contacts and retention period. Saving changes creates a new input revision and clears its approval.
3. Only approve the saved revision after reviewing it. An authorised website URL and the audit permission checkbox enable crawling. An email domain is not treated as permission.
4. **Team and knowledge** assigns existing registered users to the brand and stores sourced notes. Roles are enforced by the backend. Founder/admin owns the workspace; managers manage workflows; members handle internal records; client reviewers can review but cannot change workflows.
5. Create an automation in **Automations** or send `Create a weekly automation for InteriFY Monday at 09:00` in Work chat. This chat command creates the supported brand-review template. It is not an arbitrary workflow/code executor.
6. Review **Trigger → inputs → steps → approval points → outputs**, then activate the exact version. Use **Run now** for a manual execution.
7. **Run history → Inspect run** opens actual step state, errors, activity and saved downloads in the right preview. **Calendar** shows the seven drafts. Editing drafts creates a separate run with new files and a new review request; the previous files remain intact.
8. **Approvals** records a decision for the exact artifact hash/version. Approval does not publish, send or spend. Those external integrations are not enabled.

## Feature status

| Area | Implemented | Limits / remaining work |
| --- | --- | --- |
| Work chat | Existing Chat features plus automation creation and review links | Natural-language automation creation supports one fixed template; arbitrary task planning is later work |
| Brand workspaces | Brand fields, revisions, source references, backend membership, roles, knowledge records and history | Projects/campaigns/goals are structured workspace notes, not separate full project-management modules; asset references do not automatically import or approve logos |
| Interface | Overview, Brands, Agents, Automations, Calendar, Tasks, Approvals, Leads, Files and reports, Connections, Run history | No drag-and-drop workflow designer; dashboard is a first operational view |
| Automation engine | Persistent definitions and versions, independent scheduler/worker, manual/weekly/one-time/event/signed-webhook triggers, explicit IANA timezone | One concurrent job, maximum 100 queued/paused/running jobs; local Mac must be awake and the user logged in |
| Execution | Dependencies, authorised-website condition, bounded subprocesses, two attempts per step, pause/resume/cancel, restart recovery, deduplication receipts | Fixed step graph; no arbitrary conditions or user-supplied executable code; notifications are in-app only |
| Agents | Sequential coordinator with Brand Manager, SEO, Content, Reporting and Operations roles | Research, Creative, Campaign and CRM have manual tools/role definitions, not autonomous specialist workers; allowed tools are fixed in code |
| SEO | Robots checks, up to five HTML pages, two sitemap fetches, ten additional internal-link checks, redirects, titles, descriptions, H1/H2/H3, canonicals, noindex, evidence/impact/effort tasks | No JavaScript SEO rendering, full-site crawl, Search Console, keyword volumes, traffic, ranking or backlink datasets; no automated website changes |
| Organic marketing | Seven-day draft calendar, creative briefs, local caption review, UTM creation, version-specific approvals | No automatic images/video inside this workflow; Aerny studio remains available manually; article/campaign strategy generators and monthly reporting are later work |
| Paid advertising | Explicitly unavailable | No campaigns launched or budgets configured; integration and spend authority are required |
| CRM | Contact/company records, evidence versus assumptions, owner/stage/follow-up/history, email/phone/name deduplication, opt-out preservation | No outreach, external CRM sync, automatic onboarding or renewal notifications; contact uniqueness follows the stored normalised key |
| Tasks | Evidence-backed tasks, priority, owner/due backend fields and status UI | Owner/due editing is API-level; repeated weekly observations are retained per run rather than consolidated automatically |
| Spreadsheets | Actual three-sheet XLSX, tables, filters, typed dates, status validation, formulas and cached counts; immutable saved exports | First template covers calendar/SEO/brief; no general-purpose spreadsheet editor, budgets, workload or analytics templates yet; edits to downloaded Excel files do not sync back |
| Documents/PDF | Actual three-page InteriFY summary, editable Markdown source, embedded fonts, run evidence | No DOCX or full proposal/SOP template suite; approved logo/font automation remains to be connected; current report uses the brand name and SYnerGY footer |
| Approvals | Configurable reviewer roles, action, version/hash, reviewer, decision and timestamp; changed drafts require new review | No external publishing connector is attached. The external-action route refuses execution even after a draft review |
| Privacy/retention | Brand-scoped APIs, private saved paths, hash-checked authenticated downloads, credential-pattern rejection, sourced knowledge, deletion and 7–3650 day run retention | Admins must manage separate backups; ordinary Chat history remains account-scoped, not a substitute for brand-scoped Operations records; OS-level isolation is not provided |
| Reporting | Workflow states/next run, worker availability, run steps, failures, approvals, files, tasks and missing-connection notices | Live KPI collection is absent; unavailable metrics remain null/unavailable, not zero; no email notifications |

## Current InteriFY workflow

Workspace: `fa75618428b946aa9cbf8966d724fe54`.
Workflow: `14c487ef11f74f708f5fa0e310051cf1`, version 1.
Schedule: every Monday at **09:00 Asia/Kolkata**. The next configured occurrence after deployment is **9 November 2026 at 09:00 IST**, equivalent to 03:30 UTC.

First production run: `ee27737879944d22960d434a8cdda594`, completed in 38.83 seconds. The local `aerny:v1.5` call took 35.64 seconds. It reviewed supplied editorial drafts and preserved their text in this run. This is a real local inference call, not new model training or evidence of autonomous marketing expertise.

The run saved a seven-day calendar for 5–11 November, XLSX, PDF, editable Markdown and JSON evidence. Two input tasks were created. Its state is **completed_with_blockers** because the brief is not approved and no authorised InteriFY website was supplied. The SEO stage correctly remained blocked. The existing studio brand kit is also unapproved; no logo was silently designated approved. External actions remain disabled.

To complete the brand-specific audit, an owner must supply/authorise the website and review the saved brand brief/assets in the workspace. Run the workflow again after those inputs are ready. The example.com audit in test evidence is an isolated public test, not an InteriFY audit.

## Actual components

| Component | Software / location |
| --- | --- |
| App/API | Existing Python 3.12.15 HTTP app, cookie sessions and CSRF protection; additive `operations` module |
| Definitions, queue, jobs, permissions | SQLite tables with `ops_` prefix in the existing `accounts.sqlite3`; definitions and runs stored separately |
| Scheduler/worker | `backend/operations/worker.py`; independent macOS LaunchAgent `in.1rank.synergy-operations`; process lock, heartbeat and durable steps |
| Public crawl | Existing DNS-pinned public HTTP reader with SSRF protection; Python HTMLParser, RobotFileParser and XML parser |
| Local model | Ollama `aerny:v1.5`, existing Qwen3 4B Instruct 2507 Q4 profile on the 16 GB Intel Mac; JSON-schema bounded output, no hosted generation service |
| Spreadsheet | Included XLSX authored and recalculation-tested with Artifact Tool; runtime fills its XML with the standard library and preserves formulas/styles/validation |
| PDF | ReportLab 5.1.0 (BSD), charset-normalizer 3.5.2 (MIT), existing Pillow; bundled DejaVu fonts and their licence retained |
| Existing integrations | Desktop Commander 0.3.1, free public research and local browser inspection remain available in Chat; Firecrawl anonymous provider access remains unavailable |

No paid service, cloud GPU, new foundation model or new training run was added. OpenAI remains unconnected. CPU inference time varies with the Mac's other work. All generation is local; only an authorised public crawl sends requests to the chosen website.

## Setup on this Mac

Existing source/data/runtime paths are retained:

- Source: `/Users/a1989/Library/Application Support/SYnerGY/v1.6.0`
- Data: `/Users/a1989/Library/Application Support/SYnerGY/v1.4-data`
- Worker files: `<data>/operations/{artifacts,scratch,secrets}`
- Separate new dependencies: `<SYnerGY base>/runtime/work-deps-v160`
- App LaunchAgent: `~/Library/LaunchAgents/in.1rank.synergy-v14.plist`
- Worker LaunchAgent: `~/Library/LaunchAgents/in.1rank.synergy-operations.plist`

For a repeat installation on the same existing runtime, unpack into a new version directory. Use the managed Python recorded in the existing app LaunchAgent. Install `backend/requirements-work-v160.txt` into the separate work dependency directory with `pip --only-binary=:all: --no-deps --target ... -r ...`; the existing runtime already supplies Pillow. Then run `scripts/deploy-work-macos.py --source <absolute-source-directory>`. It checks active media/research jobs and dependencies, backs up source/database/launch configuration, switches source and starts both services. Failed health checks restore the previous LaunchAgent.

For a new machine, first follow the existing `BACKEND_SETUP.md`, `BACKEND_SETUP_V14.md`, `RESEARCH_SETUP.md` and `PLUGINS_SETUP.md` to establish the base app, models and dependencies. Then apply Work mode. The package does not include model weights, private accounts, secrets or customer databases. The included XLSX template is sufficient for runtime exports; rebuilding it requires the authoring environment named in its builder script.

Manual worker command, using the same Python and PYTHONPATH as the app:

```sh
python3 backend/operations/worker.py --data '/absolute/SYnerGY-data-directory'
```

Only one worker may own a data directory. Keep the service bound to loopback. Remote webhook ingress/public deployment requires a separately secured gateway and is not included here.

## Scheduling and recovery

The scheduler persists the due time in SQLite; it does not depend on chat, Chrome or the web server. The LaunchAgent starts while the macOS user session is active. Sleeping, shutdown or logout delays execution. On return, missed weekly occurrences coalesce into one catch-up run; this release does not wake the Mac or guarantee unattended 24/7 availability.

Pause a workflow to prevent new scheduled runs. Pause/cancel an individual run from its preview to stop current work. Pausing a workflow does not retroactively cancel a running job. Each step has a 20–120 second timeout and at most two attempts. A worker restart keeps committed steps and requeues unfinished work. Orphan step subprocesses exit if their parent dies. This guarantee covers local internal outputs; no remote side-effecting tools are enabled.

Inspect the worker with `launchctl print gui/$(id -u)/in.1rank.synergy-operations`. Logs are `<SYnerGY base>/operations-worker.log` and `operations-worker-error.log`. Restart it with `launchctl kickstart -k gui/$(id -u)/in.1rank.synergy-operations`. Do not manually alter a live job database to retry a job; use the run's Retry control when available.

Webhook setup returns a key only to an authorised manager/admin. Store it in secure caller configuration. Sign `timestamp + newline + event_id + newline + exact request body` with HMAC-SHA256. Requests expire after five minutes. Reusing an event ID returns the existing run and does not create another execution. Keys are local mode-0600 files and must not be placed in chats, reports or source control. Event triggers currently support `brand.updated` and `task.completed`.

## Backup and rollback

Pre-upgrade backup: `/Users/a1989/Library/Application Support/SYnerGY/backups/work-v160-20261104-165352`. It includes a consistent SQLite backup, the original app LaunchAgent and source. Version 1.5.2 also remains at its original path. Media and model directories remain in place.

For a full new backup, pause workflows and let active work finish; stop the app and Operations LaunchAgents, then copy the entire data directory (including artifacts and secrets), source, model lock/configuration and both plists to a protected backup destination. For an online database-only checkpoint use SQLite's backup API, never a bare copy of an actively written database. A database alone cannot restore missing artifact files or models.

To roll back the application, boot out both current LaunchAgents, restore the original `in.1rank.synergy-v14.plist` from the backup, and bootstrap it. Leave the Operations worker stopped. The old source ignores additive Operations tables. Keep the current data: restoring the older database would discard new conversations and Work records. Restore a database only for an intentional recovery with services stopped, retaining a copy of the newer data first. Retention/deletion in the app does not erase administrator backups; apply a separate backup retention policy.

## Validation commands

Run `python3 -m unittest discover -s tests` with the documented test/runtime dependencies. The Mac process acceptance script is `scripts/verify-operations-macos.py`; it creates its own isolated database, tests a one-time schedule, forcibly restarts only its own worker and tests pause/cancel. It never uses the customer database. See `WORK_MODE_VERIFICATION.md` and the evidence archive for observed results rather than treating screenshots as a functional test.
