# SYnerGY acceptance test — 4 November 2026

**The current release does not pass the complete acceptance suite.** File upload works with the browser permissions already enabled. No permission settings were changed. These are results from the live local application, not screenshots presented as proof of backend execution.

Tested application: SYnerGY 1.7.0 / Aerny v1.5, `http://127.0.0.1:8090/`, on the connected Intel Mac. Model provider: SYnerGY; Aerny Balanced; Medium response level. OpenAI was not connected or used. No paid services, publishing, outreach or advertising were activated. Application source was not changed during this acceptance run.

## Acceptance results

“Pass with notes” means the requested core behavior was observed, with the stated limitation. “Partial” means some requested behavior worked. A task marked `succeeded` by the application only means its response finished; it does not establish acceptance success.

| # | Mode / test | Result | Observed result |
|---|---|---|---|
| 1 | Chat — research | **Fail** | Compared Morphogenesis, Studio Symbiosis and groupDCA, but relied on directories for the first two. It did not inspect three official websites or their enquiry journeys. The answer also overstated access failures. |
| 2 | Chat — reasoning | **Pass with notes** | Gave five possible causes, an investigation for each and a first action without inventing conversion data. Some advice was generic and should be tested before changing pricing or adding urgency. |
| 3 | Chat — attachment | **Pass with notes** | The actual uploaded Markdown fixture yielded the correct three deliverables, owners, two deadlines, pending review and missing inputs, with section references. The closing claim that all deadlines were defined contradicted the correctly flagged missing PDF deadline. References were plain text rather than clickable citations. |
| 4 | Chat — follow-up memory | **Partial** | Remembered the previous answer and produced five short points, but turned hypotheses into assertions and added another first-action line. |
| 5 | Work — brand workspace | **Fail through chat** | Claimed the workspace was created; no brand record existed. The form subsequently created InteriFY QA with the supplied inputs, no website, revision 1 and no approved revision. |
| 6 | Work — deliverables | **Fail through chat** | Produced a table and named nonexistent XLSX/PDF files. It invented a 30% statistic and a client case study. A separately run manual workflow produced real files, but its calendar has no separate hook field. |
| 7 | Work — automation | **Fail through chat** | Confused InteriFY QA with existing InteriFY and asked for a brand name. The form saved the correct Monday 09:00 Asia/Kolkata weekly draft and showed inputs, steps, approvals and outputs. It remains inactive. |
| 8 | Work — revision and approval | **Fail through chat** | Changed only the day-three format label in its text table, retained the unrelated 2024 home-trends content, claimed nonexistent v2 files, and incorrectly said the previous approval still applied and no new approval was needed. No actual revised run was created. |
| 9 | Beast — website creation | **Fail** | The full request exceeded the seven-minute worker limit. The project retained its supplied four-file starter. The requested generated gallery and enquiry form were not delivered. |
| 10 | Beast — targeted editing | **Pass on the starter** | A one-file diff was shown before application. Revision 2 changes exactly the hero heading to “Spaces that feel like you.” All other file contents are identical. Desktop/mobile previews and the downloaded ZIP were verified. This does not turn the failed website-generation test into a pass. |
| 11 | Beast — Python debugging | **Partial** | Saved `total_price.py` with the corrected `for item in items` loop and the two requested prices. It supplied a print demonstration, not an assertion. The explanation incorrectly called it a syntax error, named the wrong exception and implied a test confirmed the result. Actual checks were AST parsing only; no application test ran. |
| 12 | Beast — Rust honesty | **Fail** | The runtime panel correctly reported Rust unavailable. The model did not claim compilation, but proposed only README instructions, with no `.rs` source or functional CLI. That incomplete proposal was left unapplied. |

## Evidence and timing

| Request | Saved task / job | Observed processing time |
|---|---|---:|
| Research | `4a49a505b21e426a83b6347e1097a23a` | 288.4 s |
| Reasoning | `19ebac95cb124d559844e4845ce4b118` | 85.9 s |
| Follow-up | `97780fad9bc846cc9da72c00f68b33b4` | 18.5 s |
| Attachment, browser | `c0f24ba9e7f847829ad2a6e64387443b` | 92.2 s |
| Brand creation claim | `4d82e7210b7b40ea9cc00a6d41712721` | 109.9 s |
| Deliverable claims | `2d49c5cff271492f9edaa72eb1cdd5d0` | 75.8 s |
| Revision claims | `2e0671f4f973489e80a2ce0d29afdb34` | 544.3 s |
| Full website | `3d90a1e6f32a4093a6f92d3188413afb` | Worker timeout after seven minutes |
| Hero edit | `f6bbff5c9ab84c38b40f58aba7f990ad` | 413.23 s |
| Python | `1922d74f86a34bcc99e0a8c8ab05b7e7` | 91.56 s |
| Rust | `a40c9d0dc2d341af8d3b5027a73d0eed` | 124.34 s |

These are observed run times, not controlled performance benchmarks. Several requests overlapped or queued. During the run the Mac reported about 6.1 GB of swap in use and the Ollama process was using approximately four CPU cores. No claim is made that memory pressure alone caused the failures.

The upload initially timed out in browser automation. Retrying the file chooser and file assignment separately succeeded without changing permissions. An additional authenticated API test used a dedicated synthetic QA account, extracted the same fixture and verified that the original downloaded attachment matched its upload hash. That API check is supplementary to the successful browser test.

## Actual Work artifacts

The real files were generated by the existing SYnerGY Operations worker after the chat export failed. A separate **manual**, internal-only workflow was reviewed, activated and run once. It was then paused. It had no scheduled trigger and performed no external publishing or sending.

- Brand: `InteriFY QA`, ID `451e793a810846f5b72a097baeaaeea5`.
- Run: `e925d0e8780b4280aba6b0b97640d0c3`, completed with blocked inputs.
- Brief: pending approval. Website: blank and not authorised. These were not invented or approved to make the test pass.
- SEO correctly remained blocked. Missing information remained unavailable rather than being represented as zero.
- Local calendar drafting timed out. The application explicitly used its **Editorial template** fallback.
- The saved calendar is different from the fabricated calendar in chat. It is a seven-day draft, 5–11 November 2026, with no invented case-study results.
- The workbook contains Calendar, SEO tasks and Brand inputs sheets, tables, status validation and four retained formulas. Counts independently reconciled to seven planned posts, seven drafts, zero approvals and unavailable SEO issue count.
- All seven workbook rows match the stored run. There is no dedicated hook field.
- The three-page PDF was rendered and visually reviewed: readable, with no clipping seen. It includes a minor punctuation defect in its limitations paragraph. No approved logo was supplied or invented.
- Actual browser XLSX/PDF downloads matched the saved artifact SHA-256 hashes.
- All artifact reviews remain pending. No client approval was fabricated.

The weekly QA workflow `41aaeeb9c5e547d683fb2452d139a529` remains **draft**, with Monday 09:00 and timezone `Asia/Kolkata`; no next run is scheduled until activation. The separate manual workflow `fffeab26fe5d492f9ac43b91891618a3` is **paused**. The original InteriFY workflow was not modified.

The manual calendar editor only exposes captions and creative briefs. It does not expose the format/topic fields required to fully perform the day-three request. Its notice correctly says revised exports need their own review, which conflicts with the chat answer. The backend contains a versioned revision route, but this acceptance run did not bypass the interface to manufacture a successful revision test.

## Actual Beast artifacts

Website QA project: `b41cceff2da64eb180521b6aa6dddc2f`, revision 2. Its preview is the supplied starter plus the accepted headline change, not a completed implementation of the website brief. The preview is HTML/CSS only: JavaScript, forms and external network requests are disabled by the current preview service.

The exported website ZIP contains the saved source and `SYNERGY_VALIDATION.json`. Source files were compared byte-for-byte with the saved revision. The hero-only assertion verifies that `index.html` equals the original file with exactly this replacement:

```diff
-<h1>Make room<br>for better.</h1>
+<h1>Spaces that feel like you.</h1>
```

Python QA project: `ffffcf05eca343d38eeeab40f4939d0e`, revision 2. The downloaded ZIP matches the saved source. `total_price.py` contains the corrected loop and inputs 100/200, but its code was **not executed** by SYnerGY or as a substitute host-side test. Its syntax passed `ast.parse`. The original bug is an undefined iterator variable at runtime, not invalid Python syntax. The generated explanation needs correction.

Rust QA project: `22f96628371a46f0bae8cd957170859e`, revision 1, with an unapplied README-only proposal. Rust was reported unavailable by the application's runtime probe. No compiler was installed and no Rust compilation or application test ran.

Detected relevant host tools were Python 3.12.15 and Node.js 24.21.0; Rust was not found. The application has no isolated build/test execution service. A detected host runtime is not evidence that generated application code ran.

## Fix priorities

1. Connect Work chat to permission-checked actions for brand creation, deliverable generation and revision. Confirm actions only from persisted action results and actual artifact links. Add regression tests for false completion claims.
2. Resolve brands by exact identity, with an ambiguity selector when needed. `InteriFY` must not capture a request for `InteriFY QA`.
3. Obtain approval state from stored artifact versions. Never infer an approval from model prose or a pending brand brief.
4. Improve official-source retrieval and enquiry-page inspection; distinguish a failed fetch from a site that was never attempted. Preserve uncertainty in follow-up summaries.
5. Expose required calendar fields, including hooks, and connect targeted edits to versioned outputs while preserving the other six entries.
6. Reduce Beast context/output cost, coordinate shared local compute, and provide a viable workflow for larger website requests. Keep the existing timeout and error reporting honest.
7. Separate model explanation from execution evidence. Feed actual runtime capabilities into coding requests, require requested source files, and reject “tested” claims without a corresponding execution result.
8. Address UI races: research completion returned the Work view to chat, and a reopened Beast preview needed its refresh control. Run-detail clicks also did not reliably replace the right preview during this session.

## Scope and retained evidence

The evidence archive includes exact model responses, the synthetic upload fixture, sanitised task/run/project records, downloaded ZIP files, actual Work artifacts, formula/hash/source checks and render reviews. It excludes credentials, browser cookies and account databases. Screenshot previews are supplied separately from the archive.

No models were trained. No image/video quality claim is made by this run; the supplied acceptance table tested chat, Work operations and coding. No scheduler restart, browser-closed schedule, cross-client permission or security penetration test was performed in this run. Earlier tests are not represented as new evidence.

The application remains available on the Mac at `http://127.0.0.1:8090/`. This loopback URL is local to that machine and is not a public deployment URL. The QA records and reviewed revisions remain saved for follow-up fixes and retesting.
