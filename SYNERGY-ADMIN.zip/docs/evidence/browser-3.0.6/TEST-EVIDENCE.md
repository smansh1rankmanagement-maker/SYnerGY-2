# SYnerGY 3.0.6 / extension 1.8.0 — actual test evidence

Date: 6 November 2026. Copied the latest reviewed deployed 3.0.5 / extension 1.7.2 source before making changes. Existing account, Work, capture, reminders and non-browser features were retained.

## Executed and passed

| Check | Environment | Actual result |
|---|---|---|
| Browser authorization and planner | Python against temporary SQLite | 17 tests passed |
| Extension, account access, Work, research and new HTTP browser flow | Candidate Docker image, isolated test configuration | 15 tests passed |
| Pause/Stop races, account mismatch and tab denial | Node VM with mocked Chrome APIs | 7 tests passed; these are not physical browser tests |
| Existing extension policy | Node test runner | 3 tests passed |
| Build | Production host, image synergy-ai:browser-3.0.6 | Built successfully |
| Deployment health | Live https://synergyai.1rank.in/healthz | status=ok, version=3.0.6 |
| Data preservation | Before/after hashes of account and business records | Unchanged |
| Mac extension files | Existing Downloads/SYnerGY-Chrome-Extension (6) | Updated from 1.7.2 to 1.8.0; backup retained |
| Chat interface | Signed-in Chrome page | New browser controls visible after refresh |

The security tests cover different accounts, different devices and pairing credentials, unselected tabs, one-use tickets, cancellation of claimed commands, revoked/expired sessions and verification only after a device action acknowledgement. The HTTP test exercises signed-in request preparation, extension bearer claim and completion, and denied access. It does not simulate a real Chrome permission grant.

## Physical end-to-end test still pending

The request “Open my selected test website, fill its sample form and inspect console errors” has not yet completed in physical Chrome. The updated unpacked extension must be reloaded and the sample tab selected in Chrome. No connected status or browser action success has been fabricated.

1. Reload SYnerGY in chrome://extensions, refresh SYnerGY, and open https://synergyai.1rank.in/browser-test.html in another tab.
2. Choose that test tab in Connect browser → Choose tabs → Connect selected tabs. Accept Chrome's site permission prompt.
3. Send the exact request above in either ETERNAL or Aerny chat.
4. Expect a verified page read, diagnostics attachment, navigation, synthetic Name/Email/Message fills and captured console-error metadata. No form submission occurs.
5. Pause/Stop and unselected-tab behavior has passed automated tests; physical Chrome confirmation remains pending. Real website submission/purchase/destructive actions were not tested or performed.

## Scope and limits

Supported chat requests include labelled fills, synthetic sample forms, same-origin navigation, page reads, scrolling, screenshots when no editable/private content is visible, and new console/network error metadata. Arbitrary multistep website tasks and custom widgets are not fully supported. Sensitive pages/fields are blocked. Diagnostics omit console argument text, request bodies and credentials; this limits how much detail the assistant can explain. Chrome notices and permission prompts remain enabled.

Previous-release test counts in inherited release files are historical, not tests rerun for this change. Raw logs accompany this report. No user credentials, databases, cookie stores or private browser contents are included.
