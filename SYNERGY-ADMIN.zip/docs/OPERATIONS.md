# Operation, backup and recovery

## Runtime layout

Only Caddy publishes host ports. The app listens on 8090 inside Docker, Ollama on 11434 inside Docker. Do not add public port mappings for them. The backend network permits outbound public research and explicit downloads. No Docker socket is mounted in application containers.

Services: `app` (HTTP, chat and media queues), `operations` (durable scheduler/export worker), `beast` (durable proposal worker), `ollama` (local chat inference), and `caddy` (HTTPS). `model-setup` is an explicit, one-off setup service. Workers do not depend on an open browser.

Data volumes: `app_data` (SQLite, uploads, projects, outputs, settings), `models` (downloaded media weights), `ollama_data` (chat weights), `caddy_data` (certificates), and `caddy_config`. Docker prefixes volume names with the Compose project name, normally `synergy`.

Use one app container, one Operations worker and one Beast worker against this database. Do not scale app replicas or share SQLite across machines. App containers run as UID/GID 10001, have a read-only image filesystem, and store writable state in the data volume and temporary directories.

## Back up

```bash
python3 deploy/manage.py backup
```

The command stops the currently running application writers, creates a consistent `application-data.tar.gz` and private `deployment.env` in a timestamped `backups/` folder, then restarts those same services. Sessions and account hashes are in this private backup. Keep an encrypted, off-server copy under your control. Model weights and TLS certificates are not included: models can be reinstalled; certificates can be issued again. Preserve their Docker volumes separately if needed.

Runtime `node_modules`, npm caches, temporary worker directories and symlinks are excluded. Reinstall Desktop Commander from the owner account after restoring if its dependency directory is missing.

## Restore into a new volume

Never overwrite the only copy of your current data. Keep the old project volumes for rollback. On the same host, stop the old services before starting the recovered copy on the same domain:

```bash
python3 deploy/manage.py stop
docker compose -p synergy-recovered run --rm --no-deps -T --entrypoint /opt/web/bin/python app /opt/synergy/deploy/data_archive.py restore < backups/TIMESTAMP/application-data.tar.gz
docker compose -p synergy-recovered up -d ollama
docker compose -p synergy-recovered run --rm --no-deps model-setup models --accept-model-licenses
docker compose -p synergy-recovered up -d --no-build --wait app operations beast caddy
```

Use the matching backed-up `.env` privately if configuration was lost. Restore refuses a nonempty data volume and rejects archive paths escaping the data directory. For a GPU deployment add `-f compose.yaml -f compose.gpu.yaml` to these commands. Keep using `-p synergy-recovered` for future operations on this restored stack; the convenience manager targets the default `synergy` project. Do not run both domains' writers simultaneously against the same volume.

Confirm login, saved projects and downloads after restore. Chat/media jobs interrupted by a restart become retryable failed jobs; source and references remain saved. Operations and Beast recover durable jobs within bounded retry policies. An old artifact's approval never approves a changed version automatically.

## Updates and rollback

1. Create a backup and retain the previous project ZIP and Docker image.
2. Stop application writers. Extract the new project to a separate directory, copy `.env` privately, and retain the same Compose project name if intentionally reusing its volumes.
3. Read the release changes and schema notes; build the new app image and start the services.
4. Run the acceptance checks. Keep `deployment-images.json` and the web/media installed package lists from the built image.
5. To roll back, stop new writers and restore the matching pre-update database into a new volume with the previous source/image. Changing only the image may be insufficient after a schema change.

Never run `docker compose down -v` against data you want to keep. `stop` preserves volumes.

## Existing Mac data

This ZIP deliberately excludes your Mac accounts, private files, secrets, virtual environments and weights. It leaves that installation intact. Start with a new server workspace, or export and verify a separate private migration. Some legacy records contain absolute Mac paths; copying the old SQLite database alone is not a supported cross-platform migration. Keep the original source and data backup until a separate migration is verified.

## Availability and troubleshooting

| Symptom | Check |
| --- | --- |
| HTTPS unavailable | DNS A/AAAA, inbound 80/443, another process using the ports, Caddy logs and certificate-provider reachability |
| 403 before login | `.env` domain must match the address used in the browser; public POST requests require the exact Origin |
| Registration closed or invite rejected | Correct private invite code; `SYNERGY_REGISTRATION_ENABLED`; registration is invite-only by default |
| Many login attempts rejected | The bounded auth rate limiter caps attempts per proxy address; wait a minute. This conservative first release is intended for a small invited group |
| Chat model unavailable | Ollama service running, model setup completed, `/api/models` availability in the app |
| Media unavailable | Finished model downloads, SHA checks, media dependency import check and writable data volume |
| Worker offline | `docker compose logs operations beast`; health check; one worker owner per data directory |
| Model timeout / slow response | Actual server CPU/GPU/RAM, model size, requested effort and contention. No speed improvement is guaranteed |
| Memory exhaustion | Reduce active workload; stop/retry jobs with lower quality; provide adequate host resources |
| Firecrawl unavailable | Its external free connector may be unavailable or rate-limited. The app reports its fallback; private browser sessions are not transferred |

Keep the VPS, Docker, proxy and dependencies patched. This package has targeted tests, not a complete security audit. For public scale, add a reviewed resource/quota policy, monitoring, abuse controls and an isolated code execution service before offering arbitrary code execution. The current Beast engine deliberately does not execute user-generated programs.
