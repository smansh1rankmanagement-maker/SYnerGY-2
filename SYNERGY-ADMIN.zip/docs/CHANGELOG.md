# 1.9.1 · Aerny v1.6

- Added account-scoped projects for all three modes and local OpenJarvis voice.
- Added the AWS deployment workflow and auth-preserving upgrade checks.
- Added a Chrome side panel, explicit page capture, source-attributed leads and Excel export.
- Routed explicit install requests before coding/creation in all modes. Added pinned workflow import and bounded Beast source import with accurate setup status.
- Added Desktop Commander workspace uploads and reusable usage guidance.
- Existing media and Brand Operations features are retained. No model training or new paid service.

# 1.8.1 automatic creation

Baseline: saved source version 12 / SYnerGY 1.8.0 domain project. The existing Mac's v1.7.0 source and startup/database backup were preserved before installing v1.8.1.

- Added bounded server-side request routing and automatic skill selection before text inference for images, short videos, posters/social designs and PDF/Word/A4 PNG/text documents.
- Connected image and video workers to durable chat tasks with actual progress, cancellation, authenticated artifact downloads and saved results. No success receipt is returned without a verified output file.
- Added real PDF/DOCX/PNG document rendering; supplied wording and previous-answer exports can bypass model rewriting. Multi-page PNG exports include a page ZIP.
- Added reference-upload reuse and saved conversational layout revisions; improved the default headline layout and removed repeated image padding on follow-up edits.
- Fixed PDF-in-chat preview by allowing same-origin PDF framing only. Other content retains its framing restriction.
- Preserved stopped/interrupted task metadata, cancelled orphaned queued child jobs, and fixed video cancellation state races.
- Added 11 creation tests; all 120 application and 9 deployment checks passed. Six real local generation requests passed on the Mac, followed by browser preview, upload and download checks.
- Kept Aerny profile/model weights unchanged; no paid service, new training, native-4K claim or public-domain deployment was introduced.

# 1.8.0 domain deployment changes

Baseline: saved source version 11 / SYnerGY 1.7.0, preserved separately and in source history.

- Added Linux/amd64 Docker build, optional NVIDIA override, Caddy HTTPS configuration, private Ollama network and persistent data/model/certificate volumes.
- Added distinct application, Operations and Beast services with health checks and restart policies.
- Added strict configured-host/origin policy, Secure cookies, registration closure, mandatory public invite secret, bounded auth limiter and bounded HTTP request threads.
- Replaced hard-coded Mac-local Ollama addresses across every active model client, including worker subprocesses. Made Chromium selection portable to a bundled Playwright browser.
- Added explicit, verified media model downloads and local Aerny profile setup; no hosted generation fallback or model training.
- Added CPU/CUDA selection in image and AnimateDiff pipelines. The new CUDA path still needs hardware acceptance testing.
- Added an unsupported Work-action boundary before text-only chat inference and fixed contained-brand-name matching for workflow drafts.
- Supplied observed runtime capabilities to Beast's proposal model; separated model explanations from actual execution receipts and made its bounded deadline configurable.
- Added deployment configuration, preflight, start/stop, backup, empty-volume restore, setup and recovery documentation.
- Kept legacy Mac scripts and existing app specifications for reference. Private accounts, model weights, secrets and user-generated files are excluded.
