> Current update: [Aerny v1.6 / SYnerGY 1.9.1](UPGRADE-1.9.1.md). The original infrastructure and media evidence below describes the initial 1.8.1 deployment.

# SYnerGY live deployment

SYnerGY AI 1.9.1, with Aerny v1.6 profiles, is deployed at https://synergyai.1rank.in on AWS Mumbai. Verified 5 November 2026. The owner's existing Mac installation remains separate and unchanged.

## Sign in after this upgrade

Continue with your existing username and password at https://synergyai.1rank.in. Existing cloud accounts and unexpired sessions were preserved; do not register again or reset your password because of the upgrade. Mac accounts remain separate unless deliberately migrated.

For a new invited user, obtain the existing private code from `/srv/synergy/secrets/invite-code.txt` through AWS Session Manager, share it privately, and use Register. Do not regenerate `.env` or the invite code during an upgrade. Owner access remains with the configured `smansh` account.

## Deployed components

| Component | Actual deployment |
|---|---|
| Public address | 13.204.133.193, one Elastic IP |
| Host | r6i.xlarge, 4 vCPU, 32 GiB RAM, Ubuntu 24.04 amd64 |
| Storage | 100 GiB encrypted gp3 |
| App and workers | Docker; persistent SQLite/files; separate Operations and Beast workers |
| HTTPS | Caddy 2.11.7; valid Let's Encrypt certificate; automatic renewal |
| Chat | Ollama 0.40.14; Qwen3 4B, Qwen3 0.6B, Qwen3-VL 2B; Aerny profiles |
| Image | epiCRealism SD1.5, optional LCM-LoRA, CPU inference |
| Selective editing | Cropped image-to-image plus exact mask compositing |
| Video | AnimateDiff-Lightning 4-step and epiCRealism; CPU inference |
| Exact layout | Pillow/SVG, exact typography and logo overlays |
| Documents | ReportLab, python-docx, openpyxl |
| DNS | Hostinger A synergyai -> 13.204.133.193, TTL 300 |

Customer experience remains free, with no subscriptions or credit balances. AWS hosting is billable under the already approved plan. No hosted paid generation API or GPU was added. OpenAI is disabled; Hybrid currently routes locally only.

## Verified outcomes

| Check | Result |
|---|---|
| HTTPS homepage and /healthz | HTTP 200, certificate validated from outside AWS |
| HTTP redirect | 308 to HTTPS |
| Public ports | TCP 80/443 only; 22,8090,11434 unreachable externally |
| Server checks | EC2 instance, system and EBS checks passed |
| Regression | 120 application + 9 domain tests passed on Linux |
| Authentication | Invite rejection, login/logout, secure cookies, incorrect-password rejection passed |
| Client isolation | Another account could not retrieve saved conversations or document artifacts |
| Chat | 100 + 200 -> 300; 14.35 seconds |
| PDF and Word | Real outputs, matching download hashes; PDF content extracted correctly; 0.33 seconds |
| Image | Real 512 x 512 inference; 114.98 seconds |
| Poster | Exact headline, 1080 x 1350, authenticated PNG/SVG downloads; 1.31 seconds |
| Selective edit | Real inference; 67.31 seconds; black-mask pixels unchanged |
| Video | Real two-second H.264 MP4; 209.68 seconds; decoded successfully |
| Work | Pending-approval InteriFY QA brief, weekly draft in Asia/Kolkata, manual worker run, deduplication, saved XLSX/PDF, formulas, revision history and new approval passed |
| Beast | Saved template, restricted HTML/CSS preview, ZIP export, Python/JS syntax diagnostics passed |
| Restart | Final image started with healthy app and workers; HTTPS remained valid |
| Post-restart acceptance | 10/10 checks passed, including code recall, login/history and real job cancellation |
| Backup restore | 152/152 file hashes match; SQLite integrity ok in isolated restore |

The initial media test recorded 48/49 assertions passing. Its strict follow-up assertion required the words 100, 200 and 300, but the response contained only 300. The arithmetic result was retained; that result does not demonstrate full expression recall. The original failed assertion is preserved in the evidence. A separate post-restart follow-up correctly recalled ORANGE-731 in 2.43 seconds; its real creation-job cancellation, logout/login and saved-history checks also passed.

The first Work test stopped because its test-report function received a duplicate `name` argument. The corrected harness then passed all 20 checks. This was a test harness error, not a workflow failure. Initial build/useradd and isolated-test path issues were corrected before successful Linux runs; command IDs and reports are retained.

## Quality and capability limits

The image sample depicts a recognisable red ceramic mug with plausible lighting. The poster preserves its image and places the exact headline. The masked edit preserved surroundings exactly, but its mug colour did not clearly match the requested blue and the crop introduced an extra translucent-looking detail. Pixel preservation is verified; prompt fidelity and professional visual quality still need human review.

The video exports 1920 x 1080 at 24 fps with 48 frames over two seconds. These are upscaled/interpolated export frames; they are not native full-HD or 4K diffusion frames. The tested fast pipeline generates eight lower-resolution motion frames. A frame was visually inspected; automated decoding is not proof of perfect motion or identity consistency.

This is a CPU server: media jobs take minutes and share limited compute. Exact human identity preservation and all coding languages executing are not promised. Beast checks syntax only, and its preview disables project JavaScript. No arbitrary project-code execution service is configured. No training or fine-tuning occurred.

InteriFY QA has no authorised website and its brief remains unapproved. SEO stays explicitly blocked. The worker completed independent draft/calendar/export steps. Nothing was published, sent or spent by the workflow. The weekly QA workflow remains a draft, and the tested manual workflow was paused. Search analytics, social publishing, email and paid-ad connections remain unconfigured.

## Administration, backup and recovery

Server source: `/srv/synergy`. Start with `cd /srv/synergy` in an AWS Session Manager session.

- Status: `sudo docker compose ps`.
- Application logs: `sudo docker compose logs --tail=100 app operations beast`.
- Safe backup: `sudo python3 deploy/manage.py backup`. This stops writers, creates a private archive/config copy, then restarts previously running writers.
- Restart services: `sudo python3 deploy/manage.py start`.
- Stop application: `sudo python3 deploy/manage.py stop`.

A private backup was created at `/srv/synergy/backups/20261105T012008Z`. It was restored into an isolated temporary container: all 152 file SHA256 hashes matched and SQLite quick_check returned ok. Four QA accounts were present in that snapshot. This verifies archive and database integrity; a full restored-server login/traffic cutover was not performed. It contains database/files and a separate deployment.env secret file. Keep it private. The reusable source ZIP deliberately excludes these, all accounts, tokens and model weights. Backups on the same server do not protect against losing that disk; maintain a separate private copy before relying on disaster recovery.

For restoration, stop all writers; retain the current Docker volume; create an empty replacement volume; use `deploy/data_archive.py restore` with the archive on stdin and SYNERGY_DATA_DIR pointing to the empty target. It rejects nonempty targets and unsafe paths. Keep the same internal data path so saved artifact paths resolve. Restore the private deployment environment separately. Verify login and downloads before switching traffic. Do not run the fresh-host launcher on the already deployed server.

The original application image was tagged `synergy-ai:1.8.1-before-cloud-label` for rollback. Original source ZIP and prior file versions are preserved. Final runtime image ID: sha256:eab534d6f43a9f175ae59eca0253d353fc4d12fb3e0c832ceae424eed7b34038.

Do not terminate the instance or remove its volumes/IP unless intentionally retiring this deployment. Termination protection is enabled. Stopping containers does not stop EC2 charges; stopped instances retain disk/IP charges. The approved base estimate was USD 202.57/month before tax, additional traffic and backups. USD 100 promotional credit is not a spending cap.
