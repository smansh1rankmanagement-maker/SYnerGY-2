# SYnerGY browser tasks — extension 1.8.0 / runtime 3.0.6

Install/update
1. Extract SYnerGY-Chrome-Extension-1.8.0.zip into a permanent folder. For an existing unpacked installation, replace the files in its existing folder, retaining a backup.
2. Open chrome://extensions and press Reload on SYnerGY. For first installation, use Developer mode → Load unpacked and select the extracted folder. Chrome must approve the declared debugger permission. Its debugging notice remains visible.
3. Refresh https://synergyai.1rank.in and sign in. The installed extension pairs with this account through the existing challenge and scoped bearer flow. An extension paired to a different account requires explicit reconnection in Settings → Extension.
4. Choose Connect browser → Choose tabs. Grant access only to the sites selected. The first selected tab is the default; activating another authorised tab makes it the default. Only a successful page read changes the browser status to Connected.

Use directly in chat
- Open my selected test website, fill its sample form and inspect console errors.
- Fill "Name" with "Smansh" on my selected tab.
- Read my selected tab and summarise it in three points.
- Inspect console errors and failed network requests on my selected tab.
- Scroll down on my selected tab.
- Take a screenshot of my selected tab.
- Click "Preview sample" on my selected tab.

The included test page is https://synergyai.1rank.in/browser-test.html. Select that tab once, then send the sample request in normal SYnerGY chat. It uses synthetic Name, Email and Message values and never submits the form. The page intentionally produces console errors and a failed request for diagnostic verification. Never use real credentials in this fixture.

Control and connection
Pause prevents subsequent steps and invalidates outstanding tickets. Stop cancels and revokes the selected session, clears the local selection, and detaches diagnostics. A synchronous click already dispatched cannot be undone. Inspect an uncertain result before retrying. Resume allows a fresh observed action; it does not replay an interrupted write. The current task and target appear in chat and the extension control page.

Same-browser sessions reconnect through stored session state and server heartbeat. Host grants alone do not authorise another tab. Authorisation renews while the connected chat is available; a long disconnection, Chrome restart, closed tab, origin change or revoked pairing requires fresh selection. The browser and device must remain running; browser tasks do not run while the device sleeps. Closing the SYnerGY chat interrupts its browser task loop. Backend-only workflows remain separate.

Safety and limits
Only fixed, validated operations run; no arbitrary page/model JavaScript, cookies, request headers or response bodies are exposed. Sensitive pages and password, hidden, payment, OTP, token and credential fields are excluded. Page text is untrusted and cannot grant action authority. Normal input values are omitted from page observations; fill verification returns a boolean. Console/network output contains error metadata, counts, resource types, status and origin, not message arguments or request payloads. Screenshots are withheld when editable, embedded, canvas or explicitly private content is visible; image pixels are displayed to the user and are not sent in the model context.

Clicks use an exact-action review in chat. Purchases, money transfers, sign-in, contracts and destructive controls remain manual. Navigation stays on the selected origin and rejects credential-bearing URLs and query strings. The planner supports explicit labelled fills, synthetic sample forms, reads, same-origin navigation, scrolling, screenshots and diagnostics. Ambiguous fields need exact labels; unsupported form controls and arbitrary multistep web workflows are not promised. Local ETERNAL/Aerny may map a quoted user value to a visible field, but cannot invent personal data or broaden access. At most 16 planned steps run per request.

Diagnostics attach before the requested sample navigation so load-time errors can be captured. Existing errors emitted before attachment cannot be recovered. DevTools or another debugger can block attachment; resolve the conflict in Chrome without suppressing its notices.

Existing Chat, Work, Notes, To-do, Leads, Meetings, reminders and account/subscription checks are retained. Desktop Commander remains the existing server-scoped integration; it is not used to bypass browser permissions.
