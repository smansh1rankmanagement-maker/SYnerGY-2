# SYNERGY 2.0 — internal patch 3.0.1

Direct Gemini in Hybrid is restricted on the backend to active Work or Beast subscriptions, including manually granted subscriptions. The seven-day free Chat trial and administrator role alone do not qualify. The current authenticated job owner is passed by the backend; request-body identities cannot override it. The gate rechecks account state, start time, expiry and revocation immediately before a Gemini request. Privacy consent remains separately required. OpenRouter and local fallback are unchanged.

The owner supplied a new key, held outside source in encrypted AWS Parameter Store and a restricted server file. No keys are included in this release. Google model discovery authenticated successfully, but the real gemini-3.1-pro-preview generation test returned HTTP 429 RESOURCE_EXHAUSTED with zero free-tier quota. The configured route is unavailable until the provider grants API quota; no Google billing was enabled. The operator records the provider retry cooldown. A Gemini consumer Pro subscription is not proof of API entitlement.

Existing logins, purchased subscriptions, projects and other features are preserved. The operator release script backs up the old source, data, configuration and key, updates the admin source archive, and verifies authentication and business-record guards. The previous image remains synergy-ai:3.0.0-final. Source vaults and archives exclude secrets and customer records.

Canva continues to require its own developer app and per-user OAuth. The owner is completing app setup in the signed-in Canva account; do not mark connected until the real tool catalogue test passes.
