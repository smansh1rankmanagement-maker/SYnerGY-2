# SYnerGY Beast managed coding — administrator beta

This release adds the first execution milestone to the existing Beast workspace. Ordinary chat continues to use Luna for free accounts and Sol for paid accounts and administrators. Managed coding is initially available only to active administrators with Beast access. The existing Beast subscription gate remains in place; this release does not grant free accounts Beast access.

## Use

Open Beast and a development project. Save pending edits. Select the files to include using Choose model context, select OpenAI or Hybrid, and enable **Codex execution · beta**. Send a coding request. The chosen saved source snapshot is uploaded to a small OpenAI-hosted workspace. API credentials remain on the application server. Network access is disabled by default. There is no automatic access to Chrome tabs or the application host.

**Coding tasks** displays saved tasks, captured commands and exit codes, errors, and downloadable outputs. Closing the dialog or refreshing the page leaves execution running. Reopen Coding tasks or the saved conversation's Open coding task button to reconnect. Running tasks accept additional guidance. Stop sends a real provider cancellation and shows Stopping until a terminal provider outcome is confirmed. There is no Pause control.

On completion, inspect the captured checks, download the outputs, and select **Review returned changes**. Apply reviewed changes creates a new revision of the private project. It does not deploy that project. A changed base revision blocks application. Unsafe archives, credentials, links, traversal paths, and writes to existing files outside the selected snapshot are rejected. The task should return changes.zip, deleted.json and result.json. An absent or malformed proposal is reported without applying anything.

## Implementation

Official Python package: `openai==3.46.0`, `client.beta.agents.sessions`. Sol `gpt-6.1-sol` and Luna `gpt-6-luna` both passed real hosted sandbox execution checks on 7 November 2026. Each created a Python file, executed it, and produced stdout `42` and exit code `0`. Both proof sessions were subsequently released. This verifies the configured project/model combination, not every account or every task type.

Additive codex_tasks/events/artifacts/messages/approvals tables share the existing account database. The existing Beast worker owns execution; leases, creation intent and provider session IDs are persisted before/after creation. A timeout after creation is ambiguous: metadata reconciliation may reconnect an existing session, but an absent eventually-consistent lookup never authorises a duplicate creation. Use Reconnect existing session to retry reconciliation. Saved events have stable increasing sequence numbers and can be replayed with `events?after=N`. The UI polls saved records rather than depending on an open provider stream.

The provider client has automatic retries disabled. Steering messages have a durable outbox and provider idempotency key. Canonical turn state determines completion; idle alone is insufficient. Artifacts are copied locally before deleting the hosted session. Interrupted artifact downloads keep the provider session for recovery. Failed cleanup is retried by the existing worker. A lease lost to another worker prevents further local updates. One active managed task per account is allowed.

The API exposes:

- `GET /api/beast/managed-capabilities`
- `GET/POST /api/beast/tasks`
- `GET /api/beast/tasks/:id`
- `GET /api/beast/tasks/:id/events?after=N`
- `POST /api/beast/tasks/:id/messages`
- `POST /api/beast/tasks/:id/stop`
- `POST /api/beast/tasks/:id/reconcile`
- `GET /api/beast/tasks/:id/artifacts[/artifact-id]`
- `GET /api/beast/tasks/:id/proposal`
- `POST /api/beast/tasks/:id/apply`

Every task/event/artifact/action checks authenticated account and source-project ownership. Browser, operations, research and legacy source proposal tools keep their existing gateways. This beta exposes no external tool gateway actions or generic approvals. Pending approval records can be denied; approval cannot create new authority.

## Cost controls and current limitation

The actual API rejected the SDK's optional `spend_control` field with `400 unknown_parameter`. Accordingly this release does **not** claim a provider-enforced dollar cap. The application reserves an estimated task allowance, shares the existing cumulative OpenAI allowance and daily account limit, rejects work that cannot be reserved, cancels at the task deadline, and requests cancellation when reported token cost reaches half the reserve. Usage can lag or be absent and sandbox/compute/cache charges may differ. A timeout or cancellation may still incur charges. The full allowance remains reserved until operator reconciliation against final provider billing; it is not charged as a fabricated exact cost. Existing account budget and usage history are preserved. No top-ups or new subscriptions are enabled.

Default task allowance is $0.25 and deadline is 180 seconds. The shared allowance remains whatever the administrator previously configured. The small model proofs were separate setup checks and are not represented as charged task-ledger entries. Provider billing remains authoritative for these checks too.

## Configuration and rollback

Existing server only; no additional AWS service is required. Docker image `synergy-ai:codex-3.1.0` adds the pinned official SDK to the existing 3.0.7 image. Reuses the server-side OpenAI credential already configured for SYnerGY.

```
SYNERGY_CODEX_ENABLED=1
SYNERGY_CODEX_ADMIN_ONLY=1
SYNERGY_CODEX_MODELS=gpt-6.1-sol,gpt-6-luna
SYNERGY_CODEX_TASK_USD=0.25
SYNERGY_CODEX_TIMEOUT=180
```

Fresh installations default to disabled and administrator-only. Turning CODEX_ENABLED off causes the managed worker to request cancellation of active known sessions; keep the worker running until outcomes are confirmed. Stop or reconcile outstanding tasks before rollback. Tables are additive and may remain after reverting the application image. Preserve the current database and artifact files; never restore an old account database over newer user activity. Deployment must snapshot the current server configuration and account database, verify the existing release and changed-file hashes, then restart only the application and its existing workers.

## Remaining phases

This is sandbox execution and reviewed private-project revisions. Paid-user rollout, automatic final provider-bill reconciliation, large repository ingestion, persistent multi-turn session continuation after completed tasks, external tool approval gateways and production deployment automation remain separate work. Browser extension permissions are not inherited by the hosted coding session. Free users continue ordinary Luna chat; they are not silently granted Beast execution.

Official references verified for implementation:
- https://developers.openai.com/api/docs/guides/agents-api/quickstart
- https://developers.openai.com/api/docs/guides/agents-api/sessions
- https://developers.openai.com/api/docs/guides/agents-api/sessions/manage
- https://developers.openai.com/api/docs/guides/agents-api/sessions/events
- https://developers.openai.com/api/docs/guides/agents-api/environments/openai-hosted
