# SYnerGY 2.0 — verification evidence

Date: 5 November 2026. Production: https://synergyai.1rank.in. Existing AWS EC2 in Mumbai, 4 vCPU / 32 GB RAM, CPU inference. No new paid infrastructure or hosted generation provider.

## Results

| Check | Observed result |
| --- | --- |
| Application regressions in deployed image | 183 passed, no skips; 47.685 seconds. |
| Deployment configuration checks | 9 passed. |
| Chrome pairing/security checks | 3 passed. |
| Real private staging core workflow | 25 checks passed: email registration, access controls, provisional UPI references, synthetic statement reconciliation, manual subscriptions, real local inference, PDF download, source ZIP, recovery and suspension. No real payment sent. |
| Real private staging feature workflow | 17 checks passed: actual 200 MiB transfer with matching SHA-256, deletion, React/Motion compilation and interactive preview, durable running-task suggestion, model persistence, first-use guide, five-minute reminder and browser error checks. |
| Transfer and manual HTTP integration | Included in the 183: hidden pending transfers, account-specific approval/reassignment/revocation, old links denied, stale review rejected, passwords/sessions preserved, manual scoped to current account and refreshed catalogue. |
| Live cutover | App, Operations and Beast healthy; HTTPS reports version 2.0.0. |
| Existing authentication | 12 pre-upgrade password records unchanged and 8 unexpired sessions preserved. An already-signed-in owner browser reopened the new release without a password reset. |
| Imported projects | All three pending. None approved or made visible to a login account by this deployment. |
| Manual UI | Visible in the live sidebar; version 2.0.0, searchable sections, current tools and skills, actual 12,388-byte Markdown download in Chrome. |
| Login-screen refinement | Seven membership HTTP tests rerun after removing pricing and early-access text from the login/register form. /pricing and /pricing.html now use the sign-in shell and open billing only after authentication. Four fresh-browser live checks also passed. |

Raw synthetic staging records are in `docs/evidence/2.0/`. Staging used separate marked data; its accounts, receipts and files were not copied into production. Test results validate the listed behaviours, not general intelligence or perfect quality.

## Actual latency and limits

A short CPU greeting measured 0.59 seconds to first token and 1.09 seconds total on Fast; Balanced measured 27.08 seconds to first token and 29.12 seconds total. These are individual observed requests, not a speed guarantee or a comparison against OpenAI. The 200 MiB transfer took 3.89 seconds over server loopback; internet upload speed differs.

The queued follow-up completed, but a request for one bullet produced three. This is recorded as successful queue execution with a language-quality limitation. Full reference-video-to-website fidelity has not been evaluated. Real video-frame extraction, reference preservation, export and React preview execution were tested separately. Existing image/video engines were retained, without new weights or a new subjective quality benchmark.

ETERNAL and Aerny 2.0 are application profiles over installed Qwen3 weights, not newly trained foundation models. Apper is listed but has no authorised connected build adapter. Email verification/delivery is not configured. The unpacked Chrome companion files were updated to 1.2.0; Chrome still requires one Reload action to activate them.

## Reproduction and recovery

Run Python application tests from `app/`, deployment tests from the repository root, and `node --test tests/extension/background.test.cjs`. The real acceptance runners require a private `.staging-only` data directory. Never add that marker to production or run synthetic payment acceptance against live data.

The pre-upgrade private backup is `/srv/synergy/backups/pre-200-20261105T092726Z`, with source/config, application data and authentication digests. It is intentionally excluded from deliverables. `deploy/auth_guard.py` reports counts and preservation checks without printing credentials. Keep the previous image and data volume; restore backups to a separate volume before a rollback so newer writes are not lost silently.

The final login-only cutover preserved all 14 then-current password records and 9 active sessions, including accounts created during the release. The additional private backup is `/srv/synergy/backups/pre-login-200`.
