
## Browser control pilot — extension 1.7.2
Download the extension from Settings > Chrome extension. Existing unpacked installs: replace files in the existing folder, open chrome://extensions, and click Reload for SYnerGY. Preserve its extension ID. There is no Chrome Web Store auto-update release.
In the extension click Connect browser > Choose tabs. Grant tab discovery, select up to ten tabs, then grant access only to selected origins. Connection is shown only after a successful page read. Sessions expire after 15 minutes.
From SYnerGY chat (ETERNAL or Aerny, any mode), use:
- Read this page and summarise it.
- Compare these two selected tabs.
- Fill "Name" with "Your supplied value" on this page.
- Click "Sample action" on this page. Review the click in the extension control tab before it runs.
- Inspect console errors and failed network requests on this page. Click Allow diagnostics in browser controls first; reproduce the issue after attaching.
- Scroll down 500 on this page.
- Navigate this tab to https://example.com/path (same selected origin only).
Use Pause or Stop; Stop detaches diagnostics. Chat can remain usable with permissions declined.
Limitations: top-level standard HTML only; no cross-origin frames, shadow-DOM traversal, password/payment pages, form submissions or automatic login. Click confirmation expires after 30 seconds. Screenshots require an active tab and Chrome capture permission, and are refused on pages with fields/iframes. Diagnostics report error kinds/statuses without console arguments, headers, request bodies or credentials; only events after attachment are available.
Device/browser must stay awake. No blind retries after uncertain actions. On debugger detachment or session expiry reconnect and observe again. Browser source excerpts sent to the selected model are bounded to 3,800 characters and are untrusted data, not instructions.
Desktop Commander is separate: the existing server-scoped connector does not give access to your personal Mac/Windows files or Chrome tabs.

Evidence: tests/test_bridge.py (12 passed); tests/browser_real.py (11 real isolated Chrome checks passed); browser-regression.log (13 existing extension tests passed). Production account pairing and user-installed extension upgrade remain unverified.
