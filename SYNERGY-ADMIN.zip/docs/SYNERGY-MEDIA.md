# SYNERGY MEDIA 1.0 · SYnerGY 2.9

SYNERGY MEDIA processes private uploads on the existing AWS server. ETERNAL and Aerny use the same checked tools in Chat, Work and Beast. Mode entitlements still apply. It does not use a hosted image API or train a new model.

## Use it

1. Open **+ → Media tools**, **Plugins → SYNERGY MEDIA MCP**, or **Settings → MCP Tools**.
2. Upload an image, video or soundtrack, or choose a saved version. The original upload is retained.
3. Choose an operation and its settings. The advanced recipe shows the exact operation the server will validate.
4. Run the edit. Progress reflects actual decoder/encoder or diffusion stages. You can close the tab and reopen Media tools → recent jobs.
5. Review the preview, download the output, or select an earlier version as the next edit's source. Each output records its parent, recipe, engine version, hash and measurements.

In chat, attach the media with Files or + and use requests such as:

- `Resize this image to 1080 × 1350.`
- `Add text "InteriFY Office" at 24, 24 size 32 #212121.`
- `Trim this video from 2 to 8 seconds.`
- `Add caption "Welcome to InteriFY" from 0 to 3 seconds.`
- `Join these videos.` Upload clips in the intended order.
- `Mix audio into this video.` Upload video first, audio second.
- `Compress this video.` Defaults to maximum 1280 width, CRF 28, 30 fps.
- `Make it brighter.` Uses the most recent completed media edit in this conversation.
- `Diffusers: a bright contemporary office with oak desks and plants.` Generates a local image. With a supplied reference, uses image-to-image.
- `Inpaint: replace the marked object with a plant.` Attach source first, white-on-black mask second; or paint a mask in Media tools.

Questions about editing do not start processing. Missing dimensions, trim ranges, caption text or dependencies produce a clarification. This first release recognises a bounded set of edit requests; arbitrary timeline descriptions may require the form or `/media {recipe}`. It does not infer missing caption transcripts or soundtrack files.

## Supported recipes

Image operations run in listed order. They support resize (contain/cover/stretch), crop, right-angle rotation, brightness/contrast/sharpness, exact text, supplied logo compositing and PNG/JPEG/WebP conversion. JPEG transparency is composited on white. Animated and multipage images are rejected instead of silently flattened.

Video operations use this fixed composition order: **trim the first clip → normalise and join additional clips → timed captions/audio mix → export/verify**. Caption times refer to the edited timeline. Inputs with no audio receive silence for reliable joins. Exports are MP4/H.264/AAC, with metadata stripped and fast-start enabled. Re-encoding is lossy. Smaller files are not guaranteed when the input was already heavily compressed; the result records actual sizes.

```json
{
  "kind": "video",
  "operations": [
    {"op": "trim", "start": 1, "end": 4},
    {"op": "captions", "cues": [{"start": 0, "end": 2.5, "text": "InteriFY Office"}]},
    {"op": "compress", "width": 1280, "crf": 28, "fps": 30}
  ]
}
```

OpenCV reports dimensions, mean luminance and Laplacian variance, and produces four sampled video frames. These measurements are **not proof of visual quality**. Human review remains necessary.

## Actual components and licences

| Component | Installed/pinned version | Licence / role |
|---|---|---|
| Python | 3.12 runtime | PSF; API, queue and isolated worker |
| Pillow | 11.3.0 | MIT-CMU; image edits, typography and overlays |
| OpenCV headless | 4.11.0.86 | Apache-2.0; frame decoding and image measurements |
| NumPy | 1.26.4 | BSD-3-Clause; compatible with the installed Torch stack |
| FFmpeg / FFprobe | Debian 5.1.9 package observed | This build enables GPL components including x264; FFmpeg GPL terms apply to binary redistribution |
| Diffusers | 0.30.3 | Apache-2.0; offline diffusion pipelines |
| PyTorch | 2.2.2+cpu | BSD-style; CPU inference |
| epiCRealism | `6522cf856b8c8e14638a0aaa7bd89b1b098aed17` | CreativeML OpenRAIL-M; existing model weights and safety checker |
| LCM-LoRA SDv1.5 | `cf2fced511dbe7e26c8d1d397e728fbab875db4b` | Model card declares OpenRAIL++; existing acceleration adapter |

Original sources: [Pillow](https://github.com/python-pillow/Pillow/tree/11.3.0), [OpenCV wheel](https://pypi.org/project/opencv-python-headless/4.11.0.86/), [FFmpeg legal](https://ffmpeg.org/legal.html), [Diffusers](https://github.com/huggingface/diffusers/tree/v0.30.3), [epiCRealism](https://huggingface.co/emilianJR/epiCRealism), [LCM-LoRA](https://huggingface.co/latent-consistency/lcm-lora-sdv1-5).

Model use remains subject to the respective licence restrictions. Weights and third-party binaries are not included in the source ZIP. Preserve upstream notices when redistributing them. MoviePy is not needed for this release: FFmpeg handles the required composition directly. No unverified “DiffuserPY” package is installed.

## AI boundaries

The observed server has **4 CPU cores, 32 GB RAM and no CUDA GPU**. Text-to-image, image-to-image and masked editing use the installed local epiCRealism SD1.5 weights. Native inference is bounded to 256–768 pixels per dimension, multiples of eight, 4–32 steps (masked edits: 20–32). At up to 12 steps the verified LCM adapter is used; higher step counts use DPM scheduling.

Selective editing runs `StableDiffusionInpaintPipeline` with the existing four-channel base weights, then composites the generated area through the supplied mask. Zero-mask pixels match the fitted reference exactly. Changing dimensions first resizes/crops that reference; exact preservation then applies in the output coordinate space. Dedicated nine-channel inpainting weights are not installed. Generated faces, body shape, texture and scene continuity are not guaranteed exact. The bundled safety checker remains enabled.

Existing short AnimateDiff generation is preserved. This release adds video **editing**, not a new video-generation checkpoint, native 4K inference or a high-end timeline editor.

## Processing and access limits

- Authorised uploads: 200 MiB per file/selection through the existing resumable upload service.
- Image input: 24 megapixels, maximum 8192 per dimension; edit export up to 4096 per dimension. AI has its own smaller native bounds.
- Video input: up to 10 minutes, 4K dimensions, 120 fps and eight streams. Output: up to 120 seconds, maximum 1920 dimension, 30 fps and 200 MiB.
- Queue: one media process, four active jobs per account and 20 globally. No per-message credit balance.
- Timeouts: 10 minutes for editing/analysis, 20 minutes for diffusion. Waiting for shared inference compute counts toward the watchdog.
- Storage: 1 GiB media assets per account, with output space reserved for queued jobs. Delete an unused media project to reclaim its versions; original uploads remain independently managed in Saved uploads.
- User-controlled paths, network media inputs, FFmpeg arguments, expressions and executable code are rejected. The processing container has no network or provider secrets; decoder subprocesses have resource and output-size bounds. This reduces exposure; it is not a proof that every third-party codec is vulnerability-free.
- Account ownership is checked for uploads, projects, jobs, previews, versions, downloads and cancellation. Downloads use private/no-store headers and video byte-range support.
- Duplicate request IDs reuse the existing job. Processing writes a new immutable version only after checksum and decode checks. Cancellation kills the subprocess group and removes partial files. Worker restart retries a running job at most once; interrupted chat wrappers reconnect to the saved job.

## MCP interface

The real newline-delimited stdio server is `app/backend/media/mcp.py`, named **SYNERGY MEDIA**, protocol `2024-11-05`. Host configuration binds it to an authenticated account and mode; remote callers cannot supply their own UID or filesystem path.

```sh
/opt/web/bin/python /opt/synergy/app/backend/media/mcp.py \
  --data /var/lib/synergy --user AUTHENTICATED_USER_ID --mode chat
```

Tools: `media_submit`, `media_job_status`, `media_cancel`, `media_projects`, `media_versions`. Chat starts actual stdio MCP calls. The form and authenticated `/api/media-tools/call` endpoint use the same validated backend operations. `media_submit` accepts authorised upload IDs or a saved source-version ID, a recipe and optional idempotency request ID. No public unauthenticated MCP port is exposed.

## Deploy, test and recover

Use the existing authorised AWS/Hostinger deployment target. Build the application image, preserve the current source, persistent data, environment and credentials, then start the new worker with the other services:

```sh
docker compose -f compose.yaml -f compose.voice.yaml -f compose.connections.yaml \
  up -d app media beast operations lab voice
docker compose -f compose.yaml -f compose.voice.yaml -f compose.connections.yaml ps
docker compose -f compose.yaml -f compose.voice.yaml -f compose.connections.yaml logs --tail 50 media
```

Never run acceptance scripts against production data. In a disposable environment with at least 3 GiB free temporary space:

```sh
cd app
SYNERGY_MEDIA_TEST_PYTHON=/opt/media/bin/python \
  /opt/web/bin/python -m unittest discover -s tests -p 'test_media*.py' -v

# From the repository root; the root must contain a .staging-only marker.
SYNERGY_MEDIA_TEST_ROOT=/media-test SYNERGY_MEDIA_TEST_AI=1 \
SYNERGY_IMAGE_PYTHON=/opt/media/bin/python \
  /opt/web/bin/python tests/media290_acceptance.py
```

The separate worker holds a data-directory lock, publishes a heartbeat and resumes durable queue entries without an open browser. Existing image/video inference and the new engine share a filesystem compute lock to prevent competing diffusion processes from exhausting RAM. Stop or cancel active jobs before a release. Keep the prior Docker image and the release backup. Rollback switches source/images back; do not replace a newer live database with an old backup unless explicitly recovering data loss. Authentication and subscription records must pass the existing deployment guards.

See the release evidence for the tests actually executed. Unavailable dependencies, failed processing or failed safety checks remain explicit errors; a UI preview alone does not establish success.
