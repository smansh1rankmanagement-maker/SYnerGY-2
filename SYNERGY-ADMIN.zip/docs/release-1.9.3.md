# SYnerGY 1.9.3 · Projects, Troubleshoot and Chrome repair

Application update, not newly trained model weights. Aerny v1.6 remains the configured assistant profile over the installed local models.

## Changes
- Informational questions stay in chat. Vague image/video requests ask for a brief; the KISSA example no longer launches an unrelated video.
- Chrome bearer authentication works when privileged requests omit Origin; foreign origins and unscoped routes remain denied. Version 1.1 adds direct website pairing, saved chats, uploads, model/response controls and cancellation. Captured page text is untrusted reference data, separate from the user's instructions.
- Project folders and a persistent project header show the current work across Chat, Work and Beast. Projects can link an owned code workspace, files and instructions.
- Troubleshoot stores ticket IDs, reports, chat references, attachments, timeline, notifications and feedback. The backend Beast worker persists work without an open browser tab.
- Tickets with linked source select a bounded context, queue a Beast proposal and run available syntax/structure checks. With automatic source corrections enabled, passing proposals save a new revision. Failed checks or conflicts stop application of the proposal.
- Saved changes wait for verification. Positive confirmation closes the ticket; negative feedback reopens it. No model statement is treated as proof of a live fix.
- Full source bundle downloads retain original assets and merge current editable source, including source deletions. Larger files support selected-region requests without sending or changing unrelated source.

## Source imports
Owner-private projects: 1RANK WEBSITE PROJECT, SYNERGY FINAL DEPLOYMENT PROJECT, WINZY FINAL DEPLOYMENT PROJECT. Imported packages retain setup instructions and original assets. Production databases, passwords and ChatGPT conversation histories are not imported. The 1Rank CMS authentication config is excluded; its existing live private config must be preserved. Historical React source is explicitly labelled reference-source; it is not claimed to rebuild the later Hostinger output exactly.

## Operating boundaries
- Automatic corrections affect saved private source. Domain deployment, application runtime tests, arbitrary tool installation and access to another client's workspace are not delegated by public tickets.
- Missing source or dependencies produce Needs information / Blocked. Browser, Desktop Commander and plugin installation retain their existing account restrictions; a ticket cannot grant itself new privileges.
- In-app notifications persist; no email or push notification delivery is configured.
- The editor preview is HTML/CSS with scripts/network disabled. PHP/MySQL projects require their documented runtime for a fully executing preview. The full source export is suitable for that setup, but copying a project does not deploy it.
- Models: aerny:v1.6, aerny-fast:v1.6, qwen3-vl:2b-instruct. OpenAI is shown unavailable unless configured and authorised. A Chrome extension does not provide access to ChatGPT subscription models.
- Existing media inference hardware and quality are unchanged by this release.

## Deployment and recovery
Use the existing /srv/synergy installation and persistent Docker volumes. Preserve .env, app_data, models, ollama_data and voice_models. Before switching the application image, back up application data and source, record private auth digests with deploy/auth_guard.py, and verify them after switching. Never run a new account/database installer over the live database.

Run the application regression suite from app with PYTHONPATH=backend:tests. Run the extension security tests with node --test tests/extension/background.test.cjs. The real request scripts in tests/features_192_acceptance.py and tests/features_193_acceptance.py require an isolated test account; their private state files are not release artifacts.

Rollback uses the prior source/config/image and preserved data. This release adds tables and columns; it does not rewrite user password or session records. Only restore a full database backup if necessary and after accounting for newer user work.
