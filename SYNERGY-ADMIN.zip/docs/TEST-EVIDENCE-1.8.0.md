# 1.8.0 verification record

Run against the updated source in a fresh local Linux Python environment on 4 November 2026. See `evidence/test-environment.json` for the actual Python/package versions. The pinned Docker environment itself has not been built here.

| Check | Result | Evidence / scope |
| --- | --- | --- |
| Existing application regression suite | 109 passed | `evidence/regression-tests.txt`; includes unit tests using model/network mocks, plus existing HTTP and export checks |
| New deployment suite | 9 passed | `evidence/domain-tests.txt` |
| Python syntax | 82 files parsed | All delivered Python source and setup/test scripts |
| Browser JavaScript syntax | 5 files passed Node `--check` | Static application modules; no browser UI test claimed |
| Domain origin/cookies | Passed actual HTTP requests | Host rejection, missing/wrong public POST Origin rejection, Secure cookies, login/logout and session invalidation |
| Account isolation | Passed actual HTTP requests | A second account could not retrieve another account's brands, image projects or saved artifacts |
| Exact layout and persistence | Passed actual subprocess / HTTP flow | Uploaded synthetic reference and synthetic logo; exact headline layer; rendered PNG downloaded at 1080 × 1350; reopened after process restart |
| Background exports | Passed actual worker process | HTTP app was stopped; Operations worker generated a real workbook, PDF, Markdown and evidence; reopened and downloaded after app restart |
| Workbook/PDF | Passed structural checks | Three sheets, formula cells retained; actual PDF readable with at least one page. This release did not re-render every exported PDF for visual review |
| Draft schedule and duplicate trigger | Passed | InteriFY QA selected over InteriFY, Monday 09:00 Asia/Kolkata draft retained, same trigger returned one run |
| Workflow approval boundary | Passed | Unactivated run refused; external publish action rejected; unsupported Work action refused before text-only model inference |
| Model download integrity | Passed fixture test | Accepted exact bytes, reused verified weights and refused corrupt hashes; not a real model download |
| Backup and restore | Passed local round trip | Restored saved bytes; refused nonempty destination and path traversal; excluded symlinks |
| Compose exposure and volumes | Passed YAML structure assertions | Only Caddy publishes ports; app data/model volumes and separate workers present |
| Docker Compose build and startup | Not run | No Docker daemon/binary available in the build workspace; use the supplied preflight and install commands on your VPS |
| Caddy certificate / real domain | Not run | No actual domain or target server selected/configured in this task |
| New-server chat/image/video inference | Not run | No model weights, Ollama or GPU in this test runtime; model setup performs its own actual chat smoke test when run |
| Optional GPU profile | Not run | CUDA path is provided for target-hardware verification; no performance or quality result claimed |
| Previous real-model 12-prompt QA | Mixed / several failures | See `docs/BASELINE-QA.md`; not reclassified as passed by these code tests |

The real end-to-end export run deliberately had no approved brand website and disabled model polishing. It completed with explicit input blockers and labelled editorial-template content. It did not fabricate an SEO audit or claim model-generated content.

No messages, posts, advertisements or payments were sent. No live Mac installation was changed. No model training was performed. Source tests establish only their listed behaviours, not perfect output quality or readiness at arbitrary public scale.
