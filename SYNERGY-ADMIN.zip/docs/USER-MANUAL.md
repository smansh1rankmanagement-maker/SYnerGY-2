# SYnerGY browser tasks — extension 1.8.0 / runtime 3.0.6

Install/update
1. Extract SYnerGY-Chrome-Extension-1.8.0.zip into a permanent folder. For an existing unpacked installation, replace the files in its existing folder, retaining a backup.
2. Open chrome://extensions and press Reload on SYnerGY. For first installation, use Developer mode → Load unpacked and select the extracted folder. Chrome must approve the declared debugger permission. Its debugging notice remains visible.
3. Refresh https://synergyai.1rank.in and sign in. The installed extension pairs with this account through the existing challenge and scoped bearer flow. An extension paired to a different account requires explicit reconnection in Settings → Extension.
4. Choose Connect browser → Choose tabs. Grant access only to the sites selected. The first selected tab is the default; activating another authorised tab makes it the default. Only a successful page read changes the browser status to Connected.

Use directly in chat
- Open my selected test website, fill its sample form and inspect console errors.
- Fill "Name" with "Smansh" on my selected tab.
- Read my selected tab and summarise it in three points.
- Inspect console errors and failed network requests on my selected tab.
- Scroll down on my selected tab.
- Take a screenshot of my selected tab.
- Click "Preview sample" on my selected tab.

The included test page is https://synergyai.1rank.in/browser-test.html. Select that tab once, then send the sample request in normal SYnerGY chat. It uses synthetic Name, Email and Message values and never submits the form. The page intentionally produces console errors and a failed request for diagnostic verification. Never use real credentials in this fixture.

Control and connection
Pause prevents subsequent steps and invalidates outstanding tickets. Stop cancels and revokes the selected session, clears the local selection, and detaches diagnostics. A synchronous click already dispatched cannot be undone. Inspect an uncertain result before retrying. Resume allows a fresh observed action; it does not replay an interrupted write. The current task and target appear in chat and the extension control page.

Same-browser sessions reconnect through stored session state and server heartbeat. Host grants alone do not authorise another tab. Authorisation renews while the connected chat is available; a long disconnection, Chrome restart, closed tab, origin change or revoked pairing requires fresh selection. The browser and device must remain running; browser tasks do not run while the device sleeps. Closing the SYnerGY chat interrupts its browser task loop. Backend-only workflows remain separate.

Safety and limits
Only fixed, validated operations run; no arbitrary page/model JavaScript, cookies, request headers or response bodies are exposed. Sensitive pages and password, hidden, payment, OTP, token and credential fields are excluded. Page text is untrusted and cannot grant action authority. Normal input values are omitted from page observations; fill verification returns a boolean. Console/network output contains error metadata, counts, resource types, status and origin, not message arguments or request payloads. Screenshots are withheld when editable, embedded, canvas or explicitly private content is visible; image pixels are displayed to the user and are not sent in the model context.

Clicks use an exact-action review in chat. Purchases, money transfers, sign-in, contracts and destructive controls remain manual. Navigation stays on the selected origin and rejects credential-bearing URLs and query strings. The planner supports explicit labelled fills, synthetic sample forms, reads, same-origin navigation, scrolling, screenshots and diagnostics. Ambiguous fields need exact labels; unsupported form controls and arbitrary multistep web workflows are not promised. Local ETERNAL/Aerny may map a quoted user value to a visible field, but cannot invent personal data or broaden access. At most 16 planned steps run per request.

Diagnostics attach before the requested sample navigation so load-time errors can be captured. Existing errors emitted before attachment cannot be recovered. DevTools or another debugger can block attachment; resolve the conflict in Chrome without suppressing its notices.

Existing Chat, Work, Notes, To-do, Leads, Meetings, reminders and account/subscription checks are retained. Desktop Commander remains the existing server-scoped integration; it is not used to bypass browser permissions.


## Existing SYnerGY features

# SYnerGY user manual

Application 2.0.0 · ETERNAL / Aerny 2.0 · Updated 5 November 2026

Open the current, account-specific guide at https://synergyai.1rank.in/guide. It refreshes from the installed release and your available tools and skills whenever opened or refreshed. This downloaded copy is a snapshot.

## Start here

Sign in with your email and password. Existing username accounts also work. New registrations receive a private recovery key: save it securely. Start a new chat, describe the result you need, and include important constraints.

Example: “Compare these options. Cite sources and separate facts from assumptions.”

## Models and modes

ETERNAL is selected by default. Use the model selector to choose Aerny 2.0. The choice is saved to your account. Chat is free. Work adds brand operations and automations; Beast adds code projects and development workflows. Work and Beast require an active subscription or administrator grant. Instant favours short replies; Medium, High, Max and Ultra allow more response work. More effort does not guarantee correctness.

Example: “Explain this in plain language, then give me three next steps.”

## Projects and transferred source

Use New project in the sidebar to keep instructions, chats and files together. Check the Working in project banner before sending. Imported ChatGPT projects are hidden until an administrator approves your exact registered email in Admin → Project transfers. Source revisions and downloads then appear only in that account. Subscription access is separate from transfer approval.

Example: “In this project, review the existing source and propose a focused change.”

## Research and attachments

Use + to attach files, photos, video or a folder. The limit is 200 MB per file or selection, and 200 files per folder selection. Uploads resume when the same file is reselected after an interruption. Saved uploads contains originals and downloads. Large files are analysed within stated limits: PDF first 50 pages; video four sampled frames, no audio; folders first 20 files and bounded text. Use Web Auto, Search on or Search off. Review Sources and open the cited pages.

Example: “Read this file. Extract deliverables and deadlines, cite sections, and flag missing information.”

## Images, posters and video

Describe the subject, composition, dimensions and what to preserve. For exact text and logos, use Image studio and its layout layers. Selective editing uses a mask. Follow-up edits can use the previous result. Short local video generation is supported when the model is available. CPU generation can take time; 4K export may be upscaled. Exact face or character preservation is not guaranteed.

Example: “Create a launch poster using this approved logo. Use this exact headline and a 1080 × 1350 canvas.”

## Documents and downloads

Ask for a PDF, Word document or spreadsheet with the exact content and fields you need. Review the generated file in Preview and download the actual artifact. Unknown facts remain unspecified. Spreadsheets from Work workflows include editable source; verify formulas and assumptions before relying on them.

Example: “Create a PDF summary from this text. Preserve the figures and add no invented claims.”

## Work and automations

Open Brand Operations, create a brand and add approved inputs. Create a workflow through chat or the automation form. Review trigger, timezone, inputs, steps, approvals and outputs before activation. Backend workers run scheduled work with the browser closed while the server is available. Missing connections block only the affected steps. External publishing, messages and spending need the configured authority.

Example: “Draft a weekly content review for Monday at 09:00 Asia/Kolkata. Show the steps before activation.”

## Beast: code and design

Open Beast workspace, select a project and the files relevant to your change. Ask for a proposal, inspect its diff and checks, then apply it. HTML previews are restricted; React previews use the installed React/Framer Motion compiler in an isolated frame without account or network access. Export the source ZIP to run the full application. Upload a reference video to preserve its original and guide design from four sampled frames. UI/UX Pro Max supplies local design guidance.

Example: “Change only the hero headline. Show the diff and preserve all other content and styling.”

## Suggestions while working

Send a text suggestion while a chat or code task runs. It is saved in a queue and used at the next safe step. Current renders and reviewed source are not altered mid-step. Stop cancels the active task; queued suggestions can be discarded. New attachments wait until the current step ends.

Example: “Keep the current facts, but make the final explanation shorter.”

## Plugins, skills and MCP

Plugins lists the tools available to your account. Skills are reusable instructions. Say Install this plugin or Install this skill followed by a GitHub URL for supported imports. A repository is not automatically a working MCP server: runtime compatibility and permissions still apply. Firecrawl availability is checked when used. Apper needs a separate authorised SYnerGY connection. Desktop Commander operates within its configured private server workspace; it does not give arbitrary access to your computer.

Example: “Use the UI/UX Pro Max guidance to improve this page’s spacing and keyboard accessibility.”

## Voice, Chrome and leads

Use the microphone to start the configured local speech service. In the Chrome companion choose Connect with SYnerGY and approve pairing from your signed-in workspace. Your password stays on SYnerGY. Use this page sends only the excerpt you review. Capture a lead, verify its visible contact details, save it and download Excel. Reload an unpacked extension after installing an update.

Example: “Use this reviewed page excerpt to summarise the business and identify missing contact information.”

## Feedback and Troubleshoot

Submit an issue, improvement request or feedback in Troubleshoot. The ticket records progress and validation. A saved code proposal is not proof that a live issue is fixed. Review the result; reopen with details if it does not meet your expectation. Observation MCP uses explicit correction and detail cues from your message, not an emotional diagnosis. Disable it in Settings if you prefer.

Example: “This is not what I asked. Keep the original facts and explain the steps in more detail.”

## Plans, payment and recovery

After signing in, open Plans & account to choose a Work or Beast duration. Pricing and payment options are kept inside your signed-in workspace. Pay the displayed UPI amount and submit both transaction ID and UTR. Access activates provisionally; bank verification happens later. Never treat a submitted reference as proof of payment. Administrators can verify receipts, grant or revoke subscriptions and suspend access. Resetting a password with the matching recovery key preserves projects and subscription history.

Example: “Open Plans & account to review your current access and saved payment references.”

## Updates and support

This manual reads the installed application version, model configuration and your available skills/tools whenever opened or refreshed. New catalogue entries appear automatically; release-specific procedures are maintained with the source. It does not invent guides or claim that an unavailable integration is connected. Contact 1Rank through About & contact for help. ETERNAL suggestions can be turned off in Settings.

Example: “Use Troubleshoot to report the expected result, actual result and steps to reproduce an issue.”

## Browser control pilot — extension 1.7.2
Download the extension from Settings > Chrome extension. Existing unpacked installs: replace files in the existing folder, open chrome://extensions, and click Reload for SYnerGY. Preserve its extension ID. There is no Chrome Web Store auto-update release.
In the extension click Connect browser > Choose tabs. Grant tab discovery, select up to ten tabs, then grant access only to selected origins. Connection is shown only after a successful page read. Sessions expire after 15 minutes.
From SYnerGY chat (ETERNAL or Aerny, any mode), use:
- Read this page and summarise it.
- Compare these two selected tabs.
- Fill "Name" with "Your supplied value" on this page.
- Click "Sample action" on this page. Review the click in the extension control tab before it runs.
- Inspect console errors and failed network requests on this page. Click Allow diagnostics in browser controls first; reproduce the issue after attaching.
- Scroll down 500 on this page.
- Navigate this tab to https://example.com/path (same selected origin only).
Use Pause or Stop; Stop detaches diagnostics. Chat can remain usable with permissions declined.
Limitations: top-level standard HTML only; no cross-origin frames, shadow-DOM traversal, password/payment pages, form submissions or automatic login. Click confirmation expires after 30 seconds. Screenshots require an active tab and Chrome capture permission, and are refused on pages with fields/iframes. Diagnostics report error kinds/statuses without console arguments, headers, request bodies or credentials; only events after attachment are available.
Device/browser must stay awake. No blind retries after uncertain actions. On debugger detachment or session expiry reconnect and observe again. Browser source excerpts sent to the selected model are bounded to 3,800 characters and are untrusted data, not instructions.
Desktop Commander is separate: the existing server-scoped connector does not give access to your personal Mac/Windows files or Chrome tabs.
