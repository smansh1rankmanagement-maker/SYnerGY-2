> Current profiles are Aerny 2.0 (free Chat) and ETERNAL (Work/Beast). These reuse Qwen3 4B/0.6B and Qwen3-VL 2B weights; the 34 workflow contracts are not evidence of training or measured expertise. OpenJarvis/Faster-Whisper/Kokoro voice details are in [the current release guide](UPGRADE-1.9.1.md). Media models below remain unchanged.

# Actual local components

| Capability | Component | Details |
| --- | --- | --- |
| Balanced chat / work / code proposals | Qwen3 4B Instruct 2507 Q4_K_M via Ollama | `qwen3:4b-instruct-2507-q4_K_M`, configured as `aerny:v1.5` |
| Fast chat | Qwen3 0.6B via Ollama | `qwen3:0.6b`, configured as `aerny-fast:v1.5` |
| Reference-image understanding | Qwen3-VL 2B Instruct via Ollama | `qwen3-vl:2b-instruct` |
| Image generation and reference editing | `emilianJR/epiCRealism` | Stable Diffusion 1.5 architecture; CreativeML OpenRAIL-M; revision `6522cf856b8c8e14638a0aaa7bd89b1b098aed17` |
| Fast image adapter | `latent-consistency/lcm-lora-sdv1-5` | OpenRAIL++; revision `cf2fced511dbe7e26c8d1d397e728fbab875db4b` |
| Short video | `ByteDance/AnimateDiff-Lightning`, 4-step adapter | CreativeML OpenRAIL-M; revision `027c893eec01df7330f5d4b733bc9485ee02e8b2`; epiCRealism base |
| Exact text / logos / export | Pillow, bundled DejaVu fonts and SVG writer | Deterministic layout; editable settings saved with projects |
| PDF / Word / A4 PNG documents | ReportLab, pypdf, python-docx and Pillow | Actual files rendered from supplied or locally drafted content; no diffusion typography |
| Video finishing | FFmpeg / imageio | Optical-flow frame interpolation and resized MP4 exports |

The pinned media manifests and large-weight SHA256 values are in `app/backend/studio/models.lock.json` and `app/backend/video_studio/models.lock.json`. The setup script downloads about 6.5 GB of media model files, plus chat models and container dependencies. Reserve additional room for outputs, caches and backups. The 4-step motion adapter is the default; do not change its step count without installing a matching adapter. Small configuration files are fetched at pinned revisions; their observed SHA256 values are recorded after download.

Qwen model pages describe their Apache-2.0 licensing; retain the model licences and comply with all applicable terms. Review the actual model cards before download:

- https://ollama.com/library/qwen3
- https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507
- https://huggingface.co/Qwen/Qwen3-0.6B
- https://huggingface.co/Qwen/Qwen3-VL-2B-Instruct
- https://ollama.com/library/qwen3-vl
- https://huggingface.co/emilianJR/epiCRealism
- https://huggingface.co/latent-consistency/lcm-lora-sdv1-5
- https://huggingface.co/ByteDance/AnimateDiff-Lightning

The upstream media licences include use restrictions; “free for your users” does not remove those terms. No rights to uploaded third-party assets are supplied by this project. Bundled software notices are preserved under `app/backend/THIRD_PARTY_NOTICES/` and the font directories.

Ollama model tags can change upstream. `model-installation.json` in the data volume records the actual model digests and installation time. Preserve the Ollama volume when reproducibility matters. Source model profiles are not foundation-model training: no ChatGPT weights were obtained, and no new model training is claimed.

## Fidelity and dimensions

- Image inference uses bounded native sizes, typically 512–768 pixels on the longest side depending on settings. Large and 4K downloads are enlarged exports, not native 4K inference.
- Selective editing uses a crop, image-to-image generation, and compositing that preserves protected pixels before overlays. It is not a separately trained inpainting model.
- Exact identity, product geometry and texture preservation are not guaranteed. Review generated content visually.
- Video is a short, roughly two-second sequence with 8–16 native model frames, interpolated to 24 fps and upscaled. It is not a long-form, native-4K video model.
- CPU inference works through the existing local pipeline but can be very slow. The new optional CUDA path has not been run on a GPU in this release.
- Safety-checker files are retained. Missing or failed checks do not silently bypass filtering.

The default deployment explicitly disables OpenAI and Ollama cloud inference. OpenAI code remains in the source for a future authorised configuration; no key or paid connection is included. The optional Firecrawl connector uses an explicitly installed external service with availability limits; it is not the image/video engine. No silent hosted generation fallback is implemented.
