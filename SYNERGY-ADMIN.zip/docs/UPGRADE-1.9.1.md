# SYnerGY 1.9.1 · Aerny v1.6

Live workspace: https://synergyai.1rank.in

This is an application and assistant-profile upgrade, not a newly trained model. Existing accounts, scrypt password records, invite configuration, session cookies, conversations and persistent Docker volumes are retained. No new paid service or GPU was activated.

## What to use

| Feature | Use it | Implementation / limits |
| --- | --- | --- |
| Projects in all modes | Left sidebar → New project; choose Chat, Work or Beast | Account-owned SQLite projects, instructions, reference files and conversations. File context is scoped to the selected project. |
| Voice | Microphone beside Send → allow the microphone → speak; End voice stops listening | Actual OpenJarvis speech adapter. Local Faster-Whisper small CPU/int8 and Kokoro-82M. Maximum 30-second recording, one speech job at a time. Browser permission/autoplay still applies. |
| AWS deployment | Skills → AWS deployment, or ask about AWS/domain deployment | In-app guide for the existing EC2, SSM, Docker, Hostinger DNS and TLS setup. It does not create an AWS connector or grant console access. |
| GitHub installation | `install https://github.com/owner/repository` in any mode | Compatible SKILL.md workflows are pinned to a commit, imported and available in every mode. Known runtime connectors run real installation and connection checks. |
| Pasted skill/code | `install this skill` followed by a fenced SKILL.md; or `install` followed by fenced source | Skills become reusable instructions. Code is saved in a Beast project for review. |
| Other repositories | Same install command | Up to 60 supported source files / 2 MB are saved in Beast and listed in Plugins as **source imported; setup required**. Unsupported/large/sensitive files are reported as skipped. Arbitrary install scripts are not run. |
| Desktop Commander | `Install Desktop Commander`, then `Desktop Commander list files` / `Desktop Commander read README.md` | npm package 0.3.1, locked integrity, MCP tool discovery. Read/list/search only, in the account's private server workspace. No laptop control or unrestricted shell. |
| Files for Desktop Commander | Plugins → Desktop Commander → Add a workspace file | UTF-8 text/code up to 8 MB. 100 files / 50 MB per account; duplicate names receive a suffix. |
| Lead capture | Leads & Chrome → Scan page → review → Save lead | One explicit public page per scan. Visible company/email/phone/source captured; missing facts remain blank. Private-network/metadata addresses blocked. No outreach is sent. |
| Spreadsheet | Leads & Chrome → Download Excel | Real XLSX: structured leads table, filters, dates, status validation, summary formulas and source/method sheet. Duplicate emails/phones or company websites are skipped. |
| Chrome companion | Leads & Chrome → download ZIP → unzip → Chrome extensions → Developer mode → Load unpacked | Manifest V3 side panel. Explicit current-page capture with activeTab; no passive browsing collection or all-sites permission. Chat and leads API access only. |
| Pair Chrome | Leads & Chrome → Connect extension → paste code into extension | Account-owned hashed, revocable 30-day token. Pairing does not change your website password. New pairing replaces the old pairing. |

## Model and software details

- Balanced: `aerny:v1.6`, a configured profile over the existing Qwen3 4B Instruct quantised model.
- Fast: `aerny-fast:v1.6`, a configured profile over the existing Qwen3 0.6B model.
- Vision: existing Qwen3-VL 2B Instruct.
- Voice: https://github.com/open-jarvis/OpenJarvis at commit `324c9c3ac61bff07a0d99b715a7511dcd78600c4`. Apache-2.0. Only its speech adapter is integrated; its wider autonomous agent/shell facilities are not enabled.
- Speech recognition: https://huggingface.co/Systran/faster-whisper-small (MIT), faster-whisper 1.2.1 / CPU int8.
- Speech synthesis: https://huggingface.co/hexgrad/Kokoro-82M (Apache-2.0), Kokoro 0.9.4 / CPU. Actual downloaded model revisions are recorded in the private voice volume's `manifest.json` and public release evidence.
- Desktop Commander: `@wonderwhy-er/desktop-commander` 0.3.1, installed using the committed npm lockfile with lifecycle scripts disabled. Only reviewed read/list tools are exposed.
- Leads: Python HTML parser and existing DNS-pinned public-page fetcher; openpyxl 3.1.5 for XLSX. No paid scraper connection added.
- Existing image/video models remain unchanged. CPU inference is still limited; 4K exports are upscaled. This upgrade does not claim improved native image/video model quality.

## Existing deployment

Mumbai `ap-south-1`, EC2 `i-079d0b994ee63ed15`, Ubuntu 24.04, r6i.xlarge, no GPU. Hostinger DNS points `synergyai.1rank.in` to Elastic IP `13.204.133.193`. Public TCP 80/443 only. SSM is the administrative path; Docker backend/model/voice ports remain private.

Source: `/srv/synergy`. Compose project: **synergy**. Keep that name: changing it would create different empty volumes. Existing data is `synergy_app_data`, models `synergy_models`, Ollama `synergy_ollama_data`; voice weights use `synergy_voice_models`. TLS state is preserved in the Caddy volumes.

Never replace the live `.env` with `.env.example`, regenerate the invite code, delete the accounts DB, run `docker compose down -v`, or rename the Compose project when upgrading.

## Upgrade an existing installation

1. Open EC2 → SYnerGY AI → Connect → Session Manager in Mumbai.
2. Inspect running jobs and wait for them to finish. Keep a copy of the current source, image tag, `.env` and Compose files.
3. Stop `app operations beast` briefly. Use `deploy/auth_guard.py snapshot` and `deploy/data_archive.py backup` against the persistent data volume. These outputs contain private auth/database data; keep permissions at 0600, never export them in the source ZIP.
4. Build and test the new image against an isolated temporary data directory on the private Docker network. Test login, projects, voice, repository imports, leads and exports before switching.
5. Copy reviewed source changes to `/srv/synergy`. Preserve `.env` and all volumes. Set `SYNERGY_APP_IMAGE=synergy-ai:1.9.1` and `COMPOSE_FILE=compose.yaml:compose.voice.yaml`; preserve all other settings.
6. Run `docker compose up -d --no-build --wait app operations beast caddy voice`. Voice image and model volume already exist after the v1.6 upgrade.
7. Run `deploy/auth_guard.py verify` against the snapshot. Then verify the existing session and password over HTTPS, all service health checks, a project reference, a voice round trip and a real saved/downloaded lead workbook.
8. Keep rollback source, image and data backup. Backups are private and retained on the existing server. The upgrade adds tables/columns; it does not replace passwords or sessions.

## Recovery

If a service cannot start, restore the backed-up source, Compose files and `.env`, then start the previous image with the same volumes. The pre-1.9.0 source/config is under `/srv/synergy/backups/pre-190`; the 1.9.0 baseline for this patch is under `/srv/synergy/backups/pre-191`. Do not restore an older database merely to roll back code: doing so could discard work saved since the backup. Data restore is a separate recovery operation requiring a review of what would be lost.

For a fresh machine use `START-HERE.md`, `docs/CLOUD-DEPLOYMENT.md` and the AWS deployment workflow. Model weights and account credentials are deliberately excluded from the project ZIP. `deploy/manage.py install` provisions the configured local services; live upgrades must follow the preservation procedure above.

## Verification scope

See `evidence/` for current automated test logs and real candidate/live request results. Browser-level physical microphone permission/audio playback and loading the extension into Chrome require that browser's user permission. The extension ZIP and server API are tested separately; do not interpret API tests as a Chrome Web Store publication or a physical-microphone test. The extension is distributed unpacked, not published in the Chrome Web Store.
