# SYnerGY 1.9.1 verification — 5 November 2026

## Automated checks

- 126 application regression/security tests passed locally (18.729 s) and in the AWS image (31.689 s).
- 9 deployment/backup tests passed locally (5.688 s).
- Python source syntax and modified JavaScript syntax validated. Extension public-key hash matches the narrow allowed Chrome origin.
- The first 1.9.0 candidate exposed a multipart project-file field omission; fixed before cutover, then the complete project/voice acceptance passed.
- The first 1.9.1 acceptance started before its private candidate listened; it was rerun after readiness and passed. This was a test startup race, not reported as successful.

## Real completed requests

- Existing account password and cookie login worked after the 1.9.0 upgrade. Existing saved conversation remained accessible.
- Projects in Chat, Work and Beast: uploaded reference used to answer CEDAR-826; a separate project answered unspecified and had no reference-file evidence.
- OpenJarvis voice: an actual saved reply produced a valid 6.225-second WAV in 2.75 seconds; local transcription completed in 2.03 seconds; transcript → Aerny response → WAV passed. This verifies the API path, not the physical microphone or browser autoplay permission.
- Authenticated/anonymous and cross-account project, reference and voice access controls passed.
- Pasted skill installation succeeded in all three modes on both the private candidate and live HTTPS site.
- Real GitHub skill import resolved to `ca45fc496a3436251f191354091d557da31c15b5`; source import of octocat/Spoon-Knife saved 3 files at `d0dd1f61b33d64e29d8bc1372a94ef6a2fee76a9`. Source-only status correctly required runtime setup.
- Public scan of https://1rank.in returned the observed company title; no email or phone was found and those fields stayed blank. Saving, duplicate prevention and an actual XLSX download passed. Workbook tables, status validation and working summary formulas were inspected with openpyxl. Excel's interactive calculation/rendering was not automated.
- Chrome pairing, exact-origin CORS, scoped bearer access, real assistant reply, protection from instructions in captured page text, revocation and ZIP download passed. Chrome extension loading and its OS permission flow have not been automated.
- Metadata URL 169.254.169.254 blocked; unit tests also covered loopback/IPv6 private access, other-account edits and spreadsheet formula-injection text.
- Desktop Commander installed through the owner's actual signed-in SYnerGY chat in 8 seconds. MCP handshake succeeded, followed by a real README.md read in 1 second. No shell tool was exposed. A live Beast-mode request with the development workspace open also reached Desktop Commander without creating a code change.

## Account continuity and health

The 1.9.1 cutover recorded and checked **9 existing account records and 6 unexpired sessions**. All password-record digests and sessions matched afterward. It did not regenerate the invite code or cookies. App, Operations, Beast and voice were healthy; Caddy and Ollama remained running and answered the real HTTPS/model requests.

Private rollback source/config/database backups are retained on the server under `backups/pre-190` and `backups/pre-191`. They are excluded from the downloadable source.

Machine-readable reports are in `evidence/release-1.9.1.json`; unit/domain logs are alongside it. Earlier image/video and Work/Beast acceptance outcomes remain in their original versioned reports. This release does not retroactively turn earlier quality/runtime failures into passes.

## Browser UI check

The owner stayed signed in after reload. Leads & Chrome appeared in the sidebar; scanning 1rank.in, reviewing and saving the record succeeded. Clicking Download Excel completed a real browser download named `SYnerGY-leads.xlsx`. The example is labelled as a verification record and no outreach was sent.

Runtime/source audit: all 91 Python/JavaScript/HTML/CSS/JSON/Markdown application files across backend, static, skills and extension matched the deployed container. Aggregate SHA-256: `5f9adb4483d56d4f24b9ab4dbf13d23b0f5e00141f64ed9b58807e817249abba`. Temporary QA containers were removed after verification.
