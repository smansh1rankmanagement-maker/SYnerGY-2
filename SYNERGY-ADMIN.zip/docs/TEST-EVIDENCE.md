# 1.8.1 verification record

Verified 5 November 2026 (India time). Source changes were tested in the supplied Linux workspace, then real generation was run on the existing Mac before installation. No paid API or model training was used.

| Check | Result | Evidence / scope |
| --- | --- | --- |
| Application regression suite | 120 passed | `evidence/regression-tests.txt`; 109 inherited checks plus 11 creation checks; mocks are used where stated in each test |
| Deployment suite | 9 passed | `evidence/domain-tests.txt`; real local HTTP/process/export and backup checks, not a Docker build |
| Python and browser JavaScript syntax | Passed | Counts in RELEASE.json; all delivered Python parsed and static JS checked by Node |
| Creation routing | Passed | Images, video, poster, Instagram, PDF, Word, A4 PNG; negative/questions/workflow requests do not trigger creation; document subjects mentioning video remain documents |
| Real document files | Passed | Actual ReportLab PDF, python-docx DOCX and Pillow PNG; text retention and dimensions checked; local model drafting verified separately on Mac |
| Download permissions | Passed | Owner can download; second account gets 404; unauthenticated request gets 401; failed task has no fake output |
| PDF preview headers | Passed | Same-origin PDF framing allowed; unrelated content retains the existing framing restrictions |
| Image and poster follow-up | Passed | Actual local CPU image, actual exact typography layout, separate saved revision; final UI upload/layout/rename/download verified |
| Real video | Passed | Actual AnimateDiff/epiCRealism run; MP4 decoded fully: 2 seconds, H.264, 1920 x 1080, 24 fps, 48 distinct frames |
| Cancellation / duplicates | Passed | Repeated request ID returns the existing task; queued image child cancels; cancelled video does not become a failed/succeeded job |
| Missing model / disabled plugin | Passed | Saved actionable failure; no completed-artifact download link |
| Main Mac deployment | Passed | 1.8.1 health response, three startup definitions updated, worker heartbeats; earlier source and database/startup backup retained |
| Browser preview and downloads | Passed | Real PDF and PNG downloads, inline PDF rendering, reference upload, Instagram post and headline revision in ordinary Chat mode |
| New public domain / TLS / Docker build / CUDA | Not run | These require target-server verification; no public deployment claimed |

The six full Mac generation results, prompts, durations, actual model settings and artifact hashes are in `evidence/mac-creation-acceptance.json`. Video decoding is recorded in `evidence/mac-video-decode.json`. UI checks and deployment observations are in `evidence/mac-ui-checks.json`. Staging generation used separate QA data; final UI checks used only synthetic test content in the user's app.

PDFs were visually checked for readable type and clipping, and the final poster preview was reviewed. Automated tests and frame differences are functional evidence, not proof of perfect visual quality. The video is interpolated/upscaled and the image is enlarged from a modest native render budget. Timings and limits are in CREATION-UPDATE.md.

The historical domain verification is retained in TEST-EVIDENCE-1.8.0.md. Older real-model quality failures in BASELINE-QA.md are not retroactively counted as passed. An initial regression command using a different, dependency-incomplete virtual environment failed imports; the final 120-test result used the primary runtime recorded in the environment file.
