# Feature status — 2.0

The current status, components and limits are maintained in [ETERNAL-2.0-RELEASE.md](ETERNAL-2.0-RELEASE.md). The signed-in [user manual](https://synergyai.1rank.in/guide) refreshes from each account’s current tools and skills.

Earlier versioned evidence remains in this directory; it does not automatically certify the latest model quality.
