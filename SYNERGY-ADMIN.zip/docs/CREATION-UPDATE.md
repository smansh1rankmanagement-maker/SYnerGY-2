# SYnerGY 1.8.1 — create directly from chat

The existing app on the Mac was updated to 1.8.1. Open http://127.0.0.1:8090/ and refresh older tabs once. Aerny remains the v1.5 local profile. No new model training or hosted generation service was used.

## What was fixed

Ordinary chat previously went to text inference, while image/video workers required separate UI paths and general document export was missing. The new server-side creation router connects supported requests to those real workers and to a document renderer. Replies attach download links only after an actual file exists and its hash is recorded. Results are saved with the account's conversation and can reopen in the right preview.

Enabled skills are selected automatically for supported requests. Built-in image direction, poster/social layout, storyboard and document creation workflows select the appropriate tool. Matching imported skills supply instructions to the text assistant; importing arbitrary code does not create an executable tool. Manually selected skills retain priority.

## Prompts to use

| Request | Result |
| --- | --- |
| Create a photo of a walnut desk beside a window, realistic wood texture. 768 x 512. | Local image inference; PNG and editable-layout SVG |
| Create an Instagram post from this image. Keep the image unchanged. Headline "Room to create". 1080 x 1350. | Exact layout using an uploaded or earlier generated image |
| Change only the headline to "Spaces that feel like you." | New saved image-project version with the prior image and layout |
| Create a fast two-second video of a plant moving gently in a sunlit room. | Local motion inference, downloadable MP4 |
| Create a short PDF about preparing an office-design brief. | Local assistant drafts content, then ReportLab renders an actual PDF |
| Create an A4 PDF. Exact content: followed by your content | Lossless supplied wording, without asking a model to rewrite it |
| Export the previous answer as PDF. | Actual PDF of the prior completed answer |
| Give me the same document in a PNG file. | A4 2480 x 3508 PNG; multi-page documents include a ZIP of pages |
| Create a Word document. Exact content: followed by your content | Actual editable DOCX |

Use **+ → Add photos or files** for a reference. Creation routing works before the Chat/Work/Beast-specific action paths. No manual skill selection is needed for these built-in requests. A selected-area edit still needs a painted mask in Image Studio; an approved logo request needs an approved brand asset. Missing inputs produce a useful error rather than a different, unrequested edit.

The task shows real worker stages, elapsed time, stop/retry controls and the selected tool. Restarted tasks are marked interrupted and can be retried; queued child work is cancelled so it cannot silently produce an unlinked second result. Completed files survive restart.

## Measured results on the existing Mac

| End-to-end request | Time | Observed output |
| --- | ---: | --- |
| Supplied-content PDF | 0.28 seconds | Valid, downloaded PDF and editable Markdown |
| Locally drafted PDF | 38.62 seconds | Five project-brief questions, rendered as a PDF |
| New desk photograph | 98.89 seconds | 768 x 512 PNG; epiCRealism + LCM, CPU |
| Instagram layout | 2.92 seconds | 1080 x 1350 PNG with exact headline |
| Headline-only revision | 2.92 seconds | Separate saved project, exact new headline |
| Local video | 356.38 seconds | Two-second MP4; 48 decoded frames at 24 fps, all 48 distinct |

These are one-device observations, not speed promises. The photo's native inference was 512 x 344 before enlargement. The video used 8 native frames at 512 x 288, interpolated and enlarged to 1920 x 1080. They are real local model outputs, not native 4K or guaranteed identity-preserving results. Subjective visual quality still needs human review.

The final installed browser flow additionally passed: create PDF → open inline PDF preview → download → export the same document to PNG → upload a generated image → create Instagram layout → change its headline → download the revised PNG. The revised default layout keeps the headline clear of the reference image.

## Runtime and rollback

Active source on the configured Mac:
`~/Library/Application Support/SYnerGY/v1.8.1`

Existing data and models remain at their configured locations. The app, Operations worker and Beast worker startup definitions were switched to the new source; the health endpoint returned version 1.8.1. All three startup definitions and a consistent SQLite backup were saved at:
`~/Library/Application Support/SYnerGY/backups/before-1.8.1-20261105-030345`

The previous v1.7.0 source directory was retained. For a rollback, first let active jobs finish or cancel them, stop all three `in.1rank.synergy-*` LaunchAgents, restore the saved startup definitions to `~/Library/LaunchAgents`, then bootstrap them in the current user's GUI domain. Normally retain the current data directory so recent work is not lost. Restoring the pre-update database is a separate recovery action: back up current data first and expect to lose records created after that snapshot. Do not run the historical v1.5 upgrade script to undo this release.

For a new Linux deployment, follow START-HERE.md, then test on the target machine. Existing source versions and the 1.8.0 release remain preserved. The ZIP contains code, docs and synthetic test evidence; it does not contain credentials, private chats, accounts, or model weights.

## Remaining limits

- This router supports the formats listed above, not every possible artifact. Spreadsheet/calendar exports continue through the existing Brand Operations workflow; generic PowerPoint and arbitrary multi-tool requests are not implemented by this change.
- Built-in routing is bounded phrase/intent matching, not an unrestricted autonomous planner. Unusual wording may need an explicit request such as "Create a PDF".
- Local video is limited to roughly two seconds. Longer requested durations are rejected clearly. CPU generation can take several minutes.
- Models and native detail are unchanged. No native-4K, perfect character fidelity, or model-training claim is made.
- Exact typography uses the installed fonts. Hindi/complex-script PDF shaping and arbitrary font upload have not been verified.
- The current Mac works locally. A public domain, Docker runtime and optional NVIDIA profile still require separate target-server acceptance; this update did not provision paid infrastructure.
