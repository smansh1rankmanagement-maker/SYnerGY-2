# SYnerGY 2.0 · ETERNAL and Aerny 2.0

This release adds subscriptions, email accounts, administration, ownership answers and contact forms to the existing application. Aerny 2.0 and ETERNAL are configured assistant profiles using existing local weights and tools. No foundation-model training or LoRA adaptation was performed.

## Plans

| Mode | 7 days | 15 days | 30 days |
| --- | ---: | ---: | ---: |
| ETERNAL or Aerny 2.0 · Chat | Free | Free | Free |
| ETERNAL · Work | ₹99 | ₹200 | ₹300 |
| ETERNAL · Beast, including Work | ₹649 | ₹1,149 | ₹1,500 |

Plans and payment options appear only after sign-in, under Plans & account. The login and registration screen has no pricing link or sales message. Direct /pricing links lead through sign-in.

Prices are for early access. Prices may vary by country at official launch. Plans are prepaid durations, with no automatic renewal or credit balance. Enterprise enquiries use the contact form.

## Registration and recovery

Registration requires an email and a password of 12–128 characters. No registration access code is required. Existing username/password accounts remain valid; users can add an email in Plans & account after confirming their current password. Password hashes, conversations and existing sessions are preserved during the upgrade.

A private recovery key is shown once at registration. Store it securely. Reset requires the matching email and key, rotates the key, and revokes old browser and extension sessions. Subscription and payment records remain intact. Administrators can issue a distinct 30-minute reset key after verifying a user's identity. Keys are stored as hashes and never listed in the dashboard. Email verification and automated password-reset delivery are not configured; this release does not claim otherwise.

## UPI checkout

1. Choose Work or Beast and a duration.
2. Scan the uploaded QR, or choose Pay with UPI on a compatible device.
3. For the supplied static QR, enter the exact displayed amount. The deep link includes the plan amount and a unique order reference.
4. Enter both the transaction ID and UTR from the completed payment.
5. Access activates provisionally immediately, as requested by the owner. Continue to WhatsApp or email to submit the prepared details.
6. The administrator compares the submission with the actual bank statement, then verifies or rejects it.

The payment address is `smanshonerank@ptyes`. The QR's bank beneficiary is **SATISH KUMAR SINGH**. The checkout is branded **SYnerGY** and shows this beneficiary clearly. References cannot be reused across accounts, orders or reference fields. Retried submissions do not duplicate access. Renewal of the same mode starts after the existing duration ends.

A submitted UTR is not bank confirmation. Provisional submissions are excluded from confirmed income. Rejected payments revoke the corresponding access. No payment gateway, banking API, automated debit, real test transfer or automated bank verification was added.

## Admin panel

Open `/admin`, or use Admin panel in the sidebar. Use the administrator credentials supplied by the owner; credentials are not included in this source package. The existing owner account also retains administrative access without a password reset.

| Area | Available actions |
| --- | --- |
| Users & contacts | Inspect username, email, name, contact number, state and last payment; activate or terminate account access; issue a reset key. |
| Manual subscription activation | Use **Activate subscription manually** beside the account. All six duration/price options are available. Add the reason; access starts immediately. This records an administrative grant, not income. |
| Subscriptions | See mode, start, expiry and origin; terminate access. Expiry is checked server-side. |
| Payments | Inspect amount, plan, UTR, transaction ID and state; verify or reject with bank evidence and payment date. |
| Bank statement | Upload CSV, inspect exact matches, confirm the reviewed batch. Unmatched, duplicate, debit and already-reviewed rows are excluded. |
| Income | Verified receipts today, this calendar week and this calendar month, using Asia/Kolkata; provisional totals shown separately. |
| Troubleshoot | Read tickets and activity, add a status update, record validation before closing. |
| Exports and history | Download payment CSV and inspect the administrative audit trail. |

Account termination suspends access and revokes sessions; it does not erase financial history. Administrators cannot suspend each other through this panel. The dashboard currently lists the latest 1,000 users/payments/subscriptions and 500 tickets; totals are calculated across the full payment table. Large-account pagination is not implemented.

Bank CSV headers: `UTR,Transaction ID,Amount,Date,Type`. Date is ISO `YYYY-MM-DD`, interpreted in Asia/Kolkata unless an explicit timestamp timezone is supplied. Amount is in rupees. Type is `credit` or `cr`; debit entries are excluded. At least one exact reference and the exact amount must match. Review batches expire after one hour and refuse stale payment state.

## Identity and contact

SYnerGY means **“A friendly assistant between you and the knowledge.”** It is owned by **1Rank — Brand Management Company**, https://www.1rank.in. Its stated purpose is to find resources and knowledge and help users create what they imagine.

Direct identity/ownership questions use the configured identity record and are saved in conversation history. The same facts are supplied to the assistant context for broader questions.

`/contact` collects name, email, optional contact number, reason and message. Email and WhatsApp buttons open a prepared message for the user to review and send. Contact: **synergyai@1rank.in**, **+91 91134 32032**. The form does not silently send email or messages.

## Components and capability status

| Component | Release status |
| --- | --- |
| Aerny 2.0 | `aerny:v2.0` / `aerny-fast:v2.0`, existing Qwen3 4B / 0.6B weights with upgraded instructions. |
| ETERNAL | `eternal:v1.0` / `eternal-fast:v1.0`, the same existing weight families; default in Chat, Work and Beast until changed. |
| Image understanding | Existing Qwen3-VL 2B profile. |
| 34 expertise areas | Versioned workflow contracts and selectable skills, grounded in available components. No independent proficiency benchmark or “medium expertise” certification. |
| Image/video, exact layout, documents | Existing engines, permissions, storage and exports retained. This release does not introduce new media weights or claim a quality increase. |
| Work scheduling and Beast | Access is checked for new requests and by workers. Expired access pauses scheduled Work; saved projects/downloads remain accessible. |
| Chrome companion | 1.2.0 source retains the extension identity, pairing and scoped permissions, and updates model/billing descriptions. Installed unpacked copies need reloading after replacing their files. |
| Voice | Existing OpenJarvis speech adapter, faster-whisper and Kokoro retained. |
| VEDICS / FOUNDERFIT | The supplied broader guide is preserved in ETERNAL-BRIEF.md. Separate school systems, grading services and dedicated FOUNDERFIT MCP servers are not implemented in this release. |
| Daily autonomous learning | Existing user-approved knowledge records remain; no autonomous training or unsupervised weight updates were added. |

OpenAI remains disconnected unless explicitly configured. No new paid provider or infrastructure was activated. Current hosting has CPU inference, no GPU; response time and visual quality retain those limitations.

## Test and deployment procedure

1. Run the Python feature tests from `app`: `PYTHONPATH=backend:tests python -m unittest discover -s tests -v`.
2. Run deployment tests from the repository root: `python -m unittest discover -s tests -v`.
3. Run extension background checks: `node --test tests/extension/background.test.cjs`.
4. Keep the existing Compose project name **synergy**, `.env`, persistent volumes, previous image and source. Never use `down -v` during an upgrade.
5. Stage `synergy-ai:2.0.0`, test against isolated data, and run the additive membership migration on a private SQLite backup. Verify auth digests before cutover.
6. Create the new Ollama profiles from the already-installed Qwen weights. Retain old aliases for rollback. Fresh installs use `deploy/setup_models.py` after reviewing model licences; this is a model download/configuration process, not training.
7. Wait for active jobs, stop application writers, snapshot auth digests and archive the application-data volume. Keep backups private, outside source packages.
8. Copy reviewed code to `/srv/synergy`, preserve `.env`, set the image to 2.0.0, and start app/workers with the existing volumes.
9. Provision the dedicated administrator once through `deploy/provision_admin.py --username <admin-username> --owner <existing-owner-username>`, piping the secret through stdin. It refuses to replace an existing non-admin and never changes an existing admin password. Do not put passwords in source or shell command arguments.
10. Verify HTTPS, service health, preserved auth digests, owner login, all three modes, admin access, contact/pricing pages and saved projects. Keep the old image and private backups for rollback.

The canonical 2.0 acceptance runner is `tests/eternal_acceptance.py`, run only against the named isolated staging data. Historical 1.x cloud acceptance scripts retain their original assumptions and are not the 2.0 release procedure.

## Rollback

Keep `synergy-ai:1.9.3` and the pre-upgrade source/config/data backup. The migration adds columns and tables; the old release can read existing users without replacing hashes. For a full rollback, stop writers, restore the prior source/config/image and restore the private data archive into a separate empty volume, then verify counts and auth digests before switching it into service. A snapshot restore loses writes made after that snapshot; retain the newer volume for recovery. Do not discard either volume or financial history.


## Model welcome and visible modes

ETERNAL is the default for all modes, including free Chat. The account saves an explicit Aerny selection. Chat / Work / Beast appear directly in the header. A first-use guide explains their capabilities and access. After switching to Aerny, a nonblocking suggestion appears at five-minute intervals while the page is visible and recently active. Dismissal preserves Aerny; users can turn off suggestions. It never changes a running job's model.

## Uploads, live suggestions and Observation MCP

The chat uploader accepts 200 MiB per file or selection and up to 200 files per folder batch. Four-MiB chunks support retries, resumption, integrity checking and account-scoped downloads. Default saved-upload quota is 1 GiB per account; delete uploads to reclaim it. Originals remain separate from analysis. PDF extraction is capped at 50 pages and 120,000 characters; folder analysis reads the first 20 files with a 100,000-character budget. Video analysis supports up to 30 minutes and 4K dimensions but samples only four frames, without audio. Image analysis uses a 1,280-pixel preview, up to 80-megapixel originals. Legacy project-reference and extension attachment forms still have 8 MiB limits; use the main chat uploader for large files.

Text suggestions sent during a running research or Beast task are stored durably and applied at the next safe step. They do not edit an active render or override reviewed source. Cancellation, bounded queues and account checks apply. Actual task dispatch was tested; the small model's response quality still needs review. In the test, a request for one bullet returned three, so infrastructure success is not a language-quality pass.

Observation MCP is a local, read-only JSON-RPC tool that extracts explicit correction, detail, brevity, urgency and positive-feedback cues from the current text. It does not infer hidden emotions, diagnose users, train weights or grant tool authority. Users can disable it in Settings.

## Design and app building

UI/UX Pro Max design data and scripts are installed locally under their MIT licence. React 19.3.1, React DOM 19.3.1, Framer Motion 14.9.1 and esbuild 0.28.2 are pinned and installed in the trusted builder runtime. Project lifecycle scripts are not executed. React previews run in opaque sandboxed iframes with no network, form submission or account access. The static HTML preview stays restricted. Build concurrency is bounded.

Reference-video originals and four extracted frames are stored privately. Beast can send sampled frames to the installed Qwen3-VL model. Frame extraction, original preservation and export are tested; full video-to-website fidelity has not been benchmarked. Sampled frames cannot reproduce unseen interactions or exact animation timing.

Firecrawl is enabled in the catalogue and checked when used; unavailable service falls back visibly to public-web tools. Apper is listed but requires a separate authorised integration. No working authenticated Apper build adapter or paid Apper service was added. These tools do not remove Work/Beast subscription checks.

## Approval of transferred ChatGPT projects

The imported **1RANK WEBSITE PROJECT**, **SYNERGY FINAL DEPLOYMENT PROJECT** and **WINZY FINAL DEPLOYMENT PROJECT** start **Pending**, invisible to every account, including the original owner. In **Admin → Project transfers**, enter an existing account's exact email, verify the recipient, record the reason and approve. Only that account receives the project and its linked chats, editable source, revisions, files and downloads. Approval does not purchase or grant a subscription.

The backend moves the imported project scope out of login accounts until approved. Direct URLs remain protected. Reassignment removes the previous account's access; Revoke hides it from all accounts again. Active jobs must finish or stop first. Approved recipients cannot change their email until an administrator revokes or reassigns their transfers. Review actions carry a version check and an audit record. Passwords, sessions, payments, subscriptions and unrelated projects are untouched. Already-downloaded files cannot be recalled.

## Automatically refreshed user manual

Every account has **User manual** in the sidebar and at `/guide`. `/api/manual` builds the guide from the installed application version, model catalogue and the signed-in account's current tools and skills. New catalogue entries appear on refresh. A revision fingerprint changes with the content. Users can search and download Markdown. Private skills stay within their account. Feature-specific procedures are maintained alongside the release source; the system does not fabricate instructions for unavailable tools.
