# SYNERGY 2.0 — interface and extension Work update

Internal runtime 3.0.2; companion extension 1.6.0. Existing 3.0.1 image and production data are backed up before deployment.

## Changes

- Home toggles project/recent navigation. Projects restores it. Composer footer whitespace reduced.
- Beast mode retains ordinary chat. Explicit development requests create private jobs automatically; opening the editor is optional. Left navigation retains Beast workspace for manual project creation. Existing review/publication controls remain.
- Extension uses compact Chat / Work navigation. Work: private Notes, To-do, Leads, Meetings. Notes/tasks/meeting records persist in account-owned SQLite rows; optimistic revisions block stale edits.
- Meeting dates store an explicit timezone. Chrome alarms and notifications run without an open side panel. Notifications recheck account and entitlement, suppress duplicates and ignore deleted/changed meetings. Chrome must be running; sleep, OS notification settings and network outages can delay delivery. Reconnection switches account scope and clears old UI context.
- Google Calendar OAuth is implemented using encrypted server-side credentials, PKCE, account-bound single-use state and a narrow calendar.events.owned scope. Admin configures a Google OAuth Web client and enables Calendar API. Each user connects their own account in Settings → Connections. Redirect: https://synergyai.1rank.in/connect/callback.
- Explicit Save to Google Calendar creates/updates a deterministic event ID and requests a Google Meet link. No attendees are added or invitations sent. Unconnected users can open a prefilled Calendar event and save it manually; that handoff never claims successful sync.
- Add extension detects an installed extension and offers one-click secure pairing. The ZIP/developer installation is moved into advanced setup. There is no published Chrome Web Store listing; browsers do not allow silent website installation. Creating a listing, accepting its terms and any registration charge remain owner steps. Removing the visible Disconnect button does not remove website revocation controls.

## Verification boundaries

Backend unit/HTTP tests cover account isolation, revision checks, failed providers, Google OAuth request construction, encryption and mock Calendar retry behaviour. Chrome API tests use a controlled API fixture; these are not proof of OS notification delivery or live Google authorization. Production release evidence records separately which browser and HTTP checks were actually run.

Google Calendar/Meet live acceptance remains blocked until an OAuth Web client and user consent exist. Canva still requires MFA/credential setup. Gemini Pro remains authenticated with zero API quota. No paid service was enabled and no model training occurred.

## Recovery

Use the existing operator deployment workflow on the pinned AWS host only. Stop workers for a consistent data archive, preserve .env/secrets, verify auth/business digests, then restart the previous image for rollback. An additive extension_work_items table is safe for the previous image to ignore. Reverting with a full database backup loses edits made after that backup, so prefer image-only rollback after accepting new traffic.
