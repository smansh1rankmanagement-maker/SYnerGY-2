# Target-server acceptance

Run these after deployment on your actual domain. Record the date, server hardware, installed image/model digests, request/result IDs, timings and downloaded file hashes. Keep subjective visual approval separate from automated checks.

1. Confirm `https://YOUR-DOMAIN/healthz` succeeds with a valid certificate, HTTP redirects to HTTPS, and only 80/443 are public. Register the owner with its invite code, sign out and sign in. Verify a second account cannot read the owner's projects or artifacts.
2. Confirm `docker compose ps` reports healthy app, Operations and Beast. Check all three local models in the application's model selector. Send a short real prompt and a follow-up. Do not treat a nonempty answer as correctness.
3. In image studio, upload a permissioned reference; generate a small Fast image first. Record native and export dimensions. Use a mask to edit one area, inspect protected surroundings, add your approved logo and exact headline, download, then reopen the saved project. Only use the real approved InteriFY logo if supplied; the test suite's synthetic coloured logo is a fixture.
4. Generate a short Fast video and play the downloaded MP4. Check motion, identity, artifacts, duration and the distinction between native model frames and interpolated/upscaled output. Record runtime and memory use. Test image-job cancellation and retry separately. Video currently has no per-job cancellation UI; stopping the app interrupts active media work.
5. Create InteriFY QA with the supplied brief pending approval and no invented website. Create a manual workflow, review its definition, activate and run it. Close the browser; verify that the separate worker completes and saves real XLSX/PDF files. Missing website/approval must remain an explicit blocker.
6. Download the workbook and PDF. Check seven calendar entries, formulas, formatting, page breaks and consistency. Revise one entry through the available editor/API, confirm the other six entries are retained and a new artifact review is required.
7. Draft the Monday 09:00 Asia/Kolkata automation; check the UTC due time is Monday 03:30. Activate only after reviewing the definition. Pause it after a test. Confirm duplicate trigger IDs create one run; restart a worker during a bounded test and inspect recovery.
8. In Beast, create a small project, propose a targeted edit, review its diff, apply it and compare the export with saved files. Check that Python/JavaScript diagnostics say parse-only. A Rust source proposal does not mean Rust was compiled or executed. HTML/CSS preview disables application JavaScript.
9. Make a private backup, restore into a separate empty volume, and verify login, saved artifacts and downloads before relying on recovery.

No external publishing, messages, advertising or spending is required for these checks. Do not send simply because a draft exists.

Local regression commands, after installing the web requirements plus PyYAML for the Compose structure test:

```bash
python3 -m pip install -r requirements-web.txt PyYAML==6.0.2
python3 tests/test_domain_release.py
cd app
python3 -m unittest discover -s tests -p 'test_*.py'
```

The suites include mocks for selected model/network unit tests. The new HTTP/process test really launches the server, layout process and Operations worker, writes SQLite, renders a PNG, exports XLSX/PDF and downloads saved files; it does not perform diffusion inference or obtain TLS certificates.
