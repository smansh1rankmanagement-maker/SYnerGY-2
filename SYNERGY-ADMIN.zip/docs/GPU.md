# Optional NVIDIA acceleration

The default Compose file uses CPU inference. To use a GPU you already control, install a compatible NVIDIA driver and NVIDIA Container Toolkit on the Linux host. Follow https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html and https://docs.docker.com/compose/how-tos/gpu-support/ .

Use:

```bash
python3 deploy/manage.py --gpu install --models --accept-model-licenses
python3 deploy/manage.py --gpu status
```

For manual commands always use both files:

```bash
docker compose -f compose.yaml -f compose.gpu.yaml exec app /opt/media/bin/python -c "import torch; print(torch.__version__); print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'Unavailable')"
```

This builds the Torch 2.2.2 CUDA 12.1 wheel variant and passes a GPU to the app and Ollama. The application explicitly errors if CUDA was selected but is unavailable. It does not silently use a hosted API. CPU generators are retained for seeded diffusion inputs; this does not imply pixel-identical results across devices.

Prefer enough GPU memory for one selected model at a time; test your actual native image/video settings and reduce resolution/quality if memory runs out. There is no measured VRAM or throughput guarantee for this release. An image/video acceptance run on your GPU is still required. GPU inference was not tested in the build workspace.

Ollama and media use the same GPU in this simple deployment. Do not invite many simultaneous users until you have measured memory use and queue behaviour. This is a single-server installation, not a distributed GPU scheduler.
