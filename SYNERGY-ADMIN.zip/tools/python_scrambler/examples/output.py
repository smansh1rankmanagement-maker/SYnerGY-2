#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A trusted example. The CLI does not execute this file."""

def invoice_total(prices, *, discount=0):
    """Return a discounted total; public keyword names stay intact."""
    _v001 = 0
    for _v002 in prices:
        _v001 += _v002
    _v003 = _v001 - discount
    return _v003
if __name__ == '__main__':
    print(invoice_total([100, 200], discount=25))
