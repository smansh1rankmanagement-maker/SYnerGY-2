#!/usr/bin/env python3
"""A trusted example. The CLI does not execute this file."""

def invoice_total(prices, *, discount=0):
    """Return a discounted total; public keyword names stay intact."""
    subtotal = 0
    for price in prices:
        subtotal += price
    final_total = subtotal - discount
    return final_total


if __name__ == "__main__":
    print(invoice_total([100, 200], discount=25))
