"""Conservative AST local-name transformation. Never executes submitted code."""
from __future__ import annotations

import ast
import codecs
import io
import keyword
import symtable
import sys
import tokenize
from dataclasses import dataclass

VERSION = "1.0.0"
MAX_SOURCE_BYTES = 256 * 1024
MAX_AST_NODES = 20_000
MAX_AST_DEPTH = 80
MAX_OUTPUT_BYTES = 1024 * 1024


class ScrambleError(ValueError):
    """An input, complexity or validation error; no source was executed."""


@dataclass
class Result:
    source: str
    report: dict
    mapping: dict


# Unknown/new constructs are denied, rather than silently treated as ordinary locals.
BODY_NODES = {
    "Assign", "AugAssign", "For", "While", "If", "Return", "Expr", "Pass",
    "Break", "Continue", "Raise", "Assert", "Import", "ImportFrom", "alias",
    "Name", "Constant", "Attribute", "Subscript", "Slice", "Tuple", "List",
    "Dict", "Set", "Starred", "BinOp", "UnaryOp", "BoolOp", "Compare", "Call",
    "keyword", "IfExp", "JoinedStr", "FormattedValue",
}
DYNAMIC_NAMES = {
    "eval", "exec", "locals", "globals", "vars", "dir", "compile", "__import__",
    "getattr", "setattr", "delattr", "hasattr", "breakpoint", "__builtins__",
    "__dict__", "__code__", "__globals__", "__closure__", "__getattribute__",
    "f_locals", "f_globals", "f_code", "f_back", "gi_frame", "cr_frame",
    "co_varnames", "co_freevars", "co_cellvars", "currentframe", "_getframe",
    "getouterframes", "getinnerframes", "settrace", "setprofile",
}
DYNAMIC_MODULES = {"inspect", "dis", "pdb", "bdb", "trace", "ctypes", "marshal", "builtins"}


def _limits(tree):
    stack = [(tree, 1)]
    count = 0
    depth = 0
    while stack:
        node, level = stack.pop()
        count += 1
        depth = max(depth, level)
        if count > MAX_AST_NODES or level > MAX_AST_DEPTH:
            raise ScrambleError("AST complexity limit exceeded (20,000 nodes / depth 80).")
        stack.extend((child, level + 1) for child in ast.iter_child_nodes(node))
    return count, depth


def _syntax(source, filename):
    try:
        tree = ast.parse(source, filename=filename, mode="exec")
        counts = _limits(tree)
        # Compilation performs scope checks too. A code object is NOT executed.
        compile(tree, filename, "exec", dont_inherit=True, optimize=0)
        return tree, counts
    except (SyntaxError, UnicodeError, ValueError) as exc:
        if isinstance(exc, ScrambleError):
            raise
        line = getattr(exc, "lineno", None)
        message = getattr(exc, "msg", str(exc))
        raise ScrambleError("Invalid Python%s: %s" % (" at line %s" % line if line else "", message)) from None
    except (RecursionError, MemoryError, OverflowError):
        raise ScrambleError("Python parser/compiler resource limit exceeded.") from None


def _inventory(tree):
    """Collect names from *all* scopes before generating any replacements."""
    reserved, imported, definitions, hazards = set(), set(), set(), set()
    for node in ast.walk(tree):
        for field in ("id", "arg", "name", "attr", "asname"):
            value = getattr(node, field, None)
            if isinstance(value, str):
                reserved.add(value)
                if value in DYNAMIC_NAMES:
                    hazards.add("dynamic name/frame access: " + value)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            definitions.add(node.name)
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            if isinstance(node, ast.ImportFrom) and node.module:
                if node.module.split(".")[0] in DYNAMIC_MODULES:
                    hazards.add("introspection module: " + node.module)
            for alias in node.names:
                if alias.name == "*":
                    hazards.add("wildcard import")
                imported.add(alias.asname or (alias.name.split(".")[0] if isinstance(node, ast.Import) else alias.name))
                if alias.name in DYNAMIC_NAMES:
                    hazards.add("dynamic imported name: " + alias.name)
                if isinstance(node, ast.Import) and alias.name.split(".")[0] in DYNAMIC_MODULES:
                    hazards.add("introspection module: " + alias.name)
        if isinstance(node, (ast.Global, ast.Nonlocal)):
            reserved.update(node.names)
    return reserved | imported | definitions, imported, definitions, sorted(hazards)


def _functions(tree):
    """Include every function in the report, even nested functions and methods."""
    found = []
    stack = [(tree, (), None)]
    while stack:
        node, scope, parent = stack.pop()
        new_scope = scope
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            found.append((node, ".".join(scope + (node.name,)), parent is tree))
            new_scope = scope + (node.name,)
        elif isinstance(node, ast.ClassDef):
            new_scope = scope + (node.name,)
        stack.extend((child, new_scope, node) for child in reversed(list(ast.iter_child_nodes(node))))
    return sorted(found, key=lambda item: (item[0].lineno, item[0].col_offset))


class _Rename(ast.NodeTransformer):
    def __init__(self, mapping):
        self.mapping = mapping

    def visit_Name(self, node):
        if node.id in self.mapping:
            node.id = self.mapping[node.id]
        return node


def scramble_source(source, preserved_names=(), *, filename="<source>", max_source_bytes=MAX_SOURCE_BYTES, output_encoding="utf-8"):
    """Return source/report/private mapping. No file I/O, importing or execution.

    Determinism is for the same source/settings and Python interpreter version.
    output_encoding is for the trusted CLI byte adapter, not a remote path option.
    """
    if sys.version_info < (3, 9):
        raise ScrambleError("Python 3.9 or newer is required (ast.unparse).")
    if not isinstance(source, str):
        raise ScrambleError("Source must be text.")
    if type(max_source_bytes) is not int or not 1 <= max_source_bytes <= MAX_SOURCE_BYTES:
        raise ScrambleError("max_source_bytes must be between 1 and 262144.")
    try:
        size = len(source.encode("utf-8"))
        encoding = codecs.lookup(output_encoding).name
    except (UnicodeError, LookupError, TypeError):
        raise ScrambleError("Invalid source characters or output encoding.") from None
    if size > max_source_bytes:
        raise ScrambleError("Source exceeds the %d-byte limit." % max_source_bytes)
    if not isinstance(preserved_names, (list, tuple, set, frozenset)) or len(preserved_names) > 1000:
        raise ScrambleError("Preserved names must be a collection of at most 1000 identifiers.")
    if any(not isinstance(n, str) or not n.isidentifier() or keyword.iskeyword(n) for n in preserved_names):
        raise ScrambleError("Every preserved name must be a valid non-keyword Python identifier.")
    import unicodedata
    preserved = {unicodedata.normalize("NFKC", name) for name in preserved_names}
    tree, (count, depth) = _syntax(source, filename)
    reserved, imported, definitions, hazards = _inventory(tree)
    reserved.update(preserved)
    # Token names supplement AST names (e.g. keyword-argument labels).
    try:
        reserved.update(unicodedata.normalize("NFKC", t.string) for t in tokenize.generate_tokens(io.StringIO(source).readline) if t.type == tokenize.NAME)
        symbols = symtable.symtable(source, filename, "exec")
    except (SyntaxError, tokenize.TokenError, RecursionError, MemoryError) as exc:
        raise ScrambleError("Scope analysis failed: " + type(exc).__name__) from None
    module_bindings = {s.get_name() for s in symbols.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
    frozen = preserved | imported | definitions | module_bindings
    reports, maps = [], []
    counter = 0
    for fn, qualified, direct in _functions(tree):
        reasons = []
        if not direct:
            reasons.append("not a direct module-level function (nested/class/conditional scope)")
        if isinstance(fn, ast.AsyncFunctionDef):
            reasons.append("asynchronous function")
        if fn.decorator_list:
            reasons.append("decorated function")
        if getattr(fn, "type_params", []):
            reasons.append("generic type-parameter scope")
        signature_nodes = list(ast.walk(fn.args)) + (list(ast.walk(fn.returns)) if fn.returns else [])
        signature_scopes = sorted({type(node).__name__ for node in signature_nodes if type(node).__name__ in {"Lambda", "ListComp", "SetComp", "DictComp", "GeneratorExp", "NamedExpr", "Yield", "YieldFrom", "Await"}})
        if signature_scopes:
            reasons.append("unsupported signature scope: " + ", ".join(signature_scopes))
        body_nodes = [node for stmt in fn.body for node in ast.walk(stmt)]
        unsupported = sorted({type(node).__name__ for node in body_nodes if type(node).__name__ not in BODY_NODES and not isinstance(node, (ast.operator, ast.unaryop, ast.boolop, ast.cmpop, ast.expr_context))})
        if unsupported:
            reasons.append("unsupported construct(s): " + ", ".join(unsupported))
        if hazards:
            reasons.extend("module guard: " + reason for reason in hazards)
        scopes = [s for s in symbols.get_children() if s.get_name() == fn.name and s.get_lineno() == fn.lineno and s.get_type() == "function"]
        if direct and len(scopes) != 1:
            reasons.append("ambiguous compiler symbol table")
        row = {"function": qualified, "line": fn.lineno, "status": "skipped" if reasons else "unchanged", "reasons": sorted(set(reasons)), "renamed_count": 0}
        if not reasons:
            scope = scopes[0]
            bindings = {}
            for node in body_nodes:
                if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
                    bindings.setdefault(node.id, (node.lineno, node.col_offset, node.id))
            eligible = []
            for name in sorted(bindings, key=bindings.get):
                symbol = scope.lookup(name)
                if name in frozen or name == "_" or name.startswith("__"):
                    continue
                if symbol.is_local() and not any((symbol.is_parameter(), symbol.is_imported(), symbol.is_global(), symbol.is_nonlocal(), symbol.is_free(), symbol.is_namespace())):
                    eligible.append(name)
            changes = {}
            for name in eligible:
                while True:
                    counter += 1
                    replacement = "_v%03d" % counter
                    if replacement not in reserved:
                        break
                reserved.add(replacement)
                changes[name] = replacement
            if changes:
                # Transform only the body: defaults and signature annotations are outer-scope expressions.
                renamer = _Rename(changes)
                fn.body = [renamer.visit(stmt) for stmt in fn.body]
                row.update(status="renamed", renamed_count=len(changes))
                maps.append({"function": qualified, "line": fn.lineno, "renames": changes})
        reports.append(row)
    try:
        regenerated = ast.unparse(tree)
        first_line = source.splitlines()[0] if source.splitlines() else ""
        header = first_line + "\n" if first_line.startswith("#!") else ""
        # Canonical header explicitly replaces the original encoding comment.
        header += "# -*- coding: %s -*-\n" % ("utf-8" if encoding == "utf-8-sig" else encoding)
        output = header + regenerated + "\n"
        if len(output.encode(encoding)) > MAX_OUTPUT_BYTES:
            raise ScrambleError("Regenerated output exceeds the 1 MiB limit.")
        _syntax(output, filename)
    except (RecursionError, MemoryError, UnicodeError):
        raise ScrambleError("Cannot regenerate within the encoding/resource limits.") from None
    report = {
        "tool": "python_scramble", "version": VERSION, "python": sys.version.split()[0],
        "filename": filename, "source_bytes_utf8": size, "ast_nodes": count, "ast_depth": depth,
        "functions": reports, "renamed_variables": sum(r["renamed_count"] for r in reports),
        "syntax_validation": {"original": "passed", "transformed": "passed", "method": "parse and compile; never execute"},
        "behaviour": {"status": "not_tested", "reason": "Submitted code is never run. Compilation is not proof of equivalence."},
        "output_encoding": encoding, "docstrings": "retained", "shebang": "retained" if header.startswith("#!") else "absent",
        "warnings": ["Formatting and line numbers change; comments (including type-checker and licence comments) are removed except the shebang and canonical encoding header.", "Review licence notices and reattach required comments before distribution.", "Reflection, external stack inspection, tracebacks and local-name-dependent behaviour are not guaranteed.", "Obfuscation cannot protect secrets or prevent determined reverse engineering."],
    }
    return Result(output, report, {"private": True, "version": VERSION, "functions": maps})


def scramble_bytes(raw, preserved_names=(), *, filename="<source>", max_source_bytes=MAX_SOURCE_BYTES):
    """Decode PEP 263/BOM input, preserve encoding, return (bytes, Result)."""
    if type(max_source_bytes) is not int or not 1 <= max_source_bytes <= MAX_SOURCE_BYTES:
        raise ScrambleError("max_source_bytes must be between 1 and 262144.")
    if not isinstance(raw, bytes) or len(raw) > min(max_source_bytes, MAX_SOURCE_BYTES):
        raise ScrambleError("Source exceeds the byte limit or is not bytes.")
    try:
        encoding, _ = tokenize.detect_encoding(io.BytesIO(raw).readline)
        text = raw.decode(encoding)
    except (SyntaxError, UnicodeError, LookupError):
        raise ScrambleError("Cannot decode the source encoding/BOM.") from None
    result = scramble_source(text, preserved_names, filename=filename, max_source_bytes=max_source_bytes, output_encoding=encoding)
    result.report["input_encoding"] = encoding
    result.report["newlines"] = "normalised to LF"
    output = result.source.encode(encoding)
    # Check actual emitted bytes too, including encoding and future imports.
    try:
        compile(output, filename, "exec", dont_inherit=True, optimize=0)
    except (SyntaxError, ValueError, UnicodeError):
        raise ScrambleError("Encoded output did not pass syntax validation.") from None
    return output, result
