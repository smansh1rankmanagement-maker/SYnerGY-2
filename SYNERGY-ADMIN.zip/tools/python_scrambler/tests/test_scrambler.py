"""Only the fixed, trusted fixtures below are executed; never submitted files."""
import ast
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import textwrap
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from engine import MAX_SOURCE_BYTES, ScrambleError, scramble_bytes, scramble_source


FIXTURES = [
    ("""
def total(items, *, discount=0):
    result = 0
    for item in items:
        result += item
    result = result - discount
    return result
""", "total([100, 200], discount=25)"),
    ("""
import math as maths
def root(value, /, *extras, rounding=2, **options):
    number = maths.sqrt(value) + sum(extras)
    result = round(number, rounding)
    return result, options
""", "root(9, 2, rounding=1, label='kept')"),
    ("""
class Box:
    def __init__(self):
        self.value = 0
def update(box):
    amount = 7
    box.value += amount
    return box.value
""", "update(Box())"),
    ("""
def walk(limit):
    index = 0
    values = []
    while index < limit:
        index += 1
        if index == 2:
            continue
        values.append(index)
    for left, right in [(2, 3), (4, 5)]:
        values.append(left + right)
    else:
        values.append(99)
    return values
""", "walk(4)"),
    ("""
def formatted(value):
    result = value * 2
    return f'{result=}; {result:.2f}'
""", "formatted(3)"),
    ("""
seed = 4
def sample(value=seed) -> int:
    seed = value + 1
    local_result = seed * 2
    return local_result
""", "sample()"),
    ("""
def unpack(items):
    first, *remaining = items
    answer = (first, remaining)
    return answer
""", "unpack([1, 2, 3])"),
]


class EngineTests(unittest.TestCase):
    def transform(self, source, **kwargs):
        return scramble_source(textwrap.dedent(source), **kwargs)

    def test_real_trusted_fixtures_match_in_bounded_subprocesses(self):
        for source, call in FIXTURES:
            with self.subTest(call=call):
                source = textwrap.dedent(source)
                transformed = scramble_source(source)
                outcomes = []
                for code in (source, transformed.source):
                    run = subprocess.run([sys.executable, "-I", "-c", code + "\nimport json\nprint(json.dumps(" + call + ", sort_keys=True))\n"], capture_output=True, text=True, timeout=3, cwd=tempfile.gettempdir())
                    self.assertEqual(run.returncode, 0, run.stderr)
                    outcomes.append(run.stdout)
                self.assertEqual(*outcomes)
                # Testing our fixtures does not change the status of arbitrary input.
                self.assertEqual(transformed.report["behaviour"]["status"], "not_tested")

    def test_references_assignments_augmented_and_loop_bindings(self):
        result = self.transform(FIXTURES[0][0])
        changes = result.mapping["functions"][0]["renames"]
        self.assertEqual(changes, {"result": "_v001", "item": "_v002"})
        names = [n.id for n in ast.walk(ast.parse(result.source)) if isinstance(n, ast.Name)]
        self.assertNotIn("result", names)
        self.assertNotIn("item", names)
        self.assertIn("items", names)
        self.assertIn("discount", names)

    def test_attributes_import_aliases_and_keywords_preserved(self):
        result = self.transform(FIXTURES[1][0] + "\nanswer = root(9, rounding=1)\n")
        tree = ast.parse(result.source)
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef))
        self.assertEqual([a.arg for a in fn.args.posonlyargs], ["value"])
        self.assertEqual(fn.args.vararg.arg, "extras")
        self.assertEqual(fn.args.kwarg.arg, "options")
        self.assertEqual(fn.args.kwonlyargs[0].arg, "rounding")
        self.assertIn("import math as maths", result.source)
        self.assertIn("maths.sqrt", result.source)
        self.assertIn("rounding=1", result.source)
        self.assertIn("self.value", self.transform(FIXTURES[2][0]).source)

    def test_function_local_import_binding_is_not_renamed(self):
        result = self.transform("""
def f(n):
    from math import sqrt as calculate
    result = calculate(n)
    return result
""")
        self.assertEqual(result.mapping["functions"][0]["renames"], {"result": "_v001"})
        self.assertIn("calculate(n)", result.source)

    def test_collision_avoidance_all_identifiers_and_scopes(self):
        result = self.transform("""
_v001 = 1
def f(_v002):
    value = _v002 + _v001
    return value
def other():
    return external(_v003=4)
""", preserved_names=["_v004"])
        self.assertEqual(result.mapping["functions"][0]["renames"], {"value": "_v005"})

    def test_preserved_names_special_names_and_global_bindings(self):
        result = self.transform("""
amount = 8
def f(n):
    important_name = n
    amount = n + 1
    __private = n + 2
    result = important_name + amount + __private
    return result
""", preserved_names=["important_name"])
        self.assertEqual(result.mapping["functions"][0]["renames"], {"result": "_v001"})

    def test_unsupported_functions_reported_with_reason(self):
        for default in ['lambda: 1','[x for x in range(2)]','(x for x in range(2))']:
            result=self.transform('def f(value='+default+'):\n    result=value\n    return result\n')
            self.assertEqual(result.report['functions'][0]['status'],'skipped')
            self.assertTrue(any('signature scope' in reason for reason in result.report['functions'][0]['reasons']))
        bodies = [
            ("def nested():\n        return 1\n    return nested()", "FunctionDef"),
            ("class Nested:\n        pass\n    return 1", "ClassDef"),
            ("value = lambda x: x\n    return value(1)", "Lambda"),
            ("value = [x for x in range(3)]\n    return value", "ListComp"),
            ("value = {x for x in range(3)}\n    return value", "SetComp"),
            ("value = {x:x for x in range(3)}\n    return value", "DictComp"),
            ("value = (x for x in range(3))\n    return value", "GeneratorExp"),
            ("yield 1", "Yield"),
            ("yield from [1]", "YieldFrom"),
            ("global value\n    value = 2\n    return value", "Global"),
            ("try:\n        return 1\n    except Exception as error:\n        return str(error)", "Try"),
            ("with open('example') as stream:\n        return stream.read()", "With"),
            ("value: int = 2\n    return value", "AnnAssign"),
            ("if (value := 1):\n        return value", "NamedExpr"),
            ("value = 1\n    del value", "Delete"),
        ]
        for body, reason in bodies:
            with self.subTest(reason=reason):
                result = scramble_source("def f():\n    " + body + "\n")
                first = result.report["functions"][0]
                self.assertEqual(first["status"], "skipped")
                self.assertIn(reason, str(first["reasons"]))
                self.assertEqual(result.report["renamed_variables"], 0)

    def test_nested_nonlocal_classes_decorators_async_and_conditional(self):
        result = self.transform("""
def outer():
    value = 1
    def inner():
        nonlocal value
        value += 1
    return inner
class Example:
    def __init__(self):
        value = 2
        self.value = value
@decorator
def decorated():
    value = 2
    return value
async def asynchronous():
    value = 2
    return value
if True:
    def conditional():
        value = 2
        return value
""")
        self.assertEqual(len(result.report["functions"]), 6)
        self.assertTrue(all(r["status"] == "skipped" and r["reasons"] for r in result.report["functions"]))

    def test_dynamic_name_and_frame_aliases_guard_whole_module(self):
        hazards = ["lookup = locals", "from builtins import eval as evaluate", "import inspect as ins", "import sys\nframe = sys._getframe", "read = getattr(builtins, 'locals')", "snapshot = vars()", "exec('x=1')", "globals()", "from example import *", "value = f.__code__.co_varnames"]
        for hazard in hazards:
            with self.subTest(hazard=hazard):
                result = scramble_source(hazard + "\ndef f():\n    value = 1\n    return value\n")
                self.assertEqual(result.report["functions"][0]["status"], "skipped")
                self.assertIn("module guard", str(result.report["functions"][0]["reasons"]))

    def test_determinism_and_no_mapping_in_report(self):
        first = self.transform(FIXTURES[0][0])
        second = self.transform(FIXTURES[0][0])
        self.assertEqual(first, second)
        self.assertNotIn("renames", json.dumps(first.report))

    def test_docstrings_default_annotation_and_shebang(self):
        source = '#!/usr/bin/env python3\n"""Module text."""\nseed = 3\ndef f(value: int = seed) -> int:\n    """Function text."""\n    result = value\n    return result\n'
        result = scramble_source(source)
        a, b = ast.parse(source), ast.parse(result.source)
        self.assertEqual(ast.get_docstring(a), ast.get_docstring(b))
        self.assertEqual(ast.get_docstring(a.body[2]), ast.get_docstring(b.body[2]))
        self.assertEqual(ast.dump(a.body[2].args), ast.dump(b.body[2].args))
        self.assertTrue(result.source.startswith('#!/usr/bin/env python3\n'))

    def test_latin1_bom_crlf_and_invalid_encoding(self):
        raw = '#!/usr/bin/python3\r\n# coding: latin-1\r\n"""Café"""\r\ndef f():\r\n    café = "déjà"\r\n    return café\r\n'.encode('latin-1')
        encoded, result = scramble_bytes(raw)
        self.assertEqual(result.report['input_encoding'], 'iso-8859-1')
        self.assertIn(b'Caf\xe9', encoded)
        self.assertNotIn(b'\r\n', encoded)
        bom, _ = scramble_bytes(b'\xef\xbb\xbfdef f():\n    value=1\n    return value\n')
        self.assertTrue(bom.startswith(b'\xef\xbb\xbf'))
        with self.assertRaisesRegex(ScrambleError, 'decode'):
            scramble_bytes(b'# coding: utf-8\ntext="\xff"')

    def test_size_depth_nodes_and_invalid_syntax(self):
        for source in ["def broken(:\n", "return 1", "def f(x, x): pass"]:
            with self.subTest(source=source), self.assertRaisesRegex(ScrambleError, 'Invalid Python'):
                scramble_source(source)
        with self.assertRaisesRegex(ScrambleError, 'byte'):
            scramble_source('#' * (MAX_SOURCE_BYTES + 1))
        with self.assertRaisesRegex(ScrambleError, 'complexity'):
            scramble_source('def f():\n    return ' + '+'.join(['x']*100))
        with self.assertRaisesRegex(ScrambleError, 'complexity'):
            scramble_source('def f():\n' + '    x = 1\n'*7000)
        with self.assertRaisesRegex(ScrambleError, 'identifier'):
            scramble_source('pass', ['a.b'])


class CLITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name)
        self.input = self.path/'input.py'
        self.output = self.path/'output.py'
        self.input.write_text('def f(n):\n    total=n+1\n    return total\n')

    def cli(self, *args):
        return subprocess.run([sys.executable, str(ROOT/'scrambler.py'), str(self.input), '--output', str(self.output), *map(str,args)], capture_output=True, text=True, timeout=5)

    def test_cli_report_private_mapping_permissions_and_input_unchanged(self):
        self.input.chmod(0o750)
        original=self.input.read_bytes()
        report=self.path/'report.json';mapping=self.path/'mapping.json'
        run=self.cli('--report',report,'--mapping',mapping)
        self.assertEqual(run.returncode,0,run.stderr)
        self.assertIn('Behaviour NOT tested',run.stdout)
        self.assertEqual(self.input.read_bytes(),original)
        self.assertEqual(json.loads(report.read_text())['syntax_validation']['transformed'],'passed')
        self.assertTrue(json.loads(mapping.read_text())['private'])
        if os.name=='posix':
            self.assertEqual(stat.S_IMODE(self.output.stat().st_mode),0o750)
            self.assertEqual(stat.S_IMODE(mapping.stat().st_mode),0o600)

    def test_existing_output_requires_force(self):
        self.output.write_text('keep')
        run=self.cli()
        self.assertNotEqual(run.returncode,0)
        self.assertIn('already exists',run.stderr)
        self.assertEqual(self.output.read_text(),'keep')
        self.assertEqual(self.cli('--force').returncode,0)

    def test_input_cannot_be_overwritten_even_force_and_aliases(self):
        original=self.input.read_bytes()
        self.assertNotEqual(self.cli('--output',self.input,'--force').returncode,0)
        os.link(self.input,self.output)
        self.assertNotEqual(self.cli('--force').returncode,0)
        self.assertEqual(self.input.read_bytes(),original)

    def test_preflight_sidecar_collision_and_existing_report(self):
        self.assertNotEqual(self.cli('--report',self.output).returncode,0)
        report=self.path/'report.json';report.write_text('keep')
        self.assertNotEqual(self.cli('--report',report).returncode,0)
        self.assertFalse(self.output.exists())
        self.assertEqual(report.read_text(),'keep')

    @unittest.skipUnless(os.name=='posix','symlink semantics require POSIX')
    def test_symlink_output_refused(self):
        self.output.symlink_to(self.path/'other.py')
        self.assertNotEqual(self.cli('--force').returncode,0)

    def test_invalid_input_clear_error_and_no_outputs(self):
        self.input.write_text('def invalid(:\n')
        run=self.cli()
        self.assertNotEqual(run.returncode,0)
        self.assertIn('Invalid Python',run.stderr)
        self.assertFalse(self.output.exists())

    def test_preserve_help_and_no_automatic_execution(self):
        marker=self.path/'MUST_NOT_EXIST'
        self.input.write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("executed")\ndef f():\n    keep=1\n    change=2\n    return keep+change\n')
        run=self.cli('--preserve','keep')
        self.assertEqual(run.returncode,0,run.stderr)
        self.assertFalse(marker.exists())
        self.assertIn('keep = 1',self.output.read_text())
        help_run=subprocess.run([sys.executable,str(ROOT/'scrambler.py'),'--help'],capture_output=True,text=True,timeout=3)
        self.assertEqual(help_run.returncode,0)
        self.assertIn('--mapping',help_run.stdout)


if __name__ == '__main__':
    unittest.main()
