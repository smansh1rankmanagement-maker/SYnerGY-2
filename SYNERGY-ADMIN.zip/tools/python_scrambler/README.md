# SYnerGY Python Code Scrambler 1.0

A conservative source-to-source tool for one `.py` file. It makes ordinary
function-local names harder to read. It does not encrypt code, hide API keys,
train a model, or prevent determined reverse engineering.

## Requirements

- Python **3.9+**, standard library only. Prefer a currently supported Python
  release. The initial release is tested on Python 3.12; a cross-version test
  matrix has not been run.
- `ast.unparse()` first appeared in Python 3.9. Input must use syntax accepted
  by the interpreter running the tool. Identical input/settings are deterministic
  on the **same Python version**; formatting may differ between versions.
- Nothing is installed automatically. Submitted code is neither imported nor run.

## Files and commands

Keep `scrambler.py` beside `engine.py`. From this folder:

```sh
python scrambler.py examples/input.py --output my-output.py
python scrambler.py examples/input.py --output my-output.py --force
python scrambler.py examples/input.py --output preserved.py --preserve subtotal final_total
python scrambler.py examples/input.py --output checked.py --report report.json --mapping mapping.json
python scrambler.py --help
python -m unittest discover -s tests -v
```

`--force` permits replacing regular output/report/mapping files. It never permits
overwriting the input, including through a hard link or matching resolved path.
Symlink destinations are refused. Parent output directories must already exist.
Every destination is checked before writing; each file is published atomically.
The set of output/sidecar writes is not a multi-file transaction: a disk failure
can leave earlier completed outputs. CLI errors go to stderr and return nonzero
(1 for transformation/I/O errors; argparse uses 2 for usage errors).

The mapping is **private debugging information**. It is created only when
`--mapping` is requested, with owner-only permissions on POSIX. Do not include it
with released source. The provided project ZIP contains no generated mapping.
Retain original source and mappings in private version control for debugging.

## What it transforms

1. Parse the complete module and check bounded AST complexity.
2. Compile the original AST for syntax/scope validation without executing it.
3. Collect names across the module and obtain Python compiler symbol tables.
4. Consider only direct module-level, undecorated synchronous functions.
5. Rename confirmed ordinary local assignments/references, including repeated
   assignments, augmented assignments, destructuring and `for` loop bindings.
6. Allocate `_v001`, `_v002`, etc. in binding order, avoiding every collected
   identifier, parameter, imported alias, explicit preserve and generated name.
7. Regenerate with `ast.unparse`, then parse and compile the result without running it.

Function/class names, all kinds of parameters, keyword-call labels, imported
bindings, module bindings, attributes, `_`, `__`-prefixed names, docstrings,
signature annotations and defaults are preserved. Only the function body is
transformed. Names requested through `--preserve` are also preserved.

Before:

```python
def total(prices, *, discount=0):
    subtotal = 0
    for price in prices:
        subtotal += price
    return subtotal - discount
```

After:

```python
def total(prices, *, discount=0):
    _v001 = 0
    for _v002 in prices:
        _v001 += _v002
    return _v001 - discount
```

## Deliberate skips and limits

Every function is reported as renamed, unchanged or skipped with reasons.
Methods and functions inside classes/conditionals/other functions are skipped.
Functions containing nested functions/classes, lambdas, comprehensions,
generators/yield, async constructs, global/nonlocal declarations, `try`, `with`,
deletion, local annotated assignments, assignment expressions, pattern matching,
generic type scopes and unknown AST constructs are skipped. Decorated functions
are skipped. Their names are unchanged, but the module is still regenerated.

Known dynamic-name access anywhere in the module conservatively skips **all**
functions. This includes references/aliases to `eval`, `exec`, `locals`,
`globals`, `vars`, `getattr` and related functions, frame/code attributes,
introspection modules such as `inspect`, and wildcard imports. This guards
obvious aliases and local helper functions, but cannot detect every computed
alias or an external dependency that inspects its caller.

The hard limits are 256 KiB of input (raw bytes and decoded UTF-8 text), 20,000
AST nodes, depth 80 and 1 MiB regenerated source. `--max-bytes` can lower the
input limit. The hosted adapter also limits wall time, CPU and address space.
Parsing can still exercise interpreter resources: **this is not a sandbox for
executing untrusted Python**.

Names, line numbers, tracebacks, exception text, tracing/profiling, source
inspection, code objects, debugger output and name-dependent external behaviour
can differ. Skipping obvious dynamic constructs is not a proof of equivalence.
Review the report and run your own trusted regression tests before distributing
transformed code. Do not blindly scramble the live SYnerGY server.

## Encoding, comments, docstrings and permissions

The file CLI detects the encoding using `tokenize.detect_encoding`, retaining
the original encoding and UTF-8 BOM when present. It preserves a first-line
shebang and emits a canonical encoding declaration. Output newlines become LF.
If regeneration cannot represent the text in that encoding, it fails clearly.
The text API and admin text editor return UTF-8.

AST regeneration changes formatting and removes comments, including licence
comments, lint directives and type-checker comments. Review and reattach any
required licence/attribution comments before shipping. **Module and function
docstrings remain by default**, including in skipped functions.

On POSIX the output retains the input's read/write/execute permission bits;
setuid/setgid/sticky bits are not copied. Ownership, ACLs and extended attributes
are not copied. Windows permissions differ. Mapping/report permissions are 0600
on POSIX. No bytecode, encoded loader, `exec` wrapper or encryption is generated.

## Validation and tests

Every transformation distinguishes **syntax validation passed** from
**behaviour not tested**. The tool never claims equivalence from compilation.
The tests execute only fixed, trusted fixtures in subprocesses with 3-second
timeouts, comparing original/transformed results. CLI tests use 5-second
timeouts and verify that even input with a top-level file write is not executed.
Tests cover scope, repeat references, loops, imports, attributes, keyword/positional
parameters, deterministic collisions, skip reports, encoding, docstrings,
complexity limits and accidental overwrite protection.

## SYnerGY integration: python_scramble

`engine.scramble_source()` is independent of the file CLI. `worker.py` is a
bounded JSON adapter for the **admin HTTP tool**, not a separately installed MCP
server. The SYnerGY 2.2 source contains the implemented admin adapter and source
browser. See its deployment report for live verification.

Input is either source text or an opaque, authorised source-vault file ID:

```json
{"source":"def f(n):\n    total=n+1\n    return total\n","preserved_names":[],"options":{"include_mapping":false,"max_source_bytes":262144}}
```

Outputs: transformed `source`, `report`, `syntax_validation`, `skipped`; private
`mapping` only with explicit opt-in. No changes are applied to the original file.
The current installed endpoint is administrator-only. It accepts no arbitrary
host paths. File IDs resolve inside the curated `synergy` archive after backend
admin checks; every preview/download also checks access. Extension bearer tokens
are not accepted. Request bodies/source/mappings are not written into audit logs.

For a later general project tool, resolve `(authenticated user, project ID,
revision, file ID)` through the existing project ownership/approved-transfer
checks; never translate a remote `path` into a host filename. Recheck permission
before returning a saved result. Use the same bounded worker and create a
separate reviewable output revision. This general project adapter and chat/MCP
installation are **not** claimed by this release.

## Protection that matters

API keys, passwords, session keys and production configuration belong in secure
server configuration, never distributed source, obfuscated strings, browser JS,
the source archive or mapping. Keep backend authorization, HTTPS, least privilege,
dependency updates, backups and monitoring. Obfuscation adds reading effort;
Python code and bytecode remain inspectable by someone who possesses them.

References: [AST](https://docs.python.org/3/library/ast.html),
[compiler symbol tables](https://docs.python.org/3/library/symtable.html),
[encoding detection](https://docs.python.org/3/library/tokenize.html).
