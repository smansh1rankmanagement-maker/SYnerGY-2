#!/usr/bin/env python3
"""File CLI; transformation logic lives in engine.py. No source execution."""
import argparse
import json
import os
from pathlib import Path
import stat
import sys
import tempfile

from engine import MAX_SOURCE_BYTES, ScrambleError, scramble_bytes


def _targets(source, paths, force):
    seen = set()
    for path in paths:
        resolved = path.resolve()
        if resolved == source.resolve() or (path.exists() and os.path.samefile(path, source)):
            raise ScrambleError("Refusing to overwrite the original input, even with --force.")
        if resolved in seen:
            raise ScrambleError("Output, report and mapping must use separate files.")
        seen.add(resolved)
        if path.is_symlink():
            raise ScrambleError("Refusing a symbolic-link output: " + str(path))
        if path.exists() and (not force or not path.is_file()):
            raise ScrambleError("Output already exists (use --force for a regular file): " + str(path))
        if not path.parent.is_dir():
            raise ScrambleError("Output directory does not exist: " + str(path.parent))


def _write(path, content, mode, force):
    descriptor, name = tempfile.mkstemp(prefix=".scrambler-", dir=str(path.parent))
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        if force:
            os.replace(temporary, path)
        else:
            # Atomic create-only publish: a competing writer cannot be overwritten.
            os.link(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Rename conservative Python function locals using AST and compiler scope analysis. Input is never executed.")
    parser.add_argument("input", type=Path, help="one .py input file")
    parser.add_argument("--output", required=True, type=Path, help="new .py output file")
    parser.add_argument("--preserve", nargs="+", default=[], metavar="NAME", help="additional identifiers to keep")
    parser.add_argument("--report", type=Path, help="transformation and syntax report JSON")
    parser.add_argument("--mapping", type=Path, help="PRIVATE debug mapping JSON; never package this with distributed code")
    parser.add_argument("--force", action="store_true", help="replace existing output/sidecar files, never input")
    parser.add_argument("--max-bytes", type=int, default=MAX_SOURCE_BYTES, help="source limit, 1..262144 (default 262144)")
    args = parser.parse_args(argv)
    try:
        if args.input.suffix.lower() != ".py" or args.output.suffix.lower() != ".py":
            raise ScrambleError("Input and output must have the .py extension.")
        if not 1 <= args.max_bytes <= MAX_SOURCE_BYTES:
            raise ScrambleError("--max-bytes must be between 1 and 262144.")
        if not args.input.is_file():
            raise ScrambleError("Input is not a regular file: " + str(args.input))
        targets = [p for p in (args.output, args.report, args.mapping) if p is not None]
        _targets(args.input, targets, args.force)
        with args.input.open("rb") as stream:
            raw = stream.read(args.max_bytes + 1)
        encoded, result = scramble_bytes(raw, args.preserve, filename=args.input.name, max_source_bytes=args.max_bytes)
        result.report["file_permissions"] = "input rwx bits retained; special bits excluded; mapping is owner-only on POSIX"
        staged = [(args.output, encoded, stat.S_IMODE(args.input.stat().st_mode) & 0o777)]
        for path, value in ((args.report, result.report), (args.mapping, result.mapping)):
            if path is not None:
                staged.append((path, (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode(), 0o600))
        for path, content, mode in staged:
            _write(path, content, mode, args.force)
        print("Syntax validation passed. Behaviour NOT tested (input was not executed).")
        print("Renamed %d local variable(s). Output: %s" % (result.report["renamed_variables"], args.output))
        for row in result.report["functions"]:
            if row["status"] == "skipped":
                print("Skipped %s (line %d): %s" % (row["function"], row["line"], "; ".join(row["reasons"])))
        if args.mapping:
            print("Private mapping saved; keep it outside distribution archives.")
        print("Formatting/comments change; docstrings are retained. Review required licence comments before distribution.")
        return 0
    except (ScrambleError, OSError, ValueError) as exc:
        print("scrambler: " + str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
