"""Private bounded JSON adapter. Not an MCP server and never an execution service."""
import json
import sys
from pathlib import Path

try:
    import resource
    resource.setrlimit(resource.RLIMIT_CPU, (4, 4))
    resource.setrlimit(resource.RLIMIT_AS, (384 * 1024 * 1024, 384 * 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_FSIZE, (0, 0))
except ImportError:
    pass
sys.path.insert(0, str(Path(__file__).resolve().parent))
from engine import ScrambleError, scramble_source


def main():
    try:
        raw = sys.stdin.buffer.read(2 * 1024 * 1024 + 1)
        if len(raw) > 2 * 1024 * 1024:
            raise ScrambleError("Request is too large.")
        request = json.loads(raw)
        result = scramble_source(request['source'], request.get('preserved_names', []), filename=request.get('filename', '<source>'), max_source_bytes=request.get('max_source_bytes', 262144))
        payload = {'source': result.source, 'report': result.report, 'syntax_validation': result.report['syntax_validation'], 'skipped': [r for r in result.report['functions'] if r['status'] == 'skipped']}
        if request.get('include_mapping') is True:
            payload['mapping'] = result.mapping
        encoded = json.dumps(payload, ensure_ascii=False)
        if len(encoded.encode()) > 2 * 1024 * 1024:
            raise ScrambleError('Transformation report exceeds the response limit.')
        print(encoded)
        return 0
    except (ScrambleError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({'error': str(exc)[:500]}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
