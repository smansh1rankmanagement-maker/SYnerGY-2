"""Authenticated staging browser and API acceptance; no production credentials."""
import json,os,sqlite3,secrets,time,urllib.request,http.cookiejar
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(os.environ['SYNERGY_DATA_DIR']);assert (root/'.staging-only').is_file();out=root/'ui-evidence';out.mkdir(exist_ok=True);checks=[];BASE='http://127.0.0.1:8090'
jar=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def api(path,data=None):
 req=urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
 with opener.open(req,timeout=30) as r:
  raw=r.read();return json.loads(raw) if r.headers.get_content_type()=='application/json' else raw
def check(name,ok):
 checks.append({'check':name,'passed':bool(ok)});(out/'evidence.json').write_text(json.dumps({'checks':checks},indent=2));print(checks[-1],flush=True);assert ok,name
user=api('/api/auth/register',{'email':'product-'+secrets.token_hex(6)+'@qa.invalid','password':secrets.token_urlsafe(24)})
with sqlite3.connect(root/'accounts.sqlite3') as c:c.execute("UPDATE users SET role='admin',full_name='SYNERGY QA' WHERE id=?",(user['id'],))
api('/api/research/settings',{'onboarding_seen':True,'eternal_reminders':False,'observation_learning':True})
project=api('/api/beast/projects',{'name':'SYNERGY 2.0 code QA','files':{'main.py':'def total(items):\n    return sum(items)\n\ndef invoice(items):\n    return total(items)\n'}})
work=api('/api/projects',{'name':'SYNERGY 2.0 QA','kind':'app','beast_project_id':project['id']})
cid=api('/api/conversations',{'project_id':work['id']})['id']
for mode in ['chat','work','beast']:
 task=api('/api/research/tasks',{'prompt':'Use Graphify to explain total and invoice','conversation_id':cid,'mode':mode,'provider':'synergy','effort':'instant','search_mode':'off','request_id':secrets.token_hex(16)})
 for _ in range(160):
  task=api('/api/research/tasks/'+task['id'])
  if task['state'] not in {'queued','running'}:break
  time.sleep(.2)
 check('Graphify real chat route in '+mode,task['state']=='succeeded' and 'mapped' in task['reply']);check(mode+' graph download',bool(api('/api/research/tasks/'+task['id']+'/graph.json')))
api('/api/research/pins',{'conversation_id':cid,'pinned':True});check('pin persists on backend',api('/api/research/pins')['conversations'][0]['id']==cid)
check('all price options exposed to admin',len(api('/api/billing/catalog')['all_prices'])==8)
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,args=['--no-sandbox']);ctx=browser.new_context(viewport={'width':1440,'height':1000});ctx.add_cookies([{'name':x.name,'value':x.value,'domain':'127.0.0.1','path':'/'} for x in jar]);page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(BASE);page.locator('#app-view').wait_for(state='visible');page.evaluate("localStorage.setItem('synergy-extension-offer:'+window.__qaUser+':1.4','shown')" ) if False else None
 if page.get_by_role('button',name='Not now',exact=True).is_visible():page.get_by_role('button',name='Not now',exact=True).click()
 page.locator('#pinned-chats .recent-chat').first.wait_for();check('pinned sidebar populated',page.locator('#pinned-chats .recent-chat').count()==1)
 check('project folder populated',page.locator('.project-folder').count()>=1)
 page.locator('#open-settings').click();expect(page.locator('#profile-menu')).to_be_visible(timeout=30000);check('profile popup has plan and settings',page.locator('#profile-menu').inner_text().find('Administrator')>=0);page.screenshot(path=str(out/'profile.png'))
 page.locator('#profile-menu').get_by_role('button',name='Settings',exact=True).click();expect(page.locator('[data-settings-panel="preferences"]')).to_be_visible();page.screenshot(path=str(out/'settings.png'));page.locator('.settings-search').fill('MCP');check('settings search filters real sections',page.locator('[data-settings="mcp"]').is_visible() and not page.locator('[data-settings="profile"]').is_visible());page.locator('.settings-search').fill('')
 page.locator('[data-settings="learning"]').click();expect(page.locator('[data-settings-panel="learning"] h2')).to_have_text('Personalization & learning');check('private opt-in shown',page.locator('input[name="observation_learning"]').is_checked())
 page.locator('[data-settings="subscriptions"]').click();expect(page.locator('#member-plans')).to_be_visible();check('regular monthly and annual prices rendered','49,999' in page.locator('#member-plans').inner_text() and '11,999' in page.locator('#member-plans').inner_text());page.screenshot(path=str(out/'pricing.png'))
 page.locator('#close-settings').click();page.locator('#new-chat').click();page.screenshot(path=str(out/'home.png'))
 # Verify actual frontend incremental display using full graphemes and its finish boundary.
 result=page.evaluate('''async()=>{const node=document.createElement('div');document.body.append(node);let final;const w=SynergyLetters.create(node,t=>final=t);const text='A quick reply 👨‍👩‍👧‍👦 with complete graphemes.';w.update(text);await new Promise(requestAnimationFrame);const intermediate=node.textContent;await w.finish();node.remove();return {intermediate,final,text};}''');check('browser letter animation finishes exact text',0<len(result['intermediate'])<len(result['text']) and result['final']==result['text'])
 page.set_viewport_size({'width':390,'height':844});check('mobile no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'));page.screenshot(path=str(out/'mobile.png'));check('no JavaScript page errors',not errors);browser.close()
check('preserved media MCP catalogue',any(x['id']=='synergy-media' for x in api('/api/plugins')['plugins']));check('manual contains current features',any(x['title']=='Graphify code maps' for x in api('/api/manual')['sections']))
api('/api/auth/logout',{})
