"""Real candidate-only HTTP/inference/search requests. No OpenAI credits used."""
import json,os,sqlite3,time,urllib.request,urllib.error,uuid
from pathlib import Path
root=Path(os.environ['SYNERGY_DATA_DIR']);assert (root/'.staging-only').exists()
base='http://127.0.0.1:8090';checks=[];runs=[]
def api(path,data=None,cookie=''):
 headers={'Cookie':cookie}
 if data is not None:headers['Content-Type']='application/json'
 req=urllib.request.Request(base+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
 with urllib.request.urlopen(req,timeout=30) as r:return json.load(r),r.headers
u,h=api('/api/auth/register',{'email':'research280-'+uuid.uuid4().hex[:8]+'@qa.invalid','password':uuid.uuid4().hex+'Qa'})
cookie=h['Set-Cookie'].split(';')[0]
with sqlite3.connect(root/'accounts.sqlite3') as c:c.execute("UPDATE users SET role='admin' WHERE id=?",(u['id'],))
api('/api/research/settings',{'onboarding_seen':True,'web_search':True},cookie)
for mode,prompt,web in [('chat','Give three short ways to keep a desk tidy.','off'),('work','Write a short three-point checklist for reviewing a draft.','off'),('beast','Explain what a Python list is in two sentences.','off'),('chat','How to use Python pathlib Path.exists? Use official documentation, keep it brief and cite sources.','on')]:
 start=time.monotonic();task,_=api('/api/research/tasks',{'prompt':prompt,'mode':mode,'effort':'medium','provider':'synergy','search_mode':web,'fresh_research':True},cookie)
 while time.monotonic()-start<360:
  task,_=api('/api/research/tasks/'+task['id'],cookie=cookie)
  if task['state'] not in {'queued','running'}:break
  time.sleep(.5)
 assert task['state']=='succeeded',(mode,task['state'],task['reply'])
 assert 'Response budget reached' not in task['reply']
 checks.append(mode+' '+web+' completes without response-target cutoff')
 if web=='on':
  assert any(s.get('access')=='read' for s in task['detail'].get('sources',[])),task['detail']
  checks.append('research returned readable evidence')
 result={'mode':mode,'search':web,'state':task['state'],'seconds':round(time.monotonic()-start,2),'reply':task['reply'],'detail':task['detail']};runs.append(result)
 Path('/tmp/research280-evidence.json').write_text(json.dumps({'checks':checks,'runs':runs,'openai_requests':0},indent=2));print(json.dumps({'mode':mode,'search':web,'state':task['state'],'seconds':result['seconds'],'reply':task['reply'],'searches':task['detail'].get('searches')}),flush=True)
Path('/tmp/qa280-session.json').write_text(json.dumps({'cookie':cookie,'user_id':u['id']}));os.chmod('/tmp/qa280-session.json',0o600)
print('PASS '+str(len(checks))+' actual-inference checks',flush=True)
