"""Real API acceptance. Private credentials stay in the specified state file."""
import argparse,io,json,os,secrets,time,urllib.request,urllib.error,wave
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('phase',choices=['before','after','candidate']);p.add_argument('--url',default='https://synergyai.1rank.in');p.add_argument('--state',required=True);p.add_argument('--report',required=True);a=p.parse_args()
origin='https://synergyai.1rank.in';cookie='';checks=[]
def call(method,path,data=None,raw=False,ctype='application/json',auth=True):
 body=json.dumps(data).encode() if isinstance(data,dict) else data
 headers={'Origin':origin,'Host':'synergyai.1rank.in','Content-Type':ctype}
 if cookie and auth:headers['Cookie']=cookie
 req=urllib.request.Request(a.url+path,data=body,headers=headers,method=method)
 try:r=urllib.request.urlopen(req,timeout=240)
 except urllib.error.HTTPError as e:r=e
 content=r.read();status=r.status;h=dict(r.headers)
 return status,(content if raw else json.loads(content)),h
def check(name,ok,**details):
 checks.append({'name':name,'passed':bool(ok),**details});print(json.dumps(checks[-1]),flush=True)
 if not ok:raise AssertionError(name)
def post(path,d):
 code,r,h=call('POST',path,d);check(path,code in {200,201,202},status=code);return r,h
def multipart(path,fields,name,data,mime='text/plain'):
 boundary='synergy-'+secrets.token_hex(12);parts=[]
 for k,v in fields.items():parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
 parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{name}"\r\nContent-Type: {mime}\r\n\r\n'.encode()+data+b'\r\n');parts.append(f'--{boundary}--\r\n'.encode())
 return call('POST',path,b''.join(parts),ctype='multipart/form-data; boundary='+boundary)
def task(cid,prompt,mode='chat'):
 r,_=post('/api/research/tasks',{'conversation_id':cid,'prompt':prompt,'mode':mode,'effort':'medium','search_mode':'off','provider':'synergy','local_model':'balanced'})
 deadline=time.monotonic()+200
 while time.monotonic()<deadline:
  _,r,_=call('GET','/api/research/tasks/'+r['id'])
  if r['state'] not in {'queued','running'}:break
  time.sleep(1)
 check('real_assistant_task',r['state']=='succeeded',state=r['state']);return r
completed=False
try:
 if a.phase in {'before','candidate'}:
  creds={'username':'upgradeqa_'+secrets.token_hex(4),'password':secrets.token_urlsafe(28),'invite_code':os.environ['SYNERGY_INVITE_CODE']}
  _,h=post('/api/auth/register',creds);cookie=h['Set-Cookie'].split(';')[0]
  old,_=post('/api/conversations',{});post('/api/conversations/edit',{'id':old['id'],'title':'Upgrade login continuity QA'})
  state={'credentials':{'username':creds['username'],'password':creds['password']},'cookie':cookie,'conversation_id':old['id']}
  Path(a.state).write_text(json.dumps(state));Path(a.state).chmod(0o600)
 else:state=json.loads(Path(a.state).read_text());cookie=state['cookie']
 if a.phase!='before':
  code,me,_=call('GET','/api/me');check('existing_session_survived',code==200 and me['username']==state['credentials']['username'])
  code,old,_=call('GET','/api/conversations/'+state['conversation_id']);check('existing_conversation_survived',code==200 and old['title']=='Upgrade login continuity QA')
  code,_,h=call('POST','/api/auth/login',state['credentials'],auth=False);check('same_password_works',code==200)
  code,health,_=call('GET','/healthz',auth=False);check('live_version',code==200 and health['version']=='1.9.1')
  _,models,_=call('GET','/api/models');check('aerny_16_profiles',models['version']=='1.6' and all(x['available'] for x in models['local_models']))
  _,skills,_=call('GET','/api/skills');check('aws_skill_installed',any(s['id']=='aws-deployment' and 'Session Manager' in s['instructions'] for s in skills['skills']))
  project,_=post('/api/projects',{'name':'Aerny 1.6 acceptance','instructions':'Approved project colour is ivory. Keep answers brief.'})
  code,project,_=multipart('/api/projects/files',{'project_id':project['id'],'name':'approved-brief.txt'},'approved-brief.txt',b'The approved project code is CEDAR-826. The launch date is 20 November 2026.');check('project_reference_uploaded',code==201 and len(project['files'])==1)
  chats=[]
  for mode in ['chat','work','beast']:
   r,_=post('/api/conversations',{'project_id':project['id'],'mode':mode});chats.append(r);check('project_'+mode,r['project_id']==project['id'] and r['mode']==mode)
  result=task(chats[0]['id'],'What is the approved project code in the reference file? Give the code only.')
  check('project_reference_used','CEDAR-826' in result['reply'],reply=result['reply'])
  other,_=post('/api/projects',{'name':'Isolated second project'})
  empty,_=post('/api/conversations',{'project_id':other['id'],'mode':'work'})
  r=task(empty['id'],'What is the approved project code? If none was provided, say unspecified.');check('other_project_has_no_reference',not any(s.get('title','').startswith('approved-brief') for s in r['detail'].get('sources',[])),reply=r['reply'])
  code,voice,_=call('GET','/api/voice/status');check('openjarvis_ready',code==200 and voice['ready'] and voice['engine']=='OpenJarvis')
  spoken=task(chats[0]['id'],'Say exactly: Hello, I am Synergy. Ten plus twenty is thirty.')
  t=time.monotonic();code,audio,_=call('POST','/api/voice/speak',{'conversation_id':chats[0]['id']},raw=True)
  check('real_voice_synthesis',code==200 and audio[:4]==b'RIFF',bytes=len(audio),elapsed=round(time.monotonic()-t,2))
  with wave.open(io.BytesIO(audio)) as w:check('valid_voice_audio',w.getnframes()>24000,seconds=w.getnframes()/w.getframerate())
  code,transcript,_=multipart('/api/voice/transcribe',{'language':'en'},'speech.wav',audio,'audio/wav');check('real_speech_transcription',code==200 and 'synergy' in transcript.get('text','').lower(),transcript=transcript.get('text'),elapsed=transcript.get('elapsed'))
  response=task(chats[1]['id'],transcript['text']);code,audio2,_=call('POST','/api/voice/speak',{'conversation_id':chats[1]['id']},raw=True);check('transcript_to_assistant_to_voice',code==200 and audio2[:4]==b'RIFF',reply=response['reply'])
  code,_,_=call('GET','/api/projects/'+project['id'],auth=False);check('anonymous_project_denied',code==401)
  code,_,_=call('POST','/api/voice/speak',{'conversation_id':chats[0]['id']},auth=False);check('anonymous_voice_denied',code==401)
  saved_cookie=cookie
  _,h=post('/api/auth/register',{'username':'isolation_'+secrets.token_hex(4),'password':secrets.token_urlsafe(28),'invite_code':os.environ['SYNERGY_INVITE_CODE']});cookie=h['Set-Cookie'].split(';')[0]
  code,_,_=call('GET','/api/projects/'+project['id']);check('foreign_project_denied',code==404)
  code,_,_=call('POST','/api/voice/speak',{'conversation_id':chats[0]['id']});check('foreign_voice_denied',code==404)
  code,_,_=call('POST','/api/conversations',{'project_id':project['id']});check('foreign_project_link_denied',code==404)
  cookie=saved_cookie
 completed=True
finally:Path(a.report).write_text(json.dumps({'phase':a.phase,'checks':checks,'passed':completed and bool(checks) and all(c['passed'] for c in checks)},indent=2))
