"""Real 2.0 HTTP acceptance on private staging ONLY. Never run on production data."""
import io,json,os,secrets,sys,time,zipfile
from datetime import datetime
from zoneinfo import ZoneInfo
from http.client import HTTPConnection
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'app/backend'),str(ROOT/'deploy')]
from provision_admin import provision
from pypdf import PdfReader
DATA=Path(os.environ.get('SYNERGY_DATA_DIR','/var/lib/synergy'))
if not (DATA/'.staging-only').is_file():raise SystemExit('Refusing: isolated staging marker is missing.')
HOST='synergyai.1rank.in';records=[]
def check(label,ok,detail=None):
 if not ok:raise AssertionError(label+': '+str(detail))
 records.append({'check':label,'passed':True,**({'detail':detail} if detail is not None else {})});print(json.dumps(records[-1]),flush=True)
def call(method,path,d=None,cookie=None,expected=None):
 c=HTTPConnection('127.0.0.1',8090,timeout=30);h={'Host':HOST,'Origin':'https://'+HOST}
 if cookie:h['Cookie']=cookie
 if d is not None:h['Content-Type']='application/json';d=json.dumps(d)
 c.request(method,path,d,h);r=c.getresponse();raw=r.read();headers=dict(r.getheaders());status=r.status;c.close();body=json.loads(raw) if headers.get('Content-Type')=='application/json' else raw
 if expected is not None and status!=expected:raise AssertionError(path+' returned '+str(status)+': '+str(body)[:400])
 return status,body,headers
for _ in range(60):
 try:
  if call('GET','/healthz')[0]==200:break
 except OSError:pass
 time.sleep(1)
password=secrets.token_urlsafe(24);email='staging-'+secrets.token_hex(4)+'@example.invalid';admin_password=secrets.token_urlsafe(24);admin_name='stage-admin-'+secrets.token_hex(4)
_,u,h=call('POST','/api/auth/register',{'email':email,'password':password},expected=200);cookie=h['Set-Cookie'].split(';')[0];check('Email registration without invite code',bool(u.get('recovery_key')) and '; Secure' in h['Set-Cookie'])
provision(DATA/'accounts.sqlite3',admin_name,admin_password)
_,a,h=call('POST','/api/auth/login',{'username':admin_name,'password':admin_password},expected=200);admin=h['Set-Cookie'].split(';')[0]
check('Unprivileged admin access denied',call('GET','/api/admin/dashboard',cookie=cookie)[0]==403)
check('Work requires subscription',call('POST','/api/research/tasks',{'mode':'work','prompt':'Explain a business plan'},cookie)[0]==402)
_,o,_=call('POST','/api/billing/checkout',{'plan_id':'work-7','request_key':secrets.token_hex(16)},cookie,200)
check('Correct UPI amount and destination','am=99.00' in o['upi_url'] and 'smanshonerank%40ptyes' in o['upi_url'])
refs={'id':o['id'],'utr':'STAGEUTR'+secrets.token_hex(8),'transaction_id':'STAGETXN'+secrets.token_hex(8)}
_,p,_=call('POST','/api/billing/submit',refs,cookie,200);check('Provisional Work activation',p['membership']['access']['work'] and not p['membership']['access']['beast'])
_,dash,_=call('GET','/api/admin/dashboard',cookie=admin,expected=200);check('Unverified payment excluded from income',dash['confirmed_income_paise']['today']==0)
call('POST','/api/billing/submit',refs,cookie,200);_,acct,_=call('GET','/api/account',cookie=cookie);check('Submission retry does not duplicate subscription',len(acct['subscriptions'])==1)
# These are synthetic references, used only in this disposable private database.
csv='UTR,Transaction ID,Amount,Date,Type\n'+','.join([refs['utr'],refs['transaction_id'],'99',datetime.now(ZoneInfo('Asia/Kolkata')).date().isoformat(),'credit'])+'\n'
_,preview,_=call('POST','/api/admin/reconcile/preview',{'csv':csv},admin,200);check('Statement preview matches exact reference and amount',preview['rows'][0]['status']=='match')
call('POST','/api/admin/reconcile/apply',{'id':preview['id']},admin,200);_,dash,_=call('GET','/api/admin/dashboard',cookie=admin);check('Verified staging receipt counted once',dash['confirmed_income_paise']['today']==9900)
call('POST','/api/admin/subscription',{'action':'grant','user_id':u['id'],'plan_id':'beast-15','note':'Private staging acceptance only; no payment received'},admin,200)
_,acct,_=call('GET','/api/account',cookie=cookie);check('Manual Beast activation includes Work',acct['access']['beast'] and acct['access']['work'])
def task(prompt,mode='chat',model='auto'):
 _,t,_=call('POST','/api/research/tasks',{'prompt':prompt,'mode':mode,'local_model':model,'search_mode':'off','effort':'instant'},cookie,202);end=time.monotonic()+240
 while t['state'] in {'running','queued'} and time.monotonic()<end:
  time.sleep(.3);_,t,_=call('GET','/api/research/tasks/'+t['id'],cookie=cookie)
 check('Completed '+mode+' request',t['state']=='succeeded',{'state':t['state'],'selection':t['detail'].get('selection'),'reply':t.get('reply','')[:400]});return t
identity=task('Who are you and who owns SYnerGY?');check('Configured ownership answer',all(x in identity['reply'] for x in ['1Rank','friendly assistant','/contact']))
real=task('Write one concise sentence explaining why a company should record customer feedback.','work','fast');check('Real ETERNAL local inference',real['detail'].get('selection',{}).get('model')=='eternal-fast:v1.0' and len(real['reply'])>10)
pdf=task('Create a PDF. Exact content: # SYnerGY staging acceptance\n\nThis document verifies saved downloads.','beast');artifact=next(x for x in pdf['detail']['artifacts'] if x['kind']=='pdf');_,raw,_=call('GET',artifact['url'],cookie=cookie,expected=200);check('Actual PDF download',raw.startswith(b'%PDF') and 'staging acceptance' in ' '.join(p.extract_text() for p in PdfReader(io.BytesIO(raw)).pages))
_,project,_=call('POST','/api/beast/projects',{'name':'ETERNAL staging source','template':'website'},cookie,201);_,raw,_=call('GET','/api/beast/projects/'+project['id']+'/export',cookie=cookie,expected=200);check('Saved Beast source ZIP',bool(zipfile.ZipFile(io.BytesIO(raw)).namelist()))
_,r,_=call('POST','/api/auth/reset',{'email':email,'recovery_key':u['recovery_key'],'password':password+'new'},expected=200);check('Reset revoked previous session',call('GET','/api/me',cookie=cookie)[0]==401)
_,_,h=call('POST','/api/auth/login',{'email':email,'password':password+'new'},expected=200);cookie=h['Set-Cookie'].split(';')[0];_,acct,_=call('GET','/api/account',cookie=cookie);check('Reset preserved paid access and saved source',acct['access']['beast'] and call('GET','/api/beast/projects/'+project['id'],cookie=cookie)[0]==200)
call('POST','/api/admin/account',{'user_id':u['id'],'action':'suspend','note':'End private staging acceptance'},admin,200);check('Account termination revokes live session',call('GET','/api/me',cookie=cookie)[0]==401)
for page in ['/pricing','/contact','/admin','/synergy-upi.png']:check('Public page '+page,call('GET',page)[0]==200)
check('No registration access-code UI',b'id="invite-code"' not in call('GET','/')[1])
(DATA/'eternal-acceptance.json').write_text(json.dumps({'records':records,'no_real_payment_sent':True,'isolated_staging':True},indent=2))
print(json.dumps({'passed':len(records),'real_payment_sent':False,'scope':'private staging only'}))
