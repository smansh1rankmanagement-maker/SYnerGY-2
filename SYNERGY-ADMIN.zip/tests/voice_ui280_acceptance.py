"""Browser state-machine tests with fake microphone; no physical recording."""
import json,os
from pathlib import Path
from playwright.sync_api import sync_playwright
assert Path(os.environ['SYNERGY_DATA_DIR'],'.staging-only').exists()
checks=[]
def check(label, value):
 assert value,label
 checks.append(label);print('PASS '+label,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,args=['--no-sandbox']);p=b.new_page(viewport={'width':1360,'height':1000});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 # Load the shipped DOM and voice module, without a real user session or microphone.
 p.goto('http://127.0.0.1:8090');p.evaluate("""() => { document.querySelector('#auth-view').classList.add('hidden');document.querySelector('#app-view').classList.remove('hidden'); }""")
 p.evaluate("""() => {
 window.voiceCalls=[];window.voiceSubmits=[];window.voiceDeny=false;window.voiceUnclear=false;window.trackStopped=false;
 navigator.mediaDevices.getUserMedia=async()=>{if(window.voiceDeny){const e=new Error('denied');e.name='NotAllowedError';throw e;}return {getTracks:()=>[{stop:()=>window.trackStopped=true}]};};
 window.AudioContext=class {resume(){return Promise.resolve()}close(){return Promise.resolve()}createMediaStreamSource(){return {connect(){}}}createAnalyser(){return {fftSize:1024,getFloatTimeDomainData(a){a.fill(.04)}}}};
 window.MediaRecorder=class {static isTypeSupported(){return true}constructor(){this.state='inactive';this.mimeType='audio/webm'}start(){this.state='recording'}stop(){this.state='inactive';this.ondataavailable?.({data:new Blob(['a'.repeat(1500)])});setTimeout(()=>this.onstop?.(),0)}};
 window.voiceCtx={state:{chatBusy:false,cid:null,modelFamily:'eternal'},toast:m=>window.voiceCalls.push(m),api:async(path)=>{window.voiceCalls.push(path);if(path.endsWith('/status'))return {ready:true,profile:{name:'SYnerGY Jarvis'}};if(path.endsWith('/transcribe'))return new Promise(r=>setTimeout(()=>r({text:'Please research office furniture.',language:'en',needs_review:window.voiceUnclear,warning:window.voiceUnclear?'Review unclear words.':''}),250));return {messages:[{id:1,role:'assistant',content:'Your answer.'}]};}};
 document.querySelector('#chat-form').requestSubmit=()=>window.voiceSubmits.push(document.querySelector('#chat-input').value);
 HTMLMediaElement.prototype.play=function(){this.onplaying?.();return Promise.resolve()};HTMLMediaElement.prototype.pause=function(){};
 const actual=window.fetch;window.fetch=async(url,...rest)=>url==='/api/voice/speak'?new Response(new Blob(['audio']),{status:200}):actual(url,...rest);
 SynergyVoice.init(window.voiceCtx);
 }""")
 p.locator('#voice-button').click();p.wait_for_function("document.querySelector('#voice-bar').dataset.state==='listening'")
 check('Listening is visible',p.locator('#voice-status').inner_text()=='Listening');check('mic level visible',p.locator('#voice-meter').is_visible())
 p.locator('#voice-finish').click();check('Transcribing is visible',p.locator('#voice-status').inner_text()=='Transcribing');p.locator('#voice-transcript').wait_for(state='visible')
 check('review is default, nothing sent',p.evaluate('window.voiceSubmits.length')==0)
 p.locator('#voice-transcript').fill('Research approved office furniture.');p.locator('#voice-send').click();p.wait_for_function("document.querySelector('#voice-bar').dataset.state==='responding'")
 check('edited transcript sent exactly once',p.evaluate('window.voiceSubmits')==['Research approved office furniture.'])
 p.evaluate("SynergyVoice.replyReady('fixture')");p.wait_for_function("document.querySelector('#voice-bar').dataset.state==='speaking'");check('Speaking is visible',p.locator('#voice-status').inner_text()=='Speaking')
 p.locator('#voice-stop').click();check('End releases microphone',p.evaluate('window.trackStopped'));check('End hides voice controls',not p.locator('#voice-bar').is_visible())
 p.evaluate("document.querySelector('#chat-input').value='';window.voiceDeny=true");p.locator('#voice-button').click();p.wait_for_function("document.querySelector('#voice-bar').dataset.state==='error'");check('permission error stays visible',p.locator('#voice-hint').inner_text().startswith('Microphone permission'))
 p.evaluate('window.voiceDeny=false');p.locator('#voice-retry').click();p.wait_for_function("document.querySelector('#voice-bar').dataset.state==='listening'")
 p.locator('#voice-handsfree').check();p.evaluate('window.voiceUnclear=true');p.locator('#voice-finish').click();p.locator('#voice-transcript').wait_for(state='visible');check('unclear hands-free speech still requires review',p.evaluate('window.voiceSubmits.length')==1)
 p.evaluate("document.querySelector('#chat-input').value='Existing typed draft'");p.locator('#voice-send').click();check('typed draft is not overwritten',p.locator('#chat-input').input_value()=='Existing typed draft');check('transcript preserved beside draft',p.locator('#voice-transcript').input_value()=='Please research office furniture.')
 p.screenshot(path='/tmp/voice280-preview.png');p.locator('#voice-stop').click();check('no browser JavaScript errors',not errors);b.close()
Path('/tmp/voice280-ui-evidence.json').write_text(json.dumps({'checks':checks,'fake_microphone':True,'physical_microphone_tested':False},indent=2));print('PASS '+str(len(checks))+' voice UI checks',flush=True)
