"""Real support worker acceptance on a private candidate or isolated QA account."""
import urllib.request,json,uuid,time,argparse,io,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--url',default='https://synergyai.1rank.in');p.add_argument('--auth',required=True);p.add_argument('--report',required=True);a=p.parse_args();auth=json.loads(Path(a.auth).read_text());checks=[]
def call(path,data=None):
 h={'Host':'synergyai.1rank.in','Cookie':auth['cookie'],'Origin':'https://synergyai.1rank.in'}
 if data is not None:h['Content-Type']='application/json'
 with urllib.request.urlopen(urllib.request.Request(a.url+path,data=json.dumps(data).encode() if data is not None else None,headers=h),timeout=120) as r:return json.load(r)
def check(name,value,**details):
 checks.append({'name':name,'passed':bool(value),**details});print(json.dumps(checks[-1]),flush=True)
 if not value:raise AssertionError(name)
try:
 check('release193',call('/healthz')['version']=='1.9.3')
 source=call('/api/beast/projects',{'name':'Ticket acceptance '+uuid.uuid4().hex[:6],'files':{'main.py':'def total(items):\n    return sum(item["price"] for item in item)\n'}})
 project=call('/api/projects',{'name':'Support acceptance','kind':'app','beast_project_id':source['id']});check('project_source_link',call('/api/projects/'+project['id'])['beast_project_id']==source['id'])
 t=call('/api/support',{'title':'Fix the iterator in main.py total','description':'Calling total([{\"price\":100},{\"price\":200}]) raises an error because the generator iterates over item instead of items. Change only the iterator to items. Expected return is 300. Do not add other files.','project_id':project['id'],'auto_apply':True,'request_key':uuid.uuid4().hex});tid=t['id'];end=time.monotonic()+1000
 Path(a.report+'.state').write_text(json.dumps({'ticket_id':tid,'project_id':project['id'],'source_id':source['id']}))
 while time.monotonic()<end:
  t=call('/api/support/'+tid)
  if t['status'] not in {'queued','investigating'}:break
  time.sleep(2)
 check('real_beast_ticket',t['status']=='needs_validation',status=t['status'],ticket_id=tid)
 saved=call('/api/beast/projects/'+source['id']);code=saved['files']['main.py']['content'];check('saved_actual_change','in items)' in code,revision=saved['revision'])
 Path(a.report+'.source.py').write_text(code)
 # Only accept the expected tiny AST before running the trusted test in a separate step.
 check('no_unrelated_files',list(saved['files'])==['main.py'])
 check('progress_recorded',len(t['events'])>=3 and bool(t['job']['activity']))
 check('no_false_live_claim','not verified' in t['events'][-1]['message'])
 print('Ready for isolated verification; ticket remains open.',flush=True)
finally:Path(a.report).write_text(json.dumps(checks,indent=2))
