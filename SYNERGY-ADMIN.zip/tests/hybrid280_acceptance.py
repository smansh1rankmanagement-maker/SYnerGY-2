"""Live OpenRouter free-only requests in disposable staging; no paid requests."""
import json,os,sqlite3,time,urllib.request,uuid
from pathlib import Path
root=Path(os.environ['SYNERGY_DATA_DIR']);assert (root/'.staging-only').exists();base='http://127.0.0.1:8090';checks=[];runs=[]
def api(path,data=None,cookie=''):
 headers={'Cookie':cookie}
 if data is not None:headers['Content-Type']='application/json'
 with urllib.request.urlopen(urllib.request.Request(base+path,data=json.dumps(data).encode() if data is not None else None,headers=headers),timeout=30) as r:return json.load(r),r.headers
u,h=api('/api/auth/register',{'email':'hybrid280-'+uuid.uuid4().hex[:8]+'@qa.invalid','password':uuid.uuid4().hex+'Qa'});cookie=h['Set-Cookie'].split(';')[0]
with sqlite3.connect(root/'accounts.sqlite3') as c:c.execute("UPDATE users SET role='admin' WHERE id=?",(u['id'],))
api('/api/research/settings',{'onboarding_seen':True,'allow_external':True,'response_cache':False},cookie)
for mode,prompt in [('chat','Reply with the single word Ready.'),('work','Write two short checklist items for reviewing a draft.'),('beast','In one sentence, explain what a Python list is.')]:
 start=time.monotonic();t,_=api('/api/research/tasks',{'prompt':prompt,'mode':mode,'effort':'medium','provider':'hybrid','search_mode':'off','fresh_research':True},cookie)
 while time.monotonic()-start<240:
  t,_=api('/api/research/tasks/'+t['id'],cookie=cookie)
  if t['state'] not in {'queued','running'}:break
  time.sleep(.5)
 assert t['state']=='succeeded',t
 route=t['detail'].get('routing',{});assert route.get('free_only'),route
 checks.append(mode+' Hybrid completes with free routing or local fallback')
 result={'mode':mode,'seconds':round(time.monotonic()-start,2),'reply':t['reply'],'routing':route};runs.append(result);print(json.dumps(result),flush=True)
 Path('/tmp/hybrid280-evidence.json').write_text(json.dumps({'checks':checks,'runs':runs,'paid_requests':0},indent=2))
# The key itself must never reach the admin response.
dashboard,_=api('/api/admin/dashboard',cookie=cookie);text=json.dumps(dashboard)
assert 'sk-or-' not in text and 'Authorization' not in text
checks.append('admin diagnostics contain no secret key')
assert set(dashboard['hybrid_routing']['vendors'])=={'Google · Gemini and Gemma','OpenAI','Claude','Perplexity'}
checks.append('all four vendor catalogues visible in admin diagnostics')
Path('/tmp/hybrid280-evidence.json').write_text(json.dumps({'checks':checks,'runs':runs,'paid_requests':0,'actual_remote_successes':sum(r['routing'].get('status')=='completed' for r in runs)},indent=2))
print('PASS '+str(len(checks))+' Hybrid checks',flush=True)
