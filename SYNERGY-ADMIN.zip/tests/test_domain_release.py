"""Real HTTP/process/storage checks; no model output or TLS results are simulated."""
import base64, io, json, os, shutil, socket, sqlite3, subprocess, sys, tarfile, tempfile, time, unittest
from http.client import HTTPConnection
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app/backend'));sys.path.insert(0,str(ROOT/'deploy'))
from hosting import Hosting, RateLimiter
from action_boundary import matching_brands, work_action_message
from configure import configure
from data_archive import backup, restore

class DomainUnitTests(unittest.TestCase):
    def test_public_configuration_fails_closed(self):
        with self.assertRaises(ValueError):Hosting({'SYNERGY_BIND_HOST':'0.0.0.0'})
        with self.assertRaises(ValueError):Hosting({'SYNERGY_PUBLIC_ORIGIN':'http://ai.example.com'})
        h=Hosting({'SYNERGY_PUBLIC_ORIGIN':'https://ai.example.com'})
        self.assertTrue(h.accepts('ai.example.com',None))
        self.assertFalse(h.accepts('evil.example',None))
        self.assertFalse(h.accepts('ai.example.com',None,'POST'))
        self.assertFalse(h.accepts('ai.example.com','https://evil.example','POST'))
        self.assertTrue(h.accepts('ai.example.com','https://ai.example.com','POST'))
        self.assertTrue(h.accepts('ai.example.com',None,'POST',webhook=True))
        self.assertIn('Secure',h.cookie_suffix)
    def test_local_default_remains_loopback(self):
        h=Hosting({});self.assertTrue(h.accepts('127.0.0.1:8090',None,'POST'));self.assertFalse(h.public)
    def test_rate_limit_is_bounded(self):
        r=RateLimiter(2,capacity=3);self.assertTrue(r.allow('one'));self.assertTrue(r.allow('one'));self.assertFalse(r.allow('one'))
        for i in range(12):r.allow(str(i))
        self.assertEqual(len(r.items),3)
    def test_brand_longest_match_and_action_boundary(self):
        brands=[{'id':'a','name':'InteriFY'},{'id':'b','name':'InteriFY QA'}]
        self.assertEqual([b['id'] for b in matching_brands(brands,'Create a weekly automation for InteriFY QA')],['b'])
        self.assertEqual(len(matching_brands(brands,'Compare InteriFY and InteriFY QA')),2)
        self.assertIsNotNone(work_action_message('Export an Excel workbook and PDF summary','work'))
        self.assertIsNone(work_action_message('How do I create a brand workspace?','work'))
    def test_secret_configuration_is_private_and_never_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);shutil.copy(ROOT/'.env.example',d/'.env.example')
            configure(d,'ai.example.com','owner@example.com','owner')
            self.assertEqual((d/'.env').stat().st_mode&0o777,0o600)
            self.assertFalse((d/'secrets/invite-code.txt').exists())
            old=(d/'.env').read_bytes()
            with self.assertRaises(FileExistsError):configure(d,'ai.example.com','owner@example.com','owner')
            self.assertEqual((d/'.env').read_bytes(),old)
    def test_backup_restore_roundtrip_and_path_guard(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);source=d/'source';source.mkdir();(source/'saved.txt').write_text('private project')
            (source/'unsafe-link').symlink_to('/etc/passwd');buf=io.BytesIO();backup(source,buf)
            target=d/'restored';target.mkdir();restore(target,io.BytesIO(buf.getvalue()))
            self.assertEqual((target/'saved.txt').read_text(),'private project');self.assertFalse((target/'unsafe-link').exists())
            with self.assertRaises(ValueError):restore(target,io.BytesIO(buf.getvalue()))
            bad=io.BytesIO()
            with tarfile.open(fileobj=bad,mode='w:gz') as t:
                item=tarfile.TarInfo('../outside');item.size=1;t.addfile(item,io.BytesIO(b'x'))
            empty=d/'empty';empty.mkdir()
            with self.assertRaises(ValueError):restore(empty,io.BytesIO(bad.getvalue()))
    def test_model_download_verification(self):
        from unittest.mock import patch
        import hashlib
        from setup_models import download
        payload=b'fixture model bytes - not actual weights'
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'model.safetensors'
            with patch('setup_models.urllib.request.urlopen',return_value=io.BytesIO(payload)):
                download('https://example.com/model',target,len(payload),hashlib.sha256(payload).hexdigest())
            self.assertEqual(target.read_bytes(),payload)
            with patch('setup_models.urllib.request.urlopen') as network:
                download('https://example.com/model',target,len(payload),hashlib.sha256(payload).hexdigest())
                network.assert_not_called()
            target.unlink()
            with patch('setup_models.urllib.request.urlopen',side_effect=lambda *a,**k:io.BytesIO(payload)),patch('setup_models.time.sleep'):
                with self.assertRaises(ValueError):download('https://example.com/model',target,len(payload),'0'*64)
            self.assertFalse(target.exists())
            self.assertFalse(target.with_suffix('.safetensors.part').exists())

    def test_compose_boundary(self):
        import yaml
        doc=yaml.safe_load((ROOT/'compose.yaml').read_text());services=doc['services']
        self.assertEqual([k for k,v in services.items() if v.get('ports')],['caddy'])
        self.assertEqual(services['app']['environment']['SYNERGY_ALLOW_OPENAI'],'${SYNERGY_ALLOW_OPENAI:-0}')
        self.assertIn('app_data:/var/lib/synergy',services['app']['volumes'])
        self.assertEqual(services['beast']['command'],['beast'])
        self.assertEqual(services['operations']['command'],['operations'])
        self.assertEqual(services['app']['user'],'10001:10001')

class DomainHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.data=Path(cls.tmp.name)
        with socket.socket() as sock:sock.bind(('127.0.0.1',0));cls.port=sock.getsockname()[1]
        cls.env={**os.environ,'SYNERGY_PORT':str(cls.port),'SYNERGY_PUBLIC_ORIGIN':'https://ai.example.com','SYNERGY_INVITE_CODE':'','SYNERGY_DATA_DIR':str(cls.data),'SYNERGY_BIND_HOST':'127.0.0.1','SYNERGY_IMAGE_PYTHON':sys.executable,'SYNERGY_OPERATIONS_AERNY':'0','SYNERGY_OLLAMA_URL':'http://127.0.0.1:9','NO_PROXY':'*','no_proxy':'*'}
        cls.process=None;cls.worker=None;cls.log=(cls.data/'server.log').open('wb');cls.start()
    @classmethod
    def start(cls):
        cls.process=subprocess.Popen([sys.executable,str(ROOT/'app/backend/server.py')],env=cls.env,stdout=cls.log,stderr=cls.log)
        for i in range(100):
            if cls.process.poll() is not None:raise RuntimeError((cls.data/'server.log').read_text())
            try:
                if cls.call('GET','/healthz')[0]==200:return
            except OSError:pass
            time.sleep(.1)
        raise RuntimeError('Server startup timeout')
    @classmethod
    def stop(cls):
        if cls.process and cls.process.poll() is None:cls.process.terminate();cls.process.wait(timeout=20)
    @classmethod
    def tearDownClass(cls):
        if cls.worker and cls.worker.poll() is None:cls.worker.terminate();cls.worker.wait(timeout=20)
        cls.stop();cls.log.close();cls.tmp.cleanup()
    @classmethod
    def call(cls,method,path,body=None,cookie=None,origin='https://ai.example.com',host='ai.example.com'):
        c=HTTPConnection('127.0.0.1',cls.port,timeout=20);headers={'Host':host}
        if origin is not None:headers['Origin']=origin
        if cookie:headers['Cookie']=cookie
        if body is not None:body=json.dumps(body);headers['Content-Type']='application/json'
        c.request(method,path,body,headers);resp=c.getresponse();raw=resp.read();h=dict(resp.getheaders());c.close()
        return resp.status,json.loads(raw) if h.get('Content-Type')=='application/json' else raw,h
    def test_real_account_layout_worker_exports_and_restart(self):
        from PIL import Image
        from openpyxl import load_workbook
        from pypdf import PdfReader
        call=self.call
        self.assertEqual(call('GET','/healthz',host='evil.example')[0],403)
        creds={'username':'owner','email':'owner@qa.invalid','password':'a long domain test password','invite_code':self.env['SYNERGY_INVITE_CODE']}
        self.assertEqual(call('POST','/api/auth/register',creds,origin=None)[0],403)
        self.assertEqual(call('POST','/api/auth/register',creds,origin='https://evil.example')[0],403)
        status,_,headers=call('POST','/api/auth/register',creds);self.assertEqual(status,200)
        self.assertIn('; Secure',headers['Set-Cookie']);cookie=headers['Set-Cookie'].split(';')[0]
        _,_,headers=call('POST','/api/auth/register',{**creds,'username':'another','email':'another@qa.invalid'});other=headers['Set-Cookie'].split(';')[0]
        import sqlite3
        with sqlite3.connect(self.data/'accounts.sqlite3') as db:
            for uid, in db.execute('SELECT id FROM users').fetchall():db.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?,?,NULL,?,?)',('fixture-'+str(uid),uid,'beast',time.time()-1,time.time()+86400,'active',time.time(),'test_fixture'))
        self.assertEqual(call('GET','/api/operations/brands')[0],401)
        _,short,_=call('POST','/api/operations/brands',{'name':'InteriFY','config':{'brief':'Original brand'}},cookie)
        _,brand,_=call('POST','/api/operations/brands',{'name':'InteriFY QA','config':{'brief':'Interior design for homes and offices.','services':'Interior design','audience':'Founders and homeowners in Delhi NCR','website':''}},cookie)
        self.assertEqual(brand['approved_revision'],0)
        self.assertEqual(call('GET','/api/operations/brands/'+brand['id'],cookie=other)[0],404)
        _,chat,_=call('POST','/api/conversations',{},cookie)
        status,d,_=call('POST','/api/operations/chat',{'conversation_id':chat['id'],'prompt':'Create a draft weekly automation for InteriFY QA every Monday at 9:00 AM Asia/Kolkata'},cookie)
        self.assertEqual(status,201);weekly=d['workflow'];self.assertEqual(weekly['brand_id'],brand['id']);self.assertEqual(weekly['state'],'draft')
        self.assertEqual(weekly['definition']['schedule']['time'],'09:00')
        status,d,_=call('POST','/api/research/tasks',{'mode':'work','prompt':'Export an Excel workbook and PDF summary for InteriFY QA'},cookie)
        self.assertEqual(status,400);self.assertIn('No brand, file',d['detail'])
        # Real layout subprocess: a reference and exact supplied logo/headline, with no model required.
        def asset(name,colour):
            img=Image.new('RGB',(320,320),colour);buf=io.BytesIO();img.save(buf,format='PNG')
            status,a,_=call('POST','/api/studio/assets',{'name':name,'data':base64.b64encode(buf.getvalue()).decode()},cookie);self.assertEqual(status,201);return a['id']
        ref=asset('Permissioned QA reference','#ddd4c8');logo=asset('Synthetic QA logo','#e66127')
        spec={'workflow':'layout','prompt':'Exact layout QA','width':1080,'height':1350,'reference_id':ref,'layers':[{'type':'text','text':'Spaces that feel like you.','x':5,'y':70,'width':90,'height':20,'colour':'#2d2119','size':5},{'type':'logo','asset_id':logo,'x':5,'y':5,'width':15,'height':15}]}
        status,project,_=call('POST','/api/studio/projects',{'title':'Domain QA layout','spec':spec},cookie);self.assertEqual(status,200)
        status,job,_=call('POST','/api/studio/jobs',{'project_id':project['id']},cookie);self.assertEqual(status,202)
        for i in range(160):
            _,job,_=call('GET','/api/studio/jobs/'+job['id'],cookie=cookie)
            if job['state'] not in {'queued','running'}:break
            time.sleep(.1)
        self.assertEqual(job['state'],'succeeded',job)
        status,png,_=call('GET','/api/studio/jobs/'+job['id']+'/output.png',cookie=cookie);self.assertEqual(status,200);self.assertEqual(Image.open(io.BytesIO(png)).size,(1080,1350))
        self.assertEqual(call('GET','/api/studio/projects/'+project['id'],cookie=other)[0],404)
        # Manual workflow executes in a separate process with browser-independent durable storage.
        _,workflow,_=call('POST','/api/operations/workflows',{'brand_id':brand['id'],'schedule':{'kind':'manual','timezone':'Asia/Kolkata'}},cookie)
        self.assertEqual(call('POST','/api/operations/run',{'workflow_id':workflow['id']},cookie)[0],400)
        self.assertEqual(call('POST','/api/operations/workflows/action',{'id':workflow['id'],'action':'activate','reviewed_hash':workflow['hash']},cookie)[0],200)
        _,run,_=call('POST','/api/operations/run',{'workflow_id':workflow['id'],'idempotency_key':'domain-qa'},cookie)
        _,dup,_=call('POST','/api/operations/run',{'workflow_id':workflow['id'],'idempotency_key':'domain-qa'},cookie);self.assertEqual(run['id'],dup['id'])
        self.stop()
        self.__class__.worker=subprocess.Popen([sys.executable,str(ROOT/'app/backend/operations/worker.py'),'--data',str(self.data)],env=self.env,stdout=self.log,stderr=self.log)
        state='queued'
        for i in range(160):
            with sqlite3.connect(self.data/'accounts.sqlite3') as db:state=db.execute('SELECT state FROM ops_runs WHERE id=?',(run['id'],)).fetchone()[0]
            if state not in {'queued','running'}:break
            time.sleep(.25)
        self.assertEqual(state,'completed_with_blockers')
        self.start()
        self.assertEqual(call('GET','/api/studio/projects/'+project['id'],cookie=cookie)[1]['title'],'Domain QA layout')
        _,result,_=call('GET','/api/operations/runs/'+run['id'],cookie=cookie)
        kinds=[]
        for art in result['artifacts']:
            status,raw,_=call('GET','/api/operations/artifacts/'+art['id'],cookie=cookie);self.assertEqual(status,200);self.assertEqual(len(raw),art['size']);kinds.append(art['kind'])
            self.assertEqual(call('GET','/api/operations/artifacts/'+art['id'],cookie=other)[0],404)
            if art['kind']=='xlsx':
                book=load_workbook(io.BytesIO(raw));self.assertEqual(len(book.sheetnames),3)
                self.assertTrue(any(c.data_type=='f' for ws in book for row in ws for c in row))
            if art['kind']=='pdf':self.assertGreaterEqual(len(PdfReader(io.BytesIO(raw)).pages),1)
        self.assertIn('xlsx',kinds);self.assertIn('pdf',kinds)
        self.assertEqual(call('POST','/api/operations/external-action',{'brand_id':brand['id'],'kind':'publish'},cookie)[0],409)
        _,dashboard,_=call('GET','/api/operations/dashboard',cookie=cookie)
        self.assertEqual(next(w for w in dashboard['workflows'] if w['id']==weekly['id'])['state'],'draft')
        self.assertIn('Secure',call('POST','/api/auth/logout',{},cookie)[2]['Set-Cookie'])
        self.assertEqual(call('GET','/api/me',cookie=cookie)[0],401)

if __name__=='__main__':unittest.main(verbosity=2)
