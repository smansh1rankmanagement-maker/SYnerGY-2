"""Disposable AWS runtime measurements; actual local inference, no provider spending."""
import json,os,sqlite3,time,urllib.request,urllib.error,uuid
from pathlib import Path
ROOT=Path(os.environ['SYNERGY_DATA_DIR']);assert (ROOT/'.staging-only').is_file()
BASE='http://127.0.0.1:8090';checks=[];measurements=[]
def check(n,v):
 if not v:raise AssertionError(n)
 checks.append(n);print('PASS '+n,flush=True)
def api(path,d=None,cookie=None):
 h={'Cookie':cookie} if cookie else {}
 if d is not None:h['Content-Type']='application/json'
 try:
  with urllib.request.urlopen(urllib.request.Request(BASE+path,data=json.dumps(d).encode() if d is not None else None,headers=h),timeout=30) as r:
   return r.status,json.load(r) if r.headers.get_content_type()=='application/json' else r.read(),r.headers
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read()),e.headers
password=uuid.uuid4().hex+'Qa'
code,u,h=api('/api/auth/register',{'email':'speed-'+uuid.uuid4().hex[:8]+'@qa.invalid','password':password});check('registration preserves normal email flow',code==200);cookie=h['Set-Cookie'].split(';')[0]
_,other,oh=api('/api/auth/register',{'email':'cache-'+uuid.uuid4().hex[:8]+'@qa.invalid','password':password});othercookie=oh['Set-Cookie'].split(';')[0]
api('/api/research/settings',{'onboarding_seen':True,'web_search':True},cookie)
for provider in ['openai','hybrid']:
 cat=api('/api/models?mode=chat',cookie=cookie)[1];check('active free user eligible for '+provider,cat['provider_access'][provider])
check('external opt-in remains required',api('/api/research/tasks',{'prompt':'Hello','provider':'openai'},cookie)[0]==400)
check('Work paid entitlement preserved',api('/api/research/tasks',{'prompt':'Hello','mode':'work'},cookie)[0]==402)
check('admin deployment panel private',api('/api/admin/dashboard',cookie=cookie)[0]==403)
with sqlite3.connect(ROOT/'accounts.sqlite3') as c:c.execute("UPDATE users SET role='admin' WHERE id=?",(u['id'],))
check('clear cache authenticated',api('/api/research/cache/clear',{})[0]==401)
def task(level,prompt,**kw):
 start=time.monotonic();code,t,_=api('/api/research/tasks',{'prompt':prompt,'effort':level,'provider':'synergy','mode':'chat','search_mode':'auto',**kw},cookie);check('submitted '+level,code==202)
 limit={'instant':5,'medium':10,'high':60,'max':120,'ultra':120}[level]
 while time.monotonic()-start<limit+15:
  t=api('/api/research/tasks/'+t['id'],cookie=cookie)[1]
  if t['state'] not in {'queued','running'}:break
  time.sleep(.1)
 check('bounded terminal state '+level,t['state'] not in {'queued','running'})
 check('partial answers labelled '+level,t['state']!='partial' or 'incomplete' in t['reply'])
 check('task data isolated '+level,api('/api/research/tasks/'+t['id'],cookie=othercookie)[0]==404)
 result={'level':level,'state':t['state'],'seconds':round(time.monotonic()-start,2),'metrics':t['detail'].get('metrics'),'first_response_seconds':t['detail'].get('first_response_seconds'),'source_count':len([s for s in t['detail'].get('sources',[]) if s.get('access')=='read']),'cache':t['detail'].get('cache'),'model':(t['detail'].get('selection') or {}).get('model'),'reply':t['reply'][:2200]};measurements.append(result);Path('/tmp/speed270-measurements.json').write_text(json.dumps(measurements,indent=2));print('MEASURE '+json.dumps(result),flush=True);return t
ui_only=os.environ.get('SYNERGY_SPEED_UI_ONLY')=='1'
if ui_only:
 measurements=json.loads(Path('/tmp/speed270-measurements.json').read_text())
else:
 for level,prompt in [
  ('instant','Give one friendly sentence welcoming a new colleague.'),
  ('medium','Write three short tips for keeping a desk tidy.'),
  ('high','Read https://docs.python.org/3/library/ast.html and explain what ast.unparse does in three brief points. Cite the source.'),
  ('max','Read https://docs.python.org/3/library/ast.html and https://docs.python.org/3/library/tokenize.html. Compare AST and token processing in a short table with sources.'),
  ('ultra','Using https://docs.python.org/3/library/ast.html and https://docs.python.org/3/library/tokenize.html, give three risks of source rewriting and a concise validation checklist with citations.')]:
  t=task(level,prompt)
  if t['state']=='succeeded' and level in {'instant','medium'}:
   hit=task(level,prompt);check('repeat answer served from private cache '+level,bool(hit['detail'].get('cache',{}).get('hit')))
  elif t['state']=='partial':check('partial result never cached '+level,not t['detail'].get('cache'))
from playwright.sync_api import sync_playwright
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,args=['--no-sandbox']);ctx=b.new_context(viewport={'width':1440,'height':1000});ctx.add_cookies([{'name':'synergy_session','value':cookie.split('=',1)[1],'domain':'127.0.0.1','path':'/'}]);page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(BASE);page.locator('#app-view').wait_for(state='visible')
 for selector in ['#welcome-dismiss']:
  if page.locator(selector).is_visible():page.locator(selector).click()
 if page.get_by_role('button',name='Not now',exact=True).is_visible():page.get_by_role('button',name='Not now',exact=True).click()
 page.locator('#effort').select_option('high');page.reload();page.locator('#app-view').wait_for(state='visible');check('cookie remembers response level',page.locator('#effort').input_value()=='high')
 pref=[x for x in ctx.cookies() if x['name']=='synergy_reply_level'];check('only level stored in preference cookie',len(pref)==1 and pref[0]['value']=='high' and pref[0]['sameSite']=='Strict')
 page.locator('#open-settings').click();page.locator('[data-settings="preferences"]').click()
 page.get_by_role('button',name='Clear my response cache',exact=True).click();check('cache setting visible in preferences',page.get_by_label('Reuse recent answers privately for up to five minutes',exact=True).is_visible())
 page.get_by_role('button',name='Research and saved-file settings',exact=True).click();dialog=page.get_by_role('dialog')
 dialog.get_by_role('button',name='Clear my response cache',exact=True).click();check('cache controls rendered',dialog.get_by_text('Reuse recent public-source answers privately',exact=False).count()==1)
 dialog.get_by_label('Refresh sources for the next reply',exact=True).check();check('refresh option reaches composer',page.locator('#fresh-research').is_checked())
 dialog.get_by_role('button',name='Close',exact=True).click();page.locator('[data-settings="admin"]').click();page.get_by_role('button',name='Deployment',exact=True).click();check('AWS deployment policy visible',page.get_by_role('heading',name='Deployment destination',exact=True).is_visible())
 page.screenshot(path='/tmp/speed270-settings.png');check('no browser JavaScript errors',not errors);b.close()
check('clear own cache succeeds',api('/api/research/cache/clear',{},cookie)[0]==200)
with sqlite3.connect(ROOT/'accounts.sqlite3') as c:check('own cached answers cleared',c.execute('SELECT count(*) FROM response_cache WHERE user_id=?',(u['id'],)).fetchone()[0]==0)
evidence={'checks':len(checks),'passed':checks,'measurements':measurements,'local_models_only':True,'openai_requests':0,'latency_guaranteed':False,'training_performed':False,'ui_only':ui_only};Path('/tmp/speed270-acceptance.json').write_text(json.dumps(evidence,indent=2));print(json.dumps(evidence),flush=True)
