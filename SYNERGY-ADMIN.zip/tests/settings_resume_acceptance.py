"""Resume an already completed synthetic QA task after closing its browser."""
import os,sys,json,sqlite3,secrets,hashlib,time,urllib.request,io,zipfile
from pathlib import Path
ROOT=Path(os.environ['SYNERGY_DATA_DIR']);assert (ROOT/'.staging-only').exists()
c=sqlite3.connect(ROOT/'accounts.sqlite3');c.row_factory=sqlite3.Row
u=c.execute("SELECT u.id,u.email FROM users u JOIN admin_source_workspaces a ON a.user_id=u.id WHERE u.email LIKE 'settings-%@qa.invalid' ORDER BY u.id DESC LIMIT 1").fetchone();assert u
# A synthetic session for the previously created staging account, never production.
token=secrets.token_urlsafe(32);c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),u['id'],time.time()+1800));c.commit();cookie='synergy_session='+token
BASE='http://127.0.0.1:8090';checks=[]
def api(path,data=None):
 req=urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers={'Cookie':cookie,'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=30) as r:
  raw=r.read();return json.loads(raw) if r.headers.get_content_type()=='application/json' else raw
def check(name,ok):
 assert ok,name
 checks.append(name);print('PASS '+name,flush=True)
w=api('/api/admin/source/workspace');job=w['jobs'][0]
check('real ETERNAL Beast saved automatically',job['state']=='completed' and w['revision']==2 and job['result']['applied_revision']==2)
check('actual local ETERNAL recorded',job['result']['selection']['model']=='eternal:v1.0')
check('parse checks passed',job['result']['checks']['failed']==0)
with zipfile.ZipFile(io.BytesIO(api('/api/admin/source/workspace/export'))) as z:check('edited source ZIP contains change','Settings acceptance' in z.read('synergy/tools/python_scrambler/examples/input.py').decode())
cat=api('/api/admin/source');fid=next(f['id'] for f in cat['files'] if f['path']=='tools/python_scrambler/examples/input.py');check('original packaged source stays unchanged','Settings acceptance' not in api('/api/admin/source/file/'+fid)['text'])
from playwright.sync_api import sync_playwright,expect
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,args=['--no-sandbox']);ctx=b.new_context(viewport={'width':1440,'height':1000});ctx.add_cookies([{'name':'synergy_session','value':token,'domain':'127.0.0.1','path':'/'}]);page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(BASE+'/admin');page.locator('#app-view').wait_for(state='visible')
 if page.get_by_role('button',name='Not now',exact=True).is_visible():page.get_by_role('button',name='Not now',exact=True).click()
 page.locator('[data-section="source"]').click();page.locator('#admin-eternal summary').click();page.get_by_text('Saved to private source revision 2.',exact=False).wait_for(timeout=30000)
 check('reopened admin chat shows saved revision and real progress',page.locator('.admin-progress li').count()>0)
 page.locator('#close-settings').click();page.locator('#new-chat').click();page.locator('#chat-welcome h1').wait_for(state='visible');check('welcome headline stays above composer',page.locator('#chat-welcome h1').bounding_box()['y']+page.locator('#chat-welcome h1').bounding_box()['height'] < page.locator('.composer').bounding_box()['y']);page.screenshot(path='/tmp/synergy230-desktop.png')
 page.set_viewport_size({'width':390,'height':844});check('mobile has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth <= innerWidth'));page.screenshot(path='/tmp/synergy230-mobile.png')
 check('no JavaScript page errors',not errors);b.close()
api('/api/research/settings',{'allow_external':True})
task=api('/api/research/tasks',{'prompt':'Explain why a project brief is useful in one short sentence.','provider':'openai','mode':'chat','effort':'instant','search_mode':'off','request_id':secrets.token_hex(16)})
for i in range(60):
 task=api('/api/research/tasks/'+task['id'])
 if task['state'] not in ['queued','running']:break
 time.sleep(1)
check('real app request uses OpenAI and returns text',task['state']=='succeeded' and bool(task.get('reply')) and task.get('detail',{}).get('selection',{}).get('provider')=='openai')
Path('/tmp/settings-resume-acceptance.json').write_text(json.dumps({'checks':len(checks),'passed':checks},indent=2));print(json.dumps({'checks':len(checks)}),flush=True)
