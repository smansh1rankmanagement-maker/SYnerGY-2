const {test}=require('node:test');
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
class Element {
 constructor(tag){this.tagName=tag;this.children=[];this.classList={add(){}};this.textContent='';}
 append(...children){this.children.push(...children)}
 replaceChildren(...children){this.children=children}
}
function render(text){const document={createElement:t=>new Element(t),createTextNode:t=>({textContent:t})},window={};vm.runInNewContext(fs.readFileSync('app/static/research.js','utf8'),{document,window});const root=new Element('div');window.SynergyResearch.render(root,text);return root;}
test('loose numbered paragraphs remain one sequential list',()=>{const r=render('1. Goal\n\n2. Structure\n\n3. Design');assert.equal(r.children.length,1);assert.equal(r.children[0].tagName,'ol');assert.equal(r.children[0].start,1);assert.equal(r.children[0].children.length,3)});
test('ordered lists keep a non-one starting number',()=>{const r=render('7. Review\n\n8. Release');assert.equal(r.children[0].start,7);assert.equal(r.children[0].children.length,2)});
test('ordered and unordered lists remain separate',()=>{const r=render('1. First\n- Detail\n\n2. Second');assert.deepEqual(r.children.map(n=>n.tagName),['ol','ul','ol']);assert.equal(r.children[2].start,2)});
test('model HTML remains text rather than an executable element',()=>{const r=render('1. <img src=x onerror=alert(1)>');const child=r.children[0].children[0].children[0];assert.equal(child.textContent,'<img src=x onerror=alert(1)>');assert.equal(child.tagName,undefined)});
