"""Actual local speech inference in an isolated candidate, using synthetic fixtures."""
import difflib,io,json,math,os,struct,time,urllib.request,wave
from pathlib import Path
assert Path(os.environ['SYNERGY_DATA_DIR'],'.staging-only').exists()
BASE='http://synergy-voice-candidate280:8091';checks=[];results=[]
def call(path,raw,headers={}):
 with urllib.request.urlopen(urllib.request.Request(BASE+path,data=raw,headers=headers),timeout=180) as r:return r.read()
def check(label,value):
 assert value,label
 checks.append(label);print('PASS '+label,flush=True)
for language,text in [('en','Please research office furniture and prepare a short summary.'),('hi','मुझे कार्यालय के लिए एक नया डिजाइन चाहिए।')]:
 started=time.monotonic();audio=call('/speak',json.dumps({'text':text}).encode(),{'Content-Type':'application/json'})
 check(language+' real speech WAV',audio.startswith(b'RIFF') and len(audio)>10000)
 out=json.loads(call('/transcribe',audio,{'X-Language':language}))
 check(language+' transcript returned',bool(out['text'].strip()))
 if language=='en':check('English fixture contains intended topic',all(x in out['text'].lower() for x in ['research','office','furniture','summary']))
 else:
  ratio=difflib.SequenceMatcher(None,text,out['text']).ratio();check('Hindi fixture broadly matches and flags uncertainty',ratio>.70 and out['needs_review']);out['fixture_character_similarity']=round(ratio,3)
 check(language+' includes review signal',isinstance(out['needs_review'],bool) and 'word_confidence' in out)
 results.append({'language':language,'expected':text,'actual':out,'roundtrip_seconds':round(time.monotonic()-started,2),'synthetic_fixture':True})
for label,tone in [('silence',False),('tone',True)]:
 b=io.BytesIO()
 with wave.open(b,'wb') as w:
  w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000);w.writeframes(b''.join(struct.pack('<h',int(1500*math.sin(2*math.pi*440*n/16000)) if tone else 0) for n in range(32000)))
 out=json.loads(call('/transcribe',b.getvalue(),{'X-Language':'en'}));check(label+' does not invent speech',not out['text']);results.append({'fixture':label,'result':out})
evidence={'version':'2.8.0','checks':checks,'results':results,'physical_microphone_tested':False,'perfect_recognition_claimed':False}
Path('/tmp/voice280-evidence.json').write_text(json.dumps(evidence,indent=2,ensure_ascii=False));print(json.dumps(evidence,ensure_ascii=False),flush=True)
