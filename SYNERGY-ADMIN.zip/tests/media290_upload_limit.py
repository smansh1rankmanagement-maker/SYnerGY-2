"""Actual authenticated 200 MiB upload, resume, processing and rejection at the boundary."""
import base64,hashlib,io,json,os,secrets,time,urllib.error,urllib.request,uuid
from pathlib import Path
from PIL import Image
DATA=Path(os.environ['SYNERGY_DATA_DIR']);assert (DATA/'.staging-only').exists();BASE='http://127.0.0.1:8090';cookie=None;checks=[]
def req(path,data=None,expected=200):
 h={'Origin':BASE}
 if cookie:h['Cookie']=cookie
 if data is not None:h['Content-Type']='application/json'
 try:r=urllib.request.urlopen(urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers=h),timeout=60)
 except urllib.error.HTTPError as e:r=e
 out=json.load(r);assert r.status==expected,(path,r.status,out);return out,r.headers
def check(name,ok):assert ok,name;checks.append(name);print('PASS '+name,flush=True)
_,h=req('/api/auth/register',{'email':'upload200-'+uuid.uuid4().hex[:8]+'@qa.invalid','password':secrets.token_urlsafe(24)});cookie=h['Set-Cookie'].split(';')[0];cid=req('/api/conversations',{},201)[0]['id'];size=200*1024*1024;CHUNK=4*1024*1024
u=req('/api/uploads/create',{'conversation_id':cid,'name':'boundary-fixture.png','size':size,'batch_id':uuid.uuid4().hex})[0];rid=u['id'];bio=io.BytesIO();Image.new('RGB',(64,64),'#769088').save(bio,'PNG');header=bio.getvalue();digest=hashlib.sha256()
for i in range(size//CHUNK):
 raw=(header+b'\0'*(CHUNK-len(header))) if i==0 else b'\0'*CHUNK;digest.update(raw);payload={'id':rid,'index':i,'data':base64.b64encode(raw).decode()};req('/api/uploads/chunk',payload)
 if i==10:check('resending a saved chunk is idempotent',req('/api/uploads/chunk',payload)[0].get('duplicate') is True)
finished=req('/api/uploads/finish',{'id':rid})[0];check('all 200 MiB received with matching SHA256',finished['size']==size and finished['sha256']==digest.hexdigest());check('completed upload retains 50 chunks',len(req('/api/uploads/'+rid)[0]['chunks'])==50)
req('/api/uploads/create',{'conversation_id':cid,'name':'too-large.png','size':size+1,'batch_id':uuid.uuid4().hex},400);check('200 MiB plus one byte rejected',True)
j=req('/api/media-tools/submit',{'conversation_id':cid,'upload_ids':[rid],'recipe':{'kind':'image','operations':[{'op':'resize','width':128,'height':128}]}})[0];deadline=time.monotonic()+120
while j['state'] in {'queued','running'}:
 assert time.monotonic()<deadline,'Media boundary processing timed out';time.sleep(.5);j=req('/api/media-tools/jobs/'+j['id'])[0]
check('200 MiB uploaded media processed successfully',j['state']=='succeeded');check('large original retained',finished['sha256']==hashlib.sha256((DATA/'uploads'/rid/'original').read_bytes()).hexdigest())
(DATA/'upload-limit-evidence.json').write_text(json.dumps({'checks':checks,'bytes':size,'fixture':'64px PNG padded with inert trailing bytes; verifies transport/storage boundary, not complex-codec throughput'},indent=2));print(json.dumps({'complete':True,'checks':len(checks)}),flush=True)
