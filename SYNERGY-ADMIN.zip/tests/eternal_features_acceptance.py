"""Staging-only large upload, feedback, React/Motion and live suggestion evidence."""
import asyncio,base64,hashlib,io,json,os,secrets,sys,time,uuid,zipfile
from pathlib import Path
from http.client import HTTPConnection
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'app/backend'),str(ROOT/'deploy')]
from provision_admin import provision
DATA=Path(os.environ.get('SYNERGY_DATA_DIR','/var/lib/synergy'));assert (DATA/'.staging-only').is_file(),'Isolated staging only'
HOST='synergyai.1rank.in';records=[]
def check(name,ok,detail=None):
 if not ok:raise AssertionError(name+': '+str(detail))
 records.append({'check':name,'passed':True,'detail':detail});print(json.dumps(records[-1]),flush=True)
def call(method,path,data=None,cookie=None,expected=200):
 c=HTTPConnection('127.0.0.1',8090,timeout=130);h={'Host':HOST,'Origin':'https://'+HOST}
 if cookie:h['Cookie']=cookie
 if data is not None:h['Content-Type']='application/json';data=json.dumps(data)
 c.request(method,path,data,h);r=c.getresponse();raw=r.read();headers=dict(r.getheaders());status=r.status;c.close();body=json.loads(raw) if headers.get('Content-Type')=='application/json' else raw
 if expected is not None and status!=expected:raise AssertionError(path+': '+str(status)+' '+str(body)[:250])
 return body,headers
name='feature-qa-'+secrets.token_hex(4);password=secrets.token_urlsafe(24);provision(DATA/'accounts.sqlite3',name,password);_,h=call('POST','/api/auth/login',{'username':name,'password':password});cookie=h['Set-Cookie'].split(';')[0]
cid=call('POST','/api/conversations',{'title':'Upgrade acceptance','mode':'chat'},cookie,201)[0]['id']
settings=call('GET','/api/research/settings',cookie=cookie)[0];check('ETERNAL is the default model',settings['model_family']=='eternal')
call('POST','/api/research/settings',{'model_family':'aerny'},cookie);check('Model choice persists',call('GET','/api/research/settings',cookie=cookie)[0]['model_family']=='aerny');call('POST','/api/research/settings',{'model_family':'eternal'},cookie)
# Transfer a real 200 MiB file through fifty bounded HTTP requests, then hash its download.
size=200*1024*1024;chunk=bytes(range(256))*(4*1024*1024//256);digest=hashlib.sha256();started=time.monotonic();u=call('POST','/api/uploads/create',{'name':'large-upload-200mb.bin','size':size,'batch_id':uuid.uuid4().hex,'conversation_id':cid},cookie)[0];encoded=base64.b64encode(chunk).decode()
for i in range(50):call('POST','/api/uploads/chunk',{'id':u['id'],'index':i,'data':encoded},cookie);digest.update(chunk)
finished=call('POST','/api/uploads/finish',{'id':u['id']},cookie)[0];download,_=call('GET','/api/uploads/'+u['id']+'/original',cookie=cookie);check('Actual 200 MB upload and download match',len(download)==size and hashlib.sha256(download).hexdigest()==digest.hexdigest()==finished['sha256'],{'bytes':size,'seconds':round(time.monotonic()-started,2)});del download
call('POST','/api/uploads/delete',{'id':u['id']},cookie);check('Upload deletion removes access',call('GET','/api/uploads/'+u['id'],cookie=cookie,expected=404)[0].get('detail') is not None)
project=call('POST','/api/beast/projects',{'name':'React Motion acceptance','template':'react'},cookie,201)[0]
info=call('GET','/api/beast/projects/'+project['id']+'/preview-info?entry=src/main.jsx',cookie=cookie)[0];check('Real React/Motion preview compilation',info['scripts'] and not info['network'])
raw,_=call('GET','/api/beast/projects/'+project['id']+'/export',cookie=cookie);check('React source export has matching pinned dependencies',json.loads(zipfile.ZipFile(io.BytesIO(raw)).read('package.json'))['dependencies']['framer-motion']=='14.9.1')
# Real local model + a suggestion sent before its first run completes.
t=call('POST','/api/research/tasks',{'prompt':'Explain why teams keep project notes in three sentences.','conversation_id':cid,'mode':'chat','effort':'instant','local_model':'fast','search_mode':'off'},cookie,202)[0]
s=call('POST','/api/live-updates',{'kind':'research','target_id':t['id'],'text':'Now make that one brief bullet point.','request_key':uuid.uuid4().hex},cookie)[0]
end=time.monotonic()+300
while time.monotonic()<end:
 rows=call('GET','/api/live-updates?conversation_id='+cid,cookie=cookie)[0]['updates'];latest=next(x for x in rows if x['id']==s['id'])
 if latest['state']=='blocked':raise AssertionError(latest['error'])
 if latest.get('child_id'):
  child=call('GET','/api/research/tasks/'+latest['child_id'],cookie=cookie)[0]
  if child['state'] not in {'queued','running'}:break
 time.sleep(.3)
check('Running-task suggestion dispatched and completed',child['state']=='succeeded',{'child_id':child['id'],'model':child['detail'].get('selection',{}).get('model'),'reply':child['reply'][:250]})
metrics=[]
for model in ['fast','balanced']:
 t=call('POST','/api/research/tasks',{'prompt':'Write a friendly greeting in one sentence.','mode':'chat','effort':'instant','local_model':model,'search_mode':'off'},cookie,202)[0];end=time.monotonic()+300
 while t['state'] in {'running','queued'} and time.monotonic()<end:time.sleep(.3);t=call('GET','/api/research/tasks/'+t['id'],cookie=cookie)[0]
 check('Measured '+model+' local response',t['state']=='succeeded');metrics.append({'requested':model,'model':t['detail'].get('selection',{}).get('model'),'first_token_seconds':t['detail'].get('first_token_seconds'),'elapsed_seconds':t.get('elapsed')})
check('Latency measurements recorded',len(metrics)==2,metrics)
# Fresh browser session against the private staging server; route only this test origin.
async def browser_checks():
 from playwright.async_api import async_playwright
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,args=['--no-sandbox']);ctx=await browser.new_context(viewport={'width':1280,'height':900});await ctx.add_cookies([{'name':'synergy_session','value':cookie.split('=',1)[1],'url':'https://'+HOST,'httpOnly':True,'secure':True,'sameSite':'Strict'}])
  async def proxy(route):
   from urllib.parse import urlsplit
   req=route.request;parsed=urlsplit(req.url)
   if parsed.hostname!=HOST:return await route.abort()
   response=await route.fetch(url='http://127.0.0.1:8090'+parsed.path+('?' + parsed.query if parsed.query else ''),headers={**req.headers,'host':HOST,'origin':'https://'+HOST},timeout=180000)
   await route.fulfill(response=response)
  await ctx.route('**/*',proxy);page=await ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));await page.goto('https://'+HOST,wait_until='domcontentloaded');await page.locator('#eternal-welcome').wait_for(state='visible',timeout=15000);check('First-sign-in ETERNAL guide visible',await page.get_by_role('heading',name='Start with ETERNAL.').is_visible());await page.get_by_role('button',name='Start chatting',exact=True).click();await page.locator('#eternal-welcome').wait_for(state='detached');check('All three modes visible',all([await page.locator('[data-mode="'+m+'"]').is_visible() for m in ['chat','work','beast']]))
  await page.locator('#model-family').select_option('aerny');await page.get_by_text('Aerny 2.0 selected for your next message.',exact=True).wait_for();await page.clock.install();await page.clock.fast_forward(299000);check('No suggestion before five minutes',await page.locator('#eternal-reminder').count()==0);await page.locator('#chat-input').click();await page.clock.fast_forward(2000);await page.locator('#eternal-reminder').wait_for(state='visible');await page.get_by_role('button',name='Keep Aerny',exact=True).click();check('Dismissal preserves Aerny',await page.locator('#model-family').input_value()=='aerny')
  await page.goto('https://'+HOST+'/?beast='+project['id'],wait_until='domcontentloaded');await page.locator('#beast-frame').wait_for(state='visible',timeout=15000);frame=page.frame_locator('#beast-frame');await frame.get_by_role('button',name='Try the preview').click(timeout=20000);check('Interactive Framer/React preview works',await frame.get_by_text('Your preview is interactive.').is_visible());check('Preview cannot access parent account',await page.locator('#beast-frame').get_attribute('sandbox')=='allow-scripts');check('No frontend runtime errors',not errors,errors);await browser.close()
asyncio.run(browser_checks())
(DATA/'eternal-features-acceptance.json').write_text(json.dumps({'checks':records,'isolated_staging':True,'no_real_payment':True},indent=2))
print(json.dumps({'passed':len(records)}))
