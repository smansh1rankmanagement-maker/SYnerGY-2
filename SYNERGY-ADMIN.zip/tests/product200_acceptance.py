"""Real Graphify + isolated MCP acceptance. Run only in disposable staging storage."""
import json,os,sqlite3,sys,threading,subprocess,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/backend'))
from beast.store import Beast
from graphify_tool import execute,COMMIT
from membership import Membership
from observation_learning import Observation
from mcp_transport import StdioClient,initialize,unpack
root=Path(os.environ['SYNERGY_PRODUCT_TEST_ROOT']);assert (root/'.staging-only').is_file();root.mkdir(exist_ok=True);checks=[]
def check(name,ok,**details):
 checks.append({'check':name,'passed':bool(ok),**details});(root/'evidence.json').write_text(json.dumps({'checks':checks},indent=2));print(checks[-1],flush=True);assert ok,name
db=root/'accounts.sqlite3'
with sqlite3.connect(db) as c:c.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT,salt BLOB,password BLOB)');c.execute("INSERT OR IGNORE INTO users VALUES(1,'fixture',x'00',x'00')")
m=Membership(db);beast=Beast(db,root/'beast');p=beast.create(1,{'name':'Graphify real fixture','files':{'pricing.py':'def total(items):\n    return sum(items)\n\ndef invoice(items):\n    return total(items)\n','app.js':'export function greet(name) { return `Hello ${name}`; }\nexport function welcome() { return greet("SYNERGY"); }','README.md':'Local test. No secret inputs.'}})
folder=root/'graph-task';folder.mkdir(exist_ok=True);stages=[]
r=execute(beast,1,p['id'],folder,'Use Graphify to explain total and invoice',threading.Event(),stages.append)
check('real pinned Graphify extraction',r['nodes']>=4 and r['files']==2,**{k:r[k] for k in ['nodes','edges','revision','commit']});graph=json.loads((folder/'graph.json').read_text());check('downloadable graph parses and includes code symbols','invoice' in json.dumps(graph) and 'total' in json.dumps(graph));check('original revision unchanged',beast.project(1,p['id'])['revision']==1);check('reported real stages',len(stages)==3)
try:execute(beast,2,p['id'],root/'unauthorised','map',threading.Event(),lambda _:None);isolated=False
except KeyError:isolated=True
check('cross-account source refused',isolated)
stop=threading.Event();stop.set();cancel=root/'cancel';cancel.mkdir(exist_ok=True)
try:execute(beast,1,p['id'],cancel,'map',stop,lambda _:None);cancelled=False
except InterruptedError:cancelled=True
check('real subprocess cancellation',cancelled and not (cancel/'graph.json').exists())
obs=Observation(db);x=obs.capture(1,'Explain Python function variables','Function variables are local bindings unless a global or nonlocal declaration changes their scope.',enabled=True)
client=StdioClient([sys.executable,str(Path(__file__).resolve().parents[1]/'app/backend/observation_mcp.py'),'--data',str(root),'--user','1'],{'PATH':os.environ['PATH']},str(root))
try:
 info=initialize(client);tools=client.request('tools/list')['tools'];check('Observation MCP real handshake',info['version']=='2.0.0' and len(tools)==4)
 data=unpack(client.request('tools/call',{'name':'observation_examples','arguments':{}}));check('Observation MCP reads owned queue',len(data['examples'])==1 and not data['training_completed'])
 data=unpack(client.request('tools/call',{'name':'observation_review','arguments':{'id':x['id'],'decision':'approve'}}));check('Observation MCP actual review and retrieval',data['ok'] and len(obs.retrieve(1,'Explain Python function variables',enabled=True))==1)
finally:client.close()
# Public Google request, with an explicit blocked result rather than invented evidence.
from research.web import google_public_search,Web
try:
 rows=google_public_search('Python ast official documentation',3,None,threading.Event());google={'status':'readable','results':len(rows),'urls':[r['href'] for r in rows]}
except Exception as e:google={'status':'unavailable','reason':str(e)[:250]}
(root/'google-check.json').write_text(json.dumps(google,indent=2));print('Google observation:',google,flush=True)
