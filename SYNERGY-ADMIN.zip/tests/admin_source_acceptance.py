"""Isolated AWS browser acceptance. Refuses to create users against production."""
import io,json,os,sqlite3,time,uuid,urllib.request,urllib.error,zipfile
from pathlib import Path
ROOT=Path(os.environ.get('SYNERGY_DATA_DIR','/var/lib/synergy'))
assert (ROOT/'.staging-only').is_file(),'Staging data is required.'
BASE='http://127.0.0.1:8090';proof=[]
def check(name,ok):
 if not ok:raise AssertionError(name)
 proof.append(name);print('PASS '+name,flush=True)
def request(path,data=None,cookie=None):
 headers={}
 if data is not None:headers['Content-Type']='application/json'
 if cookie:headers['Cookie']=cookie
 req=urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
 try:
  with urllib.request.urlopen(req,timeout=30) as r:
   raw=r.read();return r.status,json.loads(raw) if r.headers.get_content_type()=='application/json' else raw,r.headers.get('Set-Cookie')
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read()),None
for _ in range(40):
 try:
  if request('/healthz')[0]==200:break
 except urllib.error.URLError:pass
 time.sleep(.5)
email='source-'+uuid.uuid4().hex[:8]+'@qa.invalid';password=uuid.uuid4().hex+'Test!'
status,user,cookie=request('/api/auth/register',{'email':email,'password':password});check('isolated account created',status==200)
check('ordinary account denied source',request('/api/admin/source',cookie=cookie)[0]==403)
with sqlite3.connect(ROOT/'accounts.sqlite3') as c:c.execute("UPDATE users SET role='admin' WHERE email=?",(email,))
status,cat,_=request('/api/admin/source',cookie=cookie);check('admin sees curated synergy folder',status==200 and cat['folder']=='synergy' and len(cat['files'])>380)
check('MCP and scrambler source included',all(any(f['path']==p for f in cat['files']) for p in ['app/backend/specialists/server.py','app/backend/specialists/catalog.py','tools/python_scrambler/engine.py']))
status,raw,_=request('/api/admin/source/synergy.zip',cookie=cookie)
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 check('source ZIP downloads with synergy root',status==200 and len(z.namelist())==len(cat['files']) and all(n.startswith('synergy/') for n in z.namelist()))
 check('no runtime secrets or account data in source ZIP',not any(n=='synergy/.env' or n.endswith('accounts.sqlite3') or n.endswith('/mapping.json') for n in z.namelist()))
original='def total(prices, *, discount=0):\n    subtotal=0\n    for price in prices:\n        subtotal+=price\n    return subtotal-discount\n'
status,result,_=request('/api/admin/source/scramble',{'source':original},cookie)
check('real bounded worker transforms without execution claim',status==200 and result['report']['renamed_variables']==2 and result['report']['behaviour']['status']=='not_tested' and 'mapping' not in result)
from playwright.sync_api import sync_playwright,expect
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--no-sandbox']);context=browser.new_context(viewport={'width':1440,'height':1000});page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 context.add_cookies([{'name':'synergy_session','value':cookie.split(';')[0].split('=',1)[1],'domain':'127.0.0.1','path':'/'}]);page.goto(BASE+'/admin');page.locator('#app-view').wait_for(state='visible',timeout=30000)
 page.get_by_role('button',name='Start chatting',exact=True).wait_for(state='visible',timeout=30000);page.get_by_role('button',name='Start chatting',exact=True).click()
 if page.locator('#welcome-dismiss').is_visible():page.locator('#welcome-dismiss').click()
 page.get_by_role('button',name='Admin panel',exact=True).click()
 page.locator('#admin-source summary').click();page.get_by_role('heading',name='synergy/',exact=True).wait_for(timeout=20000)
 check('admin source folder opens in browser',True)
 page.get_by_label('Find files in synergy',exact=True).fill('specialists/server.py');page.get_by_label('Source files',exact=True).select_option(index=0)
 expect(page.get_by_label('Original source preview',exact=True)).to_contain_text('initialize')
 page.get_by_label('Python source',exact=True).fill(original)
 page.get_by_role('button',name='Scramble a copy',exact=True).click();page.get_by_role('heading',name='Syntax validation passed · Behaviour not tested',exact=True).wait_for(timeout=20000)
 check('browser submits real transformation', '_v001' in page.get_by_label('Transformed Python source',exact=True).input_value())
 with page.expect_download() as event:page.get_by_role('button',name='Download transformed .py',exact=True).click()
 download=event.value;download.save_as('/tmp/scrambler-ui-output.py');check('browser output download matches API source',Path('/tmp/scrambler-ui-output.py').read_text()==result['source'])
 with page.expect_download() as event:page.get_by_role('link',name='Download synergy folder ZIP',exact=True).click()
 download=event.value;download.save_as('/tmp/synergy-admin-source.zip')
 check('browser authenticated ZIP download completes',zipfile.is_zipfile('/tmp/synergy-admin-source.zip'))
 page.locator('#admin-source').screenshot(path='/tmp/admin-source-preview.png')
 page.locator('#admin-source summary').click();page.locator('#admin-eternal summary').click()
 page.get_by_role('button',name='Open ETERNAL workspace',exact=True).click()
 page.get_by_label('Admin task',exact=True).wait_for(timeout=30000)
 check('admin ETERNAL workspace opens in browser',True)
 page.get_by_label('Response level',exact=True).select_option('instant')
 page.get_by_label('Selected source context',exact=True).select_option('tools/python_scrambler/examples/input.py')
 for mode,prompt in [('work','Explain invoice_total in one sentence. Do not propose any file changes.'),('beast','Append only this exact comment to the end of tools/python_scrambler/examples/input.py: # Admin workspace acceptance. Preserve every existing line. Use operation append.')]:
  page.get_by_label('Administrator mode',exact=True).select_option(mode)
  page.get_by_label('Admin task',exact=True).fill(prompt)
  page.get_by_role('button',name='Send to ETERNAL',exact=True).click()
  deadline=time.monotonic()+500;job=None
  while time.monotonic()<deadline:
   status,w,_=request('/api/admin/source/workspace',cookie=cookie)
   job=next((j for j in w.get('jobs',[]) if j['request']['prompt']==prompt),None)
   if job and job['state'] not in ['queued','running']:break
   time.sleep(2)
  check('real ETERNAL '+mode+' task finishes',job and job['state'] in ['completed','awaiting_review'])
  check('ETERNAL '+mode+' uses local model',job['result']['selection']['provider']=='synergy' and job['result']['selection']['model']=='eternal:v1.0')
  if mode=='work':check('Work does not change source',job['state']=='completed' and not job['result']['changes'] and w['revision']==1)
  else:
   check('Beast produces reviewable diff',job['state']=='awaiting_review' and 'Admin workspace acceptance' in job['result']['diff'])
   page.get_by_role('button',name='Apply reviewed diff to private copy',exact=True).wait_for(timeout=15000)
   page.get_by_role('button',name='Apply reviewed diff to private copy',exact=True).click()
   for _ in range(25):
    w=request('/api/admin/source/workspace',cookie=cookie)[1]
    if w['revision']==2:break
    time.sleep(.2)
   check('reviewed change saved as private revision',w['revision']==2)
   status,edited,_=request('/api/admin/source/workspace/export',cookie=cookie)
   with zipfile.ZipFile(io.BytesIO(edited)) as z:check('edited source download contains accepted change',status==200 and 'Admin workspace acceptance' in z.read('synergy/tools/python_scrambler/examples/input.py').decode())
   original_id=next(f['id'] for f in cat['files'] if f['path']=='tools/python_scrambler/examples/input.py')
   check('deployed original stays unchanged', 'Admin workspace acceptance' not in request('/api/admin/source/file/'+original_id,cookie=cookie)[1]['text'])
 page.locator('#admin-eternal').screenshot(path='/tmp/admin-eternal-preview.png')
 check('no JavaScript errors',not errors);browser.close()
Path('/tmp/admin-source-acceptance.json').write_text(json.dumps({'checks':len(proof),'passed':proof},indent=2))
print(json.dumps({'checks':len(proof)}),flush=True)
