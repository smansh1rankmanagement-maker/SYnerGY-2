"""Real Gemini replies; isolated OpenRouter cooldown exercises cross-provider fallback."""
import json,os,sqlite3,sys,time,uuid
from pathlib import Path
sys.path.insert(0,'/opt/synergy/app/backend')
root=Path(os.environ['SYNERGY_DATA_DIR']);assert (root/'.staging-only').exists()
# Reuse only the request helper, not the other acceptance test's side effects.
import urllib.request
base='http://127.0.0.1:8090'
def api(path,data=None,cookie=''):
 h={'Cookie':cookie,'Content-Type':'application/json'}
 with urllib.request.urlopen(urllib.request.Request(base+path,data=json.dumps(data).encode() if data is not None else None,headers=h),timeout=30) as r:return json.load(r),r.headers
u,h=api('/api/auth/register',{'email':'gemini280-'+uuid.uuid4().hex[:8]+'@qa.invalid','password':uuid.uuid4().hex+'Qa'});cookie=h['Set-Cookie'].split(';')[0]
with sqlite3.connect(root/'accounts.sqlite3') as c:c.execute("UPDATE users SET role='admin' WHERE id=?",(u['id'],))
api('/api/research/settings',{'allow_external':True,'allow_free_data_use':True,'onboarding_seen':True,'response_cache':False},cookie)
import free_router
free_router.cooldown('account',180,'isolated-acceptance-fixture')
runs=[]
try:
 for mode in ['chat','work','beast']:
  start=time.monotonic();t,_=api('/api/research/tasks',{'prompt':'In one sentence, explain why a task checklist is useful.','mode':mode,'provider':'hybrid','effort':'instant','search_mode':'off','fresh_research':True},cookie)
  while time.monotonic()-start<100:
   t,_=api('/api/research/tasks/'+t['id'],cookie=cookie)
   if t['state'] not in {'queued','running'}:break
   time.sleep(.3)
  assert t['state']=='succeeded',t['detail'].get('error')
  route=t['detail'].get('routing',{});assert route.get('actual_provider')=='gemini',route
  runs.append({'mode':mode,'reply':t['reply'],'seconds':round(time.monotonic()-start,2),'routing':route});print(json.dumps(runs[-1]),flush=True)
 p,_=api('/api/beast/projects',{'name':'Gemini source QA','files':{'main.py':{'encoding':'utf-8','content':'def add(a, b):\n    return a - b\n'}}},cookie)
 j,_=api('/api/beast/jobs',{'project_id':p['id'],'revision':p['revision'],'prompt':'Fix only the add function to return a + b. Use a replace operation.','task_mode':'change','provider':'hybrid','effort':'medium','paths':['main.py'],'idempotency_key':uuid.uuid4().hex},cookie)
 from beast.store import Beast
 from beast.worker import Worker
 from membership import Membership
 s=Beast(root/'accounts.sqlite3',root/'beast');m=Membership(s.db);s.access=m.require;s.provider_access=m.require_provider
 with s.connect() as c:
  c.execute("UPDATE beast_jobs SET state='running' WHERE id=?",(j['id'],));row=dict(c.execute('SELECT * FROM beast_jobs WHERE id=?',(j['id'],)).fetchone())
 Worker(s).process(row);done=s.job(u['id'],j['id']);assert done['state']=='awaiting_review',done
 r=done['result'];assert r['usage']['routing']['actual_provider']=='gemini';assert r['checks']['failed']==0
 assert s.project(u['id'],p['id'])['revision']==p['revision']
 s.job_action(u['id'],{'id':j['id'],'action':'apply','revision':p['revision'],'reviewed_hash':r['hash']})
 final=s.project(u['id'],p['id']);assert 'return a + b' in final['files']['main.py']['content']
 runs.append({'beast_source':'reviewed and applied to disposable project','syntax_checks':r['checks'],'runtime_execution_claimed':False})
finally:
 with free_router.database() as c:c.execute("DELETE FROM cooldown WHERE scope='account' AND reason='isolated-acceptance-fixture'")
Path('/tmp/gemini280-evidence.json').write_text(json.dumps({'runs':runs,'real_provider_calls':True,'openrouter_cooldown_injected_only_in_disposable_candidate':True},indent=2));print('PASS Gemini 3 modes and Beast source review/apply',flush=True)
