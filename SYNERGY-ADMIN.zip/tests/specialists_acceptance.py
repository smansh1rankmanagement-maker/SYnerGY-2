"""Runs only against an isolated .staging-only candidate; never creates production QA users."""
import json,os,sqlite3,time,uuid,urllib.request,urllib.error,hashlib
from pathlib import Path
ROOT=Path(os.environ.get('SYNERGY_DATA_DIR','/var/lib/synergy'))
assert (ROOT/'.staging-only').is_file(),'Refusing to test production data.'
BASE='http://127.0.0.1:8090';proof=[]
def check(name,condition):
 if not condition:raise AssertionError(name)
 proof.append(name);print('PASS '+name,flush=True)
def request(path,data=None,cookie=None):
 headers={}
 if data is not None:headers['Content-Type']='application/json'
 if cookie:headers['Cookie']=cookie
 req=urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
 try:
  with urllib.request.urlopen(req,timeout=60) as r:
   raw=r.read();return r.status,json.loads(raw) if r.headers.get_content_type()=='application/json' else raw,r.headers.get('Set-Cookie')
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read()),None
for _ in range(60):
 try:
  if request('/healthz')[0]==200:break
 except urllib.error.URLError:pass
 time.sleep(.5)
else:raise AssertionError('Candidate backend did not become ready.')
email='specialists-'+uuid.uuid4().hex[:8]+'@qa.invalid';password=uuid.uuid4().hex+'Test!'
status,user,cookie=request('/api/auth/register',{'email':email,'password':password});check('register candidate account',status==200)
with sqlite3.connect(ROOT/'accounts.sqlite3') as c:
 uid=c.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()[0]
 c.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?,?,NULL,?,?)',(uuid.uuid4().hex,uid,'beast',time.time()-1,time.time()+3600,'active',time.time(),'staging_fixture'))
status,cat,_=request('/api/specialists',cookie=cookie);check('two MCP servers with live worker',status==200 and len(cat['servers'])==2 and cat['worker_ready'])
status,skills,_=request('/api/skills',cookie=cookie);check('34 detailed skills installed',len([s for s in skills['skills'] if s['id'].startswith('eternal-')])==34)
def tool(server,name,args):
 status,job,_=request('/api/specialists/'+server+'/call',{'tool':name,'arguments':args,'request_id':uuid.uuid4().hex,'mode':'chat'},cookie);assert status==202,(name,status,job)
 for _ in range(150):
  _,result,_=request('/api/specialists/jobs/'+job['id'],cookie=cookie)
  if result['state'] in {'complete','failed','cancelled'}:
   assert result['state']=='complete',(name,result);return result['result']
  time.sleep(.2)
 raise AssertionError('Job timeout')
lesson=tool('vedics','lesson_create',{'topic':'fractions','metadata':{'grade':'5','subject':'Mathematics','board':'Independent','language':'English'}})['record'];check('lesson saved with metadata','3/4' in lesson['data']['content'])
practice=tool('vedics','practice_generate',{'topic':'fractions','count':5})['record'];exam=tool('vedics','exam_create',{'title':'Staging fractions assessment','practice_id':practice['id']})['record']
check('exam freezes answer key','answer' not in exam['data']['questions'][0])
attempt=tool('vedics','exam_submit',{'exam_id':exam['id'],'answers':[{'question_id':q['id'],'answer':q['answer']} for q in practice['data']['questions']]})['record'];check('actual objective scoring',attempt['data']['score']==5 and attempt['data']['status']=='graded')
export=tool('vedics','scorecard_export',{'attempt_id':attempt['id']});pdf=next(a for a in export['artifacts'] if a['kind']=='pdf');status,raw,_=request(pdf['url'],cookie=cookie);check('scorecard download',status==200 and raw.startswith(b'%PDF'))
(Path('/tmp')/'vedics-scorecard.pdf').write_bytes(raw)
founder=tool('foundr','task_assign',{'title':'Review launch plan','due':'2026-11-09'});check('founder task persisted',founder['record']['kind']=='task')
payroll=tool('foundr','payroll_calculate',{'period':'2026-11','effective_date':'2026-11-01','currency':'INR','rules':'Supplied amounts only.','employees':[{'name':'Staging employee','gross':'30000','additions':'1000','deductions':'500'}]});check('payroll total and output',payroll['record']['data']['total_net']=='30500.00' and bool(payroll['artifacts']))
status,raw,_=request(payroll['artifacts'][0]['url'],cookie=cookie);check('spreadsheet download',status==200 and raw.startswith(b'PK'));(Path('/tmp')/'foundr-payroll.xlsx').write_bytes(raw)
status,job,_=request('/api/research/tasks',{'prompt':'VEDICS explain 1/2 + 1/4','search_mode':'off','mode':'chat'},cookie)
for _ in range(120):
 _,result,_=request('/api/research/tasks/'+job['id'],cookie=cookie)
 if result['state'] in {'succeeded','failed'}:break
 time.sleep(.2)
check('chat invokes actual MCP',result['state']=='succeeded' and result['detail']['metrics'].get('actual_mcp_call') and '3/4' in result['reply'])
# Browser checks use the real signed-in candidate interface, not a static screenshot.
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 value=cookie.split(';')[0].split('=',1)[1];browser.contexts[0].add_cookies([{'name':'synergy_session','value':value,'domain':'127.0.0.1','path':'/'}]);page.goto(BASE);page.locator('#app-view').wait_for(state='visible',timeout=30000)
 page.get_by_role('button',name='Start chatting',exact=True).wait_for(state='visible',timeout=30000)
 page.get_by_role('button',name='Start chatting',exact=True).click()
 if page.locator('#welcome-dismiss').count() and page.locator('#welcome-dismiss').is_visible():page.locator('#welcome-dismiss').click()
 # Optional onboarding dialog can obscure navigation. Dismiss via its visible close button.
 for dialog in page.locator('dialog[open]').all():
  button=dialog.get_by_role('button',name='Close',exact=False)
  if button.count():button.first.click()
 page.locator('[data-page="vedics"]').click();page.locator('#vedics-records .specialist-record').first.wait_for(timeout=20000)
 page.locator('#vedics-tool').select_option('question_explain');page.locator('#vedics-tool-form [name="expression"]').fill('2/3 + 1/6');page.locator('#vedics-tool-form button[type="submit"]').click();page.locator('#vedics-result').get_by_text('2/3 + 1/6 = 5/6',exact=True).wait_for(timeout=20000);check('VEDICS browser form executes',True);page.screenshot(path='/tmp/vedics-preview.png',full_page=False)
 page.locator('[data-page="foundr"]').click();page.locator('#foundr-records .specialist-record').first.wait_for(timeout=20000);page.locator('#foundr-tool-form [name="title"]').fill('Browser-created task');page.locator('#foundr-tool-form button[type="submit"]').click();page.locator('#foundr-result').get_by_role('heading',name='Browser-created task').wait_for(timeout=20000);check('FOUNDR browser form executes',True);page.screenshot(path='/tmp/foundr-preview.png',full_page=False)
 check('no browser JavaScript errors',not errors);browser.close()
# Real configured local model -> lesson draft -> MCP persistence.
status,job,_=request('/api/research/tasks',{'prompt':'VEDICS teach fractions for class 5. Use one short worked example and one check question.','search_mode':'off','mode':'chat','effort':'instant','local_model':'balanced'},cookie);assert status==202,job
for _ in range(900):
 _,result,_=request('/api/research/tasks/'+job['id'],cookie=cookie)
 if result['state'] in {'succeeded','failed','cancelled'}:break
 time.sleep(.5)
check('local model lesson saved through MCP',result['state']=='succeeded' and result['detail']['metrics'].get('actual_mcp_call'))
(Path('/tmp')/'specialists-model-response.json').write_text(json.dumps({'reply':result['reply'],'selection':result['detail']['selection'],'elapsed':result['elapsed']},indent=2))
(Path('/tmp')/'specialists-acceptance.json').write_text(json.dumps({'passed':proof,'count':len(proof),'model':result['detail']['selection'],'elapsed':result['elapsed']},indent=2))
print(json.dumps({'checks':len(proof),'model':result['detail']['selection'],'elapsed':result['elapsed']}),flush=True)
