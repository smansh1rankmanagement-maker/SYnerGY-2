"""Exercise the live HTTPS app with a separate QA account; never log credentials."""
import base64, hashlib, io, json, os, secrets, time, urllib.request, urllib.error
from pathlib import Path
from PIL import Image, ImageChops, ImageStat
from pypdf import PdfReader

BASE='https://synergyai.1rank.in'
ROOT=Path('/var/lib/synergy')/'cloud-final-checks'
ROOT.mkdir(mode=0o700,exist_ok=True)
COOKIE=None
REPORT={'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'output_directory':str(ROOT),'checks':[]}

def save():
    (ROOT/'verification.json').write_text(json.dumps(REPORT,indent=2))
    (ROOT/'verification.json').chmod(0o600)

def record(name, passed, **details):
    row={'check':name,'passed':passed,**details};REPORT['checks'].append(row);save();print(json.dumps(row),flush=True)

def call(method,path,data=None,authenticated=True,timeout=25):
    headers={'Origin':BASE}
    if authenticated and COOKIE:headers['Cookie']=COOKIE
    if data is not None:
        data=json.dumps(data).encode();headers['Content-Type']='application/json'
    req=urllib.request.Request(BASE+path,data=data,headers=headers,method=method)
    try:r=urllib.request.urlopen(req,timeout=timeout)
    except urllib.error.HTTPError as e:r=e
    raw=r.read();ctype=r.headers.get('Content-Type','')
    return r.status,json.loads(raw) if ctype=='application/json' else raw,dict(r.headers)

def task(name,prompt,deadline=300,**extra):
    req={'prompt':prompt,'mode':'chat','effort':'instant','provider':'synergy','search_mode':'off',**extra}
    code,t,_=call('POST','/api/research/tasks',req)
    if code!=202:raise RuntimeError(name+' submission: '+str((code,t)))
    last=None;until=time.monotonic()+deadline
    while t['state'] in {'queued','running'}:
        stage=t['detail'].get('stage','queued')
        if stage!=last:print(json.dumps({'task':name,'id':t['id'],'stage':stage}),flush=True);last=stage
        if time.monotonic()>until:
            call('POST','/api/research/cancel',{'id':t['id']})
            raise TimeoutError(name+' exceeded verification time budget; cancellation requested')
        time.sleep(2)
        _,t,_=call('GET','/api/research/tasks/'+t['id'])
    (ROOT/(name+'-task.json')).write_text(json.dumps(t,indent=2))
    record(name,t['state']=='succeeded',task_id=t['id'],state=t['state'],elapsed=t.get('elapsed'),skill=t['request'].get('selected_skill'),error=t['detail'].get('error'),reply=t.get('reply','')[:700])
    if t['state']!='succeeded':raise RuntimeError(name+' failed: '+str(t['detail'].get('error')))
    for a in t['detail'].get('artifacts',[]):
        code,raw,_=call('GET',a['url']);p=ROOT/(name+'-'+a['name'])
        if code!=200 or not isinstance(raw,bytes):raise RuntimeError('Download failed: '+a['name'])
        p.write_bytes(raw);p.chmod(0o600)
        record(name+' download '+a['name'],len(raw)==a['bytes'] and hashlib.sha256(raw).hexdigest()==a['sha256'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),file=str(p))
        unauthorized=call('GET',a['url'],authenticated=False)[0]
        record(name+' anonymous access '+a['name'],unauthorized==401,status=unauthorized)
    code,chat,_=call('GET','/api/conversations/'+t['conversation_id'])
    record(name+' saved conversation',code==200 and any(m.get('metadata',{}).get('task_id')==t['id'] for m in chat['messages']))
    return t

try:
    name='finalqa_'+time.strftime('%m%d_%H%M%S');password=secrets.token_urlsafe(28)
    code,_,headers=call('POST','/api/auth/register',{'username':name,'password':password,'invite_code':os.environ['SYNERGY_INVITE_CODE']},authenticated=False)
    assert code==200,code
    COOKIE=headers['Set-Cookie'].split(';')[0]
    record('registration after restart',True)
    _,caps,_=call('GET','/api/capabilities')
    record('deployed cloud location label',caps['image']['detail']=='Local image engine connected. Runs on this server; no credits.')
    first=task('memory_setup','For this conversation, our test project code is ORANGE-731. Reply only: recorded.',deadline=120,local_model='balanced')
    second=task('memory_recall','What project code did I give you? Reply only with the code.',deadline=120,local_model='balanced',conversation_id=first['conversation_id'])
    record('follow-up code recalled',second['reply'].strip().rstrip('.')=='ORANGE-731',answer=second['reply'])
    code,job,_=call('POST','/api/research/tasks',{'prompt':'Create an image of a simple wooden chair. 512 x 512.','mode':'chat','effort':'instant','provider':'synergy','search_mode':'off'})
    assert code==202
    call('POST','/api/research/cancel',{'id':job['id']})
    for _ in range(40):
        _,job,_=call('GET','/api/research/tasks/'+job['id'])
        if job['state'] not in ['queued','running']:break
        time.sleep(.5)
    record('real creation job cancellation',job['state']=='cancelled' and not job['detail'].get('artifacts'),state=job['state'],task_id=job['id'])
    code,_,_=call('POST','/api/auth/logout',{})
    record('logout after restart',code==200 and call('GET','/api/me')[0]==401)
    COOKIE=None
    code,_,headers=call('POST','/api/auth/login',{'username':name,'password':password},authenticated=False)
    assert code==200
    COOKIE=headers['Set-Cookie'].split(';')[0];password=None
    record('login and saved history after logout',call('GET','/api/conversations/'+first['conversation_id'])[0]==200)
except Exception as exc:
    record('final check completion',False,error=type(exc).__name__+': '+str(exc))
finally:
    if COOKIE:
        try:call('POST','/api/auth/logout',{})
        except Exception:pass
    REPORT['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save()
    print(json.dumps({'finished':True,'failed_checks':[x['check'] for x in REPORT['checks'] if not x['passed']]}),flush=True)
