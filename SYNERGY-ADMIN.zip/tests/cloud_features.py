"""Exercise the live HTTPS app with a separate QA account; never log credentials."""
import base64, hashlib, io, json, os, secrets, time, urllib.request, urllib.error
from pathlib import Path
from PIL import Image, ImageChops, ImageStat
from pypdf import PdfReader

BASE='https://synergyai.1rank.in'
ROOT=Path('/var/lib/synergy')/'cloud-features-rerun'
ROOT.mkdir(mode=0o700,exist_ok=True)
COOKIE=None
REPORT={'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'output_directory':str(ROOT),'checks':[]}

def save():
    (ROOT/'verification.json').write_text(json.dumps(REPORT,indent=2))
    (ROOT/'verification.json').chmod(0o600)

def record(name, passed, **details):
    row={'check':name,'passed':passed,**details};REPORT['checks'].append(row);save();print(json.dumps(row),flush=True)

def call(method,path,data=None,authenticated=True,timeout=25):
    headers={'Origin':BASE}
    if authenticated and COOKIE:headers['Cookie']=COOKIE
    if data is not None:
        data=json.dumps(data).encode();headers['Content-Type']='application/json'
    req=urllib.request.Request(BASE+path,data=data,headers=headers,method=method)
    try:r=urllib.request.urlopen(req,timeout=timeout)
    except urllib.error.HTTPError as e:r=e
    raw=r.read();ctype=r.headers.get('Content-Type','')
    return r.status,json.loads(raw) if ctype=='application/json' else raw,dict(r.headers)

def task(name,prompt,deadline=300,**extra):
    req={'prompt':prompt,'mode':'chat','effort':'instant','provider':'synergy','search_mode':'off',**extra}
    code,t,_=call('POST','/api/research/tasks',req)
    if code!=202:raise RuntimeError(name+' submission: '+str((code,t)))
    last=None;until=time.monotonic()+deadline
    while t['state'] in {'queued','running'}:
        stage=t['detail'].get('stage','queued')
        if stage!=last:print(json.dumps({'task':name,'id':t['id'],'stage':stage}),flush=True);last=stage
        if time.monotonic()>until:
            call('POST','/api/research/cancel',{'id':t['id']})
            raise TimeoutError(name+' exceeded verification time budget; cancellation requested')
        time.sleep(2)
        _,t,_=call('GET','/api/research/tasks/'+t['id'])
    (ROOT/(name+'-task.json')).write_text(json.dumps(t,indent=2))
    record(name,t['state']=='succeeded',task_id=t['id'],state=t['state'],elapsed=t.get('elapsed'),skill=t['request'].get('selected_skill'),error=t['detail'].get('error'),reply=t.get('reply','')[:700])
    if t['state']!='succeeded':raise RuntimeError(name+' failed: '+str(t['detail'].get('error')))
    for a in t['detail'].get('artifacts',[]):
        code,raw,_=call('GET',a['url']);p=ROOT/(name+'-'+a['name'])
        if code!=200 or not isinstance(raw,bytes):raise RuntimeError('Download failed: '+a['name'])
        p.write_bytes(raw);p.chmod(0o600)
        record(name+' download '+a['name'],len(raw)==a['bytes'] and hashlib.sha256(raw).hexdigest()==a['sha256'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),file=str(p))
        unauthorized=call('GET',a['url'],authenticated=False)[0]
        record(name+' anonymous access '+a['name'],unauthorized==401,status=unauthorized)
    code,chat,_=call('GET','/api/conversations/'+t['conversation_id'])
    record(name+' saved conversation',code==200 and any(m.get('metadata',{}).get('task_id')==t['id'] for m in chat['messages']))
    return t

try:
    import copy, zipfile
    from openpyxl import load_workbook
    name='opsqa_'+time.strftime('%m%d_%H%M%S')
    code,_,headers=call('POST','/api/auth/register',{'username':name,'password':secrets.token_urlsafe(28),'invite_code':os.environ['SYNERGY_INVITE_CODE']},authenticated=False)
    assert code==200, code
    COOKIE=headers['Set-Cookie'].split(';')[0]
    code,brand,_=call('POST','/api/operations/brands',{'name':'InteriFY QA','config':{'brief':'Interior design for homes and offices.','services':'Interior design','audience':'Founders and premium homeowners in Delhi NCR','website':''}})
    record('brand saved pending approval',code==201 and brand['approved_revision']==0 and not brand['config']['website'],brand_id=brand['id'])
    _,chat,_=call('POST','/api/conversations',{})
    code,d,_=call('POST','/api/operations/chat',{'conversation_id':chat['id'],'prompt':'Create a draft weekly automation for InteriFY QA every Monday at 9:00 AM Asia/Kolkata'})
    weekly=d['workflow'];schedule=weekly['definition']['schedule']
    record('weekly draft schedule',code==201 and weekly['state']=='draft' and schedule['weekday']==0 and schedule['time']=='09:00' and schedule['timezone']=='Asia/Kolkata',workflow_id=weekly['id'],schedule=schedule)
    _,workflow,_=call('POST','/api/operations/workflows',{'brand_id':brand['id'],'schedule':{'kind':'manual','timezone':'Asia/Kolkata'}})
    assert workflow['definition']['external_actions'] is False
    assert [x['id'] for x in workflow['definition']['steps']]==['inputs','seo','tasks','calendar','xlsx','pdf','review','notify']
    record('manual definition reviewed',True,definition=workflow['definition'])
    code,_,_=call('POST','/api/operations/run',{'workflow_id':workflow['id']})
    record('activation required',code==400,status=code)
    code,_,_=call('POST','/api/operations/workflows/action',{'id':workflow['id'],'action':'activate','reviewed_hash':workflow['hash']});assert code==200
    _,run,_=call('POST','/api/operations/run',{'workflow_id':workflow['id'],'idempotency_key':'cloud-qa-manual'})
    _,dup,_=call('POST','/api/operations/run',{'workflow_id':workflow['id'],'idempotency_key':'cloud-qa-manual'})
    record('duplicate run prevented',run['id']==dup['id'],run_id=run['id'])
    def wait_run(run):
        deadline=time.monotonic()+220
        while run['state'] in ['queued','running']:
            assert time.monotonic()<deadline,'Operations time budget exceeded'
            time.sleep(2);_,run,_=call('GET','/api/operations/runs/'+run['id'])
        return run
    run=wait_run(run)
    (ROOT/'operations-run.json').write_text(json.dumps(run,indent=2))
    record('backend worker completes with explicit blockers',run['state']=='completed_with_blockers',run_id=run['id'],state=run['state'])
    kinds=[]
    for art in run['artifacts']:
        code,raw,_=call('GET','/api/operations/artifacts/'+art['id']);assert code==200
        (ROOT/art['name']).write_bytes(raw);kinds.append(art['kind'])
        record('operations download '+art['kind'],len(raw)==art['size'] and hashlib.sha256(raw).hexdigest()==art['sha256'],filename=art['name'],sha256=art['sha256'])
        if art['kind']=='xlsx':
            book=load_workbook(io.BytesIO(raw));formulas=[c.value for ws in book for row in ws for c in row if c.data_type=='f']
            record('workbook formulas retained',bool(formulas) and len(book.sheetnames)==3,sheets=book.sheetnames,formulas=formulas)
        if art['kind']=='pdf':record('PDF readable',len(PdfReader(io.BytesIO(raw)).pages)>0)
    record('spreadsheet and PDF saved',{'xlsx','pdf'}<=set(kinds))
    calendar=next(s['result'] for s in run['steps'] if s['key']=='calendar')
    record('seven content drafts',len(calendar['posts'])==7,method=calendar['method'],warnings=calendar['warnings'])
    posts=copy.deepcopy(calendar['posts']);posts[2].update(topic='Office design',format='Carousel')
    code,revised,_=call('POST','/api/operations/revise',{'id':run['id'],'posts':posts});assert code==202
    revised=wait_run(revised)
    newcalendar=next(s['result'] for s in revised['steps'] if s['key']=='calendar')
    record('targeted calendar revision',all(newcalendar['posts'][i]==calendar['posts'][i] for i in [0,1,3,4,5,6]) and newcalendar['posts'][2]['format']=='Carousel',old_run=run['id'],new_run=revised['id'])
    _,dashboard,_=call('GET','/api/operations/dashboard')
    approvals=[a for a in dashboard['approvals'] if a['run_id']==revised['id']]
    record('new output requires new approval',bool(approvals) and all(a['state']=='pending' for a in approvals))
    code,_,_=call('POST','/api/operations/external-action',{'brand_id':brand['id'],'kind':'publish'})
    record('unconnected publishing blocked',code==409,status=code)
    call('POST','/api/operations/workflows/action',{'id':workflow['id'],'action':'pause'})
    code,p,_=call('POST','/api/beast/projects',{'name':'InteriFY Website QA','template':'website'});assert code==201
    pid=p['id']
    code,html,h=call('GET','/api/beast/projects/'+pid+'/preview')
    record('Beast preview',code==200 and b'Make room' in html and "script-src 'none'" in h['Content-Security-Policy'],project_id=pid)
    code,raw,_=call('GET','/api/beast/projects/'+pid+'/export')
    (ROOT/'beast-source.zip').write_bytes(raw)
    record('Beast source export',code==200 and zipfile.is_zipfile(io.BytesIO(raw)),sha256=hashlib.sha256(raw).hexdigest())
    code,_,_=call('POST','/api/beast/edit',{'project_id':pid,'revision':1,'action':'write','path':'total.py','content':"def total(items): return sum(item['price'] for item in items)\n"});assert code==200
    code,checks,_=call('POST','/api/beast/checks',{'project_id':pid,'revision':2})
    record('Beast diagnostics return real result',code==200,result=checks)
except Exception as exc:
    record('feature run completion',False,error=type(exc).__name__+': '+str(exc))
finally:
    if COOKIE:
        try:call('POST','/api/auth/logout',{})
        except Exception:pass
    REPORT['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save()
    print(json.dumps({'finished':True,'report':str(ROOT/'verification.json'),'failed_checks':[x['check'] for x in REPORT['checks'] if not x['passed']]}),flush=True)
