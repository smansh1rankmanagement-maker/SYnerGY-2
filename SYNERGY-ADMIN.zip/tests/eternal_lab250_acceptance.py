"""Real private staging acceptance; refuses to run on production data."""
import json,os,sqlite3,sys,time,uuid,urllib.request,urllib.error
from pathlib import Path
ROOT=Path(os.environ['SYNERGY_DATA_DIR']);assert (ROOT/'.staging-only').is_file()
sys.path.insert(0,'/opt/synergy/app/backend')
from eternal_lab.templates import agent,tool,example,ref
BASE='http://127.0.0.1:8090';checks=[];evidence={}
def check(name,ok):
 if not ok:raise AssertionError(name)
 checks.append(name);print('PASS '+name,flush=True)
def api(path,data=None,cookie=None):
 h={'Cookie':cookie} if cookie else {};raw=None
 if data is not None:raw=json.dumps(data).encode();h['Content-Type']='application/json'
 try:
  with urllib.request.urlopen(urllib.request.Request(BASE+path,data=raw,headers=h),timeout=200) as r:return r.status,json.load(r) if r.headers.get_content_type()=='application/json' else r.read(),r.headers.get('Set-Cookie')
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read()),None
for _ in range(60):
 try:
  if api('/healthz')[0]==200:break
 except urllib.error.URLError:pass
 time.sleep(.5)
password=uuid.uuid4().hex+'Qa';suffix=uuid.uuid4().hex[:8]
s,user,cookie=api('/api/auth/register',{'email':'lab-'+suffix+'@qa.invalid','password':password});check('private staging registration',s==200)
_,other,othercookie=api('/api/auth/register',{'email':'lab-other-'+suffix+'@qa.invalid','password':password})
with sqlite3.connect(ROOT/'accounts.sqlite3') as c:c.execute("UPDATE users SET role='admin' WHERE id=?",(user['id'],))
api('/api/research/settings',{'onboarding_seen':True,'web_search':False},cookie)
def call(path,d=None):
 s,r,_=api('/api/admin/lab'+path,d,cookie)
 if s!=200:raise AssertionError((path,s,r))
 return r
def save(kind,spec):return call('/save',{'kind':kind,'spec':spec})
def run(kind,obj,inputs=None):
 r=call('/submit',{'kind':kind,'id':obj['id'],'version':obj['version'],'inputs':inputs or {},'request_id':uuid.uuid4().hex});deadline=time.monotonic()+180
 while time.monotonic()<deadline:
  r=call('/run?id='+r['id'])
  if r['state'] not in {'queued','running'}:return r
  time.sleep(.3)
 raise AssertionError('Lab job timed out')
def release(obj):return call('/action',{'id':obj['id'],'version':obj['version'],'action':'activate','expected_version':obj['latest'],'reviewed_hash':obj['hash'],'note':'Staging acceptance: checked trusted fixture and exact version.'})
check('ordinary user cannot inspect Lab',api('/api/admin/lab',cookie=othercookie)[0]==403)
check('ordinary user cannot propose global changes',api('/api/admin/lab/propose',{'prompt':'Create an agent'},othercookie)[0]==403)
check('all 34 packages visible without training claim',len(call('')['coverage'])==34 and not call('')['training_performed'])
server=call('/object?id=server-vedics')['object'];check('real VEDICS discovery',run('test',server)['state']=='succeeded');release(server)
foundr=call('/object?id=server-foundr')['object'];check('real FOUNDR discovery retained',run('test',foundr)['state']=='succeeded');release(foundr)
t=save('mcp_tool',tool());check('real arithmetic tool test',run('test',t)['state']=='succeeded');release(t)
ev=save('evaluation',example('evaluation'));release(ev)
spec=agent('Staging VEDICS parent');spec['tools']=[ref(t['id'])];spec['evaluation']=ref(ev['id']);a=save('agent',spec)
check('unreleased agent blocked',api('/api/admin/lab/submit',{'kind':'agent','id':a['id'],'inputs':{'prompt':'1/2 + 1/4'}},cookie)[0]==400)
r=run('evaluation',a);check('real deterministic evaluation passes',r['state']=='succeeded' and r['result']['score']==1);release(a)
p=call('/propose',{'prompt':'Create the supplied VEDICS agent','kind':'agent','configuration':spec,'family':'aerny'});b=call('/apply',{'id':p['id'],'reviewed_hash':p['hash']})[0];check('Beast and manual same validated record',a['spec']==b['spec']);check('conversational agent evaluation',run('evaluation',b)['state']=='succeeded');release(b)
childspec=json.loads(json.dumps(spec));childspec.update(name='Staging VEDICS child',parent=ref(a['id']));childspec['delegation']['depth']=0;child=save('subagent',childspec);check('subagent evaluates',run('evaluation',child)['state']=='succeeded');release(child)
r=run('agent',a,{'prompt':'What is 1/2 + 1/4?','delegate_id':child['id']});check('bounded actual delegation',r['state']=='succeeded' and json.loads(r['result']['text'])['answer']=='3/4')
speed=[]
for i in range(3):
 r=run('agent',a,{'prompt':'What is 1/2 + 1/4? Explain in one short sentence.'});check('tool-assisted speed fixture '+str(i),r['state']=='succeeded');speed.append({'seconds':r['result']['metrics']['seconds'],'tool_seconds':r['result']['metrics']['calls'][0]['seconds'],'queue_and_worker_seconds':r['finished']-r['created'],'answer':json.loads(r['result']['text'])['answer']})
evidence['tool_speed']=speed
restricted_spec=json.loads(json.dumps(spec));restricted_spec['name']='Tool-only reviewed scope';restricted_spec['allow_model_fallback']=False;restricted=save('agent',restricted_spec);check('tool-only agent evaluates',run('evaluation',restricted)['state']=='succeeded');release(restricted);check('out-of-scope teaching blocked',run('agent',restricted,{'prompt':'Explain what a denominator means.'})['state']=='blocked')
# A real local model fallback in the same agent. No OpenAI request is made.
r=run('agent',a,{'prompt':'Explain what a denominator means in one short sentence.'});check('actual ETERNAL local language fallback',r['state']=='succeeded' and bool(r['result']['text']));evidence['local_model_run']=r['result']
spec2=json.loads(json.dumps(spec));spec2['instructions']+=' Use one concise explanation.';a2=call('/save',{'id':a['id'],'expected_version':1,'kind':'agent','spec':spec2});check('source edit creates immutable draft v2',a2['version']==2 and a2['active']==1);check('v2 evaluates',run('evaluation',a2)['state']=='succeeded');release(a2)
rolled=call('/action',{'id':a['id'],'version':1,'expected_version':2,'reviewed_hash':a['hash'],'action':'rollback','note':'Staging rollback of a tested configuration.'});check('tested version rolls back',rolled['active']==1)
bad=tool('Unimplemented fixture');bad['handler']='draft';bad['tool_name']='unimplemented_fixture';draft=save('mcp_tool',bad);check('missing handler remains blocked',run('test',draft)['state']=='blocked')
check('secret values rejected',api('/api/admin/lab/propose',{'prompt':'Create with api_key=privatefixture012345'},cookie)[0]==400)
project=call('/server-project',{'name':'Staging editable MCP'});check('new server private source saved not executed',project['execution']=='not_started' and project['capability']['active'] is None)
dataset=save('dataset',example('dataset'));experiment=example('experiment');experiment['dataset']=ref(dataset['id']);experiment=save('experiment',experiment);r=run('training',experiment);check('training correctly blocked without false checkpoint',r['state']=='blocked' and not r['result']['weights_trained'])
for mode in ['chat','work','beast']:
 s,model,_=api('/api/models?mode='+mode,cookie=cookie);check(mode+' existing provider locks preserved',s==200 and model['provider_access']['openai']==(mode!='chat'))
# Real due schedule with no browser open. No simulated scheduler clock.
w=example('workflow');w.update(name='Browser-closed scheduled evaluation',trigger='daily',schedule='00:00',enabled_schedule=True,agents=[ref(a['id'])],steps=[{'action':'evaluate'}]);w=save('workflow',w);check('workflow executable configuration test',run('test',w)['state']=='succeeded');release(w);deadline=time.monotonic()+75;scheduled=None
while time.monotonic()<deadline:
 with sqlite3.connect(ROOT/'accounts.sqlite3') as db:record=db.execute("SELECT id FROM lab_runs WHERE object_id=? AND kind='workflow' ORDER BY created DESC LIMIT 1",(w['id'],)).fetchone()
 if record:
  scheduled=call('/run?id='+record[0])
  if scheduled['state'] not in {'queued','running'}:break
 time.sleep(1)
check('actual scheduled job completes with browser closed',scheduled is not None and scheduled['state']=='succeeded')
with sqlite3.connect(ROOT/'accounts.sqlite3') as db:receipts=db.execute('SELECT count(*) FROM lab_schedule_receipts WHERE object_id=?',(w['id'],)).fetchone()[0]
check('real scheduler records one daily trigger',receipts==1)
evidence['scheduled_run']={'id':scheduled['id'],'state':scheduled['state'],'timezone':'Asia/Kolkata','browser_open':False}
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--no-sandbox']);ctx=browser.new_context(viewport={'width':1440,'height':1000});page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));ctx.add_cookies([{'name':'synergy_session','value':cookie.split(';')[0].split('=',1)[1],'domain':'127.0.0.1','path':'/'}]);page.goto(BASE);page.locator('#app-view').wait_for(state='visible')
 for label in ['Not now']:
  if page.get_by_role('button',name=label,exact=True).is_visible():page.get_by_role('button',name=label,exact=True).click()
 if page.locator('#welcome-dismiss').is_visible():page.locator('#welcome-dismiss').click()
 page.locator('#open-settings').click();page.locator('[data-settings="admin"]').click();page.locator('[data-section="eternal-lab"]').click();section=page.locator('[data-admin-section="eternal-lab"]');section.get_by_label('Eternal Lab section').wait_for();check('browser displays 34 skill packages',section.get_by_text('34 skill packages',exact=True).is_visible());section.get_by_label('Eternal Lab section').select_option('agent');section.get_by_role('button',name='New Agent',exact=False).click();section.get_by_label('Name',exact=True).fill('Browser manual agent');section.get_by_role('button',name='Save draft',exact=True).click();page.get_by_role('dialog',name='Capability review').wait_for();check('browser manual form saves draft',page.get_by_role('dialog',name='Capability review').get_by_role('heading',name='Browser manual agent').is_visible());page.get_by_role('dialog',name='Capability review').get_by_role('button',name='Close',exact=True).click()
 section.get_by_label('Eternal Lab section').select_option('overview');section.get_by_label('Request',exact=True).fill('Add a filmmaking agent with storyboard and video-editing skills.');section.get_by_role('button',name='Prepare proposal',exact=True).click();section.get_by_role('button',name='Apply reviewed proposal',exact=True).wait_for();check('browser Beast proposal readable',section.get_by_text('Proposed changes',exact=True).is_visible());section.get_by_role('button',name='Apply reviewed proposal',exact=True).click();page.get_by_role('dialog',name='Capability review').wait_for();check('browser Beast creates saved draft',page.get_by_role('dialog',name='Capability review').get_by_role('heading',name='Filmmaking agent').is_visible());page.get_by_role('dialog',name='Capability review').get_by_role('button',name='Close',exact=True).click();page.screenshot(path='/tmp/synergy250-lab.png');page.set_viewport_size({'width':390,'height':844});check('mobile no document overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'));check('no JavaScript page errors',not errors);browser.close()
evidence.update(checks=len(checks),passed=checks,weights_trained=False,new_packages=34,external_requests=0)
Path('/tmp/eternal-lab250-acceptance.json').write_text(json.dumps(evidence,indent=2));print(json.dumps(evidence),flush=True)
