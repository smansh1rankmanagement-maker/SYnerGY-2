"""Actual response DOM with synthetic activity and quota events; no invented execution."""
import json,os,time
from pathlib import Path
from playwright.sync_api import sync_playwright
assert Path(os.environ['SYNERGY_DATA_DIR'],'.staging-only').exists()
checks=[]
def check(name,ok):
 assert ok,name
 checks.append(name);print('PASS '+name,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,args=['--no-sandbox']);p=b.new_page(viewport={'width':1440,'height':1040});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto('http://127.0.0.1:8090');p.evaluate("""() => {document.querySelector('#auth-view').classList.add('hidden');document.querySelector('#app-view').classList.remove('hidden');document.querySelector('#chat-welcome').classList.add('hidden');let a=document.createElement('article');a.className='message assistant';a.id='qa-response';a.innerHTML='<div class="author">ETERNAL</div><div class="message-copy">Your answer will appear here.</div>';document.querySelector('#messages').append(a);window.qaUpdate=t=>SynergyProgress.update(a,t)}""")
 fixture={'state':'running','elapsed':85,'stage':'Reading the selected sources.','events':[{'action':'Understanding the request'},{'action':'Searching public sources'},{'action':'Reading the selected sources.'}]}
 p.evaluate('qaUpdate',fixture)
 check('working duration visible',p.locator('.response-working').inner_text()=='Working for 1m 25s')
 check('real supplied activity visible',p.locator('.response-activity-row').count()==3)
 check('progress before answer',p.evaluate("document.querySelector('#qa-response').innerHTML.indexOf('response-progress')<document.querySelector('#qa-response').innerHTML.indexOf('message-copy')"))
 check('Hybrid selected by default',p.locator('#provider').input_value()=='hybrid')
 check('only three provider choices',p.locator('#provider option').evaluate_all('(els)=>els.map(e=>e.value)')==['synergy','openai','hybrid'])
 notice={'id':'fixture-1','message':'Free quota 1 reached. Continuing with quota 2.','created':time.time(),'expires':time.time()+20}
 fixture['notices']=[notice];p.evaluate('qaUpdate',fixture);check('quota subtitle displayed',p.locator('.quota-switch').is_visible())
 check('no model name in quota notice',p.locator('.quota-switch').inner_text()==notice['message'])
 p.screenshot(path='/tmp/response280-desktop.png');p.locator('.quota-switch').wait_for(state='hidden',timeout=6500)
 check('quota subtitle disappears',not p.locator('.quota-switch').is_visible());p.evaluate('qaUpdate',fixture);check('same event does not repeat',not p.locator('.quota-switch').is_visible())
 notice['id']='fixture-2';notice['message']='Free quota 2 reached. Continuing with quota 3.';fixture['notices']=[notice];p.evaluate('qaUpdate',fixture);check('new exhaustion produces new notice',p.locator('.quota-switch').inner_text()==notice['message'])
 fixture.update(state='succeeded',elapsed=92,notices=[]);p.evaluate('qaUpdate',fixture);check('completed activity collapses',not p.locator('.response-activity').evaluate('(e)=>e.open'))
 p.set_viewport_size({'width':390,'height':844});p.screenshot(path='/tmp/response280-mobile.png');check('mobile has no horizontal overflow',p.evaluate('document.documentElement.scrollWidth<=innerWidth'))
 fixture.update(events=[]);p.evaluate('qaUpdate',fixture);check('empty historical activity stays hidden',not p.locator('.response-activity').is_visible());check('completed stage stays hidden',not p.locator('.response-update').is_visible())
 check('no browser errors',not errors);b.close()
Path('/tmp/response280-ui-evidence.json').write_text(json.dumps({'checks':checks,'fixture_activity_only':True},indent=2))
