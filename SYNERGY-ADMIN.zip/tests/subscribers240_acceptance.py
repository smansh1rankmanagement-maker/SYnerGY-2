"""Real isolated HTTP, browser, local model, external review and voice checks."""
import io,json,os,sqlite3,sys,time,uuid,urllib.request,urllib.error,wave
from pathlib import Path
ROOT=Path(os.environ['SYNERGY_DATA_DIR']);assert (ROOT/'.staging-only').is_file()
sys.path.insert(0,'/opt/synergy/app/backend')
BASE='http://127.0.0.1:8090';checks=[];evidence={}
def check(name,ok):
 if not ok:raise AssertionError(name)
 checks.append(name);print('PASS '+name,flush=True)
def api(path,data=None,cookie=None,raw=None,ctype=None):
 headers={}
 if cookie:headers['Cookie']=cookie
 if data is not None:raw=json.dumps(data).encode();ctype='application/json'
 if ctype:headers['Content-Type']=ctype
 req=urllib.request.Request(BASE+path,data=raw,headers=headers)
 try:
  with urllib.request.urlopen(req,timeout=200) as r:
   body=r.read();return r.status,json.loads(body) if r.headers.get_content_type()=='application/json' else body,r.headers.get('Set-Cookie')
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read()),None
for attempt in range(60):
 try:
  if api('/healthz')[0]==200:break
 except urllib.error.URLError:pass
 time.sleep(.5)
suffix=uuid.uuid4().hex[:8];password=uuid.uuid4().hex+'Qa!'
s,user,cookie=api('/api/auth/register',{'email':'subscribers-'+suffix+'@qa.invalid','password':password});check('isolated registration',s==200)
_,member,membercookie=api('/api/auth/register',{'email':'member-'+suffix+'@qa.invalid','password':password})
with sqlite3.connect(ROOT/'accounts.sqlite3') as c:c.execute("UPDATE users SET role='admin',full_name='Subscriber QA' WHERE id=?",(user['id'],))
api('/api/research/settings',{'allow_external':True,'onboarding_seen':True,'web_search':False},cookie)
import openai_budget
initial=openai_budget.status();evidence['initial_spending']=initial['accounted_usd']
def cap(percent):
 old=openai_budget.status()
 s,b,_=api('/api/admin/openai-limit',{'total_budget_usd':2,'usage_percent':percent,'revision':old['revision'],'note':'Isolated acceptance test of requested allowance'},cookie)
 check('admin budget accepts '+str(percent)+' percent',s==200);return b
check('ten percent is twenty cents',cap(10)['allowance_usd']==.2)
check('member cannot edit shared budget',api('/api/admin/openai-limit',{},membercookie)[0]==403)
for mode in ['chat','work','beast']:
 s,cat,_=api('/api/models?mode='+mode,cookie=cookie)
 check(mode+' provider catalog permission',s==200 and cat['provider_access']['openai']==(mode!='chat') and cat['provider_access']['hybrid']==(mode!='chat'))
for actor in [cookie,membercookie]:
 for provider in ['openai','hybrid']:
  for path in ['/api/research/tasks','/api/chat','/api/extension/ask']:
   s,_,_=api(path,{'prompt':'Explain video creation options','mode':'chat','provider':provider},actor)
   check(path+' Chat '+provider+' denied '+('admin' if actor==cookie else 'member'),s==402)
def task(prompt,provider='hybrid',mode='work'):
 s,j,_=api('/api/research/tasks',{'prompt':prompt,'provider':provider,'mode':mode,'model_family':'eternal','local_model':'fast','effort':'instant','search_mode':'off','request_id':uuid.uuid4().hex},cookie)
 check(mode+' '+provider+' request accepted',s==202)
 deadline=time.monotonic()+600
 while time.monotonic()<deadline:
  _,j,_=api('/api/research/tasks/'+j['id'],cookie=cookie)
  if j['state'] not in ['queued','running']:return j
  time.sleep(1)
 raise AssertionError('Task timed out')
j=task('Explain in one sentence why a quoted price is not proof that a customer has paid.')
evidence['real_hybrid']={'state':j['state'],'selection':j['detail'].get('selection'),'metrics':j['detail'].get('metrics')}
reviewed=j['detail'].get('selection',{}).get('review_status')=='reviewed'
if reviewed:check('real local draft and OpenAI review complete',j['state']=='succeeded')
else:check('real OpenAI quota blocker recorded and local draft survives',j['state']=='succeeded' and j['detail']['selection'].get('review_status')=='local_fallback' and openai_budget.status()['provider_status']['state']=='quota_exhausted')
evidence['openai_review_completed']=reviewed
check('actual local and attempted review models recorded',j['detail']['selection']['model'].startswith('eternal') and j['detail']['selection']['review_model']=='gpt-6.1-sol')
saved=task('Remember: use short replies and bullet points. What is a project?','synergy','beast')
check('real local Beast reply completes',saved['state']=='succeeded')
prefs=api('/api/research/preferences',cookie=cookie)[1]
check('explicit private preferences saved without training',prefs['preferences']=={'length':'concise','format':'bullets'} and prefs['training_performed'] is False)
check('preferences are account isolated',not api('/api/research/preferences',cookie=membercookie)[1]['preferences'])
cap(0)
fallback=task('Explain what a content calendar is in one short sentence.')
check('exhausted external allowance keeps completed local draft',fallback['state']=='succeeded' and fallback['detail']['selection']['review_status']=='local_fallback' and bool(fallback['reply']))
direct=task('Say hello in two words.','openai')
check('direct OpenAI blocked at zero budget',direct['state']=='failed')
local=task('Say hello in two words.','synergy','chat')
check('local Chat remains usable at zero external budget',local['state']=='succeeded')
cap(10)
check('budget edits retain cumulative spending',openai_budget.status()['accounted_usd']>=initial['accounted_usd'] and openai_budget.status()['reserved_usd']>=initial['reserved_usd'])
_,voice,_=api('/api/voice/status',cookie=cookie);evidence['voice']=voice
check('actual OpenJarvis speech workers ready',voice['ready'] and voice['profile']['default'] and not voice['profile']['personal_clone_trained'])
from workspace import Workspace
w=Workspace(ROOT/'accounts.sqlite3')
for mode in ['chat','work','beast']:
 chat=w.create_chat(user['id'],'Voice fixture '+mode,mode=mode)
 with w.connect() as c:c.execute('INSERT INTO messages(id,conversation_id,role,content,metadata,created) VALUES(?,?,?,?,?,?)',(uuid.uuid4().hex,chat['id'],'assistant','Welcome to Synergy. Your project is ready.','{}',time.time()))
 s,wav,_=api('/api/voice/speak',{'conversation_id':chat['id']},cookie)
 check(mode+' voice returns real audio',s==200 and wav[:4]==b'RIFF')
 with wave.open(io.BytesIO(wav)) as sound:check(mode+' voice has audible duration',sound.getnframes()/sound.getframerate()>1)
 if mode=='chat':
  boundary='synergy-'+uuid.uuid4().hex
  body=('--'+boundary+'\r\nContent-Disposition: form-data; name="language"\r\n\r\nen\r\n--'+boundary+'\r\nContent-Disposition: form-data; name="file"; filename="voice.wav"\r\nContent-Type: audio/wav\r\n\r\n').encode()+wav+('\r\n--'+boundary+'--\r\n').encode()
  s,transcript,_=api('/api/voice/transcribe',cookie=cookie,raw=body,ctype='multipart/form-data; boundary='+boundary)
  evidence['transcription']=transcript;check('real speech transcription round trip',s==200 and 'project' in transcript.get('text','').lower())
from playwright.sync_api import sync_playwright,expect
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--no-sandbox']);ctx=browser.new_context(viewport={'width':1440,'height':1000});page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 ctx.add_cookies([{'name':'synergy_session','value':cookie.split(';')[0].split('=',1)[1],'domain':'127.0.0.1','path':'/'}]);page.goto(BASE);page.locator('#app-view').wait_for(state='visible')
 for label in ['Not now']:
  if page.get_by_role('button',name=label,exact=True).is_visible():page.get_by_role('button',name=label,exact=True).click()
 if page.locator('#welcome-dismiss').is_visible():page.locator('#welcome-dismiss').click()
 for mode in ['chat','work','beast']:
  page.locator('[data-mode="'+mode+'"]').click()
  page.wait_for_function("(mode)=>document.querySelector('#provider option[value=openai]').disabled === (mode==='chat')",arg=mode)
  check(mode+' browser provider lock matches policy',True)
  check(mode+' microphone visible',page.locator('#voice-button').is_visible())
 page.locator('#open-settings').click();page.locator('[data-settings="admin"]').click();page.locator('[data-section="overview"]').click()
 page.get_by_role('button',name='Set OpenAI usage limit',exact=True).click()
 check('administrator can open usage controls',page.get_by_label('Total API budget (USD)',exact=False).is_visible())
 page.get_by_label('Percentage available to SYnerGY',exact=False).fill('12.5');page.get_by_label('Reason for change',exact=True).fill('Trusted browser acceptance of administrator budget controls');page.get_by_role('button',name='Save change',exact=True).click();page.locator('#admin-action-dialog').wait_for(state='hidden');check('browser saves administrator percentage',openai_budget.status()['allowance_usd']==.25);cap(10);page.screenshot(path='/tmp/synergy240-admin.png')
 page.locator('#close-settings').click();page.set_viewport_size({'width':390,'height':844});check('mobile has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'));check('no browser JavaScript errors',not errors);browser.close()
evidence.update(checks=len(checks),passed=checks,spending=openai_budget.status(),physical_microphone_tested=False,training_performed=False)
Path('/tmp/subscribers240-acceptance.json').write_text(json.dumps(evidence,indent=2));print(json.dumps({'checks':len(checks),'spending':evidence['spending']}),flush=True)
