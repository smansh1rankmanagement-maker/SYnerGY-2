"""Real browser uploads, processing, download and version recovery; disposable staging only."""
import hashlib,io,json,os,secrets,sqlite3,subprocess,time,urllib.request,uuid
from pathlib import Path
from PIL import Image,ImageDraw
from playwright.sync_api import sync_playwright
DATA=Path(os.environ['SYNERGY_DATA_DIR']);assert (DATA/'.staging-only').exists()
OUT=DATA/'ui-evidence';OUT.mkdir(exist_ok=True);BASE='http://127.0.0.1:8090';checks=[];limitations=[]
def check(name,value):
 assert value,name
 checks.append(name);print('PASS '+name,flush=True)
def request(path,payload=None,cookie=None):
 headers={'Origin':BASE}
 if cookie:headers['Cookie']=cookie
 if payload is not None:headers['Content-Type']='application/json'
 req=urllib.request.Request(BASE+path,data=json.dumps(payload).encode() if payload is not None else None,headers=headers)
 with urllib.request.urlopen(req,timeout=30) as r:return json.load(r),r.headers
email='media-browser-'+uuid.uuid4().hex[:8]+'@qa.invalid';password=secrets.token_urlsafe(24)
_,headers=request('/api/auth/register',{'email':email,'password':password});cookie=headers['Set-Cookie'].split(';')[0]
request('/api/research/settings',{'onboarding_seen':True,'allow_external':False,'eternal_reminders':False},cookie)
fixture=OUT/'reference.png';im=Image.new('RGB',(400,300),'#d3c5af');ImageDraw.Draw(im).rectangle((70,60,330,250),fill='#456253');im.save(fixture);original=hashlib.sha256(fixture.read_bytes()).hexdigest()
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,args=['--no-sandbox']);p=browser.new_page(viewport={'width':1440,'height':1050});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto(BASE);p.locator('#username').fill(email);p.locator('#password').fill(password);p.locator('#auth-submit').click();p.locator('#app-view').wait_for(state='visible');p.locator('#plus-button').wait_for(state='visible');
 if p.get_by_role('button',name='Not now',exact=True).is_visible():p.get_by_role('button',name='Not now',exact=True).click()
 check('real email/password login',not p.locator('#auth-view').is_visible());p.locator('#plus-button').click();p.locator('#open-media-tools').click();d=p.locator('dialog.media-dialog');d.wait_for();check('worker readiness visible','Media worker ready' in d.inner_text())
 d.get_by_label('Upload media').set_input_files(str(fixture));d.get_by_label('Width',exact=True).fill('640');d.get_by_label('Height',exact=True).fill('480');d.get_by_role('button',name='Run edit',exact=True).click();d.get_by_role('link',name='Download output.png',exact=True).wait_for(timeout=60000)
 check('actual image preview dimensions',d.locator('.media-output img').evaluate('(i)=>i.complete && i.naturalWidth===640 && i.naturalHeight===480'))
 with p.expect_download() as down:d.get_by_role('link',name='Download output.png',exact=True).click()
 download=down.value;download.save_as(str(OUT/'download.png'))
 with Image.open(OUT/'download.png') as im:check('downloaded PNG decodes at requested size',im.size==(640,480))
 check('source fixture preserved',hashlib.sha256(fixture.read_bytes()).hexdigest()==original)
 check('right preview populated',p.locator('#research-output img').get_attribute('src').startswith('/api/media-tools/assets/'))
 d.get_by_role('button',name='Versions & follow-up edits',exact=True).click();d=p.locator('dialog.media-dialog');d.get_by_role('button',name='Open this conversation',exact=True).wait_for();check('original and output versions listed',d.locator('.media-version').count()==2)
 d.get_by_label('Media operation').select_option('text');d.get_by_label('Exact text',exact=True).fill('InteriFY Office');d.get_by_role('button',name='Run edit',exact=True).click();d.get_by_role('button',name='Versions & follow-up edits',exact=True).wait_for(timeout=60000);check('follow-up source edit completes','Version 3' in d.inner_text())
 d.get_by_role('button',name='Versions & follow-up edits',exact=True).click();d=p.locator('dialog.media-dialog');d.get_by_role('button',name='Open this conversation',exact=True).wait_for();check('prior versions retained after edit',d.locator('.media-version').count()==3)
 d.get_by_label('Media operation').select_option('inpaint');d.get_by_role('button',name='Paint a mask',exact=True).click();paint=p.locator('dialog.media-dialog').last;canvas=paint.locator('canvas');canvas.wait_for();box=canvas.bounding_box();p.mouse.move(box['x']+box['width']*.3,box['y']+box['height']*.4);p.mouse.down();p.mouse.move(box['x']+box['width']*.6,box['y']+box['height']*.6,steps=8);p.mouse.up();paint.get_by_role('button',name='Use mask',exact=True).click();p.wait_for_function("() => document.querySelectorAll('dialog.media-dialog').length===1");check('mask painter closes after attaching',True)
 d=p.locator('dialog.media-dialog');d.get_by_label('Media operation').select_option('resize');p.screenshot(path=str(OUT/'media-desktop.png'));p.set_viewport_size({'width':390,'height':844});p.screenshot(path=str(OUT/'media-mobile.png'));check('mobile dialog fits viewport',d.bounding_box()['width']<=390);check('mobile media form has no horizontal overflow',d.evaluate('(d)=>d.scrollWidth<=d.clientWidth+1'));p.set_viewport_size({'width':1440,'height':1050})
 d.get_by_role('button',name='Open this conversation',exact=True).click();p.locator('#model-family').select_option('aerny');p.locator('#attachment').set_input_files(str(fixture));p.locator('#chat-input').fill('Resize this image to 320 x 240');p.locator('#send-button').click();p.locator('#messages .assistant .message-copy').filter(has_text='Your edited image is ready').wait_for(timeout=60000);check('Aerny natural-language upload edit',p.locator('#research-output img').count()>0)
 p.locator('#chat-input').fill('Make it brighter');p.locator('#send-button').click();p.wait_for_function("() => [...document.querySelectorAll('#messages .assistant .message-copy')].filter(e=>e.textContent.includes('Your edited image is ready')).length>=2",timeout=60000);check('conversational follow-up uses saved source',True)
 p.reload();p.locator('#messages .assistant .message-copy').filter(has_text='Your edited image is ready').last.wait_for(state='visible');p.locator('#plus-button').click();p.locator('#open-media-tools').click();d=p.locator('dialog.media-dialog');d.wait_for();check('saved projects survive browser reload',d.locator('.media-versions>button').count()>=1);d.get_by_role('button',name='Close',exact=True).click()
 p.locator('#open-settings').click();p.get_by_role('button',name='MCP Tools',exact=True).click();p.get_by_role('button',name='Open Media tools',exact=True).wait_for();check('MCP entry visible in settings',True)
 p.get_by_role('button',name='Open Media tools',exact=True).click();p.locator('dialog.media-dialog').wait_for();check('MCP settings opens actual editor',True)
 d=p.locator('dialog.media-dialog');video=OUT/'clip.mp4';subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=320x180:rate=24:duration=6','-c:v','libx264','-threads','1',str(video)],check=True,timeout=20);d.get_by_label('Media operation').select_option('trim');d.get_by_label('Upload media').set_input_files(str(video));d.get_by_label('Start · seconds').fill('1');d.get_by_label('End · seconds').fill('4');d.get_by_role('button',name='Run edit',exact=True).click();d.get_by_role('link',name='Download output.mp4',exact=True).wait_for(timeout=60000);cap=d.locator('video').evaluate("(v)=>v.canPlayType('video/mp4; codecs=\"avc1.42E01E, mp4a.40.2\"')")
 if cap:
  try:p.wait_for_function("() => document.querySelector('.media-output video')?.readyState>=1",timeout=10000)
  except Exception:
   print(json.dumps({'video_debug':d.locator('video').evaluate('(v)=>({src:v.currentSrc,ready:v.readyState,error:v.error?.message,code:v.error?.code})')}),flush=True);raise
  check('video preview decodes trimmed duration',abs(d.locator('video').evaluate('(v)=>v.duration')-3)<.15)
 else:limitations.append('Bundled Chromium cannot decode H264/AAC; actual Chrome playback must be checked after deployment.');check('video preview points to authenticated MP4',d.locator('video').get_attribute('src').startswith('/api/media-tools/assets/'))
 with p.expect_download() as down:d.get_by_role('link',name='Download output.mp4',exact=True).click()
 down.value.save_as(str(OUT/'download.mp4'));probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-of','json',str(OUT/'download.mp4')],timeout=10));check('browser MP4 download verified',abs(float(probe['format']['duration'])-3)<.15)
 d.get_by_label('Media operation').select_option('generate');d.get_by_label('Upload media').set_input_files([]);d.get_by_role('button',name='Run edit',exact=True).click();d.get_by_role('link',name='Download output.png',exact=True).wait_for(timeout=300000);p.wait_for_function("() => document.querySelector('.media-output img')?.naturalWidth===512");check('default 512px Diffusers browser generation succeeds',d.locator('.media-output img').evaluate('(i)=>i.naturalWidth===512 && i.naturalHeight===512'));p.screenshot(path=str(OUT/'media-ai-desktop.png'))
 check('no browser JavaScript errors',not errors);browser.close()
(OUT/'evidence.json').write_text(json.dumps({'checks':checks,'real_browser':True,'actual_media_processing':True,'browser':'bundled Chromium','limitations':limitations},indent=2));print(json.dumps({'complete':True,'checks':len(checks)}),flush=True)
