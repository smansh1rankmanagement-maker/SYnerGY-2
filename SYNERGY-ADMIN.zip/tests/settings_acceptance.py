"""Real browser/API checks against isolated data. Never use production accounts."""
import io,json,os,sqlite3,time,uuid,urllib.request,urllib.error,zipfile
from pathlib import Path
ROOT=Path(os.environ['SYNERGY_DATA_DIR']);assert (ROOT/'.staging-only').is_file()
BASE='http://127.0.0.1:8090';checks=[]
def check(name,ok):
 if not ok:raise AssertionError(name)
 checks.append(name);print('PASS '+name,flush=True)
def api(path,data=None,cookie=None):
 headers={}
 if data is not None:headers['Content-Type']='application/json'
 if cookie:headers['Cookie']=cookie
 request=urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
 try:
  with urllib.request.urlopen(request,timeout=30) as r:
   raw=r.read();return r.status,json.loads(raw) if r.headers.get_content_type()=='application/json' else raw,r.headers.get('Set-Cookie')
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read()),None
for attempt in range(60):
 try:
  if api('/healthz')[0]==200:break
 except urllib.error.URLError:pass
 time.sleep(.5)
suffix=uuid.uuid4().hex[:8];email='settings-'+suffix+'@qa.invalid';password=uuid.uuid4().hex+'Qa!'
s,user,cookie=api('/api/auth/register',{'email':email,'password':password});check('isolated registration',s==200)
memberemail='member-'+suffix+'@qa.invalid';_,member,membercookie=api('/api/auth/register',{'email':memberemail,'password':password})
with sqlite3.connect(ROOT/'accounts.sqlite3') as c:c.execute("UPDATE users SET role='admin',full_name='Workspace QA' WHERE id=?",(user['id'],))
api('/api/research/settings',{'onboarding_seen':True},cookie)
check('private provider gate returns 402',api('/api/research/tasks',{'prompt':'Hello','provider':'hybrid'},membercookie)[0]==402)
s,project,_=api('/api/projects',{'name':'Composer QA','kind':'general','instructions':'Preserve facts.'},cookie);check('project saved',s in [200,201])
from playwright.sync_api import sync_playwright,expect
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--no-sandbox']);ctx=browser.new_context(viewport={'width':1440,'height':1000});page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE);page.locator('#auth-view').wait_for(state='visible');check('small Early access login subtitle',page.locator('.auth-early').inner_text()=='Early access')
 ctx.add_cookies([{'name':'synergy_session','value':cookie.split(';')[0].split('=',1)[1],'domain':'127.0.0.1','path':'/'}]);page.goto(BASE);page.locator('#app-view').wait_for(state='visible');page.locator('#account-name').get_by_text('Workspace QA',exact=True).wait_for(timeout=30000)
 if page.get_by_role('button',name='Not now',exact=True).is_visible():page.get_by_role('button',name='Not now',exact=True).click()
 if page.locator('#welcome-dismiss').is_visible():page.locator('#welcome-dismiss').click()
 check('Chat has no Free badge',page.locator('[data-mode="chat"]').inner_text()=='Chat')
 check('Chat hides paid workflow shortcuts',not page.locator('#open-beast').is_visible() and not page.locator('[data-page="operations"]').is_visible() and not page.locator('[data-page="leads"]').is_visible())
 page.locator('[data-mode="work"]').click();check('Work shows operations and leads only',page.locator('[data-page="operations"]').is_visible() and page.locator('[data-page="leads"]').is_visible() and not page.locator('#open-beast').is_visible())
 page.locator('[data-mode="beast"]').click();check('Beast shortcut is visible in Beast',page.locator('#open-beast').is_visible());page.locator('[data-mode="chat"]').click()
 page.locator('#composer-project').click();page.locator('.context-dialog').get_by_role('button',name='Composer QA').click();expect(page.locator('#composer-project')).to_contain_text('Composer QA');check('composer selects saved project',True)
 page.locator('#composer-files').click();expect(page.get_by_role('heading',name='Connect files')).to_be_visible();check('files chooser has uploads and project references',page.get_by_role('button',name='Project reference files').is_visible());page.get_by_role('button',name='Close',exact=True).click()
 page.locator('#composer-plugins').click();expect(page.locator('#plugins-page')).to_be_visible();check('plugins expose named MCP tools',page.get_by_role('heading',name='vedics MCP',exact=True).is_visible() and page.get_by_role('heading',name='Founder MCP',exact=True).is_visible())
 page.locator('#open-settings').click();expect(page.locator('[data-settings-panel="profile"]')).to_contain_text(email);check('profile shows real email and plan', 'Administrator' in page.locator('[data-settings-panel="profile"]').inner_text())
 page.locator('[data-settings="mcp"]').click();page.locator('[data-settings-panel="mcp"]').get_by_role('heading',name='vedics MCP').wait_for();check('Settings MCP catalogue loads',True)
 page.locator('[data-settings="extension"]').click();page.locator('#extension-version').get_by_text('Version 1.3.0',exact=False).wait_for();expect(page.locator('#extension-health')).to_contain_text('not detected',timeout=15000);check('extension diagnostics show installation status',True)
 page.locator('#extension-show-setup').click();expect(page.locator('#extension-dialog')).to_be_visible();check('extension install popup exists','Load unpacked' in page.locator('#extension-dialog').inner_text());page.locator('#close-extension-dialog').click()
 with page.expect_download() as event:page.locator('#extension-download').click()
 download=event.value;download.save_as('/tmp/SYnerGY-Chrome-Extension.zip')
 with zipfile.ZipFile('/tmp/SYnerGY-Chrome-Extension.zip') as z:
  check('download is real extension 1.3 ZIP',json.loads(z.read('manifest.json'))['version']=='1.3.0' and b'value="work" selected' in z.read('panel.html') and b'value="low"' in z.read('panel.html'))
 page.locator('[data-settings="admin"]').click();page.locator('[data-section="subscriptions"]').click();page.get_by_role('button',name='Create exceptional profile',exact=True).click()
 page.get_by_label('Recipient email',exact=True).fill(memberemail);page.get_by_label('Subscription',exact=True).select_option('work-30');page.get_by_label('Recipient verification',exact=True).select_option('yes');page.get_by_label('Reason for complimentary access',exact=True).fill('QA grant authorised in isolated data');page.get_by_role('button',name='Save change',exact=True).click();page.locator('#admin-action-dialog').wait_for(state='hidden')
 a=api('/api/account',cookie=membercookie)[1];check('admin email grant activates correct 30-day plan',a['plan']['label']=='ETERNAL Work' and a['provider_access']['openai'])
 for section in ['overview','transfers','payments','users','subscriptions','tickets','activity','source']:
  page.locator('[data-section="'+section+'"]').click();check('admin '+section+' tab opens',page.locator('[data-section="'+section+'"]').get_attribute('aria-pressed')=='true')
 page.locator('#admin-eternal summary').click();page.get_by_role('button',name='Open ETERNAL workspace',exact=True).click();page.get_by_label('Admin task',exact=True).wait_for(timeout=30000)
 page.get_by_label('Administrator mode',exact=True).select_option('beast');page.get_by_label('Response level',exact=True).select_option('instant');page.get_by_label('Selected source context',exact=True).select_option('tools/python_scrambler/examples/input.py')
 prompt='Append only this exact comment at the end of tools/python_scrambler/examples/input.py: # Settings acceptance. Preserve every existing line. Use operation append.'
 page.get_by_label('Admin task',exact=True).fill(prompt);page.get_by_role('button',name='Send to ETERNAL',exact=True).click()
 deadline=time.monotonic()+900;job=None
 while time.monotonic()<deadline:
  w=api('/api/admin/source/workspace',cookie=cookie)[1];job=next((j for j in w.get('jobs',[]) if j['request']['prompt']==prompt),None)
  if job and (job['state'] in ['completed','failed','cancelled'] or job['state']=='awaiting_review' and job.get('result',{}).get('checks',{}).get('failed')):break
  time.sleep(2)
 check('real ETERNAL Beast completes and saves automatically',job and job['state']=='completed' and w['revision']==2)
 check('local ETERNAL actual model recorded',job['result']['selection']['model']=='eternal:v1.0')
 page.get_by_text('Saved to private source revision 2.',exact=False).wait_for(timeout=15000);check('chat shows completed edit and real progress',page.locator('.admin-progress li').count()>0)
 check('immutable deployed source preserved', 'Settings acceptance' not in api('/api/admin/source/file/'+next(f['id'] for f in api('/api/admin/source',cookie=cookie)[1]['files'] if f['path']=='tools/python_scrambler/examples/input.py'),cookie=cookie)[1]['text'])
 page.locator('#close-settings').click();page.locator('#new-chat').click();page.locator('#toggle-preview').click() if page.locator('#preview').is_visible() else None
 page.screenshot(path='/tmp/synergy230-desktop.png')
 page.set_viewport_size({'width':390,'height':844});check('mobile page has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
 page.screenshot(path='/tmp/synergy230-mobile.png');check('no JavaScript page errors',not errors);browser.close()
Path('/tmp/settings-acceptance.json').write_text(json.dumps({'checks':len(checks),'passed':checks},indent=2));print(json.dumps({'checks':len(checks)}),flush=True)
