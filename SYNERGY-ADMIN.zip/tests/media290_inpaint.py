"""Focused real inpainting test on the previously generated office fixture; safety stays on."""
import json,os,sqlite3,sys,time,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/backend'))
from PIL import Image,ImageChops,ImageOps
from membership import Membership
from media.store import Media,digest
from media.worker import Worker
from mcp_transport import StdioClient,initialize,unpack
root=Path(os.environ['SYNERGY_MEDIA_TEST_ROOT']);assert (root/'.staging-only').exists()
data=root/'case';media=Media(data,Membership(data/'accounts.sqlite3').require)
with media.connect() as c:
 row=c.execute("SELECT * FROM media_jobs WHERE state='succeeded' AND recipe LIKE '%generate%' ORDER BY created DESC LIMIT 1").fetchone()
 previous=json.loads(row['result']);cid=row['conversation_id']
 mask=c.execute("SELECT id FROM large_uploads WHERE conversation_id=? AND name='mask.png' AND user_id=1",(cid,)).fetchone()[0]
recipe={'kind':'ai','operation':'inpaint','prompt':'An empty modern office, a green potted plant on a wooden desk, architectural interior photograph, no people','width':256,'height':256,'steps':20,'seed':73,'strength':.55,'mask_upload_id':mask}
client=StdioClient([sys.executable,str(Path(__file__).resolve().parents[1]/'app/backend/media/mcp.py'),'--data',str(data),'--user','1'],{'PATH':os.environ['PATH']},str(data))
try:
 initialize(client);job=unpack(client.request('tools/call',{'name':'media_submit','arguments':{'conversation_id':cid,'source_id':previous['asset_id'],'recipe':recipe,'request_id':uuid.uuid4().hex}}))
finally:client.close()
worker=Worker(media,os.environ.get('SYNERGY_IMAGE_PYTHON','/opt/media/bin/python'));done=worker.execute(worker.claim());result={'job_state':done['state'],'error':done['error'],'elapsed':done['elapsed'],'recipe':recipe,'safety_checker_enabled':True}
if done['state']=='succeeded':
 outpath=media.asset_path(1,done['result']['asset_id']);out=root/'inpaint-verified.png';out.write_bytes(outpath.read_bytes());reference=ImageOps.fit(Image.open(media.asset_path(1,previous['asset_id'])).convert('RGB'),(256,256),method=Image.Resampling.LANCZOS);im=Image.open(out).convert('RGB');maskim=Image.open(data/'uploads'/mask/'original').convert('L');diff=ImageChops.difference(im,reference)
 result.update(protected_pixels_exact=Image.composite(diff,Image.new('RGB',im.size),ImageChops.invert(maskim)).getbbox() is None,selected_pixels_changed=Image.composite(diff,Image.new('RGB',im.size),maskim).getbbox() is not None,sha256=digest(out),metadata=done['result']['metadata'],output=str(out))
(root/'inpaint-evidence.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
assert result['job_state']=='succeeded',result
assert result['protected_pixels_exact'] and result['selected_pixels_changed'],result
