"""Real local model → private candidate → review → retrieval, disposable account only."""
import json,secrets,sqlite3,time,urllib.request,http.cookiejar,os
from pathlib import Path
root=Path(os.environ['SYNERGY_DATA_DIR']);assert (root/'.staging-only').is_file();out=root/'observation-live.json';checks=[]
jar=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def api(path,data=None):
 with opener.open(urllib.request.Request('http://127.0.0.1:8090'+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'}),timeout=30) as r:return json.load(r)
def check(name,ok,**data):
 checks.append({'check':name,'passed':bool(ok),**data});out.write_text(json.dumps({'checks':checks},indent=2));print(checks[-1],flush=True);assert ok,name
u=api('/api/auth/register',{'email':'observation-'+secrets.token_hex(5)+'@qa.invalid','password':secrets.token_urlsafe(24)})
api('/api/research/settings',{'observation_learning':True,'response_cache':False,'allow_external':False,'observation_external':False,'web_search':False})
def ask():
 t=api('/api/research/tasks',{'prompt':'Explain project briefs clearly in two short sentences.','provider':'synergy','local_model':'fast','model_family':'eternal','mode':'chat','effort':'instant','search_mode':'off','request_id':secrets.token_hex(16)})
 end=time.monotonic()+180
 while time.monotonic()<end:
  t=api('/api/research/tasks/'+t['id'])
  if t['state'] not in {'queued','running'}:return t
  time.sleep(.5)
 raise AssertionError('Local response did not complete within 180 seconds')
a=ask();check('actual ETERNAL local answer',a['state']=='succeeded' and len(a['reply'])>30,selection=a['detail'].get('selection'),elapsed=a.get('elapsed'));rows=api('/api/research/observations')['examples'];check('actual answer captured pending review',len(rows)==1 and rows[0]['state']=='pending',capture=a['detail'].get('observation_capture'));api('/api/research/observations/review',{'id':rows[0]['id'],'decision':'approve'});b=ask();check('approved example reused in actual local request',b['state']=='succeeded' and b['detail'].get('observation_reused')==1,elapsed=b.get('elapsed'));api('/api/research/observations/clear',{});check('private queue deletion',not api('/api/research/observations')['examples']);api('/api/auth/logout',{})
