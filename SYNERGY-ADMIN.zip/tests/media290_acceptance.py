"""Real Pillow/OpenCV/FFmpeg/Diffusers/MCP tests on disposable data, never production data."""
import base64,hashlib,io,json,os,sqlite3,subprocess,sys,tempfile,time,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/backend'))
from PIL import Image,ImageDraw,ImageChops,ImageStat
from workspace import Workspace
from membership import Membership
from uploads import Uploads,CHUNK
from media.store import Media,digest
from media.worker import Worker
from media.processor import probe
from mcp_transport import StdioClient,initialize,unpack

ROOT=Path(os.environ['SYNERGY_MEDIA_TEST_ROOT']);assert (ROOT/'.staging-only').exists(),'Only disposable staging data is authorised.'
ROOT.mkdir(exist_ok=True);checks=[];outputs=[]
def check(name,ok,**details):
 checks.append({'check':name,'passed':bool(ok),**details});(ROOT/'evidence.json').write_text(json.dumps({'checks':checks,'outputs':outputs},indent=2));print(json.dumps(checks[-1]),flush=True);assert ok,name
data=ROOT/'case';data.mkdir(exist_ok=True)
with sqlite3.connect(data/'accounts.sqlite3') as conn:
 conn.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,salt BLOB,password BLOB)');conn.execute("INSERT OR IGNORE INTO users(id,username,salt,password) VALUES(1,'media-fixture',x'00',x'00')")
ws=Workspace(data/'accounts.sqlite3');member=Membership(data/'accounts.sqlite3');media=Media(data,member.require);up=Uploads(ws,None,data/'uploads');cid=ws.create_chat(1)['id'];worker=Worker(media,os.environ.get('SYNERGY_IMAGE_PYTHON','/opt/media/bin/python'))
def upload(path):
 b=path.read_bytes();r=up.create(1,{'conversation_id':cid,'name':path.name,'size':len(b),'batch_id':uuid.uuid4().hex})
 for offset in range(0,len(b),CHUNK):up.chunk(1,{'id':r['id'],'index':offset//CHUNK,'data':base64.b64encode(b[offset:offset+CHUNK]).decode()})
 return up.finish(1,r['id'])['id']
def run(name,recipe,ids=None,source=None):
 args={'conversation_id':cid,'recipe':recipe,'upload_ids':ids or [],'request_id':uuid.uuid4().hex,'title':name}
 if source:args['source_id']=source
 client=StdioClient([sys.executable,str(Path(__file__).resolve().parents[1]/'app/backend/media/mcp.py'),'--data',str(data),'--user','1','--mode','chat'],{'PATH':os.environ['PATH']},str(data))
 try:
  info=initialize(client);catalog=client.request('tools/list');check(name+' MCP handshake',info['name']=='SYNERGY MEDIA' and len(catalog['tools'])==5)
  j=unpack(client.request('tools/call',{'name':'media_submit','arguments':args}))
 finally:client.close()
 result=worker.execute(worker.claim());check(name+' real processing',result['state']=='succeeded',state=result['state'],error=result['error'],elapsed=result['elapsed'])
 r=result['result'];p=media.asset_path(1,r['asset_id']);copy=ROOT/(name+'-'+r['file']);copy.write_bytes(p.read_bytes());outputs.append({'name':name,'path':str(copy),'sha256':digest(copy),'size':copy.stat().st_size,'metadata':r['metadata']});check(name+' digest and saved version',digest(copy)==r['sha256'] and media.asset(1,r['asset_id'])['version']==r['version']);return r,copy

def cmd(args):subprocess.run(args,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=90)
fixture=ROOT/'reference.png';im=Image.new('RGB',(512,384),'#bfd0b4');draw=ImageDraw.Draw(im);draw.rectangle((40,160,470,340),fill='#d8b88a');draw.rectangle((200,40,400,140),fill='#eeeeee');draw.text((30,20),'InteriFY test reference',fill='black');im.save(fixture)
logo=ROOT/'logo.png';Image.new('RGB',(80,40),'#7d3826').save(logo);mask=ROOT/'mask.png';ma=Image.new('L',(256,256));ImageDraw.Draw(ma).rectangle((85,70,170,185),fill=255);ma.save(mask)
video=ROOT/'fixture.mp4';cmd(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=640x360:rate=24:duration=6','-f','lavfi','-i','sine=frequency=330:sample_rate=48000:duration=6','-c:v','libx264','-crf','0','-preset','ultrafast','-threads','2','-c:a','aac','-shortest',str(video)])
sound=ROOT/'sound.wav';cmd(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=frequency=660:sample_rate=48000:duration=6',str(sound)])
photo_id,logo_id,video_id,sound_id,mask_id=map(upload,[fixture,logo,video,sound,mask])
r,p=run('image-overlays',{'kind':'image','operations':[{'op':'resize','width':640,'height':480,'fit':'stretch'},{'op':'text','text':'InteriFY Office','x':24,'y':24,'size':26,'colour':'#212121'},{'op':'logo','upload_id':logo_id,'x':500,'y':390,'width':100}]},[photo_id]);check('exact supplied logo pixels',Image.open(p).getpixel((520,400))[:3]==(125,56,38));check('original upload unchanged',digest(up.path(1,photo_id))==digest(fixture))
r2,p2=run('trim',{'kind':'video','operations':[{'op':'trim','start':1,'end':4}]},[video_id]);check('trim duration and audio',abs(probe(p2)['duration']-3)<.15 and bool(probe(p2)['audio']))
r3,p3=run('captions',{'kind':'video','operations':[{'op':'captions','cues':[{'start':0,'end':2.5,'text':'InteriFY — Your next chapter'}]}]},source=r2['asset_id'])
for src,name in [(p2,'before'),(p3,'after')]:cmd(['ffmpeg','-v','error','-y','-ss','1','-i',str(src),'-frames:v','1',str(ROOT/(name+'.png'))])
a=Image.open(ROOT/'before.png').convert('RGB');b=Image.open(ROOT/'after.png').convert('RGB');check('captions rendered in bottom frame area',sum(ImageStat.Stat(ImageChops.difference(a,b).crop((0,250,640,360))).mean)>2)
r4,p4=run('audio-mix',{'kind':'video','operations':[{'op':'audio','upload_id':sound_id,'volume':.4,'original_volume':.7}]},source=r2['asset_id']);check('audio mixing retained video duration',abs(probe(p4)['duration']-3)<.15 and bool(probe(p4)['audio']))
for src,name in [(p2,'before-audio'),(p4,'after-audio')]:cmd(['ffmpeg','-v','error','-y','-i',str(src),'-vn','-c:a','pcm_s16le',str(ROOT/(name+'.wav'))])
check('audio samples changed after mixing',digest(ROOT/'before-audio.wav')!=digest(ROOT/'after-audio.wav'))
r5,p5=run('compression',{'kind':'video','operations':[{'op':'compress','width':320,'crf':32,'fps':24}]},[video_id]);check('compression reduced actual bytes',p5.stat().st_size<video.stat().st_size,original_bytes=video.stat().st_size,output_bytes=p5.stat().st_size)
r6,p6=run('join',{'kind':'video','operations':[{'op':'trim','start':0,'end':2},{'op':'join','upload_ids':[video_id]}]},[video_id]);check('joined clip duration',abs(probe(p6)['duration']-8)<.2)
run('analysis',{'kind':'analyze'},[video_id])
# Actual cancellation during the processing subprocess, not a simulated UI state.
j=media.submit(1,{'conversation_id':cid,'upload_ids':[video_id],'recipe':{'kind':'video','operations':[{'op':'compress','crf':18}]}});claim=worker.claim()
import threading
thread=threading.Thread(target=worker.execute,args=(claim,));thread.start();deadline=time.monotonic()+10
while worker.process is None and time.monotonic()<deadline:time.sleep(.02)
media.cancel(1,j['id']);thread.join(10);check('running subprocess cancellation',not thread.is_alive() and media.job(1,j['id'])['state']=='cancelled' and not media.job(1,j['id'])['result'])
# A restart requeues the pinned job once, then a real process completes it.
j=media.submit(1,{'conversation_id':cid,'upload_ids':[photo_id],'recipe':{'kind':'image','operations':[{'op':'convert'}]}});worker.claim();worker.recover();done=worker.execute(worker.claim());check('worker restart recovery real output',done['state']=='succeeded' and done['attempt']==2)
if os.environ.get('SYNERGY_MEDIA_TEST_AI')=='1':
 generated=None
 for name,op in [('diffusers-generate','generate'),('diffusers-img2img','img2img'),('diffusers-inpaint','inpaint')]:
  recipe={'kind':'ai','operation':op,'prompt':'A bright contemporary office, oak desks, potted plant, soft daylight','width':256,'height':256,'steps':8,'seed':42}
  if op=='inpaint':recipe.update(mask_upload_id=mask_id,steps=20,seed=73,strength=.55,prompt='An empty modern office, a green potted plant on a wooden desk, architectural interior photograph, no people')
  r,p=run(name,recipe,[] if op in {'generate','inpaint'} else [photo_id],source=generated['asset_id'] if op=='inpaint' else None);
  if op=='generate':generated=r
  check(name+' native output',Image.open(p).size==(256,256) and r['metadata']['device']=='cpu' and bool(r['metadata']['engine']))
  if op=='inpaint':
   from PIL import ImageOps
   reference=ImageOps.fit(Image.open(media.asset_path(1,generated['asset_id'])).convert('RGB'),(256,256),method=Image.Resampling.LANCZOS);out=Image.open(p).convert('RGB');protected=ImageChops.invert(ma);diff=ImageChops.difference(out,reference);check('inpainting protected pixels exactly retained',Image.composite(diff,Image.new('RGB',(256,256)),protected).getbbox() is None);check('inpainting changed selected region',Image.composite(diff,Image.new('RGB',(256,256)),ma).getbbox() is not None)
check('reopen project versions',len(Media(data).versions(1,r2['project_id']))>=4)
print(json.dumps({'complete':True,'checks':len(checks),'outputs':len(outputs)}),flush=True)
