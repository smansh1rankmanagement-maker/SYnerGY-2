# SYnerGY 2.5 — Eternal Lab

Open Settings → Administration → Eternal Lab after signing in with the existing administrator account. See `docs/releases/2.5.0-eternal-lab.md` for verified capabilities, setup, limitations and tests. This release adds 34 versioned packages and a capability builder; it does not contain newly trained model weights.

# SYnerGY 2.2 · ETERNAL and Aerny 2.0

Workspace: https://synergyai.1rank.in · User manual: https://synergyai.1rank.in/guide · Administration: https://synergyai.1rank.in/admin

Read [the current release guide](docs/releases/2.2.0-source-scrambler.md) for the admin source folder and Python scrambler, and [the account guide](docs/ETERNAL-2.0-RELEASE.md) for payment flow and recovery. Historical versioned reports remain as evidence for their own releases. No foundation-model training was performed.

## Existing installation

Preserve `/srv/synergy/.env`, the Compose project name `synergy`, existing Docker volumes, passwords and sessions. Never run `docker compose down -v`. Stage and test the image before changing the live app. Stop writers briefly, take private source/config/data backups and use `deploy/auth_guard.py` to verify that existing authentication records survive. Current application target: `synergy-ai:2.2.0`.

Imported ChatGPT projects are hidden until an administrator approves the intended registered email in Admin → Project transfers. This is separate from a paid Work/Beast plan. Existing account credentials do not need resetting.

## Fresh Linux installation

This is a Python/Docker application, not a static/PHP hosting upload. Use Linux x86_64 with Docker Compose, Python 3, model storage and adequate RAM. The current server uses 32 GB RAM and CPU inference. Weights, credentials and private account data are not included.

Point DNS to your server; expose only HTTPS/HTTP through Caddy. Keep app, voice and Ollama private. Review model licences in `docs/MODELS.md`, then:

```bash
python3 deploy/configure.py --domain ai.yourdomain.com --email you@yourdomain.com --admin owner
python3 deploy/build_source_vault.py --source . --checksums SHA256SUMS --output source-vault --version 2.2.0
python3 deploy/preflight.py
python3 deploy/manage.py install --models --accept-model-licenses
```

Registration uses email and password, without an invite code. Provision a dedicated administrator with `deploy/provision_admin.py`; provide its password through stdin, never a source file or command argument. Use `--owner` only for an existing account you explicitly intend to promote. Existing administrators' passwords are never replaced.

```bash
python3 -c 'import getpass; print(getpass.getpass("New administrator password: "))' | docker compose exec -T app /opt/web/bin/python /opt/synergy/deploy/provision_admin.py --username admin@example.com
```

The application preserves subscriptions through password recovery. No email delivery or email-ownership verification service is configured; keep recovery keys private. Payment references activate provisional access and require later bank reconciliation. Admin manual grants do not count as income.

## Tests and recovery

Run application tests from `app/`, deployment tests from the repository root, and the three extension security tests. Private staging acceptance scripts refuse to run without `.staging-only`; never place that marker in production. See the release guide for backup and rollback steps. Source archives contain no private database or payment history.

The root `SOURCE-CHANGES.patch` and `CLOUD-CHANGES.patch` are historical 1.x change records. Current source is in `app/`, `deploy/`, `tools/`, `tests/` and the release guides; the packaged Git bundle records the new release. `SHA256SUMS` covers current source files. The admin source archive is generated from this allowlist before the Docker build; it is never assembled from runtime folders.

## VEDICS and FOUNDR

The 2.1 release includes bundled account-scoped MCP tools and 34 expanded expertise workflows. See `docs/releases/2.1.0-specialists.md` for usage, real tool status, tests and remaining connections. No model retraining or new hosted AI service is required.

## Administrator source and Python scrambler

Sign in as the administrator, open **Admin panel → Source code · synergy**, then browse or download the reviewed source folder. The Python tool makes a separate copy, validates syntax and lists unsupported functions. It never overwrites deployed code. The standalone CLI and tests are in `tools/python_scrambler/`. This is readability obfuscation, not an uncrackable security layer; keep secrets outside all distributed source.
