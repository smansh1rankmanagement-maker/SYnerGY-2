# SYNERGY 2.0 — deployment 3.0.5
- Native Ctrl+V / Command+V in the existing composer. No new copy/paste buttons.
- Clipboard files become pending attachments; no automatic upload or send.
- New sent messages retain authorised original-file cards and bounded private image thumbnails.
- Hybrid tries eligible Gemini, then configured OpenAI, then other free connected providers before the local fallback. Privacy, paid Gemini eligibility and shared provider budgets remain enforced.
- Extension 1.6.2 contains the owner-supplied logo unchanged. Extension permissions and fixed ID remain unchanged.
- ZIP-installed extensions require update/reload. No Chrome Web Store publication is claimed.
- Existing accounts, sessions, projects, subscriptions, payment records and external budget ledger are preserved during deployment.
- PDF/text extraction is bounded. Video context contains sampled frames; it does not imply audio transcription or complete scene coverage.
